-- ============================================================
-- Trivia Helper — RLS + RPCs (ejecutar en Supabase SQL Editor)
-- NO abre las tablas al anon. Solo funciones security definer.
-- ============================================================

-- 1) Quitar políticas abiertas anteriores (si existen)
drop policy if exists "anon all users" on public.users;
drop policy if exists "anon all banned_devices" on public.banned_devices;
drop policy if exists "anon all banned_users" on public.banned_users;
drop policy if exists "Allow all for anon" on public.users;
drop policy if exists "Allow all for anon" on public.banned_devices;
drop policy if exists "Allow all for anon" on public.banned_users;

-- 2) RLS ON — sin políticas = nadie lee/escribe tablas directo con anon key
alter table public.users enable row level security;
alter table public.banned_devices enable row level security;
alter table public.banned_users enable row level security;

-- Bloqueo explícito de acceso directo (anon / authenticated)
-- Las operaciones reales van por funciones SECURITY DEFINER.
revoke all on public.users from anon, authenticated;
revoke all on public.banned_devices from anon, authenticated;
revoke all on public.banned_users from anon, authenticated;

-- ============================================================
-- Helpers internos
-- ============================================================
create or replace function public._is_admin(p_admin_id text)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.users
    where user_id = p_admin_id and upper(coalesce(role, 'USER')) = 'ADMIN'
  );
$$;

-- ============================================================
-- App cliente: comprobar baneo (no expone filas)
-- ============================================================
create or replace function public.is_banned(p_user_id text, p_device_id text)
returns json
language plpgsql
security definer
set search_path = public
as $$
declare
  r record;
begin
  if p_device_id is not null and length(trim(p_device_id)) > 0 then
    select reason into r from public.banned_devices where device_id = p_device_id limit 1;
    if found then
      return json_build_object('banned', true, 'kind', 'DEVICE', 'reason', r.reason);
    end if;
  end if;

  if p_user_id is not null and length(trim(p_user_id)) > 0 then
    select reason into r from public.banned_users where user_id = p_user_id limit 1;
    if found then
      return json_build_object('banned', true, 'kind', 'USER', 'reason', r.reason);
    end if;
  end if;

  return json_build_object('banned', false, 'kind', null, 'reason', null);
end;
$$;

-- ============================================================
-- App cliente: upsert SOLO su propio user_id (no cambia role si ya existe)
-- ============================================================
create or replace function public.upsert_my_user(
  p_user_id text,
  p_email text,
  p_nombre text,
  p_device_id text
)
returns json
language plpgsql
security definer
set search_path = public
as $$
begin
  if p_user_id is null or length(trim(p_user_id)) = 0 then
    raise exception 'user_id required';
  end if;

  insert into public.users (user_id, email, nombre, device_id, role)
  values (p_user_id, p_email, p_nombre, p_device_id, 'USER')
  on conflict (user_id) do update set
    email = excluded.email,
    nombre = excluded.nombre,
    device_id = excluded.device_id;
    -- role NO se sobrescribe: conserva ADMIN

  return (
    select json_build_object(
      'user_id', u.user_id,
      'email', u.email,
      'nombre', u.nombre,
      'device_id', u.device_id,
      'role', u.role
    )
    from public.users u where u.user_id = p_user_id
  );
end;
$$;

create or replace function public.get_my_role(p_user_id text)
returns text
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(
    (select role from public.users where user_id = p_user_id limit 1),
    'USER'
  );
$$;

-- ============================================================
-- Admin only (verifica role = ADMIN del p_admin_id)
-- ============================================================
create or replace function public.admin_list_users(p_admin_id text)
returns setof public.users
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public._is_admin(p_admin_id) then
    raise exception 'forbidden';
  end if;
  return query select * from public.users order by nombre nulls last, email nulls last;
end;
$$;

create or replace function public.admin_set_role(
  p_admin_id text,
  p_target_user_id text,
  p_role text
)
returns json
language plpgsql
security definer
set search_path = public
as $$
declare
  new_role text;
begin
  if not public._is_admin(p_admin_id) then
    raise exception 'forbidden';
  end if;
  new_role := upper(coalesce(p_role, 'USER'));
  if new_role not in ('USER', 'ADMIN') then
    raise exception 'invalid role';
  end if;
  update public.users set role = new_role where user_id = p_target_user_id;
  if not found then
    raise exception 'user not found';
  end if;
  return json_build_object('user_id', p_target_user_id, 'role', new_role);
end;
$$;

create or replace function public.admin_ban(
  p_admin_id text,
  p_user_id text,
  p_device_id text,
  p_reason text default null
)
returns json
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public._is_admin(p_admin_id) then
    raise exception 'forbidden';
  end if;

  if p_user_id is not null and length(trim(p_user_id)) > 0 then
    insert into public.banned_users (user_id, reason, banned_at)
    values (p_user_id, p_reason, now())
    on conflict (user_id) do update set reason = excluded.reason, banned_at = now();
  end if;

  if p_device_id is not null and length(trim(p_device_id)) > 0 then
    insert into public.banned_devices (device_id, reason, banned_at)
    values (p_device_id, p_reason, now())
    on conflict (device_id) do update set reason = excluded.reason, banned_at = now();
  end if;

  return json_build_object('ok', true);
end;
$$;

create or replace function public.admin_unban(
  p_admin_id text,
  p_user_id text,
  p_device_id text
)
returns json
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public._is_admin(p_admin_id) then
    raise exception 'forbidden';
  end if;

  if p_user_id is not null and length(trim(p_user_id)) > 0 then
    delete from public.banned_users where user_id = p_user_id;
  end if;
  if p_device_id is not null and length(trim(p_device_id)) > 0 then
    delete from public.banned_devices where device_id = p_device_id;
  end if;

  return json_build_object('ok', true);
end;
$$;

create or replace function public.admin_list_bans(p_admin_id text)
returns json
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public._is_admin(p_admin_id) then
    raise exception 'forbidden';
  end if;
  return json_build_object(
    'devices', coalesce((select json_agg(d) from (select * from public.banned_devices order by banned_at desc) d), '[]'::json),
    'users', coalesce((select json_agg(u) from (select * from public.banned_users order by banned_at desc) u), '[]'::json)
  );
end;
$$;

-- Permisos: solo EXECUTE de RPCs al anon (no tablas)
grant execute on function public.is_banned(text, text) to anon, authenticated;
grant execute on function public.upsert_my_user(text, text, text, text) to anon, authenticated;
grant execute on function public.get_my_role(text) to anon, authenticated;
grant execute on function public.admin_list_users(text) to anon, authenticated;
grant execute on function public.admin_set_role(text, text, text) to anon, authenticated;
grant execute on function public.admin_ban(text, text, text, text) to anon, authenticated;
grant execute on function public.admin_unban(text, text, text) to anon, authenticated;
grant execute on function public.admin_list_bans(text) to anon, authenticated;

-- Tu admin de prueba (después de que exista la fila en users):
-- update public.users set role = 'ADMIN' where user_id = 'admin_randy';
