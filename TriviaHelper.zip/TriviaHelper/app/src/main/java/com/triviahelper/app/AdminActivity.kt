package com.triviahelper.app

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding

class AdminActivity : AppCompatActivity() {

    private lateinit var prefs: PrefsHelper
    private lateinit var userList: LinearLayout
    private lateinit var tvStatus: TextView
    private lateinit var tvOnlineCount: TextView
    private var bannedUsers = emptySet<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = PrefsHelper(this)
        if (!prefs.getUserRole().equals("ADMIN", true)) {
            Toast.makeText(this, "Solo ADMIN", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        setContentView(R.layout.activity_admin)
        // Animación tipo pasar página (entra desde la derecha)
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)

        userList = findViewById(R.id.userList)
        tvStatus = findViewById(R.id.tvStatus)
        tvOnlineCount = findViewById(R.id.tvOnlineCount)
        findViewById<Button>(R.id.btnClose).setOnClickListener { finish() }
        findViewById<Button>(R.id.btnRefresh).setOnClickListener { load() }

        SessionRealtimeWatcher.attach(this)
        load()
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
    }

    override fun onResume() {
        super.onResume()
        if (!prefs.getUserRole().equals("ADMIN", true)) {
            finish()
            return
        }
        SessionRealtimeWatcher.attach(this)
        load()
    }

    private fun load() {
        tvStatus.text = "Cargando…"
        val adminId = prefs.getUserUid()
        Thread {
            try {
                val users = SupabaseBanClient.adminListUsers(adminId)
                val bans = SupabaseBanClient.adminListBans(adminId)
                bannedUsers = bans.first
                val online = users.count { it.isOnline() }
                runOnUiThread {
                    tvOnlineCount.text = "Online: $online"
                    render(users)
                    tvStatus.text = "${users.size} usuarios"
                }
            } catch (e: Exception) {
                runOnUiThread {
                    tvStatus.text = "Error: ${e.message}"
                    Toast.makeText(this, e.message, Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun render(users: List<SupabaseBanClient.UserRow>) {
        userList.removeAllViews()
        if (users.isEmpty()) {
            val empty = TextView(this).apply {
                text = "Sin usuarios"
                setTextColor(Color.parseColor("#9A9AB0"))
            }
            userList.addView(empty)
            return
        }
        val adminId = prefs.getUserUid()
        for (u in users) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(24)
                setBackgroundColor(Color.parseColor("#1B1B28"))
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.bottomMargin = 16
                layoutParams = lp
            }
            val banned = bannedUsers.contains(u.userId)
            val online = u.isOnline()
            val title = TextView(this).apply {
                text = buildString {
                    append(u.nombre.ifBlank { u.email.ifBlank { u.userId } })
                    append("  ·  ${u.role.uppercase()}")
                    if (banned) append("  ·  BANEADO")
                    if (online) append("  ·  ● ONLINE") else append("  ·  offline")
                }
                setTextColor(if (online) Color.parseColor("#69F0AE") else Color.parseColor("#F5F5F7"))
                textSize = 14f
            }
            val meta = TextView(this).apply {
                text = "id: ${u.userId}\ndevice: ${u.deviceId.ifBlank { "—" }}\n${u.email}"
                setTextColor(Color.parseColor("#9A9AB0"))
                textSize = 11f
            }
            val actions = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.START
            }

            val btnBan = Button(this).apply {
                text = if (banned) "Unban" else "Ban"
                setOnClickListener {
                    isEnabled = false
                    Thread {
                        try {
                            if (banned) {
                                SupabaseBanClient.adminUnban(adminId, u.userId, u.deviceId)
                            } else {
                                SupabaseBanClient.adminBan(adminId, u.userId, u.deviceId, "banned from app")
                            }
                            runOnUiThread { load() }
                        } catch (e: Exception) {
                            runOnUiThread {
                                isEnabled = true
                                Toast.makeText(this@AdminActivity, e.message, Toast.LENGTH_LONG).show()
                            }
                        }
                    }.start()
                }
            }
            val btnRole = Button(this).apply {
                val next = if (u.role.equals("ADMIN", true)) "USER" else "ADMIN"
                text = if (next == "ADMIN") "Hacer ADMIN" else "Quitar ADMIN"
                setOnClickListener {
                    isEnabled = false
                    Thread {
                        try {
                            SupabaseBanClient.adminSetRole(adminId, u.userId, next)
                            runOnUiThread { load() }
                        } catch (e: Exception) {
                            runOnUiThread {
                                isEnabled = true
                                Toast.makeText(this@AdminActivity, e.message, Toast.LENGTH_LONG).show()
                            }
                        }
                    }.start()
                }
            }
            actions.addView(btnBan)
            actions.addView(btnRole)
            card.addView(title)
            card.addView(meta)
            card.addView(actions)
            userList.addView(card)
        }
    }
}
