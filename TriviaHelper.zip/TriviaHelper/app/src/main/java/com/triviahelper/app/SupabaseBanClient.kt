package com.triviahelper.app

import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

/**
 * Cliente Supabase vía RPC (tablas NO accesibles con anon key).
 * Llamar desde hilo de fondo.
 */
object SupabaseBanClient {

    data class BanResult(
        val banned: Boolean,
        val kind: String? = null,
        val reason: String? = null
    )

    fun checkIfBanned(deviceId: String, userId: String?): BanResult {
        return try {
            val body = JSONObject()
                .put("p_user_id", userId ?: "")
                .put("p_device_id", deviceId)
            val json = rpc("is_banned", body)
            BanResult(
                banned = json.optBoolean("banned", false),
                kind = if (json.isNull("kind")) null else json.optString("kind", null),
                reason = if (json.isNull("reason")) null else json.optString("reason", null)
            )
        } catch (_: Exception) {
            BanResult(false)
        }
    }

    fun upsertUser(userId: String, email: String, nombre: String, deviceId: String): String {
        val body = JSONObject()
            .put("p_user_id", userId)
            .put("p_email", email)
            .put("p_nombre", nombre)
            .put("p_device_id", deviceId)
        val json = rpc("upsert_my_user", body)
        return json.optString("role", "USER").ifBlank { "USER" }
    }

    fun getUserRole(userId: String): String {
        if (userId.isBlank()) return "USER"
        return try {
            val body = JSONObject().put("p_user_id", userId)
            // get_my_role returns plain text from PostgREST sometimes quoted
            val raw = rpcRaw("get_my_role", body).trim().trim('"')
            raw.ifBlank { "USER" }
        } catch (_: Exception) {
            "USER"
        }
    }

    private fun rpc(fn: String, body: JSONObject): JSONObject {
        val text = rpcRaw(fn, body)
        if (text.isBlank()) return JSONObject()
        return try {
            JSONObject(text)
        } catch (_: Exception) {
            JSONObject()
        }
    }

    private fun rpcRaw(fn: String, body: JSONObject): String {
        val url = URL("${SupabaseConfig.URL.trimEnd('/')}/rest/v1/rpc/$fn")
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 20000
        conn.readTimeout = 20000
        conn.requestMethod = "POST"
        conn.doOutput = true
        conn.instanceFollowRedirects = true
        conn.setRequestProperty("apikey", SupabaseConfig.ANON_KEY)
        conn.setRequestProperty("Authorization", "Bearer ${SupabaseConfig.ANON_KEY}")
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("Accept", "application/json")
        OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.let { BufferedReader(InputStreamReader(it, Charsets.UTF_8)).use { r -> r.readText() } } ?: ""
        conn.disconnect()
        if (code !in 200..299) {
            throw IllegalStateException("Supabase RPC $fn HTTP $code: $text")
        }
        return text
    }
}
