package com.triviahelper.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Ban checks + optional user upsert against Supabase REST.
 * Call from a background thread.
 */
object SupabaseBanClient {

    data class BanResult(
        val banned: Boolean,
        val kind: String? = null, // DEVICE | USER
        val reason: String? = null
    )

    fun checkIfBanned(deviceId: String, userId: String?): BanResult {
        // Device ban first
        if (deviceId.isNotBlank()) {
            val rows = getRows(
                SupabaseConfig.TABLE_BANNED_DEVICES,
                "device_id=eq.${enc(deviceId)}&select=device_id,reason&limit=1"
            )
            if (rows.length() > 0) {
                val r = rows.getJSONObject(0)
                return BanResult(true, "DEVICE", r.optString("reason", null))
            }
        }
        // User ban
        if (!userId.isNullOrBlank()) {
            val rows = getRows(
                SupabaseConfig.TABLE_BANNED_USERS,
                "user_id=eq.${enc(userId)}&select=user_id,reason&limit=1"
            )
            if (rows.length() > 0) {
                val r = rows.getJSONObject(0)
                return BanResult(true, "USER", r.optString("reason", null))
            }
        }
        return BanResult(false)
    }

    /**
     * Upsert user row so panel can manage roles (default USER).
     */
    fun upsertUser(userId: String, email: String, nombre: String, deviceId: String) {
        val body = JSONObject()
            .put("user_id", userId)
            .put("email", email)
            .put("nombre", nombre)
            .put("device_id", deviceId)
            .put("role", "USER")
            .toString()
        // Prefer merge-duplicates on user_id
        request(
            "POST",
            "/rest/v1/${SupabaseConfig.TABLE_USERS}?on_conflict=user_id",
            body,
            extraHeaders = mapOf(
                "Prefer" to "resolution=merge-duplicates,return=minimal"
            )
        )
    }

    fun getUserRole(userId: String): String {
        if (userId.isBlank()) return "USER"
        val rows = getRows(
            SupabaseConfig.TABLE_USERS,
            "user_id=eq.${enc(userId)}&select=role&limit=1"
        )
        if (rows.length() == 0) return "USER"
        return rows.getJSONObject(0).optString("role", "USER").ifBlank { "USER" }
    }

    private fun getRows(table: String, query: String): JSONArray {
        val text = request("GET", "/rest/v1/$table?$query", null)
        if (text.isBlank()) return JSONArray()
        return try {
            JSONArray(text)
        } catch (_: Exception) {
            JSONArray()
        }
    }

    private fun request(
        method: String,
        pathAndQuery: String,
        body: String?,
        extraHeaders: Map<String, String> = emptyMap()
    ): String {
        val url = URL(SupabaseConfig.URL.trimEnd('/') + pathAndQuery)
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 20000
        conn.readTimeout = 20000
        conn.requestMethod = method
        conn.instanceFollowRedirects = true
        conn.setRequestProperty("apikey", SupabaseConfig.ANON_KEY)
        conn.setRequestProperty("Authorization", "Bearer ${SupabaseConfig.ANON_KEY}")
        conn.setRequestProperty("Accept", "application/json")
        extraHeaders.forEach { (k, v) -> conn.setRequestProperty(k, v) }
        if (body != null) {
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body) }
        }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.let { readAll(it) } ?: ""
        conn.disconnect()
        if (code !in 200..299) {
            // Non-fatal for upsert if table missing columns — caller ignores
            return text
        }
        return text
    }

    private fun enc(s: String): String =
        URLEncoder.encode(s, Charsets.UTF_8.name())

    private fun readAll(stream: java.io.InputStream): String =
        BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
}
