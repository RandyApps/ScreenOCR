package com.triviahelper.app

/**
 * Backend API (Google Apps Script).
 * Change only this constant when the deploy URL changes.
 */
object ApiConfig {
    const val API_URL =
        "https://script.google.com/macros/s/AKfycbwnvOedL6BerTuEXqRWDF_MbR9qu6LlcIWMPYWjXt-nlczp99t42fpR8jZ0aOGe_cg/exec"
}
