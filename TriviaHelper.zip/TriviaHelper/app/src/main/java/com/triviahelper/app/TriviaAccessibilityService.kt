package com.triviahelper.app

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Reads trivia question + options via Accessibility (WWE Champions web).
 * Options: prefer clickable nodes of similar size below the question (typically 4).
 */
class TriviaAccessibilityService : AccessibilityService() {

    data class TriviaRead(val question: String, val options: List<String>)

    private data class NodeText(
        val text: String,
        val clickable: Boolean,
        val buttonLike: Boolean,
        val bounds: Rect
    )

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* poll-based */ }

    override fun onInterrupt() {}

    fun readTrivia(): TriviaRead? {
        val root = rootInActiveWindow ?: return null
        val nodes = mutableListOf<NodeText>()
        collectNodes(root, nodes)
        try { root.recycle() } catch (_: Exception) {}

        if (nodes.isEmpty()) return null

        // --- Question: longest text with ? / ¿ ---
        val questionNode = nodes
            .filter { isLikelyQuestion(it.text) }
            .maxByOrNull { it.text.length }
            ?: return null
        val question = questionNode.text.trim()
        val qNorm = normalize(question)
        val qBottom = questionNode.bounds.bottom
        val qCenterY = questionNode.bounds.centerY()

        // --- Option candidates ---
        val candidates = nodes
            .asSequence()
            .filter { it.text.isNotBlank() }
            .filter { !isLikelyQuestion(it.text) }
            .filter { normalize(it.text) != qNorm }
            .filter { it.text.length in 2..48 }
            .filter { !it.text.contains('\n') }
            .filter { !isChrome(it.text) }
            // Prefer below the question
            .filter { it.bounds.top >= qBottom - 20 || it.bounds.centerY() > qCenterY }
            .distinctBy { normalize(it.text) }
            .toList()

        if (candidates.isEmpty()) return null

        // Score: clickable/button + size clustering
        val clickable = candidates.filter { it.clickable || it.buttonLike }
        val pool = if (clickable.size >= 2) clickable else candidates

        val options = selectBestOptions(pool)
        if (options.size < 2) return null

        return TriviaRead(question, options)
    }

    /**
     * Prefer a cluster of 3–4 nodes with similar width/height (the orange buttons).
     * Sorted top-to-bottom.
     */
    private fun selectBestOptions(pool: List<NodeText>): List<String> {
        if (pool.isEmpty()) return emptyList()

        // Group by similar size (width & height within ~25%)
        data class Group(val members: MutableList<NodeText>)

        val groups = mutableListOf<Group>()
        for (n in pool.sortedBy { it.bounds.top }) {
            val w = n.bounds.width().coerceAtLeast(1)
            val h = n.bounds.height().coerceAtLeast(1)
            var placed = false
            for (g in groups) {
                val ref = g.members.first()
                val rw = ref.bounds.width().coerceAtLeast(1)
                val rh = ref.bounds.height().coerceAtLeast(1)
                val sameW = kotlin.math.abs(w - rw).toFloat() / rw <= 0.30f
                val sameH = kotlin.math.abs(h - rh).toFloat() / rh <= 0.35f
                if (sameW && sameH) {
                    g.members.add(n)
                    placed = true
                    break
                }
            }
            if (!placed) groups.add(Group(mutableListOf(n)))
        }

        // Prefer group with size 4, then 3, then largest clickable group
        val ranked = groups.sortedWith(
            compareByDescending<Group> { g ->
                when (g.members.size) {
                    4 -> 100
                    3 -> 80
                    5 -> 70
                    2 -> 50
                    else -> g.members.size
                }
            }.thenByDescending { g -> g.members.count { it.clickable || it.buttonLike } }
                .thenByDescending { g -> g.members.size }
        )

        val best = ranked.firstOrNull()?.members ?: return emptyList()
        return best
            .sortedBy { it.bounds.top }
            .map { it.text.trim() }
            .filter { it.isNotEmpty() }
            .distinctBy { normalize(it) }
            .take(5)
    }

    private fun collectNodes(node: AccessibilityNodeInfo?, out: MutableList<NodeText>) {
        if (node == null) return
        try {
            val text = node.text?.toString()?.trim().orEmpty()
            val desc = node.contentDescription?.toString()?.trim().orEmpty()
            val bounds = Rect()
            try { node.getBoundsInScreen(bounds) } catch (_: Exception) {}

            val className = node.className?.toString().orEmpty().lowercase()
            val buttonLike = node.isClickable ||
                className.contains("button") ||
                className.contains("clickable") ||
                node.isCheckable

            if (text.isNotEmpty() && bounds.width() > 0 && bounds.height() > 0) {
                out.add(NodeText(text, node.isClickable, buttonLike, Rect(bounds)))
            } else if (desc.isNotEmpty() && bounds.width() > 0 && bounds.height() > 0) {
                out.add(NodeText(desc, node.isClickable, buttonLike, Rect(bounds)))
            }

            for (i in 0 until node.childCount) {
                val child = node.getChild(i)
                collectNodes(child, out)
                try { child?.recycle() } catch (_: Exception) {}
            }
        } catch (_: Exception) {
        }
    }

    private fun isLikelyQuestion(s: String): Boolean {
        val t = s.trim()
        if (t.length < 12) return false
        if (!(t.contains('?') || t.contains('¿'))) return false
        if (t == "?" || t == "¿?") return false
        return true
    }

    private fun isChrome(s: String): Boolean {
        val n = normalize(s)
        if (n in CHROME_WORDS) return true
        if (CHROME_WORDS.any { n.startsWith("$it ") || n.endsWith(" $it") }) return true
        // points / question counters
        if (n.matches(Regex("""question\s*\d+\s*/\s*\d+"""))) return true
        if (n.matches(Regex("""\d+\s*points?"""))) return true
        return false
    }

    private fun normalize(s: String): String {
        val sb = StringBuilder()
        var prev = false
        for (ch in s.lowercase()) {
            when {
                ch.isLetterOrDigit() -> {
                    sb.append(ch)
                    prev = false
                }
                ch.isWhitespace() -> {
                    if (!prev) {
                        sb.append(' ')
                        prev = true
                    }
                }
            }
        }
        return sb.toString().trim()
    }

    companion object {
        @Volatile var instance: TriviaAccessibilityService? = null

        fun isEnabled(): Boolean = instance != null

        fun readTriviaOrNull(): TriviaRead? = instance?.readTrivia()

        private val CHROME_WORDS = setOf(
            "all time", "month", "week", "points", "point", "question",
            "wwe champions", "official page", "respuesta", "answer",
            "searching", "buscando", "trivia helper", "donate", "donaciones",
            "tutorial", "language", "idioma", "search", "menu", "home",
            "shop", "cart", "profile", "settings", "close", "back"
        )
    }
}
