package com.triviahelper.app

import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

data class UserApiResponse(
    val status: String,
    val role: String?
)

object UserApiClient {

    /**
     * POST { uid, email, nombre, deviceId } → { status, role }
     * Call from a background thread.
     */
    fun registerOrCheck(
        uid: String,
        email: String,
        nombre: String,
        deviceId: String
    ): UserApiResponse {
        val body = JSONObject()
            .put("uid", uid)
            .put("email", email)
            .put("nombre", nombre)
            .put("deviceId", deviceId)
            .toString()

        return try {
            val text = postJson(ApiConfig.API_URL, body)
            parse(text)
        } catch (e: Exception) {
            UserApiResponse("ERROR", null)
        }
    }

    private fun postJson(urlStr: String, body: String): String {
        val url = URL(urlStr)
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 30000
        conn.readTimeout = 30000
        conn.requestMethod = "POST"
        conn.doOutput = true
        // HttpURLConnection turns POST+302 into GET on redirect (typical for Apps Script)
        conn.instanceFollowRedirects = true
        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        conn.setRequestProperty("Accept", "application/json, text/plain, */*")
        OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body) }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.let { readAll(it) } ?: ""
        conn.disconnect()
        if (code !in 200..299 && text.isBlank()) {
            throw IllegalStateException("HTTP $code")
        }
        return text
    }

    private fun parse(text: String): UserApiResponse {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return UserApiResponse("ERROR", null)
        val start = trimmed.indexOf('{')
        val end = trimmed.lastIndexOf('}')
        if (start < 0 || end <= start) return UserApiResponse("ERROR", null)
        val json = JSONObject(trimmed.substring(start, end + 1))
        val status = json.optString("status", "ERROR")
        val role = when {
            !json.has("role") || json.isNull("role") -> null
            else -> json.optString("role").ifBlank { null }
        }
        return UserApiResponse(status, role)
    }

    private fun readAll(stream: java.io.InputStream): String {
        return BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
    }
}
