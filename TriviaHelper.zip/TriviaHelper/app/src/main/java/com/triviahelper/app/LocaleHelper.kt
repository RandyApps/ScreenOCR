package com.triviahelper.app

import android.content.Context

object LocaleHelper {
    const val EN = "en"
    const val ES = "es"
    const val PT = "pt"
    const val ID = "id"

    fun getLang(ctx: Context): String =
        ctx.getSharedPreferences("trivia_helper_prefs", Context.MODE_PRIVATE)
            .getString("lang", EN) ?: EN

    fun setLang(ctx: Context, lang: String) {
        ctx.getSharedPreferences("trivia_helper_prefs", Context.MODE_PRIVATE)
            .edit().putString("lang", lang).apply()
    }

    fun t(ctx: Context, key: String): String {
        val lang = getLang(ctx)
        return (map[lang] ?: map[EN]!!)[key] ?: map[EN]!![key] ?: key
    }

    private val map = mapOf(
        EN to mapOf(
            "app_name" to "Trivia Helper",
            "api_card" to "API KEY",
            "api_ok" to "API Assigned!",
            "api_need" to "API Required!",
            "assign_api" to "Assign API",
            "areas_label" to "Designate detection areas",
            "questions" to "Questions",
            "options" to "Options",
            "float_label" to "Open the floating window to start",
            "show" to "Show",
            "hide" to "Hide",
            "language" to "Language",
            "save" to "Save",
            "back" to "Back",
            "api_title" to "Assign API",
            "api_hint" to "Paste your Google AI Studio key…",
            "api_saved_hint" to "Key saved. Paste a new one to replace it.",
            "api_toast_empty" to "Paste an API key",
            "api_toast_ok" to "API saved",
            "overlay_title" to "Overlay permission",
            "overlay_msg" to "Needed for the floating window and area selection.",
            "overlay_allow" to "Allow",
            "overlay_cancel" to "Cancel",
            "lang_en" to "English",
            "lang_es" to "Spanish",
            "lang_pt" to "Portuguese",
            "lang_id" to "Indonesian",
            "about_title" to "About Trivia Helper",
            "about_body" to "Trivia Helper is an application created to help WWE Champions players answer trivias quickly and easily and thus obtain Charlotte Flair - \"Icons of WrestleMania\". The creator of this application is not responsible for how this application may be used.",
            "help_api_title" to "How to get an API key",
            "help_api_body" to "1) Open Google AI Studio:\nhttps://aistudio.google.com/apikey\n\n2) Sign in with your Google account\n\n3) Tap Create API key\n\n4) Copy the key (starts with AIza…)\n\n5) In Trivia Helper tap Assign API, paste the key and Save\n\nThe free tier is usually enough for casual trivia use.\n\nTap the link above to open Google AI Studio.",
            "tutorial" to "Tutorial",
            "donations" to "Donations",
            "donation_message" to "Any voluntary donation is received with love",
            "tutorial_title" to "How to designate areas",
            "tutorial_body" to "QUESTIONS area:\nMarks where the trivia question text appears on the screen.\n\n1) Tap Questions\n2) Move and resize the blue box over the question only\n3) Tap Confirm\n\nOPTIONS area:\nMarks where the answer choices appear.\n\n1) Tap Options\n2) Move and resize the green box over all options\n3) Tap Confirm\n\nThen open the floating window and press Play to start.",
            "donation_tooltip" to "This application was created with no profit motive, but any voluntary donation is received with much love."
        ),
        ES to mapOf(
            "app_name" to "Trivia Helper",
            "api_card" to "CLAVE API",
            "api_ok" to "¡API Asignada!",
            "api_need" to "¡Se requiere una API!",
            "assign_api" to "Asignar API",
            "areas_label" to "Designar áreas de detección",
            "questions" to "Preguntas",
            "options" to "Opciones",
            "float_label" to "Abre la ventana flotante para iniciar",
            "show" to "Mostrar",
            "hide" to "Ocultar",
            "language" to "Idioma",
            "save" to "Guardar",
            "back" to "Volver",
            "api_title" to "Asignar API",
            "api_hint" to "Pega aquí tu clave de Google AI Studio…",
            "api_saved_hint" to "Clave guardada. Pega una nueva para reemplazarla.",
            "api_toast_empty" to "Pega una clave API",
            "api_toast_ok" to "API guardada",
            "overlay_title" to "Permiso de superposición",
            "overlay_msg" to "Necesario para la ventana flotante y designar áreas.",
            "overlay_allow" to "Permitir",
            "overlay_cancel" to "Cancelar",
            "lang_en" to "Inglés",
            "lang_es" to "Español",
            "lang_pt" to "Portugués",
            "lang_id" to "Indonesio",
            "about_title" to "Acerca de Trivia Helper",
            "about_body" to "Trivia Helper es una aplicación creada con el fin de ayudar a los jugadores de WWEChampions a responder las trivias rápido y fácil y así lograr obtener a Charlotte Flair - \"Icons of WrestleMania\". El creador de esta aplicación no se hace responsable por el uso que puedan darle a esta aplicación.",
            "help_api_title" to "Cómo obtener una clave API",
            "help_api_body" to "1) Abre Google AI Studio:\nhttps://aistudio.google.com/apikey\n\n2) Inicia sesión con tu cuenta de Google\n\n3) Pulsa Create API key / Crear clave\n\n4) Copia la clave (empieza por AIza…)\n\n5) En Trivia Helper toca Asignar API, pégala y Guarda\n\nEl nivel gratuito suele bastar para uso ocasional.\n\nToca el enlace de arriba para abrir Google AI Studio.",
            "tutorial" to "Tutorial",
            "donations" to "Donaciones",
            "donation_message" to "Cualquier donación voluntaria es recibida con amor",
            "tutorial_title" to "Cómo designar las áreas",
            "tutorial_body" to "Área de PREGUNTAS:\nMarca dónde aparece el texto de la pregunta en la pantalla.\n\n1) Toca Preguntas\n2) Mueve y ajusta el cuadro azul solo sobre la pregunta\n3) Toca Confirmar\n\nÁrea de OPCIONES:\nMarca dónde aparecen las opciones de respuesta.\n\n1) Toca Opciones\n2) Mueve y ajusta el cuadro verde sobre todas las opciones\n3) Toca Confirmar\n\nLuego abre la ventana flotante y pulsa Play para iniciar.",
            "donation_tooltip" to "Esta aplicación ha sido creada sin ningún interés lucrativo pero cualquier donación voluntaria es recibida con mucho amor."
        ),
        PT to mapOf(
            "app_name" to "Trivia Helper",
            "api_card" to "CHAVE API",
            "api_ok" to "API atribuída!",
            "api_need" to "API necessária!",
            "assign_api" to "Atribuir API",
            "areas_label" to "Definir áreas de detecção",
            "questions" to "Perguntas",
            "options" to "Opções",
            "float_label" to "Abra a janela flutuante para iniciar",
            "show" to "Mostrar",
            "hide" to "Ocultar",
            "language" to "Idioma",
            "save" to "Salvar",
            "back" to "Voltar",
            "api_title" to "Atribuir API",
            "api_hint" to "Cole sua chave do Google AI Studio…",
            "api_saved_hint" to "Chave salva. Cole uma nova para substituir.",
            "api_toast_empty" to "Cole uma chave API",
            "api_toast_ok" to "API salva",
            "overlay_title" to "Permissão de sobreposição",
            "overlay_msg" to "Necessária para a janela flutuante e seleção de áreas.",
            "overlay_allow" to "Permitir",
            "overlay_cancel" to "Cancelar",
            "lang_en" to "Inglês",
            "lang_es" to "Espanhol",
            "lang_pt" to "Português",
            "lang_id" to "Indonésio",
            "about_title" to "Sobre o Trivia Helper",
            "about_body" to "Trivia Helper é um aplicativo criado para ajudar os jogadores de WWE Champions a responder trivias de forma rápida e fácil e assim obter Charlotte Flair - \"Icons of WrestleMania\". O criador deste aplicativo não se responsabiliza pelo uso que possa ser dado a este aplicativo.",
            "help_api_title" to "Como obter uma chave API",
            "help_api_body" to "1) Abra o Google AI Studio:\nhttps://aistudio.google.com/apikey\n\n2) Entre com sua conta Google\n\n3) Toque em Create API key\n\n4) Copie a chave (começa com AIza…)\n\n5) No Trivia Helper toque em Atribuir API, cole e Salve\n\nO nível gratuito costuma bastar para uso ocasional.\n\nToque no link acima para abrir o Google AI Studio.",
            "tutorial" to "Tutorial",
            "donations" to "Doações",
            "donation_message" to "Toda doação voluntária é recebida com amor",
            "tutorial_title" to "Como definir as áreas",
            "tutorial_body" to "Área de PERGUNTAS:\nMarca onde aparece o texto da pergunta na tela.\n\n1) Toque em Perguntas\n2) Mova e ajuste a caixa azul só sobre a pergunta\n3) Toque em Confirmar\n\nÁrea de OPÇÕES:\nMarca onde aparecem as opções de resposta.\n\n1) Toque em Opções\n2) Mova e ajuste a caixa verde sobre todas as opções\n3) Toque em Confirmar\n\nDepois abra a janela flutuante e toque em Play para iniciar.",
            "donation_tooltip" to "Este aplicativo foi criado sem qualquer interesse lucrativo, mas qualquer doação voluntária é recebida com muito amor."
        ),
        ID to mapOf(
            "app_name" to "Trivia Helper",
            "api_card" to "KUNCI API",
            "api_ok" to "API Ditetapkan!",
            "api_need" to "API Diperlukan!",
            "assign_api" to "Tetapkan API",
            "areas_label" to "Tentukan area deteksi",
            "questions" to "Pertanyaan",
            "options" to "Opsi",
            "float_label" to "Buka jendela mengambang untuk mulai",
            "show" to "Tampilkan",
            "hide" to "Sembunyikan",
            "language" to "Bahasa",
            "save" to "Simpan",
            "back" to "Kembali",
            "api_title" to "Tetapkan API",
            "api_hint" to "Tempel kunci Google AI Studio Anda…",
            "api_saved_hint" to "Kunci tersimpan. Tempel yang baru untuk mengganti.",
            "api_toast_empty" to "Tempel kunci API",
            "api_toast_ok" to "API disimpan",
            "overlay_title" to "Izin overlay",
            "overlay_msg" to "Diperlukan untuk jendela mengambang dan pemilihan area.",
            "overlay_allow" to "Izinkan",
            "overlay_cancel" to "Batal",
            "lang_en" to "Inggris",
            "lang_es" to "Spanyol",
            "lang_pt" to "Portugis",
            "lang_id" to "Indonesia",
            "about_title" to "Tentang Trivia Helper",
            "about_body" to "Trivia Helper adalah aplikasi yang dibuat untuk membantu pemain WWE Champions menjawab trivia dengan cepat dan mudah sehingga dapat memperoleh Charlotte Flair - \"Icons of WrestleMania\". Pembuat aplikasi ini tidak bertanggung jawab atas penggunaan aplikasi ini.",
            "help_api_title" to "Cara mendapatkan kunci API",
            "help_api_body" to "1) Buka Google AI Studio:\nhttps://aistudio.google.com/apikey\n\n2) Masuk dengan akun Google\n\n3) Ketuk Create API key\n\n4) Salin kunci (dimulai dengan AIza…)\n\n5) Di Trivia Helper ketuk Tetapkan API, tempel dan Simpan\n\nKuota gratis biasanya cukup untuk penggunaan sesekali.\n\nKetuk tautan di atas untuk membuka Google AI Studio.",
            "tutorial" to "Tutorial",
            "donations" to "Donasi",
            "donation_message" to "Setiap donasi sukarela diterima dengan penuh kasih",
            "tutorial_title" to "Cara menentukan area",
            "tutorial_body" to "Area PERTANYAAN:\nMenandai di mana teks pertanyaan muncul di layar.\n\n1) Ketuk Pertanyaan\n2) Pindahkan dan sesuaikan kotak biru hanya di atas pertanyaan\n3) Ketuk Konfirmasi\n\nArea OPSI:\nMenandai di mana pilihan jawaban muncul.\n\n1) Ketuk Opsi\n2) Pindahkan dan sesuaikan kotak hijau di atas semua opsi\n3) Ketuk Konfirmasi\n\nLalu buka jendela mengambang dan tekan Play untuk mulai.",
            "donation_tooltip" to "Aplikasi ini dibuat tanpa motif keuntungan, tetapi setiap donasi sukarela diterima dengan penuh kasih."
        )
    )
}
