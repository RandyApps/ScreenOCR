package com.triviahelper.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class AnswerResult(
    val text: String,
    val confidence: Int = 50,
    val isError: Boolean = false,
    val source: String = "ia" // "sheet" or "ia"
)

object GeminiClient {

    fun findAnswer(apiKey: String, question: String, options: List<String>): AnswerResult {
        if (apiKey.isBlank()) return AnswerResult("Error: falta clave API", 0, true, "ia")
        if (question.isBlank()) return AnswerResult("Error: no se leyó la pregunta", 0, true, "ia")
        val cleanOptions = options.map { it.trim() }.filter { it.length > 1 }.distinct()
        if (cleanOptions.isEmpty()) return AnswerResult("Error: no se leyeron opciones", 0, true, "ia")

        val models = listOf(
            "gemini-3.8-flash",
            "gemini-3.6-flash",
            "gemini-3.5-flash-lite",
            "gemini-3.1-flash-lite",
            "gemini-flash-latest"
        )

        var lastError = "ningún modelo respondió"
        for (model in models) {
            try {
                val raw = callModel(apiKey, model, buildPrompt(question, cleanOptions))
                val matched = forceToOption(raw, cleanOptions)
                if (matched != null) {
                    return AnswerResult(matched.first, matched.second, false, "ia")
                }
            } catch (e: Exception) {
                lastError = e.message ?: "Error de red"
                if (lastError.contains("401") || lastError.contains("403")) {
                    return AnswerResult("Error: $lastError", 0, true, "ia")
                }
                if (lastError.contains("429") || lastError.contains("quota", true) ||
                    lastError.contains("RESOURCE_EXHAUSTED", true)
                ) {
                    return AnswerResult("Error: $lastError", 0, true, "ia")
                }
            }
        }
        return AnswerResult("Error: $lastError", 0, true, "ia")
    }

    private fun buildPrompt(question: String, options: List<String>): String {
        val optionsBlock = options.mapIndexed { i, o -> "${i + 1}) $o" }.joinToString("\n")
        return """
You are a WWE / professional wrestling facts expert with access to Google Search.
Use Google Search to find the correct, up-to-date answer if needed (especially recent events).

This is MULTIPLE CHOICE. You MUST pick exactly one of the numbered options.
Do NOT invent answers outside the list.

QUESTION:
$question

OPTIONS (choose only from these):
$optionsBlock

Reply with ONLY the option number (1-${options.size}).
Example: 2
""".trimIndent()
    }

    private fun forceToOption(raw: String?, options: List<String>): Pair<String, Int>? {
        if (raw.isNullOrBlank()) return null
        val text = raw.trim().trim('"').trim('\'').lines()
            .map { it.trim() }.firstOrNull { it.isNotEmpty() } ?: return null

        val digits = text.filter { it.isDigit() }
        if (digits.isNotEmpty()) {
            val n = digits.take(2).toIntOrNull()
            if (n != null && n in 1..options.size) return options[n - 1] to 90
        }
        if (text.isNotEmpty() && text[0].isDigit()) {
            val n = text.takeWhile { it.isDigit() }.toIntOrNull()
            if (n != null && n in 1..options.size) return options[n - 1] to 88
        }
        TriviaDatabase.strictMatchOption(text, options)?.let { return it to 80 }
        return null
    }

    private fun callModel(apiKey: String, model: String, prompt: String): String? {
        val url = URL(
            "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=" +
                URLEncoder.encode(apiKey, "UTF-8")
        )
        // Grounding with Google Search so Gemini can look up live web facts
        val body = JSONObject().apply {
            put("contents", JSONArray().put(JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().put("text", prompt)))
            }))
            put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            put("generationConfig", JSONObject().apply {
                put("temperature", 0)
                put("topP", 0.2)
                put("maxOutputTokens", 64)
            })
        }
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput = true
            connectTimeout = 12000
            readTimeout = 25000
        }
        OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
        conn.disconnect()
        if (code !in 200..299) {
            // If tools not supported on this model, retry without tools is handled by next model
            val msg = try {
                JSONObject(text).optJSONObject("error")?.optString("message") ?: text.take(100)
            } catch (_: Exception) { text.take(100) }
            throw Exception("HTTP $code ($model): $msg")
        }
        val json = JSONObject(text)
        val candidates = json.optJSONArray("candidates") ?: return null
        if (candidates.length() == 0) return null
        val content = candidates.getJSONObject(0).optJSONObject("content") ?: return null
        val parts = content.optJSONArray("parts") ?: return null
        // Prefer text parts
        for (i in 0 until parts.length()) {
            val p = parts.getJSONObject(i)
            if (p.has("text")) {
                val t = p.optString("text", "")
                if (t.isNotBlank()) return t
            }
        }
        return null
    }
}
