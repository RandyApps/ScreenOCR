package com.triviahelper.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

data class AnswerResult(
    val text: String,
    val confidence: Int = 50,
    val isError: Boolean = false
)

object GeminiClient {

    fun findAnswer(apiKey: String, question: String, options: List<String>): AnswerResult {
        if (apiKey.isBlank()) return AnswerResult("Error: falta clave API", 0, true)
        if (question.isBlank()) return AnswerResult("Error: no se leyó la pregunta", 0, true)
        val cleanOptions = options.map { it.trim() }.filter { it.length > 1 }.distinct()
        if (cleanOptions.isEmpty()) return AnswerResult("Error: no se leyeron opciones", 0, true)

        val models = listOf(
            "gemini-3.8-flash",
            "gemini-3.6-flash",
            "gemini-2.5-flash",
            "gemini-3.5-flash-lite",
            "gemini-flash-latest"
        )

        var lastError = "ningún modelo respondió"
        for (model in models) {
            try {
                val primary = callModel(apiKey, model, buildPrompt(question, cleanOptions, false))
                val match1 = matchToOption(primary, cleanOptions)
                if (match1 != null) return AnswerResult(match1.first, match1.second, false)

                val secondary = callModel(apiKey, model, buildPrompt(question, cleanOptions, true))
                val match2 = matchToOption(secondary, cleanOptions)
                if (match2 != null) return AnswerResult(match2.first, match2.second, false)
            } catch (e: Exception) {
                lastError = e.message ?: "Error de red"
                if (lastError.contains("401") || lastError.contains("403")) {
                    return AnswerResult("Error: $lastError", 0, true)
                }
                if (lastError.contains("429") || lastError.contains("quota", true) ||
                    lastError.contains("RESOURCE_EXHAUSTED", true)
                ) {
                    return AnswerResult("Error: $lastError", 0, true)
                }
            }
        }
        return AnswerResult("Error: $lastError", 0, true)
    }

    private fun buildPrompt(question: String, options: List<String>, strict: Boolean): String {
        val optionsBlock = options.mapIndexed { i, o -> "${i + 1}) $o" }.joinToString("\n")
        return if (!strict) {
            """
You are an expert on WWE and professional wrestling history.

MULTIPLE-CHOICE question. Choose EXACTLY one option from the list.
Use well-known WWE facts (titles, events, debuts, real names).

QUESTION:
$question

OPTIONS:
$optionsBlock

Reply on one line only:
INDEX:<number>|TEXT:<exact option text>|CONF:<0-100>
""".trimIndent()
        } else {
            """
WWE trivia. Reply ONLY with the correct option number (1-${options.size}).

QUESTION: $question

OPTIONS:
$optionsBlock
""".trimIndent()
        }
    }

    /** Returns Pair(optionText, confidence) or null */
    private fun matchToOption(raw: String?, options: List<String>): Pair<String, Int>? {
        if (raw.isNullOrBlank()) return null
        var text = raw.trim().trim('"').trim('\'')
            .lines().map { it.trim() }.firstOrNull { it.isNotEmpty() } ?: return null

        var conf = 75
        val confMarker = text.uppercase(Locale.US).indexOf("CONF:")
        if (confMarker >= 0) {
            val c = text.substring(confMarker + 5).trim().takeWhile { it.isDigit() }.toIntOrNull()
            if (c != null) conf = c.coerceIn(1, 99)
        }

        val idxMarker = text.uppercase(Locale.US).indexOf("INDEX:")
        if (idxMarker >= 0) {
            val after = text.substring(idxMarker + 6).trim()
            val n = after.takeWhile { it.isDigit() }.toIntOrNull()
            if (n != null && n in 1..options.size) return options[n - 1] to conf
        }

        val textMarker = text.uppercase(Locale.US).indexOf("TEXT:")
        if (textMarker >= 0) {
            var t = text.substring(textMarker + 5)
            val pipe = t.indexOf('|')
            if (pipe >= 0) t = t.substring(0, pipe)
            text = t.trim().trim('"').trim('\'')
        }

        val onlyDigits = text.filter { it.isDigit() }
        if (onlyDigits.length in 1..2 && text.length <= 3) {
            val n = onlyDigits.toIntOrNull()
            if (n != null && n in 1..options.size) return options[n - 1] to conf
        }

        if (text.isNotEmpty() && text[0].isDigit()) {
            val n = text.takeWhile { it.isDigit() }.toIntOrNull()
            if (n != null && n in 1..options.size) {
                val rest = text.dropWhile { it.isDigit() }.trimStart(')', '.', '-', ':', ' ')
                if (rest.isEmpty()) return options[n - 1] to conf
                options.firstOrNull { it.equals(rest, ignoreCase = true) }?.let { return it to conf }
                return options[n - 1] to conf
            }
        }

        options.firstOrNull { it.equals(text, ignoreCase = true) }?.let { return it to conf }

        val normText = normalize(text)
        options.firstOrNull { normalize(it) == normText }?.let { return it to (conf - 5).coerceAtLeast(50) }

        options.firstOrNull {
            val n = normalize(it)
            n.isNotEmpty() && (normText.contains(n) || n.contains(normText))
        }?.let { return it to (conf - 10).coerceAtLeast(45) }

        var best: String? = null
        var bestScore = 0.0
        for (opt in options) {
            val score = similarity(normText, normalize(opt))
            if (score > bestScore) {
                bestScore = score
                best = opt
            }
        }
        if (best != null && bestScore >= 0.72) {
            return best to (bestScore * 100).toInt().coerceIn(40, 90)
        }
        return null
    }

    private fun normalize(s: String): String {
        val sb = StringBuilder()
        var prevSpace = false
        for (ch in s.lowercase(Locale.US)) {
            if (ch.isLetterOrDigit()) {
                sb.append(ch); prevSpace = false
            } else if (ch.isWhitespace()) {
                if (!prevSpace) sb.append(' ')
                prevSpace = true
            }
        }
        return sb.toString().trim()
    }

    private fun similarity(a: String, b: String): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        if (a == b) return 1.0
        if (a.contains(b) || b.contains(a)) {
            return 0.8 + 0.2 * (minOf(a.length, b.length).toDouble() / maxOf(a.length, b.length))
        }
        val ba = bigrams(a)
        val bb = bigrams(b)
        if (ba.isEmpty() || bb.isEmpty()) return 0.0
        val inter = ba.intersect(bb).size.toDouble()
        return (2.0 * inter) / (ba.size + bb.size)
    }

    private fun bigrams(s: String): Set<String> {
        if (s.length < 2) return setOf(s)
        return (0 until s.length - 1).map { s.substring(it, it + 2) }.toSet()
    }

    private fun callModel(apiKey: String, model: String, prompt: String): String? {
        val url = URL(
            "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=" +
                URLEncoder.encode(apiKey, "UTF-8")
        )
        val body = JSONObject().apply {
            put("contents", JSONArray().put(JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().put("text", prompt)))
            }))
            put("generationConfig", JSONObject().apply {
                put("temperature", 0)
                put("topP", 0.8)
                put("maxOutputTokens", 100)
            })
        }
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput = true
            connectTimeout = 14000
            readTimeout = 18000
        }
        OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
        conn.disconnect()
        if (code !in 200..299) {
            val msg = try {
                JSONObject(text).optJSONObject("error")?.optString("message") ?: text.take(80)
            } catch (_: Exception) { text.take(80) }
            throw Exception("HTTP $code ($model): $msg")
        }
        val json = JSONObject(text)
        val candidates = json.optJSONArray("candidates") ?: return null
        if (candidates.length() == 0) return null
        val content = candidates.getJSONObject(0).optJSONObject("content") ?: return null
        val parts = content.optJSONArray("parts") ?: return null
        if (parts.length() == 0) return null
        return parts.getJSONObject(0).optString("text", null)
    }
}
