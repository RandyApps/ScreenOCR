package com.triviahelper.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object GeminiClient {

    /**
     * Asks Gemini which option is correct. Returns the option text or an error message.
     */
    fun findAnswer(apiKey: String, question: String, options: List<String>): String {
        if (apiKey.isBlank()) return "Error: falta clave API"
        if (question.isBlank()) return "Error: no se leyó la pregunta"
        if (options.isEmpty()) return "Error: no se leyeron opciones"

        val optionsBlock = options.mapIndexed { i, o -> "${i + 1}. $o" }.joinToString("\n")
        val prompt = """
You are a WWE / professional wrestling trivia expert.
Answer this multiple-choice question. You MUST pick exactly one of the given options.
Reply with ONLY the exact text of the correct option, nothing else. No numbers, no quotes, no explanation.

QUESTION:
$question

OPTIONS:
$optionsBlock
""".trimIndent()

        val models = listOf(
            "gemini-2.0-flash",
            "gemini-1.5-flash",
            "gemini-1.5-flash-latest"
        )

        var lastError = "Error desconocido"
        for (model in models) {
            try {
                val result = callModel(apiKey, model, prompt)
                if (result != null) {
                    // Match to closest option
                    val cleaned = result.trim().trim('"').trim('\'')
                    val match = options.firstOrNull {
                        it.equals(cleaned, ignoreCase = true) ||
                            cleaned.contains(it, ignoreCase = true) ||
                            it.contains(cleaned, ignoreCase = true)
                    }
                    return match ?: cleaned
                }
            } catch (e: Exception) {
                lastError = e.message ?: "Error de red"
            }
        }
        return "Error: $lastError"
    }

    private fun callModel(apiKey: String, model: String, prompt: String): String? {
        val url = URL(
            "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=" +
                URLEncoder.encode(apiKey, "UTF-8")
        )
        val body = JSONObject().apply {
            put("contents", JSONArray().put(JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().put("text", prompt)))
            }))
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.1)
                put("maxOutputTokens", 120)
            })
        }

        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput = true
            connectTimeout = 12000
            readTimeout = 12000
        }
        OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
        conn.disconnect()

        if (code !in 200..299) {
            throw Exception("HTTP $code")
        }

        val json = JSONObject(text)
        val candidates = json.optJSONArray("candidates") ?: return null
        if (candidates.length() == 0) return null
        val content = candidates.getJSONObject(0).optJSONObject("content") ?: return null
        val parts = content.optJSONArray("parts") ?: return null
        if (parts.length() == 0) return null
        return parts.getJSONObject(0).optString("text", null)
    }
}
