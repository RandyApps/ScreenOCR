package com.triviahelper.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

object GeminiClient {

    fun findAnswer(apiKey: String, question: String, options: List<String>): String {
        if (apiKey.isBlank()) return "Error: falta clave API"
        if (question.isBlank()) return "Error: no se leyó la pregunta"
        val cleanOptions = options
            .map { it.trim() }
            .filter { it.length > 1 }
            .distinct()
        if (cleanOptions.isEmpty()) return "Error: no se leyeron opciones"

        val models = listOf(
            "gemini-3.8-flash",
            "gemini-3.6-flash",
            "gemini-2.5-flash",
            "gemini-3.5-flash-lite",
            "gemini-3.1-flash-lite",
            "gemini-flash-latest"
        )

        var lastError = "ningún modelo respondió"
        for (model in models) {
            try {
                val primary = callModel(apiKey, model, buildPrompt(question, cleanOptions, false))
                val match1 = matchToOption(primary, cleanOptions)
                if (match1 != null) return match1

                val secondary = callModel(apiKey, model, buildPrompt(question, cleanOptions, true))
                val match2 = matchToOption(secondary, cleanOptions)
                if (match2 != null) return match2
            } catch (e: Exception) {
                lastError = e.message ?: "Error de red"
                if (lastError.contains("401") || lastError.contains("403")) {
                    return "Error: $lastError (revisa tu clave API)"
                }
                if (lastError.contains("429") || lastError.contains("quota", true) ||
                    lastError.contains("RESOURCE_EXHAUSTED", true)
                ) {
                    return "Error: $lastError"
                }
            }
        }
        return "Error: $lastError"
    }

    private fun buildPrompt(question: String, options: List<String>, strict: Boolean): String {
        val optionsBlock = options.mapIndexed { i, o -> "${i + 1}) $o" }.joinToString("\n")
        return if (!strict) {
            """
You are an expert on WWE and professional wrestling history, pay-per-views, championships, and wrestlers.

Solve this MULTIPLE-CHOICE trivia question.
Rules:
- Exactly ONE option is correct.
- You MUST choose only from the numbered options below.
- Prefer well-known documented facts (title reigns, event results, debuts, real names, stables).
- If unsure, pick the option that best matches mainstream WWE history.

QUESTION:
$question

OPTIONS:
$optionsBlock

Reply in this exact format on one line:
INDEX:<number>|TEXT:<exact option text>

Example: INDEX:2|TEXT:The Rock
""".trimIndent()
        } else {
            """
WWE trivia. Choose the correct option number ONLY.

QUESTION: $question

OPTIONS:
$optionsBlock

Reply with ONLY the number (1-${options.size}), nothing else.
""".trimIndent()
        }
    }

    private fun matchToOption(raw: String?, options: List<String>): String? {
        if (raw.isNullOrBlank()) return null
        var text = raw.trim()
            .trim('"')
            .trim('\'')
            .lines()
            .map { it.trim() }
            .firstOrNull { it.isNotEmpty() }
            ?: return null

        // INDEX:2|TEXT:...
        val idxMarker = text.uppercase(Locale.US).indexOf("INDEX:")
        if (idxMarker >= 0) {
            val after = text.substring(idxMarker + 6).trim()
            val num = after.takeWhile { it.isDigit() }
            val n = num.toIntOrNull()
            if (n != null && n in 1..options.size) return options[n - 1]
        }

        // TEXT:exact
        val textMarker = text.uppercase(Locale.US).indexOf("TEXT:")
        if (textMarker >= 0) {
            text = text.substring(textMarker + 5).trim().trim('"').trim('\'')
        }

        // Solo dígitos
        val onlyDigits = text.filter { it.isDigit() }
        if (onlyDigits.length in 1..2 && text.length <= 3) {
            val n = onlyDigits.toIntOrNull()
            if (n != null && n in 1..options.size) return options[n - 1]
        }

        // Prefijo "2)" "2." "2 -"
        if (text.isNotEmpty() && text[0].isDigit()) {
            val n = text.takeWhile { it.isDigit() }.toIntOrNull()
            if (n != null && n in 1..options.size) {
                val rest = text.dropWhile { it.isDigit() }.trimStart(')', '.', '-', ':', ' ')
                if (rest.isEmpty()) return options[n - 1]
                // si hay texto después, preferir match por texto; si no, usar índice
                val byText = options.firstOrNull { it.equals(rest, ignoreCase = true) }
                if (byText != null) return byText
                return options[n - 1]
            }
        }

        // Exacto
        options.firstOrNull { it.equals(text, ignoreCase = true) }?.let { return it }

        val normText = normalize(text)
        options.firstOrNull { normalize(it) == normText }?.let { return it }

        options.firstOrNull {
            val n = normalize(it)
            n.isNotEmpty() && (normText.contains(n) || n.contains(normText))
        }?.let { return it }

        var best: String? = null
        var bestScore = 0.0
        for (opt in options) {
            val score = similarity(normText, normalize(opt))
            if (score > bestScore) {
                bestScore = score
                best = opt
            }
        }
        if (best != null && bestScore >= 0.72) return best
        return null
    }

    private fun normalize(s: String): String {
        val sb = StringBuilder()
        var prevSpace = false
        for (ch in s.lowercase(Locale.US)) {
            val ok = ch.isLetterOrDigit() || ch.isWhitespace()
            if (ok) {
                if (ch.isWhitespace()) {
                    if (!prevSpace) sb.append(' ')
                    prevSpace = true
                } else {
                    sb.append(ch)
                    prevSpace = false
                }
            }
        }
        return sb.toString().trim()
    }

    private fun similarity(a: String, b: String): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        if (a == b) return 1.0
        if (a.contains(b) || b.contains(a)) {
            val ratio = minOf(a.length, b.length).toDouble() / maxOf(a.length, b.length)
            return 0.8 + 0.2 * ratio
        }
        val ba = bigrams(a)
        val bb = bigrams(b)
        if (ba.isEmpty() || bb.isEmpty()) return 0.0
        val inter = ba.intersect(bb).size.toDouble()
        return (2.0 * inter) / (ba.size + bb.size)
    }

    private fun bigrams(s: String): Set<String> {
        if (s.length < 2) return setOf(s)
        val out = HashSet<String>()
        for (i in 0 until s.length - 1) {
            out.add(s.substring(i, i + 2))
        }
        return out
    }

    private fun callModel(apiKey: String, model: String, prompt: String): String? {
        val url = URL(
            "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=" +
                URLEncoder.encode(apiKey, "UTF-8")
        )
        val body = JSONObject().apply {
            put("contents", JSONArray().put(JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().put("text", prompt)))
            }))
            put("generationConfig", JSONObject().apply {
                put("temperature", 0)
                put("topP", 0.8)
                put("maxOutputTokens", 80)
            })
        }

        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput = true
            connectTimeout = 14000
            readTimeout = 18000
        }
        OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
        conn.disconnect()

        if (code !in 200..299) {
            val msg = try {
                JSONObject(text).optJSONObject("error")?.optString("message") ?: text.take(80)
            } catch (_: Exception) {
                text.take(80)
            }
            throw Exception("HTTP $code ($model): $msg")
        }

        val json = JSONObject(text)
        val candidates = json.optJSONArray("candidates") ?: return null
        if (candidates.length() == 0) return null
        val content = candidates.getJSONObject(0).optJSONObject("content") ?: return null
        val parts = content.optJSONArray("parts") ?: return null
        if (parts.length() == 0) return null
        return parts.getJSONObject(0).optString("text", null)
    }
}
