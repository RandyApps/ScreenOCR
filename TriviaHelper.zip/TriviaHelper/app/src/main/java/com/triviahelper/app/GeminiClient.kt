package com.triviahelper.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

object GeminiClient {

    fun findAnswer(apiKey: String, question: String, options: List<String>): String {
        if (apiKey.isBlank()) return "Error: falta clave API"
        if (question.isBlank()) return "Error: no se leyó la pregunta"
        val cleanOptions = options
            .map { it.trim() }
            .filter { it.length > 1 }
            .distinct()
        if (cleanOptions.isEmpty()) return "Error: no se leyeron opciones"

        // Current stable Gemini Flash IDs. Avoid retired/incorrect model names.
        val models = listOf(
            "gemini-3.8-flash",
            "gemini-3.7-flash",
            "gemini-3.6-flash",
            "gemini-3.5-flash",
            "gemini-3.5-flash-lite",
            "gemini-3.1-flash-lite"
        )

        // A real, free external lookup for wrestling trivia. If Wikipedia is slow or
        // unavailable, continue with Gemini rather than failing the entire search.
        val webContext = searchWikipedia(question)

        var lastError = "ningún modelo respondió"
        for (model in models) {
            try {
                val primary = callModel(apiKey, model, buildPrompt(question, cleanOptions, false, webContext))
                val match1 = matchToOption(primary, cleanOptions)
                if (match1 != null) return match1

                val secondary = callModel(apiKey, model, buildPrompt(question, cleanOptions, true, webContext))
                val match2 = matchToOption(secondary, cleanOptions)
                if (match2 != null) return match2
                // Do not query every remaining model after an ambiguous answer: that
                // multiplies API usage and can burn the free quota on one trivia.
                return "Error: Gemini no devolvió una opción válida para esta pregunta."
            } catch (e: Exception) {
                lastError = e.message ?: "Error de red"
                if (lastError.contains("401") || lastError.contains("403")) {
                    return "Error: $lastError (revisa tu clave API)"
                }
                // Only a missing model warrants trying the next model. Network, server,
                // quota and request errors should be reported immediately, not spam retries.
                val httpCode = Regex("HTTP\\s+(\\d{3})").find(lastError)?.groupValues?.getOrNull(1)?.toIntOrNull()
                if (httpCode != null && httpCode != 404) return "Error: $lastError"
                if (httpCode == null && !lastError.contains("model", true)) return "Error: $lastError"
                if (lastError.contains("429") || lastError.contains("quota", true) ||
                    lastError.contains("RESOURCE_EXHAUSTED", true) ||
                    lastError.contains("rate limit", true) ||
                    lastError.contains("billing", true)
                ) {
                    return "Error: $lastError"
                }
                // Authentication errors cannot be fixed by trying another model.
                if (lastError.contains("400") && lastError.contains("API key", true)) {
                    return "Error: $lastError"
                }
            }
        }
        return "Error: $lastError"
    }

    private fun buildPrompt(question: String, options: List<String>, strict: Boolean, webContext: String): String {
        val optionsBlock = options.mapIndexed { i, o -> "${i + 1}) $o" }.joinToString("\n")
        val references = if (webContext.isBlank()) "No external reference results were available." else webContext
        return if (!strict) {
            """
You are an expert on WWE and professional wrestling history, pay-per-views, championships, and wrestlers.

Solve this MULTIPLE-CHOICE trivia question.
Rules:
- Exactly ONE option is correct.
- You MUST choose only from the numbered options below.
- Prefer well-known documented facts (title reigns, event results, debuts, real names, stables).
- Use the reference search results below when relevant; prefer facts supported by those results.
- If unsure, pick the option that best matches mainstream WWE history.

QUESTION:
$question

REFERENCE SEARCH RESULTS:
$references

OPTIONS:
$optionsBlock

Reply in this exact format on one line:
INDEX:<number>|TEXT:<exact option text>

Example: INDEX:2|TEXT:The Rock
""".trimIndent()
        } else {
            """
WWE trivia. Choose the correct option number ONLY. Use the reference results when relevant.

QUESTION: $question

REFERENCE SEARCH RESULTS:
$references

OPTIONS:
$optionsBlock

Reply with ONLY the number (1-${options.size}), nothing else.
""".trimIndent()
        }
    }

    private fun matchToOption(raw: String?, options: List<String>): String? {
        if (raw.isNullOrBlank()) return null
        var text = raw.trim()
            .trim('"')
            .trim('\'')
            .lines()
            .map { it.trim() }
            .firstOrNull { it.isNotEmpty() }
            ?: return null

        // INDEX:n|TEXT:... — if both are supplied, they must agree.
        val upper = text.uppercase(Locale.US)
        val idxMarker = upper.indexOf("INDEX:")
        val textMarker = upper.indexOf("TEXT:")
        if (idxMarker >= 0) {
            val after = text.substring(idxMarker + 6).trim()
            val n = after.takeWhile { it.isDigit() }.toIntOrNull()
            if (n == null || n !in 1..options.size) return null
            if (textMarker >= 0) {
                val returnedText = text.substring(textMarker + 5).trim().trim('"').trim('\'')
                val exactText = options.firstOrNull { it.equals(returnedText, ignoreCase = true) }
                    ?: options.firstOrNull { normalize(it) == normalize(returnedText) }
                return if (exactText != null && exactText == options[n - 1]) exactText else null
            }
            return options[n - 1]
        }

        // TEXT:exact
        if (textMarker >= 0) {
            text = text.substring(textMarker + 5).trim().trim('"').trim('\'')
        }

        // Solo dígitos
        val onlyDigits = text.filter { it.isDigit() }
        if (onlyDigits.length in 1..2 && text.length <= 3) {
            val n = onlyDigits.toIntOrNull()
            if (n != null && n in 1..options.size) return options[n - 1]
        }

        // Prefijo "2)" "2." "2 -"
        if (text.isNotEmpty() && text[0].isDigit()) {
            val n = text.takeWhile { it.isDigit() }.toIntOrNull()
            if (n != null && n in 1..options.size) {
                val rest = text.dropWhile { it.isDigit() }.trimStart(')', '.', '-', ':', ' ')
                if (rest.isEmpty()) return options[n - 1]
                // si hay texto después, preferir match por texto; si no, usar índice
                val byText = options.firstOrNull { it.equals(rest, ignoreCase = true) }
                    ?: options.firstOrNull { normalize(it) == normalize(rest) }
                return if (byText != null && byText == options[n - 1]) byText else null
            }
        }

        // Exacto
        options.firstOrNull { it.equals(text, ignoreCase = true) }?.let { return it }

        val normText = normalize(text)
        options.firstOrNull { normalize(it) == normText }?.let { return it }

        // Do not guess with fuzzy similarity: an uncertain model output must not
        // silently select a different answer option.
        return null
    }

    private fun normalize(s: String): String {
        val sb = StringBuilder()
        var prevSpace = false
        for (ch in s.lowercase(Locale.US)) {
            val ok = ch.isLetterOrDigit() || ch.isWhitespace()
            if (ok) {
                if (ch.isWhitespace()) {
                    if (!prevSpace) sb.append(' ')
                    prevSpace = true
                } else {
                    sb.append(ch)
                    prevSpace = false
                }
            }
        }
        return sb.toString().trim()
    }

    private fun searchWikipedia(question: String): String {
        var connection: HttpURLConnection? = null
        return try {
            val query = URLEncoder.encode(question.take(220), "UTF-8")
            val url = URL("https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=$query&format=json&utf8=1&srlimit=4")
            connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                setRequestProperty("User-Agent", "TriviaHelper/1.0 (Android trivia assistant)")
                // La búsqueda externa es opcional: que no retrase demasiado la respuesta.
                connectTimeout = 1500
                readTimeout = 1800
            }
            if (connection.responseCode !in 200..299) return ""
            val response = BufferedReader(InputStreamReader(connection.inputStream, Charsets.UTF_8)).use { it.readText() }
            val results = JSONObject(response).optJSONObject("query")?.optJSONArray("search") ?: return ""
            val snippets = mutableListOf<String>()
            for (i in 0 until minOf(results.length(), 4)) {
                val item = results.optJSONObject(i) ?: continue
                val title = (item.optString("title", "") ?: "").trim()
                val rawSnippet = item.optString("snippet", "") ?: ""
                val snippet = rawSnippet.replace(Regex("<[^>]*>"), " ")
                    .replace("&quot;", "\"")
                    .replace("&#39;", "'")
                    .replace("&amp;", "&")
                    .replace("&lt;", "<")
                    .replace("&gt;", ">")
                    .replace(Regex("\\s+"), " ").trim()
                if (title.isNotBlank() && snippet.isNotBlank()) {
                    snippets.add("- $title: ${snippet.take(220)}")
                }
            }
            snippets.joinToString("\n")
        } catch (_: Exception) {
            ""
        } finally {
            connection?.disconnect()
        }
    }

    private fun callModel(apiKey: String, model: String, prompt: String): String? {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        val body = JSONObject().apply {
            put("contents", JSONArray().put(JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().put("text", prompt)))
            }))
            put("generationConfig", JSONObject().apply {
                put("temperature", 0)
                put("topP", 0.8)
                put("maxOutputTokens", 80)
            })
        }

        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("x-goog-api-key", apiKey)
            setRequestProperty("Connection", "close")
            doOutput = true
            // En conexiones móviles lentas Gemini puede tardar más de 18 s.
            // Mantener una ventana mayor evita falsos timeouts sin disparar reintentos.
            connectTimeout = 20000
            readTimeout = 45000
        }
        val code: Int
        val text: String
        try {
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
            code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            text = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
        } finally {
            conn.disconnect()
        }

        if (code !in 200..299) {
            val msg = try {
                JSONObject(text).optJSONObject("error")?.optString("message") ?: text.take(80)
            } catch (_: Exception) {
                text.take(80)
            }
            throw Exception("HTTP $code ($model): $msg")
        }

        val json = JSONObject(text)
        val candidates = json.optJSONArray("candidates") ?: return null
        if (candidates.length() == 0) return null
        val content = candidates.getJSONObject(0).optJSONObject("content") ?: return null
        val parts = content.optJSONArray("parts") ?: return null
        if (parts.length() == 0) return null
        return parts.getJSONObject(0).optString("text", null)
    }
}
