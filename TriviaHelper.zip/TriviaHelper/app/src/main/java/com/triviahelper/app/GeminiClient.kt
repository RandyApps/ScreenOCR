package com.triviahelper.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

data class AnswerResult(
    val text: String,
    val confidence: Int = 50,
    val isError: Boolean = false
)

object GeminiClient {

    /**
     * Always returns one of [options] on success, or an error.
     * Never returns free-form text that is not in the options list.
     */
    fun findAnswer(apiKey: String, question: String, options: List<String>): AnswerResult {
        if (apiKey.isBlank()) return AnswerResult("Error: falta clave API", 0, true)
        if (question.isBlank()) return AnswerResult("Error: no se leyó la pregunta", 0, true)
        val cleanOptions = options.map { it.trim() }.filter { it.length > 1 }.distinct()
        if (cleanOptions.isEmpty()) return AnswerResult("Error: no se leyeron opciones", 0, true)

        // Fewer models = faster. Prefer solid flash models.
        // Modelos actuales (2026). 2.0/2.5 a menudo dan 404 a claves nuevas.
        val models = listOf(
            "gemini-3.8-flash",
            "gemini-3.6-flash",
            "gemini-3.5-flash-lite",
            "gemini-3.1-flash-lite",
            "gemini-flash-latest"
        )

        var lastError = "ningún modelo respondió"
        for (model in models) {
            try {
                val raw = callModel(apiKey, model, buildPrompt(question, cleanOptions))
                val matched = forceToOption(raw, cleanOptions)
                if (matched != null) {
                    return AnswerResult(matched.first, matched.second, false)
                }
            } catch (e: Exception) {
                lastError = e.message ?: "Error de red"
                if (lastError.contains("401") || lastError.contains("403")) {
                    return AnswerResult("Error: $lastError", 0, true)
                }
                if (lastError.contains("429") || lastError.contains("quota", true) ||
                    lastError.contains("RESOURCE_EXHAUSTED", true)
                ) {
                    return AnswerResult("Error: $lastError", 0, true)
                }
            }
        }
        return AnswerResult("Error: $lastError", 0, true)
    }

    private fun buildPrompt(question: String, options: List<String>): String {
        val optionsBlock = options.mapIndexed { i, o -> "${i + 1}) $o" }.joinToString("\n")
        return """
You are a WWE / professional wrestling facts expert.
This is a MULTIPLE CHOICE question. You MUST pick exactly one of the numbered options below.
Do NOT invent answers. Do NOT pick anything outside the list.
If unsure, choose the option that best matches public WWE history.

QUESTION:
$question

OPTIONS (choose only from these):
$optionsBlock

Reply with ONLY this format (one line):
NUMBER
where NUMBER is 1 to ${options.size}.
Example: 2
""".trimIndent()
    }

    /**
     * Force model output into one of the provided options. Returns null if impossible.
     */
    private fun forceToOption(raw: String?, options: List<String>): Pair<String, Int>? {
        if (raw.isNullOrBlank()) return null
        val text = raw.trim().trim('"').trim('\'').lines()
            .map { it.trim() }.firstOrNull { it.isNotEmpty() } ?: return null

        // Pure number
        val digits = text.filter { it.isDigit() }
        if (digits.isNotEmpty()) {
            val n = digits.take(2).toIntOrNull()
            if (n != null && n in 1..options.size) return options[n - 1] to 85
        }

        // "1)" or "1." prefix
        if (text.isNotEmpty() && text[0].isDigit()) {
            val n = text.takeWhile { it.isDigit() }.toIntOrNull()
            if (n != null && n in 1..options.size) return options[n - 1] to 80
        }

        // Strict option match only
        TriviaDatabase.strictMatchOption(text, options)?.let { return it to 75 }

        return null
    }

    private fun callModel(apiKey: String, model: String, prompt: String): String? {
        val url = URL(
            "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=" +
                URLEncoder.encode(apiKey, "UTF-8")
        )
        val body = JSONObject().apply {
            put("contents", JSONArray().put(JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().put("text", prompt)))
            }))
            put("generationConfig", JSONObject().apply {
                put("temperature", 0)
                put("topP", 0.1)
                put("maxOutputTokens", 16)
            })
        }
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput = true
            connectTimeout = 8000
            readTimeout = 12000
        }
        OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
        conn.disconnect()
        if (code !in 200..299) {
            val msg = try {
                JSONObject(text).optJSONObject("error")?.optString("message") ?: text.take(80)
            } catch (_: Exception) { text.take(80) }
            throw Exception("HTTP $code ($model): $msg")
        }
        val json = JSONObject(text)
        val candidates = json.optJSONArray("candidates") ?: return null
        if (candidates.length() == 0) return null
        val content = candidates.getJSONObject(0).optJSONObject("content") ?: return null
        val parts = content.optJSONArray("parts") ?: return null
        if (parts.length() == 0) return null
        return parts.getJSONObject(0).optString("text", null)
    }
}
