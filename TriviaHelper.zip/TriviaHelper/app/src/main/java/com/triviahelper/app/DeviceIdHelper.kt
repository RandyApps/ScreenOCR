package com.triviahelper.app

import android.content.Context
import android.provider.Settings
import java.util.UUID

object DeviceIdHelper {
    private const val PREF = "trivia_helper_prefs"
    private const val KEY = "device_id_v1"

    fun get(context: Context): String {
        val p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val existing = p.getString(KEY, null)
        if (!existing.isNullOrBlank()) return existing

        val androidId = try {
            Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
        } catch (_: Exception) {
            null
        }
        val id = when {
            !androidId.isNullOrBlank() && androidId != "9774d56d682e549c" -> "aid_$androidId"
            else -> "uuid_${UUID.randomUUID()}"
        }
        p.edit().putString(KEY, id).apply()
        return id
    }
}
