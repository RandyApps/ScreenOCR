package com.triviahelper.app

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import kotlin.concurrent.thread

class LoginActivity : AppCompatActivity() {

    private lateinit var prefs: PrefsHelper
    private lateinit var googleClient: GoogleSignInClient
    private lateinit var progress: ProgressBar
    private lateinit var tvStatus: TextView
    private lateinit var btnGoogle: View

    private val signInLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        val task = GoogleSignIn.getSignedInAccountFromIntent(data)
        try {
            val account = task.getResult(ApiException::class.java)
            val uid = account.id ?: account.idToken ?: ""
            val email = account.email ?: ""
            val nombre = account.displayName ?: email.ifBlank { "Usuario" }
            if (uid.isBlank()) {
                setLoading(false)
                tvStatus.text = "No se pudo obtener el ID de Google"
                return@registerForActivityResult
            }
            registerWithBackend(uid, email, nombre)
        } catch (e: ApiException) {
            setLoading(false)
            tvStatus.text = "Error de Google (${e.statusCode})"
        } catch (e: Exception) {
            setLoading(false)
            tvStatus.text = "Error: ${e.message}"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        prefs = PrefsHelper(this)

        // Already banned → lock screen
        if (prefs.isBanned()) {
            goBanned()
            return
        }
        // Already approved → main app
        if (prefs.isApproved()) {
            goMain()
            return
        }

        setContentView(R.layout.activity_login)
        progress = findViewById(R.id.progress)
        tvStatus = findViewById(R.id.tvStatus)
        btnGoogle = findViewById(R.id.btnGoogleSignIn)

        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestProfile()
            .build()
        googleClient = GoogleSignIn.getClient(this, gso)

        // Silent: already signed in with Google
        val existing = GoogleSignIn.getLastSignedInAccount(this)
        if (existing != null && !existing.isExpired) {
            val uid = existing.id ?: ""
            val email = existing.email ?: ""
            val nombre = existing.displayName ?: email
            if (uid.isNotBlank()) {
                setLoading(true)
                registerWithBackend(uid, email, nombre)
            }
        }

        btnGoogle.setOnClickListener {
            tvStatus.text = ""
            setLoading(true)
            signInLauncher.launch(googleClient.signInIntent)
        }
    }

    private fun registerWithBackend(uid: String, email: String, nombre: String) {
        setLoading(true)
        val deviceId = DeviceIdHelper.get(this)
        thread {
            val response = try {
                UserApiClient.registerOrCheck(uid, email, nombre, deviceId)
            } catch (e: Exception) {
                UserApiResponse("ERROR", null)
            }
            runOnUiThread { handleApiResponse(uid, email, nombre, response) }
        }
    }

    private fun handleApiResponse(
        uid: String,
        email: String,
        nombre: String,
        response: UserApiResponse
    ) {
        setLoading(false)
        when (response.status.uppercase()) {
            "DEVICE_BANNED", "BANNED" -> {
                try { googleClient.signOut() } catch (_: Exception) {}
                prefs.saveUserSession(
                    uid, email, nombre,
                    response.status.uppercase(),
                    response.role ?: ""
                )
                goBanned()
            }
            "APPROVED" -> {
                val role = response.role?.ifBlank { "INVITADO" } ?: "INVITADO"
                prefs.saveUserSession(uid, email, nombre, "APPROVED", role)
                goMain()
            }
            else -> {
                tvStatus.text = "No se pudo verificar la cuenta (${response.status}). Reintenta."
                Toast.makeText(this, "Error de servidor: ${response.status}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setLoading(loading: Boolean) {
        progress.visibility = if (loading) View.VISIBLE else View.GONE
        btnGoogle.isEnabled = !loading
        btnGoogle.alpha = if (loading) 0.5f else 1f
    }

    private fun goMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private fun goBanned() {
        startActivity(Intent(this, BannedActivity::class.java))
        finish()
    }
}
