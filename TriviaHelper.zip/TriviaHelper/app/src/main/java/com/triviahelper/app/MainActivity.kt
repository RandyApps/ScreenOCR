package com.triviahelper.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.method.LinkMovementMethod
import android.text.util.Linkify
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.triviahelper.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: PrefsHelper
    private var edgeSwipeStartX = 0f
    private var edgeSwipeStartY = 0f
    private var edgeSwipeTracking = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            applyStrings()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        TriviaDatabase.init(this)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefs = PrefsHelper(this)

        if (prefs.isBanned()) {
            startActivity(Intent(this, BannedActivity::class.java))
            finish()
            return
        }
        if (!prefs.isApproved()) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        // Re-check bans on Supabase (instant remote ban)
        Thread {
            val ban = try {
                SupabaseBanClient.checkIfBanned(
                    DeviceIdHelper.get(this@MainActivity),
                    prefs.getUserUid()
                )
            } catch (_: Exception) {
                SupabaseBanClient.BanResult(false)
            }
            if (ban.banned) {
                runOnUiThread {
                    val status = if (ban.kind == "DEVICE") "DEVICE_BANNED" else "BANNED"
                    prefs.saveUserSession(
                        prefs.getUserUid(),
                        prefs.getUserEmail(),
                        prefs.getUserNombre(),
                        status,
                        prefs.getUserRole()
                    )
                    startActivity(Intent(this@MainActivity, BannedActivity::class.java))
                    finish()
                }
            }
        }.start()

        if (intent?.getBooleanExtra("EXIT", false) == true) {
            finishAffinity()
            return
        }

        SessionRealtimeWatcher.start(this)
        setupAdminSwipe()

        binding.btnAbout.setOnClickListener {
            showHelp(
                LocaleHelper.t(this, "about_title"),
                LocaleHelper.t(this, "about_body"),
                null
            )
        }
        binding.btnApiHelp.setOnClickListener {
            showHelp(
                LocaleHelper.t(this, "help_api_title"),
                LocaleHelper.t(this, "help_api_body"),
                null
            )
        }
        binding.btnHelpClose.setOnClickListener {
            binding.helpOverlay.visibility = View.GONE
        }
        // No cerrar al tocar el fondo oscuro ni el panel (solo la X)
        binding.helpOverlay.setOnClickListener { /* ignore */ }
        binding.helpOverlay.getChildAt(0)?.setOnClickListener { /* consume */ }

        setupModeSwitch()
        binding.cardLanguage.setOnClickListener { showLanguagePicker() }

        binding.cardApi.setOnClickListener {
            startActivity(Intent(this, ApiActivity::class.java))
        }

        binding.cardQuestions.setOnClickListener {
            if (prefs.isAccessibilityMode()) {
                Toast.makeText(this, LocaleHelper.t(this, "areas_disabled_a11y"), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (!ensureOverlay()) return@setOnClickListener
            startForegroundService(Intent(this, TriviaService::class.java).apply {
                action = TriviaService.ACTION_SELECT_QUESTION
            })
            moveTaskToBack(true)
        }

        binding.cardOptions.setOnClickListener {
            if (prefs.isAccessibilityMode()) {
                Toast.makeText(this, LocaleHelper.t(this, "areas_disabled_a11y"), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (!ensureOverlay()) return@setOnClickListener
            startForegroundService(Intent(this, TriviaService::class.java).apply {
                action = TriviaService.ACTION_SELECT_OPTIONS
            })
            moveTaskToBack(true)
        }

        binding.cardShow.setOnClickListener {
            if (!ensureOverlay()) return@setOnClickListener
            if (TriviaService.isFloatVisible) {
                startService(Intent(this, TriviaService::class.java).apply {
                    action = TriviaService.ACTION_HIDE_FLOAT
                })
                binding.root.postDelayed({ applyStrings() }, 200)
            } else {
                startForegroundService(Intent(this, TriviaService::class.java).apply {
                    action = TriviaService.ACTION_SHOW_FLOAT
                    putExtra(TriviaService.EXTRA_CENTER_FLOAT, true)
                })
                moveTaskToBack(true)
            }
        }

        binding.cardTutorial.setOnClickListener {
            showHelp(
                LocaleHelper.t(this, "tutorial_title"),
                LocaleHelper.t(this, "tutorial_body"),
                R.drawable.illust_area
            )
        }

        binding.cardDonate.setOnClickListener {
            openPaypal()
        }
        binding.cardDonate.setOnLongClickListener {
            Toast.makeText(this, LocaleHelper.t(this, "donation_tooltip"), Toast.LENGTH_LONG).show()
            true
        }
        if (Build.VERSION.SDK_INT >= 26) {
            binding.cardDonate.tooltipText = LocaleHelper.t(this, "donation_tooltip")
        }
    }

    override fun onResume() {
        super.onResume()
        applyStrings()
        SessionRealtimeWatcher.attach(this)
        val f = IntentFilter(TriviaService.ACTION_STATUS)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, f, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(receiver, f)
        }
    }

    override fun onPause() {
        super.onPause()
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
    }

    private fun applyStrings() {
        val c = this
        binding.tvAppTitle.text = LocaleHelper.t(c, "app_name")
        binding.tvLanguage.text = LocaleHelper.t(c, "language")
        try { refreshModeUi() } catch (_: Exception) {}
        binding.tvApiLabel.text = "◆  " + LocaleHelper.t(c, "api_card")
        binding.tvAssignApi.text = LocaleHelper.t(c, "assign_api")
        binding.tvAreasLabel.text = LocaleHelper.t(c, "areas_label")
        binding.tvQuestions.text = LocaleHelper.t(c, "questions")
        binding.tvOptions.text = LocaleHelper.t(c, "options")
        binding.tvFloatLabel.text = LocaleHelper.t(c, "float_label")
        binding.tvTutorial.text = LocaleHelper.t(c, "tutorial")
        try { binding.tvDonationLabel.text = LocaleHelper.t(c, "donation_label") } catch (_: Exception) {}
        binding.tvDonate.text = LocaleHelper.t(c, "donations")

        if (prefs.hasApiKey()) {
            binding.tvApiStatus.text = LocaleHelper.t(c, "api_ok")
            binding.tvApiStatus.setTextColor(0xFF00E676.toInt())
        } else {
            binding.tvApiStatus.text = LocaleHelper.t(c, "api_need")
            binding.tvApiStatus.setTextColor(0xFFFF5252.toInt())
        }

        if (TriviaService.isFloatVisible) {
            binding.tvShow.text = LocaleHelper.t(c, "hide")
            binding.iconShow.setImageResource(R.drawable.ic_notif_eye_off)
        } else {
            binding.tvShow.text = LocaleHelper.t(c, "show")
            binding.iconShow.setImageResource(R.drawable.ic_notif_eye)
        }

        if (Build.VERSION.SDK_INT >= 26) {
            binding.cardDonate.tooltipText = LocaleHelper.t(c, "donation_tooltip")
        }
    }

    private fun showHelp(title: String, body: String, imageRes: Int?) {
        binding.tvHelpTitle.text = title
        binding.tvHelpBody.text = body
        Linkify.addLinks(binding.tvHelpBody, Linkify.WEB_URLS)
        binding.tvHelpBody.movementMethod = LinkMovementMethod.getInstance()
        if (imageRes != null) {
            binding.imgHelp.setImageResource(imageRes)
            binding.imgHelp.visibility = View.VISIBLE
        } else {
            binding.imgHelp.visibility = View.GONE
        }
        binding.helpOverlay.visibility = View.VISIBLE
    }

    private fun openPaypal() {
        val uri = Uri.parse("https://www.paypal.me/randyrubi")
        // Intentar app de PayPal
        val appIntent = Intent(Intent.ACTION_VIEW, uri).apply {
            setPackage("com.paypal.android.p2pmobile")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            startActivity(appIntent)
        } catch (_: Exception) {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        }
    }

    private fun showLanguagePicker() {
        val labels = arrayOf(
            LocaleHelper.t(this, "lang_en"),
            LocaleHelper.t(this, "lang_es"),
            LocaleHelper.t(this, "lang_pt"),
            LocaleHelper.t(this, "lang_id")
        )
        val codes = arrayOf(LocaleHelper.EN, LocaleHelper.ES, LocaleHelper.PT, LocaleHelper.ID)
        AlertDialog.Builder(this)
            .setTitle(LocaleHelper.t(this, "language"))
            .setItems(labels) { _, which ->
                LocaleHelper.setLang(this, codes[which])
                applyStrings()
            }
            .show()
    }

    private fun ensureOverlay(): Boolean {
        if (Settings.canDrawOverlays(this)) return true
        AlertDialog.Builder(this)
            .setTitle(LocaleHelper.t(this, "overlay_title"))
            .setMessage(LocaleHelper.t(this, "overlay_msg"))
            .setPositiveButton(LocaleHelper.t(this, "overlay_allow")) { _, _ ->
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
            .setNegativeButton(LocaleHelper.t(this, "overlay_cancel"), null)
            .show()
        return false
    }

    private fun setupModeSwitch() {
        refreshModeUi()
        binding.cardMode.setOnClickListener {
            val next = if (prefs.isAccessibilityMode()) "ocr" else "a11y"
            if (next == "a11y" && !TriviaAccessibilityService.isEnabled()) {
                Toast.makeText(this, LocaleHelper.t(this, "mode_need_a11y"), Toast.LENGTH_LONG).show()
                try {
                    startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
                } catch (_: Exception) {}
            }
            prefs.setDetectionMode(next)
            refreshModeUi()
            val msg = if (next == "a11y") LocaleHelper.t(this, "mode_a11y_on")
                      else LocaleHelper.t(this, "mode_ocr_on")
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        }
        binding.cardMode.setOnLongClickListener {
            Toast.makeText(this, LocaleHelper.t(this, "mode_tooltip"), Toast.LENGTH_LONG).show()
            true
        }
        try {
            binding.cardMode.tooltipText = LocaleHelper.t(this, "mode_tooltip")
        } catch (_: Exception) {}
    }

    private fun refreshModeUi() {
        val a11y = prefs.isAccessibilityMode()
        binding.tvMode.text = LocaleHelper.t(this, if (a11y) "mode_a11y" else "mode_ocr")
        // Dim area buttons in a11y mode
        val alpha = if (a11y) 0.4f else 1f
        try {
            binding.cardQuestions.alpha = alpha
            binding.cardOptions.alpha = alpha
        } catch (_: Exception) {}
    }


    /**
     * Solo ADMIN: deslizar de derecha → izquierda (borde derecho).
     * Usa dispatchTouchEvent para que el ScrollView no se coma el gesto.
     */
    private fun setupAdminSwipe() {
        // El gesto real está en dispatchTouchEvent.
        // Aquí solo refrescamos el rol por si lo cambiaste en Supabase.
        Thread {
            try {
                val role = SupabaseBanClient.getUserRole(prefs.getUserUid())
                if (role.isNotBlank() && role != prefs.getUserRole()) {
                    prefs.saveUserSession(
                        prefs.getUserUid(),
                        prefs.getUserEmail(),
                        prefs.getUserNombre(),
                        "APPROVED",
                        role
                    )
                }
            } catch (_: Exception) { }
        }.start()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (::prefs.isInitialized && prefs.isApproved()) {
            val w = resources.displayMetrics.widthPixels.coerceAtLeast(1)
            val edge = w * 0.18f // 18% derecho de la pantalla
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    edgeSwipeTracking = ev.x >= (w - edge)
                    edgeSwipeStartX = ev.x
                    edgeSwipeStartY = ev.y
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (edgeSwipeTracking) {
                        val dx = ev.x - edgeSwipeStartX
                        val dy = ev.y - edgeSwipeStartY
                        // derecha → izquierda
                        if (dx < -80 && kotlin.math.abs(dx) > kotlin.math.abs(dy) * 1.1f) {
                            tryOpenAdminPanel()
                        }
                    }
                    edgeSwipeTracking = false
                }
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun tryOpenAdminPanel() {
        // Relee rol desde Supabase por si acabas de ponerte ADMIN
        Thread {
            val role = try {
                SupabaseBanClient.getUserRole(prefs.getUserUid())
            } catch (_: Exception) {
                prefs.getUserRole()
            }
            if (role.isNotBlank()) {
                prefs.saveUserSession(
                    prefs.getUserUid(),
                    prefs.getUserEmail(),
                    prefs.getUserNombre(),
                    "APPROVED",
                    role
                )
            }
            val isAdmin = role.equals("ADMIN", ignoreCase = true) ||
                prefs.getUserRole().equals("ADMIN", ignoreCase = true)
            runOnUiThread {
                if (isAdmin) {
                    startActivity(Intent(this, AdminActivity::class.java))
                } else {
                    // Silencioso: no eres admin (evita molestar a usuarios normales)
                }
            }
        }.start()
    }


}
