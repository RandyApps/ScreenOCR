package com.triviahelper.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.triviahelper.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: PrefsHelper

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            updateUI()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefs = PrefsHelper(this)

        if (intent?.getBooleanExtra("EXIT", false) == true) {
            finishAffinity()
            return
        }

        if (prefs.hasApiKey()) {
            binding.etApiKey.setText("••••••••" + prefs.getApiKey().takeLast(4))
            binding.etApiKey.hint = "Clave guardada (pega una nueva para cambiarla)"
        }

        binding.btnSaveApi.setOnClickListener {
            val raw = binding.etApiKey.text.toString().trim()
            if (raw.isEmpty() || raw.startsWith("••")) {
                Toast.makeText(this, "Escribe o pega una clave nueva", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            prefs.saveApiKey(raw)
            binding.etApiKey.setText("••••••••" + raw.takeLast(4))
            Toast.makeText(this, "Clave guardada", Toast.LENGTH_SHORT).show()
        }

        binding.btnAreaQuestion.setOnClickListener {
            if (!ensureOverlay()) return@setOnClickListener
            startForegroundService(Intent(this, TriviaService::class.java).apply {
                action = TriviaService.ACTION_SELECT_QUESTION
            })
            moveTaskToBack(true)
        }

        binding.btnAreaOptions.setOnClickListener {
            if (!ensureOverlay()) return@setOnClickListener
            startForegroundService(Intent(this, TriviaService::class.java).apply {
                action = TriviaService.ACTION_SELECT_OPTIONS
            })
            moveTaskToBack(true)
        }

        binding.btnToggle.setOnClickListener {
            if (TriviaService.isRunning) {
                startService(Intent(this, TriviaService::class.java).apply {
                    action = TriviaService.ACTION_STOP
                })
            } else {
                if (!prefs.hasApiKey()) {
                    Toast.makeText(this, "Primero guarda tu clave API", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                if (!prefs.isAreasSet()) {
                    Toast.makeText(this, "Designa las áreas de pregunta y opciones", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                if (!ensureOverlay()) return@setOnClickListener
                startActivity(Intent(this, ScreenCaptureActivity::class.java))
            }
            binding.root.postDelayed({ updateUI() }, 400)
        }

        binding.btnShowFloat.setOnClickListener {
            if (!ensureOverlay()) return@setOnClickListener
            startForegroundService(Intent(this, TriviaService::class.java).apply {
                action = TriviaService.ACTION_TOGGLE_FLOAT
            })
        }
    }

    override fun onResume() {
        super.onResume()
        updateUI()
        val f = IntentFilter(TriviaService.ACTION_STATUS)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, f, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(receiver, f)
        }
    }

    override fun onPause() {
        super.onPause()
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
    }

    private fun updateUI() {
        binding.tvAnswer.text = prefs.getLastAnswer()
        binding.tvQuestionPreview.text = prefs.getLastQuestion()
        if (TriviaService.isRunning) {
            binding.btnToggle.text = "Detener ayuda"
            binding.btnToggle.backgroundTintList =
                ContextCompat.getColorStateList(this, R.color.red)
            binding.tvStatus.text = "Buscando respuestas…"
        } else {
            binding.btnToggle.text = "Iniciar ayuda"
            binding.btnToggle.backgroundTintList =
                ContextCompat.getColorStateList(this, R.color.green)
            binding.tvStatus.text = if (prefs.hasApiKey() && prefs.isAreasSet())
                "Listo para iniciar" else "Configura clave y áreas"
        }
    }

    private fun ensureOverlay(): Boolean {
        if (Settings.canDrawOverlays(this)) return true
        AlertDialog.Builder(this)
            .setTitle("Permiso de superposición")
            .setMessage("Necesario para la ventana flotante y designar áreas.")
            .setPositiveButton("Permitir") { _, _ ->
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
            .setNegativeButton("Cancelar", null)
            .show()
        return false
    }
}
