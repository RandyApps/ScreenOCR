package com.triviahelper.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.triviahelper.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: PrefsHelper

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            updateUI()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefs = PrefsHelper(this)

        if (intent?.getBooleanExtra("EXIT", false) == true) {
            finishAffinity()
            return
        }

        binding.cardApi.setOnClickListener {
            startActivity(Intent(this, ApiActivity::class.java))
        }

        binding.cardQuestions.setOnClickListener {
            if (!ensureOverlay()) return@setOnClickListener
            startForegroundService(Intent(this, TriviaService::class.java).apply {
                action = TriviaService.ACTION_SELECT_QUESTION
            })
            moveTaskToBack(true)
        }

        binding.cardOptions.setOnClickListener {
            if (!ensureOverlay()) return@setOnClickListener
            startForegroundService(Intent(this, TriviaService::class.java).apply {
                action = TriviaService.ACTION_SELECT_OPTIONS
            })
            moveTaskToBack(true)
        }

        binding.cardShow.setOnClickListener {
            if (!ensureOverlay()) return@setOnClickListener
            startForegroundService(Intent(this, TriviaService::class.java).apply {
                action = TriviaService.ACTION_SHOW_FLOAT
            })
            moveTaskToBack(true)
        }
    }

    override fun onResume() {
        super.onResume()
        updateUI()
        val f = IntentFilter(TriviaService.ACTION_STATUS)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, f, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(receiver, f)
        }
    }

    override fun onPause() {
        super.onPause()
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
    }

    private fun updateUI() {
        if (prefs.hasApiKey()) {
            binding.tvApiStatus.text = "API Asignada!"
            binding.tvApiStatus.setTextColor(0xFF00E676.toInt())
        } else {
            binding.tvApiStatus.text = "Se requiere una API!"
            binding.tvApiStatus.setTextColor(0xFFFF5252.toInt())
        }
        if (TriviaService.isFloatVisible) {
            binding.tvShow.text = "Ocultar"
            binding.iconShow.setImageResource(R.drawable.ic_notif_eye_off)
        } else {
            binding.tvShow.text = "Mostrar"
            binding.iconShow.setImageResource(R.drawable.ic_notif_eye)
        }
    }

    private fun ensureOverlay(): Boolean {
        if (Settings.canDrawOverlays(this)) return true
        AlertDialog.Builder(this)
            .setTitle("Permiso de superposición")
            .setMessage("Necesario para la ventana flotante y designar áreas.")
            .setPositiveButton("Permitir") { _, _ ->
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
            .setNegativeButton("Cancelar", null)
            .show()
        return false
    }
}
