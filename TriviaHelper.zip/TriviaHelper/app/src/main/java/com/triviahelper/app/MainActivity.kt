package com.triviahelper.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.method.LinkMovementMethod
import android.text.util.Linkify
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.triviahelper.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: PrefsHelper

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            applyStrings()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        TriviaDatabase.init(this)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefs = PrefsHelper(this)

        if (intent?.getBooleanExtra("EXIT", false) == true) {
            finishAffinity()
            return
        }

        binding.btnAbout.setOnClickListener {
            showHelp(
                LocaleHelper.t(this, "about_title"),
                LocaleHelper.t(this, "about_body"),
                null
            )
        }
        binding.btnApiHelp.setOnClickListener {
            showHelp(
                LocaleHelper.t(this, "help_api_title"),
                LocaleHelper.t(this, "help_api_body"),
                null
            )
        }
        binding.btnHelpClose.setOnClickListener {
            binding.helpOverlay.visibility = View.GONE
        }
        // No cerrar al tocar el fondo oscuro ni el panel (solo la X)
        binding.helpOverlay.setOnClickListener { /* ignore */ }
        binding.helpOverlay.getChildAt(0)?.setOnClickListener { /* consume */ }

        binding.cardLanguage.setOnClickListener { showLanguagePicker() }

        binding.cardApi.setOnClickListener {
            startActivity(Intent(this, ApiActivity::class.java))
        }

        binding.cardQuestions.setOnClickListener {
            if (!ensureOverlay()) return@setOnClickListener
            startForegroundService(Intent(this, TriviaService::class.java).apply {
                action = TriviaService.ACTION_SELECT_QUESTION
            })
            moveTaskToBack(true)
        }

        binding.cardOptions.setOnClickListener {
            if (!ensureOverlay()) return@setOnClickListener
            startForegroundService(Intent(this, TriviaService::class.java).apply {
                action = TriviaService.ACTION_SELECT_OPTIONS
            })
            moveTaskToBack(true)
        }

        binding.cardShow.setOnClickListener {
            if (!ensureOverlay()) return@setOnClickListener
            if (TriviaService.isFloatVisible) {
                startService(Intent(this, TriviaService::class.java).apply {
                    action = TriviaService.ACTION_HIDE_FLOAT
                })
                binding.root.postDelayed({ applyStrings() }, 200)
            } else {
                startForegroundService(Intent(this, TriviaService::class.java).apply {
                    action = TriviaService.ACTION_SHOW_FLOAT
                    putExtra(TriviaService.EXTRA_CENTER_FLOAT, true)
                })
                moveTaskToBack(true)
            }
        }

        binding.cardTutorial.setOnClickListener {
            showHelp(
                LocaleHelper.t(this, "tutorial_title"),
                LocaleHelper.t(this, "tutorial_body"),
                R.drawable.illust_area
            )
        }

        binding.cardDonate.setOnClickListener {
            openPaypal()
        }
        binding.cardDonate.setOnLongClickListener {
            Toast.makeText(this, LocaleHelper.t(this, "donation_tooltip"), Toast.LENGTH_LONG).show()
            true
        }
        if (Build.VERSION.SDK_INT >= 26) {
            binding.cardDonate.tooltipText = LocaleHelper.t(this, "donation_tooltip")
        }
    }

    override fun onResume() {
        super.onResume()
        applyStrings()
        val f = IntentFilter(TriviaService.ACTION_STATUS)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, f, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(receiver, f)
        }
    }

    override fun onPause() {
        super.onPause()
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
    }

    private fun applyStrings() {
        val c = this
        binding.tvAppTitle.text = LocaleHelper.t(c, "app_name")
        binding.tvLanguage.text = LocaleHelper.t(c, "language")
        binding.tvApiLabel.text = "◆  " + LocaleHelper.t(c, "api_card")
        binding.tvAssignApi.text = LocaleHelper.t(c, "assign_api")
        binding.tvAreasLabel.text = LocaleHelper.t(c, "areas_label")
        binding.tvQuestions.text = LocaleHelper.t(c, "questions")
        binding.tvOptions.text = LocaleHelper.t(c, "options")
        binding.tvFloatLabel.text = LocaleHelper.t(c, "float_label")
        binding.tvTutorial.text = LocaleHelper.t(c, "tutorial")
        try { binding.tvDonationLabel.text = LocaleHelper.t(c, "donation_label") } catch (_: Exception) {}
        binding.tvDonate.text = LocaleHelper.t(c, "donations")

        if (prefs.hasApiKey()) {
            binding.tvApiStatus.text = LocaleHelper.t(c, "api_ok")
            binding.tvApiStatus.setTextColor(0xFF00E676.toInt())
        } else {
            binding.tvApiStatus.text = LocaleHelper.t(c, "api_need")
            binding.tvApiStatus.setTextColor(0xFFFF5252.toInt())
        }

        if (TriviaService.isFloatVisible) {
            binding.tvShow.text = LocaleHelper.t(c, "hide")
            binding.iconShow.setImageResource(R.drawable.ic_notif_eye_off)
        } else {
            binding.tvShow.text = LocaleHelper.t(c, "show")
            binding.iconShow.setImageResource(R.drawable.ic_notif_eye)
        }

        if (Build.VERSION.SDK_INT >= 26) {
            binding.cardDonate.tooltipText = LocaleHelper.t(c, "donation_tooltip")
        }
    }

    private fun showHelp(title: String, body: String, imageRes: Int?) {
        binding.tvHelpTitle.text = title
        binding.tvHelpBody.text = body
        Linkify.addLinks(binding.tvHelpBody, Linkify.WEB_URLS)
        binding.tvHelpBody.movementMethod = LinkMovementMethod.getInstance()
        if (imageRes != null) {
            binding.imgHelp.setImageResource(imageRes)
            binding.imgHelp.visibility = View.VISIBLE
        } else {
            binding.imgHelp.visibility = View.GONE
        }
        binding.helpOverlay.visibility = View.VISIBLE
    }

    private fun openPaypal() {
        val uri = Uri.parse("https://www.paypal.me/randyrubi")
        // Intentar app de PayPal
        val appIntent = Intent(Intent.ACTION_VIEW, uri).apply {
            setPackage("com.paypal.android.p2pmobile")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            startActivity(appIntent)
        } catch (_: Exception) {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        }
    }

    private fun showLanguagePicker() {
        val labels = arrayOf(
            LocaleHelper.t(this, "lang_en"),
            LocaleHelper.t(this, "lang_es"),
            LocaleHelper.t(this, "lang_pt"),
            LocaleHelper.t(this, "lang_id")
        )
        val codes = arrayOf(LocaleHelper.EN, LocaleHelper.ES, LocaleHelper.PT, LocaleHelper.ID)
        AlertDialog.Builder(this)
            .setTitle(LocaleHelper.t(this, "language"))
            .setItems(labels) { _, which ->
                LocaleHelper.setLang(this, codes[which])
                applyStrings()
            }
            .show()
    }

    private fun ensureOverlay(): Boolean {
        if (Settings.canDrawOverlays(this)) return true
        AlertDialog.Builder(this)
            .setTitle(LocaleHelper.t(this, "overlay_title"))
            .setMessage(LocaleHelper.t(this, "overlay_msg"))
            .setPositiveButton(LocaleHelper.t(this, "overlay_allow")) { _, _ ->
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
            .setNegativeButton(LocaleHelper.t(this, "overlay_cancel"), null)
            .show()
        return false
    }
}
