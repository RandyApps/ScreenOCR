package com.triviahelper.app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

/**
 * Full-screen lock when status is BANNED or DEVICE_BANNED.
 * Back does not return to the app main UI.
 */
class BannedActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_banned)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        finishAffinity()
    }
}
