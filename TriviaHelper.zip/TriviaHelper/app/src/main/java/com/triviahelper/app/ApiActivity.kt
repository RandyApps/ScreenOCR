package com.triviahelper.app

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.triviahelper.app.databinding.ActivityApiBinding

class ApiActivity : AppCompatActivity() {
    private lateinit var binding: ActivityApiBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityApiBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val prefs = PrefsHelper(this)
        if (prefs.hasApiKey()) {
            binding.etApiKey.hint = "Clave guardada. Pega una nueva para reemplazarla."
        }

        binding.btnSave.setOnClickListener {
            val key = binding.etApiKey.text.toString().trim()
            if (key.isEmpty()) {
                Toast.makeText(this, "Pega una clave API", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            prefs.saveApiKey(key)
            Toast.makeText(this, "API guardada", Toast.LENGTH_SHORT).show()
            finish()
        }
        binding.btnBack.setOnClickListener { finish() }
    }
}
