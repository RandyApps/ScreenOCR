package com.triviahelper.app

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.triviahelper.app.databinding.ActivityApiBinding

class ApiActivity : AppCompatActivity() {
    private lateinit var binding: ActivityApiBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityApiBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val prefs = PrefsHelper(this)
        binding.tvApiTitle.text = LocaleHelper.t(this, "api_title")
        binding.btnSave.text = LocaleHelper.t(this, "save")
        binding.btnBack.text = LocaleHelper.t(this, "back")
        binding.etApiKey.hint = if (prefs.hasApiKey())
            LocaleHelper.t(this, "api_saved_hint")
        else
            LocaleHelper.t(this, "api_hint")

        binding.btnSave.setOnClickListener {
            val key = binding.etApiKey.text.toString().trim()
            if (key.isEmpty()) {
                Toast.makeText(this, LocaleHelper.t(this, "api_toast_empty"), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            prefs.saveApiKey(key)
            Toast.makeText(this, LocaleHelper.t(this, "api_toast_ok"), Toast.LENGTH_SHORT).show()
            finish()
        }
        binding.btnBack.setOnClickListener { finish() }
    }
}
