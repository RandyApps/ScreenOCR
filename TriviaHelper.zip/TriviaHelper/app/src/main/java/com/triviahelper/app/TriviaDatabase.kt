package com.triviahelper.app

import android.content.Context
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Local trivia Q&A from assets/trivia_sheet.tsv.
 * ONLY exact question match (case/punctuation insensitive). No fuzzy/partial matching.
 */
object TriviaDatabase {

    data class SheetResult(
        val answer: String?,
        val confidence: Int,
        val accessError: String? = null
    )

    private data class QA(val a: String, val norm: String)

    /** norm question -> answer */
    @Volatile private var byNorm: Map<String, String>? = null
    private val loading = AtomicBoolean(false)

    fun init(context: Context) {
        if (byNorm != null && byNorm!!.isNotEmpty()) return
        if (!loading.compareAndSet(false, true)) return
        try {
            val map = LinkedHashMap<String, String>()
            context.applicationContext.assets.open("trivia_sheet.tsv")
                .bufferedReader(Charsets.UTF_8).use { br ->
                    br.forEachLine { line ->
                        val tab = line.indexOf('\t')
                        if (tab <= 0) return@forEachLine
                        val q = line.substring(0, tab).trim()
                        val a = line.substring(tab + 1).trim()
                        if (q.length < 5 || a.isEmpty()) return@forEachLine
                        if (a == "#N/A") return@forEachLine
                        val n = normalize(q)
                        if (n.isEmpty()) return@forEachLine
                        // first wins
                        if (!map.containsKey(n)) map[n] = a
                    }
                }
            byNorm = map
        } catch (e: Exception) {
            byNorm = emptyMap()
        } finally {
            loading.set(false)
        }
    }

    fun clearCache() { /* local sheet stays */ }

    fun size(): Int = byNorm?.size ?: 0

    /**
     * Exact match only on normalized question text.
     * Then answer must match one of the OCR options (or soft-contain).
     */
    fun findAnswer(question: String, options: List<String>): SheetResult {
        val map = byNorm
        if (map == null || map.isEmpty()) {
            return SheetResult(null, 0, "local_empty")
        }

        val qNorm = normalize(question)
        if (qNorm.length < 5) return SheetResult(null, 0, null)

        val answer = map[qNorm] ?: return SheetResult(null, 0, null)

        // Prefer option text that matches sheet answer
        val matched = matchToOption(answer, options)
        return if (matched != null) {
            SheetResult(matched, 100, null)
        } else {
            // Exact question found but OCR options don't include that answer
            SheetResult(null, 0, null)
        }
    }

    fun strictMatchOption(answer: String, options: List<String>): String? =
        matchToOption(answer, options)

    private fun matchToOption(answer: String, options: List<String>): String? {
        if (options.isEmpty()) return null
        val na = normalize(answer)
        if (na.isEmpty()) return null
        // exact
        options.firstOrNull { normalize(it) == na }?.let { return it }
        // contain either way (OCR partial)
        options.firstOrNull {
            val n = normalize(it)
            n.length >= 2 && (na == n || na.contains(n) || n.contains(na))
        }?.let { return it }
        return null
    }

    /** Lowercase, strip punctuation, collapse spaces — keeps words for exact compare. */
    private fun normalize(s: String): String {
        val sb = StringBuilder()
        var prevSpace = false
        for (ch in s.lowercase(Locale.US)) {
            when {
                ch.isLetterOrDigit() -> {
                    sb.append(ch)
                    prevSpace = false
                }
                ch == '-' || ch == '/' || ch.isWhitespace() -> {
                    if (!prevSpace) {
                        sb.append(' ')
                        prevSpace = true
                    }
                }
                ch == '?' || ch == '!' || ch == '"' || ch.code == 39 -> {
                    if (!prevSpace) {
                        sb.append(' ')
                        prevSpace = true
                    }
                }
                else -> {
                    // skip other punctuation
                }
            }
        }
        return sb.toString().trim()
    }
}
