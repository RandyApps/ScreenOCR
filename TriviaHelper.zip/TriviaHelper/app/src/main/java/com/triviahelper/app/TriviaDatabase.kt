package com.triviahelper.app

import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/**
 * Single Google Sheet Q&A lookup with fuzzy question match.
 * Failures never block the API path.
 */
object TriviaDatabase {

    data class SheetResult(
        val answer: String?,
        val confidence: Int,
        val accessError: String? = null // only real failures, not "empty"
    )

    private data class QA(val q: String, val a: String, val normTokens: Set<String>)

    private const val SHEET_URL =
        "https://docs.google.com/spreadsheets/d/1LI2IZbFr6MlXw12wJVotzX5M4TlN7UzK0c1wtTHaj4k/gviz/tq?tqx=out:csv"

    @Volatile private var cache: List<QA>? = null
    @Volatile private var lastError: String? = null
    @Volatile private var lastLoad = 0L

    fun findAnswer(question: String, options: List<String>): SheetResult {
        ensureLoaded()
        val list = cache
        if (list == null || list.isEmpty()) {
            // empty is not an "access error" for the user path — just miss
            return SheetResult(null, 0, lastError)
        }

        val qTokens = tokens(question)
        if (qTokens.isEmpty()) return SheetResult(null, 0, null)

        var best: QA? = null
        var bestScore = 0.0
        for (qa in list) {
            val score = jaccard(qTokens, qa.normTokens)
            if (score > bestScore) {
                bestScore = score
                best = qa
            }
        }
        // Require stronger match for sheets
        if (best == null || bestScore < 0.45) return SheetResult(null, 0, null)

        val matched = strictMatchOption(best.a, options) ?: return SheetResult(null, 0, null)
        val conf = (bestScore * 100).toInt().coerceIn(55, 98)
        return SheetResult(matched, conf, null)
    }

    /** Answer must be one of the options (case-insensitive / contains). */
    fun strictMatchOption(answer: String, options: List<String>): String? {
        val na = normalize(answer)
        if (na.isEmpty()) return null
        options.firstOrNull { normalize(it) == na }?.let { return it }
        options.firstOrNull {
            val n = normalize(it)
            n.length >= 2 && (na == n || na.contains(n) || n.contains(na))
        }?.let { return it }
        // last resort: high similarity only
        var best: String? = null
        var bestS = 0.0
        for (o in options) {
            val s = jaccard(tokens(answer), tokens(o))
            if (s > bestS) {
                bestS = s
                best = o
            }
        }
        return if (best != null && bestS >= 0.65) best else null
    }

    private fun ensureLoaded() {
        val now = System.currentTimeMillis()
        if (cache != null && now - lastLoad < 20 * 60 * 1000) return
        lastLoad = now
        val (list, err) = loadSheet(SHEET_URL)
        cache = list
        lastError = err
    }

    private fun loadSheet(url: String): Pair<List<QA>?, String?> {
        return try {
            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 4000
                readTimeout = 6000
                requestMethod = "GET"
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "Mozilla/5.0 TriviaHelper/1.1")
            }
            val code = conn.responseCode
            if (code !in 200..299) {
                conn.disconnect()
                return null to "HTTP $code"
            }
            val text = BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8)).use { it.readText() }
            conn.disconnect()
            if (text.contains("<!DOCTYPE html>", ignoreCase = true) ||
                text.contains("ServiceLogin") ||
                text.contains("accounts.google.com")
            ) {
                return null to "no_public_access"
            }
            val rows = parseCsv(text)
            val list = mutableListOf<QA>()
            for (row in rows) {
                if (row.isEmpty()) continue
                // Column A = question, B = answer (skip empty / notes)
                val q = row.getOrNull(0)?.trim().orEmpty()
                val a = row.getOrNull(1)?.trim().orEmpty()
                if (q.length < 8 || a.length < 1) continue
                if (q.contains("NOTE:", true) || q.contains("Discord", true)) continue
                if (q.equals("question", true) || q.equals("pregunta", true)) continue
                list.add(QA(q, a, tokens(q)))
            }
            if (list.isEmpty()) null to "empty" else list to null
        } catch (e: Exception) {
            null to (e.message ?: "network_error")
        }
    }

    private fun parseCsv(text: String): List<List<String>> {
        val rows = mutableListOf<List<String>>()
        val cur = mutableListOf<String>()
        val sb = StringBuilder()
        var inQuotes = false
        var i = 0
        while (i < text.length) {
            val c = text[i]
            when {
                c == '"' -> {
                    if (inQuotes && i + 1 < text.length && text[i + 1] == '"') {
                        sb.append('"'); i++
                    } else inQuotes = !inQuotes
                }
                c == ',' && !inQuotes -> {
                    cur.add(sb.toString()); sb.clear()
                }
                (c == '\n' || c == '\r') && !inQuotes -> {
                    if (c == '\r' && i + 1 < text.length && text[i + 1] == '\n') i++
                    cur.add(sb.toString()); sb.clear()
                    if (cur.any { it.isNotBlank() }) rows.add(cur.toList())
                    cur.clear()
                }
                else -> sb.append(c)
            }
            i++
        }
        if (sb.isNotEmpty() || cur.isNotEmpty()) {
            cur.add(sb.toString())
            if (cur.any { it.isNotBlank() }) rows.add(cur.toList())
        }
        return rows
    }

    private fun normalize(s: String): String {
        val sb = StringBuilder()
        var prevSpace = false
        for (ch in s.lowercase(Locale.US)) {
            val c = if (ch == '¿' || ch == '?') ' ' else ch
            if (c.isLetterOrDigit()) {
                sb.append(c); prevSpace = false
            } else if (c.isWhitespace()) {
                if (!prevSpace) sb.append(' ')
                prevSpace = true
            }
        }
        return sb.toString().trim()
    }

    private fun tokens(s: String): Set<String> {
        val stop = setOf(
            "the", "a", "an", "of", "in", "on", "at", "to", "for", "and", "or", "is", "was", "were",
            "what", "which", "who", "when", "where", "how", "did", "does", "do", "year", "won",
            "el", "la", "los", "las", "de", "en", "un", "una", "que", "cual", "quien", "quién",
            "año", "anos", "o", "y", "del", "por"
        )
        return normalize(s).split(" ").filter { it.length > 1 && it !in stop }.toSet()
    }

    private fun jaccard(a: Set<String>, b: Set<String>): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        val inter = a.intersect(b).size.toDouble()
        val uni = a.union(b).size.toDouble()
        return if (uni == 0.0) 0.0 else inter / uni
    }
}
