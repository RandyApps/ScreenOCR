package com.triviahelper.app

import android.content.Context
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Local trivia Q&A loaded from assets/trivia_sheet.tsv (bundled sheet).
 * No network required for sheet lookup — instant after first load.
 */
object TriviaDatabase {

    data class SheetResult(
        val answer: String?,
        val confidence: Int,
        val accessError: String? = null
    )

    private data class QA(val q: String, val a: String, val norm: String, val tokens: Set<String>)

    @Volatile private var cache: List<QA>? = null
    private val loading = AtomicBoolean(false)

    /** Load TSV from assets once. Safe to call multiple times. */
    fun init(context: Context) {
        if (cache != null && cache!!.isNotEmpty()) return
        if (!loading.compareAndSet(false, true)) return
        try {
            val list = mutableListOf<QA>()
            context.applicationContext.assets.open("trivia_sheet.tsv").bufferedReader(Charsets.UTF_8).use { br ->
                for (line in br) {
                    val tab = line.indexOf('\t')
                    if (tab <= 0) continue
                    val q = line.substring(0, tab).trim()
                    val a = line.substring(tab + 1).trim()
                    if (q.length < 8 || a.isEmpty()) continue
                    list.add(QA(q, a, normalize(q), tokens(q)))
                }
            }
            cache = list
        } catch (e: Exception) {
            cache = emptyList()
        } finally {
            loading.set(false)
        }
    }

    fun clearCache() {
        // Keep local data; only used if we ever reload. Local sheet stays.
    }

    fun size(): Int = cache?.size ?: 0

    fun findAnswer(question: String, options: List<String>): SheetResult {
        val list = cache
        if (list == null || list.isEmpty()) {
            return SheetResult(null, 0, "local_empty")
        }

        val qNorm = normalize(question)
        val qTokens = tokens(question)
        if (qTokens.isEmpty() && qNorm.length < 8) return SheetResult(null, 0, null)

        // Exact normalized match
        list.firstOrNull { it.norm == qNorm }?.let { qa ->
            val matched = strictMatchOption(qa.a, options)
            if (matched != null) return SheetResult(matched, 99, null)
            // Question exact but options OCR weak: still return sheet answer if only one option close
            return SheetResult(qa.a, 90, null).let { r ->
                val m = strictMatchOption(qa.a, options)
                if (m != null) SheetResult(m, 99, null) else {
                    // Try softer option match
                    softMatchOption(qa.a, options)?.let { SheetResult(it, 85, null) }
                        ?: SheetResult(null, 0, null)
                }
            }
        }

        // Contains either way
        list.firstOrNull {
            qNorm.length >= 12 && (it.norm.contains(qNorm) || qNorm.contains(it.norm)) && itLenOk(it.norm, qNorm)
        }?.let { qa ->
            softMatchOption(qa.a, options)?.let { return SheetResult(it, 92, null) }
        }

        // Fuzzy
        var best: QA? = null
        var bestScore = 0.0
        for (qa in list) {
            val jac = jaccard(qTokens, qa.tokens)
            val coverage = if (qTokens.isEmpty()) 0.0
            else qTokens.intersect(qa.tokens).size.toDouble() / qTokens.size
            val score = maxOf(jac, coverage * 0.95)
            if (score > bestScore) {
                bestScore = score
                best = qa
            }
        }
        if (best == null || bestScore < 0.35) return SheetResult(null, 0, null)

        val matched = softMatchOption(best.a, options) ?: return SheetResult(null, 0, null)
        return SheetResult(matched, (bestScore * 100).toInt().coerceIn(50, 97), null)
    }

    private fun itLenOk(a: String, b: String): Boolean {
        val shorter = minOf(a.length, b.length).toDouble()
        val longer = maxOf(a.length, b.length).toDouble()
        return shorter / longer >= 0.55
    }

    fun strictMatchOption(answer: String, options: List<String>): String? {
        val na = normalize(answer)
        if (na.isEmpty()) return null
        options.firstOrNull { normalize(it) == na }?.let { return it }
        options.firstOrNull {
            val n = normalize(it)
            n.length >= 1 && (na == n || na.contains(n) || n.contains(na))
        }?.let { return it }
        return null
    }

    /** Softer match for OCR option text. */
    private fun softMatchOption(answer: String, options: List<String>): String? {
        strictMatchOption(answer, options)?.let { return it }
        val na = normalize(answer)
        var best: String? = null
        var bestS = 0.0
        for (o in options) {
            val s = jaccard(tokens(answer), tokens(o))
            if (s > bestS) {
                bestS = s
                best = o
            }
        }
        if (best != null && bestS >= 0.45) return best
        // partial: any option token fully inside answer or vice versa
        for (o in options) {
            val n = normalize(o)
            if (n.length >= 3 && (na.contains(n) || n.contains(na))) return o
        }
        return null
    }

    private fun normalize(s: String): String {
        val sb = StringBuilder()
        var prevSpace = false
        for (ch in s.lowercase(Locale.US)) {
            val c = if (ch == '¿' || ch == '?') ' ' else ch
            if (c.isLetterOrDigit()) {
                sb.append(c); prevSpace = false
            } else if (c.isWhitespace()) {
                if (!prevSpace) sb.append(' ')
                prevSpace = true
            }
        }
        return sb.toString().trim()
    }

    private fun tokens(s: String): Set<String> {
        val stop = setOf(
            "the", "a", "an", "of", "in", "on", "at", "to", "for", "and", "or", "is", "was", "were",
            "what", "which", "who", "when", "where", "how", "did", "does", "do", "year", "won",
            "el", "la", "los", "las", "de", "en", "un", "una", "que", "cual", "quien",
            "año", "anos", "o", "y", "del", "por", "from", "most", "had", "has", "have", "not"
        )
        return normalize(s).split(" ").filter { it.length > 1 && it !in stop }.toSet()
    }

    private fun jaccard(a: Set<String>, b: Set<String>): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        val inter = a.intersect(b).size.toDouble()
        val uni = a.union(b).size.toDouble()
        return if (uni == 0.0) 0.0 else inter / uni
    }
}
