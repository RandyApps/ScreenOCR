package com.triviahelper.app

import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/**
 * Loads Q&A from Google Sheet via gviz JSON (more reliable than CSV).
 */
object TriviaDatabase {

    data class SheetResult(
        val answer: String?,
        val confidence: Int,
        val accessError: String? = null
    )

    private data class QA(val q: String, val a: String, val norm: String, val tokens: Set<String>)

    private const val SHEET_JSON =
        "https://docs.google.com/spreadsheets/d/1LI2IZbFr6MlXw12wJVotzX5M4TlN7UzK0c1wtTHaj4k/gviz/tq?tqx=out:json"
    private const val SHEET_CSV =
        "https://docs.google.com/spreadsheets/d/1LI2IZbFr6MlXw12wJVotzX5M4TlN7UzK0c1wtTHaj4k/gviz/tq?tqx=out:csv"

    @Volatile private var cache: List<QA>? = null
    @Volatile private var lastError: String? = null
    @Volatile private var lastLoad = 0L

    fun clearCache() {
        cache = null
        lastError = null
        lastLoad = 0L
    }

    fun findAnswer(question: String, options: List<String>): SheetResult {
        ensureLoaded()
        val list = cache
        if (list == null || list.isEmpty()) {
            return SheetResult(null, 0, lastError)
        }

        val qNorm = normalize(question)
        val qTokens = tokens(question)
        if (qTokens.isEmpty() && qNorm.length < 8) return SheetResult(null, 0, null)

        // 1) Exact / near-exact normalized match
        list.firstOrNull { it.norm == qNorm }?.let { qa ->
            val matched = strictMatchOption(qa.a, options)
            if (matched != null) return SheetResult(matched, 98, null)
        }
        list.firstOrNull { it.norm.contains(qNorm) || qNorm.contains(it.norm) }?.let { qa ->
            if (qNorm.length >= 12 && itLenOk(qa.norm, qNorm)) {
                val matched = strictMatchOption(qa.a, options)
                if (matched != null) return SheetResult(matched, 92, null)
            }
        }

        // 2) Fuzzy token score
        var best: QA? = null
        var bestScore = 0.0
        for (qa in list) {
            val jac = jaccard(qTokens, qa.tokens)
            val coverage = if (qTokens.isEmpty()) 0.0
            else qTokens.intersect(qa.tokens).size.toDouble() / qTokens.size
            val score = maxOf(jac, coverage * 0.95)
            if (score > bestScore) {
                bestScore = score
                best = qa
            }
        }
        // Coverage 0.55 or jaccard 0.35 is enough for reworded questions
        if (best == null || bestScore < 0.35) return SheetResult(null, 0, null)

        val matched = strictMatchOption(best.a, options) ?: return SheetResult(null, 0, null)
        val conf = (bestScore * 100).toInt().coerceIn(50, 97)
        return SheetResult(matched, conf, null)
    }

    private fun itLenOk(a: String, b: String): Boolean {
        val shorter = minOf(a.length, b.length).toDouble()
        val longer = maxOf(a.length, b.length).toDouble()
        return shorter / longer >= 0.55
    }

    fun strictMatchOption(answer: String, options: List<String>): String? {
        val na = normalize(answer)
        if (na.isEmpty()) return null
        options.firstOrNull { normalize(it) == na }?.let { return it }
        options.firstOrNull {
            val n = normalize(it)
            n.length >= 1 && (na == n || na.contains(n) || n.contains(na))
        }?.let { return it }
        var best: String? = null
        var bestS = 0.0
        for (o in options) {
            val s = jaccard(tokens(answer), tokens(o))
            if (s > bestS) {
                bestS = s
                best = o
            }
        }
        return if (best != null && bestS >= 0.55) best else null
    }

    private fun ensureLoaded() {
        val now = System.currentTimeMillis()
        if (cache != null && cache!!.isNotEmpty() && now - lastLoad < 30 * 60 * 1000) return
        if (cache != null && cache!!.isEmpty() && now - lastLoad < 60 * 1000) return
        lastLoad = now
        val (list, err) = loadJson()
        if (list != null && list.isNotEmpty()) {
            cache = list
            lastError = null
            return
        }
        val (list2, err2) = loadCsvFallback()
        cache = list2
        lastError = err2 ?: err
    }

    private fun loadJson(): Pair<List<QA>?, String?> {
        return try {
            val text = httpGet(SHEET_JSON) ?: return null to "network_error"
            if (text.contains("<!DOCTYPE html>", true) || text.contains("ServiceLogin")) {
                return null to "no_public_access"
            }
            val start = text.indexOf('{')
            val end = text.lastIndexOf('}')
            if (start < 0 || end <= start) return null to "bad_json"
            val json = JSONObject(text.substring(start, end + 1))
            val table = json.optJSONObject("table") ?: return null to "no_table"
            val rows = table.optJSONArray("rows") ?: return null to "no_rows"
            val list = mutableListOf<QA>()
            for (i in 0 until rows.length()) {
                val row = rows.optJSONObject(i) ?: continue
                val cells = row.optJSONArray("c") ?: continue
                val q = cellValue(cells, 0)
                val a = cellValue(cells, 1)
                if (q.length < 8 || a.isEmpty()) continue
                if (q.contains("NOTE:", true)) continue
                list.add(QA(q, a, normalize(q), tokens(q)))
            }
            if (list.isEmpty()) null to "empty" else list to null
        } catch (e: Exception) {
            null to (e.message ?: "json_error")
        }
    }

    private fun cellValue(cells: org.json.JSONArray, idx: Int): String {
        if (idx >= cells.length()) return ""
        val c = cells.optJSONObject(idx) ?: return ""
        val v = c.opt("v") ?: return ""
        return v.toString().trim()
    }

    private fun loadCsvFallback(): Pair<List<QA>?, String?> {
        return try {
            val text = httpGet(SHEET_CSV) ?: return null to "network_error"
            if (text.contains("<!DOCTYPE html>", true)) return null to "no_public_access"
            val list = mutableListOf<QA>()
            // Line-based: skip giant header, parse "q","a" lines
            for (line in text.split('\n')) {
                val parsed = parseCsvLine(line)
                if (parsed.size < 2) continue
                val q = parsed[0].trim()
                val a = parsed[1].trim()
                if (q.length < 8 || a.isEmpty()) continue
                if (q.startsWith("Question Adam Cole")) continue // broken header
                if (q.contains("NOTE:", true)) continue
                list.add(QA(q, a, normalize(q), tokens(q)))
            }
            if (list.isEmpty()) null to "empty" else list to null
        } catch (e: Exception) {
            null to (e.message ?: "csv_error")
        }
    }

    private fun parseCsvLine(line: String): List<String> {
        val out = mutableListOf<String>()
        val sb = StringBuilder()
        var inQ = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            when {
                c == '"' -> {
                    if (inQ && i + 1 < line.length && line[i + 1] == '"') {
                        sb.append('"'); i++
                    } else inQ = !inQ
                }
                c == ',' && !inQ -> {
                    out.add(sb.toString()); sb.clear()
                }
                else -> sb.append(c)
            }
            i++
        }
        out.add(sb.toString())
        return out
    }

    private fun httpGet(url: String): String? {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 8000
            readTimeout = 20000
            requestMethod = "GET"
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "Mozilla/5.0 TriviaHelper/1.2")
        }
        val code = conn.responseCode
        if (code !in 200..299) {
            conn.disconnect()
            return null
        }
        val text = BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8)).use { it.readText() }
        conn.disconnect()
        return text
    }

    private fun normalize(s: String): String {
        val sb = StringBuilder()
        var prevSpace = false
        for (ch in s.lowercase(Locale.US)) {
            val c = if (ch == '¿' || ch == '?') ' ' else ch
            if (c.isLetterOrDigit()) {
                sb.append(c); prevSpace = false
            } else if (c.isWhitespace()) {
                if (!prevSpace) sb.append(' ')
                prevSpace = true
            }
        }
        return sb.toString().trim()
    }

    private fun tokens(s: String): Set<String> {
        val stop = setOf(
            "the", "a", "an", "of", "in", "on", "at", "to", "for", "and", "or", "is", "was", "were",
            "what", "which", "who", "when", "where", "how", "did", "does", "do", "year", "won",
            "el", "la", "los", "las", "de", "en", "un", "una", "que", "cual", "quien",
            "año", "anos", "o", "y", "del", "por", "from", "most", "had", "has", "have", "not"
        )
        return normalize(s).split(" ").filter { it.length > 1 && it !in stop }.toSet()
    }

    private fun jaccard(a: Set<String>, b: Set<String>): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        val inter = a.intersect(b).size.toDouble()
        val uni = a.union(b).size.toDouble()
        return if (uni == 0.0) 0.0 else inter / uni
    }
}
