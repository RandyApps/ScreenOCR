package com.triviahelper.app

import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/**
 * Loads Q&A from Google Sheets and finds answers with fuzzy semantic match.
 */
object TriviaDatabase {

    data class SheetResult(
        val answer: String?,
        val confidence: Int, // 0-100
        val sheetIndex: Int, // 1 or 2
        val accessError: String? = null
    )

    private data class QA(val q: String, val a: String, val normTokens: Set<String>)

    private val sheetUrls = listOf(
        "https://docs.google.com/spreadsheets/d/1HN2YqBeE7we3fgAok2xDsKpH5RDAkD9BvA91pQ55iYk/gviz/tq?tqx=out:csv",
        "https://docs.google.com/spreadsheets/d/1EIa3fbShghHoyoXLHKG00JjibgTbQCvVZ4gHXD6RofA/gviz/tq?tqx=out:csv"
    )

    @Volatile private var cache1: List<QA>? = null
    @Volatile private var cache2: List<QA>? = null
    @Volatile private var err1: String? = null
    @Volatile private var err2: String? = null
    @Volatile private var lastLoad = 0L

    fun findAnswer(question: String, options: List<String>): SheetResult {
        ensureLoaded()
        // Sheet 1 first
        val r1 = searchIn(cache1, question, options, 1, err1)
        if (r1.answer != null) return r1
        // Sheet 2
        val r2 = searchIn(cache2, question, options, 2, err2)
        if (r2.answer != null) return r2
        // Prefer reporting access errors if both failed to load
        val access = when {
            err1 != null && err2 != null -> "sheet1+2: $err1 / $err2"
            err1 != null -> "sheet1: $err1"
            err2 != null -> "sheet2: $err2"
            else -> null
        }
        return SheetResult(null, 0, 0, access)
    }

    private fun searchIn(
        list: List<QA>?,
        question: String,
        options: List<String>,
        sheetIndex: Int,
        accessError: String?
    ): SheetResult {
        if (list == null || list.isEmpty()) {
            return SheetResult(null, 0, sheetIndex, accessError)
        }
        val qTokens = tokens(question)
        if (qTokens.isEmpty()) return SheetResult(null, 0, sheetIndex, null)

        var best: QA? = null
        var bestScore = 0.0
        for (qa in list) {
            val score = jaccard(qTokens, qa.normTokens)
            // also try containment bonus
            val bonus = if (qa.normTokens.containsAll(qTokens.take(4))) 0.15 else 0.0
            val s = score + bonus
            if (s > bestScore) {
                bestScore = s
                best = qa
            }
        }
        // Threshold for "same question, different wording"
        if (best == null || bestScore < 0.35) {
            return SheetResult(null, 0, sheetIndex, null)
        }
        val conf = (bestScore * 100).toInt().coerceIn(0, 99)
        val ans = best.a.trim()
        // Must match one of the trivia options
        val matched = matchOption(ans, options)
        return if (matched != null) {
            SheetResult(matched, max(conf, 70), sheetIndex, null)
        } else {
            // Found QA but answer not in options → treat as miss for this sheet
            SheetResult(null, 0, sheetIndex, null)
        }
    }

    private fun matchOption(answer: String, options: List<String>): String? {
        val na = normalize(answer)
        options.firstOrNull { normalize(it) == na }?.let { return it }
        options.firstOrNull {
            val n = normalize(it)
            n.isNotEmpty() && (na.contains(n) || n.contains(na))
        }?.let { return it }
        // fuzzy
        var best: String? = null
        var bestS = 0.0
        for (o in options) {
            val s = jaccard(tokens(answer), tokens(o))
            if (s > bestS) { bestS = s; best = o }
        }
        return if (best != null && bestS >= 0.5) best else null
    }

    private fun ensureLoaded() {
        val now = System.currentTimeMillis()
        if (cache1 != null && cache2 != null && now - lastLoad < 30 * 60 * 1000) return
        lastLoad = now
        val (l1, e1) = loadSheet(sheetUrls[0])
        val (l2, e2) = loadSheet(sheetUrls[1])
        cache1 = l1
        cache2 = l2
        err1 = e1
        err2 = e2
    }

    private fun loadSheet(url: String): Pair<List<QA>?, String?> {
        return try {
            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 10000
                readTimeout = 15000
                requestMethod = "GET"
                setRequestProperty("User-Agent", "TriviaHelper/1.0")
            }
            val code = conn.responseCode
            if (code !in 200..299) {
                conn.disconnect()
                return null to "HTTP $code"
            }
            val text = BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8)).use { it.readText() }
            conn.disconnect()
            if (text.contains("<!DOCTYPE html>", ignoreCase = true) || text.contains("ServiceLogin")) {
                return null to "login_required"
            }
            val rows = parseCsv(text)
            val list = mutableListOf<QA>()
            for (row in rows) {
                if (row.size < 2) continue
                val q = row[0].trim()
                val a = row[1].trim()
                if (q.length < 8 || a.length < 1) continue
                if (q.contains("NOTE:", true) || q.contains("Discord", true)) continue
                list.add(QA(q, a, tokens(q)))
            }
            if (list.isEmpty()) null to "empty" else list to null
        } catch (e: Exception) {
            null to (e.message ?: "network_error")
        }
    }

    private fun parseCsv(text: String): List<List<String>> {
        val rows = mutableListOf<List<String>>()
        val cur = mutableListOf<String>()
        val sb = StringBuilder()
        var inQuotes = false
        var i = 0
        while (i < text.length) {
            val c = text[i]
            when {
                c == '"' -> {
                    if (inQuotes && i + 1 < text.length && text[i + 1] == '"') {
                        sb.append('"'); i++
                    } else inQuotes = !inQuotes
                }
                c == ',' && !inQuotes -> {
                    cur.add(sb.toString()); sb.clear()
                }
                (c == '\n' || c == '\r') && !inQuotes -> {
                    if (c == '\r' && i + 1 < text.length && text[i + 1] == '\n') i++
                    cur.add(sb.toString()); sb.clear()
                    if (cur.any { it.isNotBlank() }) rows.add(cur.toList())
                    cur.clear()
                }
                else -> sb.append(c)
            }
            i++
        }
        if (sb.isNotEmpty() || cur.isNotEmpty()) {
            cur.add(sb.toString())
            if (cur.any { it.isNotBlank() }) rows.add(cur.toList())
        }
        return rows
    }

    private fun normalize(s: String): String {
        val sb = StringBuilder()
        var prevSpace = false
        for (ch in s.lowercase(Locale.US)) {
            val c = if (ch == '¿' || ch == '?') ' ' else ch
            if (c.isLetterOrDigit()) {
                sb.append(c); prevSpace = false
            } else if (c.isWhitespace() || c == ' ') {
                if (!prevSpace) sb.append(' ')
                prevSpace = true
            }
        }
        return sb.toString().trim()
    }

    private fun tokens(s: String): Set<String> {
        val stop = setOf(
            "the", "a", "an", "of", "in", "on", "at", "to", "for", "and", "or", "is", "was",
            "what", "which", "who", "when", "where", "how", "did", "does", "do", "year",
            "el", "la", "los", "las", "de", "en", "un", "una", "que", "cual", "quién",
            "año", "anos", "debut", "o", "y"
        )
        return normalize(s).split(" ").filter { it.length > 1 && it !in stop }.toSet()
    }

    private fun jaccard(a: Set<String>, b: Set<String>): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        val inter = a.intersect(b).size.toDouble()
        val uni = a.union(b).size.toDouble()
        return if (uni == 0.0) 0.0 else inter / uni
    }
}
