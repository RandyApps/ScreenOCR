package com.triviahelper.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import java.lang.ref.WeakReference
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Polling ~3s: ban + rol + heartbeat.
 * Tablas cerradas con RLS → no hay postgres Realtime con anon;
 * este watcher da efecto "en tiempo real" para ban/rol.
 */
object SessionRealtimeWatcher {
    private val running = AtomicBoolean(false)
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private var activityRef: WeakReference<Activity>? = null
    private var appCtx: Context? = null

    private val tick = object : Runnable {
        override fun run() {
            if (!running.get()) return
            val ctx = appCtx ?: return
            executor.execute {
                try {
                    val prefs = PrefsHelper(ctx)
                    val uid = prefs.getUserUid()
                    val deviceId = DeviceIdHelper.get(ctx)
                    if (uid.isBlank()) return@execute

                    try { SupabaseBanClient.heartbeat(uid) } catch (_: Exception) {}

                    val ban = try {
                        SupabaseBanClient.checkIfBanned(deviceId, uid)
                    } catch (_: Exception) {
                        SupabaseBanClient.BanResult(false)
                    }
                    if (ban.banned) {
                        val status = if (ban.kind == "DEVICE") "DEVICE_BANNED" else "BANNED"
                        prefs.saveUserSession(
                            uid, prefs.getUserEmail(), prefs.getUserNombre(), status, prefs.getUserRole()
                        )
                        main.post {
                            val act = activityRef?.get()
                            val c = act ?: ctx
                            // Stop detection if running
                            try {
                                c.startService(Intent(c, TriviaService::class.java).apply {
                                    action = TriviaService.ACTION_STOP
                                })
                            } catch (_: Exception) {}
                            val i = Intent(c, BannedActivity::class.java).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                            }
                            c.startActivity(i)
                            act?.finishAffinity()
                        }
                        return@execute
                    }

                    val role = try {
                        SupabaseBanClient.getUserRole(uid)
                    } catch (_: Exception) {
                        prefs.getUserRole()
                    }
                    if (role.isNotBlank() && role != prefs.getUserRole()) {
                        prefs.saveUserSession(
                            uid, prefs.getUserEmail(), prefs.getUserNombre(), "APPROVED", role
                        )
                        main.post {
                            // Si perdió ADMIN y está en panel admin, se cierra ahí
                            val act = activityRef?.get()
                            if (act is AdminActivity && !role.equals("ADMIN", true)) {
                                act.finish()
                            }
                        }
                    }
                } catch (_: Exception) {
                }
            }
            main.postDelayed(this, 3500L)
        }
    }

    fun start(activity: Activity) {
        appCtx = activity.applicationContext
        activityRef = WeakReference(activity)
        if (running.compareAndSet(false, true)) {
            main.removeCallbacks(tick)
            main.post(tick)
        } else {
            activityRef = WeakReference(activity)
        }
    }

    fun attach(activity: Activity) {
        activityRef = WeakReference(activity)
        appCtx = activity.applicationContext
        if (!running.get()) start(activity)
    }

    fun stop() {
        running.set(false)
        main.removeCallbacks(tick)
    }
}
