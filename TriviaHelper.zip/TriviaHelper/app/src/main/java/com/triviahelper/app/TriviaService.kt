package com.triviahelper.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.*
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RemoteViews
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.concurrent.thread
import kotlin.math.max

class TriviaService : Service() {

    companion object {
        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
        const val ACTION_SELECT_QUESTION = "ACTION_SELECT_QUESTION"
        const val ACTION_SELECT_OPTIONS = "ACTION_SELECT_OPTIONS"
        const val ACTION_SHOW_FLOAT = "ACTION_SHOW_FLOAT"
        const val ACTION_HIDE_FLOAT = "ACTION_HIDE_FLOAT"
        const val ACTION_TOGGLE_FLOAT = "ACTION_TOGGLE_FLOAT"
        const val ACTION_CLOSE_FLOAT = "ACTION_CLOSE_FLOAT"
        const val ACTION_CLOSE_ALL = "ACTION_CLOSE_ALL"
        const val ACTION_STATUS = "com.triviahelper.app.STATUS"
        const val ACTION_REQUEST_START = "ACTION_REQUEST_START"

        @Volatile var isRunning = false
        @Volatile var isFloatVisible = false
        @Volatile var isSearching = false
        @Volatile var isShuttingDown = false
    }

    private lateinit var windowManager: WindowManager
    private lateinit var prefs: PrefsHelper
    private val mainHandler = Handler(Looper.getMainLooper())
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var ocrThread: HandlerThread? = null
    private var ocrHandler: Handler? = null

    private var screenWidth = 0
    private var screenHeight = 0
    private var densityDpi = 0

    private var floatView: View? = null
    private var floatParams: WindowManager.LayoutParams? = null
    private var tvFloatAnswer: TextView? = null
    private var dotsView: TextView? = null
    private var blinkRunnable: Runnable? = null
    private var dotsOn = true

    private var areaRoot: View? = null
    private var areaButtons: View? = null
    private var selectingQuestion = true
    private var boxLeft = 80
    private var boxTop = 200
    private var boxWidth = 600
    private var boxHeight = 200

    /** Preguntas ya respondidas en esta sesión (se limpia al reiniciar la app). */
    private val answeredQuestions = mutableSetOf<String>()

    private var busy = false
    private var quotaNotified = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = PrefsHelper(this)
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
        densityDpi = metrics.densityDpi
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (isShuttingDown) {
            try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) {}
            stopSelf()
            return START_NOT_STICKY
        }
        when (intent?.action) {
            ACTION_START -> {
                val code = intent.getIntExtra(ScreenCaptureActivity.EXTRA_RESULT_CODE, 0)
                val data = if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableExtra(ScreenCaptureActivity.EXTRA_RESULT_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(ScreenCaptureActivity.EXTRA_RESULT_DATA)
                }
                if (code != 0 && data != null) {
                    startForeground(2, buildNotification())
                    startLoop(code, data)
                }
            }
            ACTION_REQUEST_START -> {
                startForeground(2, buildNotification())
                if (!prefs.hasApiKey() || !prefs.isAreasSet()) {
                    startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } else {
                    startActivity(Intent(this, ScreenCaptureActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }
            ACTION_STOP -> stopLoop()
            ACTION_SELECT_QUESTION -> {
                startForeground(2, buildNotification())
                selectingQuestion = true
                showAreaSelector()
            }
            ACTION_SELECT_OPTIONS -> {
                startForeground(2, buildNotification())
                selectingQuestion = false
                showAreaSelector()
            }
            ACTION_SHOW_FLOAT -> {
                startForeground(2, buildNotification())
                isFloatVisible = true
                if (floatView == null) showFloat() else floatView?.visibility = View.VISIBLE
                updateNotification()
                broadcast()
            }
            ACTION_HIDE_FLOAT, ACTION_TOGGLE_FLOAT -> {
                if (floatView == null) {
                    startForeground(2, buildNotification())
                    showFloat()
                } else if (isFloatVisible) {
                    isFloatVisible = false
                    floatView?.visibility = View.GONE
                } else {
                    isFloatVisible = true
                    floatView?.visibility = View.VISIBLE
                }
                updateNotification()
                broadcast()
            }
            ACTION_CLOSE_FLOAT -> {
                // Solo detener detección y cerrar flotante (no app ni notificación)
                stopLoop()
                removeFloat()
                updateNotification()
                broadcast()
            }
            ACTION_CLOSE_ALL -> shutdownEverything()
            else -> startForeground(2, buildNotification())
        }
        return if (intent?.action == ACTION_CLOSE_ALL) START_NOT_STICKY else START_STICKY
    }

    private fun shutdownEverything() {
        isShuttingDown = true
        stopLoop()
        removeFloat()
        removeArea()
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) {}
        try {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.cancel(2)
            nm.cancelAll()
        } catch (_: Exception) {}
        try {
            startActivity(Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                putExtra("EXIT", true)
            })
        } catch (_: Exception) {}
        stopSelf()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel("trivia_ch", "Trivia Helper", NotificationManager.IMPORTANCE_LOW)
            )
            nm.createNotificationChannel(
                NotificationChannel("trivia_alert", "Trivia Alertas", NotificationManager.IMPORTANCE_HIGH)
            )
        }
    }

    private fun buildNotification(): Notification {
        fun pi(id: Int, action: String) = PendingIntent.getService(
            this, id, Intent(this, TriviaService::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val rv = RemoteViews(packageName, R.layout.notification_custom)
        rv.setTextViewText(R.id.notif_title, "Trivia Helper")
        rv.setTextViewText(
            R.id.notif_text,
            if (isRunning) "Buscando respuestas…" else "En espera"
        )
        if (isRunning) {
            rv.setImageViewResource(R.id.btn_notif_play, R.drawable.ic_notif_pause)
            rv.setOnClickPendingIntent(R.id.btn_notif_play, pi(1, ACTION_STOP))
        } else {
            rv.setImageViewResource(R.id.btn_notif_play, R.drawable.ic_notif_play)
            rv.setOnClickPendingIntent(R.id.btn_notif_play, pi(2, ACTION_REQUEST_START))
        }
        if (isFloatVisible) {
            rv.setImageViewResource(R.id.btn_notif_eye, R.drawable.ic_notif_eye)
            rv.setOnClickPendingIntent(R.id.btn_notif_eye, pi(3, ACTION_HIDE_FLOAT))
        } else {
            rv.setImageViewResource(R.id.btn_notif_eye, R.drawable.ic_notif_eye_off)
            rv.setOnClickPendingIntent(R.id.btn_notif_eye, pi(4, ACTION_SHOW_FLOAT))
        }
        rv.setOnClickPendingIntent(R.id.btn_notif_close, pi(5, ACTION_CLOSE_ALL))

        return NotificationCompat.Builder(this, "trivia_ch")
            .setSmallIcon(R.drawable.ic_notif_eye)
            .setCustomContentView(rv)
            .setCustomBigContentView(rv)
            .setStyle(NotificationCompat.DecoratedCustomViewStyle())
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setColor(Color.parseColor("#9C27FF"))
            .setContentIntent(
                PendingIntent.getActivity(
                    this, 10, Intent(this, MainActivity::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            )
            .build()
    }

    private fun updateNotification() {
        if (isShuttingDown) return
        try {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(2, buildNotification())
        } catch (_: Exception) {}
    }

    private fun notifyQuotaExhausted() {
        if (quotaNotified) return
        quotaNotified = true
        val n = NotificationCompat.Builder(this, "trivia_alert")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("Trivia Helper")
            .setContentText("Límite gratuito de la API alcanzado. No se pueden buscar más respuestas por ahora.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setColor(Color.parseColor("#FF5252"))
            .build()
        try {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(99, n)
        } catch (_: Exception) {}
    }

    private fun broadcast() {
        sendBroadcast(Intent(ACTION_STATUS).setPackage(packageName))
    }

    // ---------- OCR LOOP ----------
    private fun startLoop(resultCode: Int, data: Intent) {
        if (isRunning) return
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = mpm.getMediaProjection(resultCode, data)
        mediaProjection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { mainHandler.post { stopLoop() } }
        }, mainHandler)

        imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "TriviaHelper",
            screenWidth, screenHeight, densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, null
        )

        ocrThread = HandlerThread("trivia-ocr").also { it.start() }
        ocrHandler = Handler(ocrThread!!.looper)

        isRunning = true
        if (floatView == null) showFloat() else {
            isFloatVisible = true
            floatView?.visibility = View.VISIBLE
            refreshFloatIcons()
        }
        startBlink(searching = false)
        updateNotification()
        broadcast()

        ocrHandler?.post(object : Runnable {
            override fun run() {
                if (!isRunning) return
                captureAndSolve()
                ocrHandler?.postDelayed(this, 2500)
            }
        })
    }

    private fun stopLoop() {
        isRunning = false
        isSearching = false
        try { virtualDisplay?.release() } catch (_: Exception) {}
        try { imageReader?.close() } catch (_: Exception) {}
        try { mediaProjection?.stop() } catch (_: Exception) {}
        virtualDisplay = null
        imageReader = null
        mediaProjection = null
        ocrThread?.quitSafely()
        ocrThread = null
        ocrHandler = null
        stopBlink()
        refreshFloatIcons()
        updateNotification()
        broadcast()
    }


    /** True solo si el texto parece pregunta de trivia (termina en ?). */
    private fun isTriviaQuestion(text: String): Boolean {
        val t = text.trim()
        if (t.length < 10) return false
        // Debe contener signo de interrogación (OCR a veces deja espacios: "?")
        if (!t.contains('?')) return false
        // La última parte significativa debe terminar en ?
        val lastChunk = t.trimEnd().trimEnd('.', '!', '…', ' ')
        return lastChunk.endsWith('?') || t.indexOf('?') >= 8
    }

    private fun normalizeQuestion(text: String): String {
        return text.lowercase()
            .replace(Regex("[¿?]"), "?")
            .replace(Regex("[^a-z0-9?\\s]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun captureAndSolve() {
        if (busy) return
        val reader = imageReader ?: return
        val image = try { reader.acquireLatestImage() } catch (_: Exception) { null } ?: return
        try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * screenWidth
            val bitmap = Bitmap.createBitmap(
                screenWidth + rowPadding / pixelStride,
                screenHeight,
                Bitmap.Config.ARGB_8888
            )
            bitmap.copyPixelsFromBuffer(buffer)

            val qArea = prefs.getAreaQuestion() ?: return
            val oArea = prefs.getAreaOptions() ?: return

            fun crop(a: IntArray): Bitmap? {
                val l = a[0].coerceIn(0, bitmap.width - 1)
                val t = a[1].coerceIn(0, bitmap.height - 1)
                val r = a[2].coerceIn(l + 1, bitmap.width)
                val b = a[3].coerceIn(t + 1, bitmap.height)
                val w = r - l
                val h = b - t
                if (w < 20 || h < 20) return null
                return Bitmap.createBitmap(bitmap, l, t, w, h)
            }

            val qBmp = crop(qArea)
            val oBmp = crop(oArea)
            bitmap.recycle()
            if (qBmp == null || oBmp == null) {
                qBmp?.recycle(); oBmp?.recycle()
                return
            }

            val qImage = InputImage.fromBitmap(qBmp, 0)
            val oImage = InputImage.fromBitmap(oBmp, 0)

            recognizer.process(qImage)
                .addOnSuccessListener { qResult ->
                    val lines = qResult.textBlocks
                        .flatMap { it.lines }
                        .map { it.text.trim() }
                        .filter { it.isNotEmpty() }
                    // Preferir línea/texto que termine en ? (todas las trivias terminan así)
                    val withQ = lines.filter { it.contains('?') }
                    val questionRaw = when {
                        withQ.isNotEmpty() -> withQ.joinToString(" ")
                        else -> lines.joinToString(" ")
                    }.trim()
                    // Normalizar espacios
                    val question = questionRaw.replace(Regex("\\s+"), " ")

                    // Solo buscar si parece pregunta real de trivia
                    if (!isTriviaQuestion(question)) {
                        qBmp.recycle()
                        oBmp.recycle()
                        return@addOnSuccessListener
                    }

                    val qNorm = normalizeQuestion(question)
                    // Ya respondida en esta sesión → no volver a buscar
                    if (answeredQuestions.contains(qNorm)) {
                        qBmp.recycle()
                        oBmp.recycle()
                        return@addOnSuccessListener
                    }

                    recognizer.process(oImage)
                        .addOnSuccessListener { oResult ->
                            val options = oResult.textBlocks
                                .flatMap { it.lines }
                                .map { it.text.trim() }
                                .filter { it.length > 1 }
                                .distinct()
                            qBmp.recycle()
                            oBmp.recycle()
                            if (options.isEmpty()) return@addOnSuccessListener
                            // Marcar antes de buscar para evitar dobles por OCR repetido
                            answeredQuestions.add(qNorm)
                            askGemini(question, options)
                        }
                        .addOnFailureListener { qBmp.recycle(); oBmp.recycle() }
                }
                .addOnFailureListener { qBmp.recycle(); oBmp.recycle() }
        } catch (_: Exception) {
        } finally {
            image.close()
        }
    }

    private fun askGemini(question: String, options: List<String>) {
        if (busy) return
        busy = true
        isSearching = true
        mainHandler.post {
            startBlink(searching = true)
            tvFloatAnswer?.text = "…"
        }
        val key = prefs.getApiKey()
        thread {
            val answer = try {
                GeminiClient.findAnswer(key, question, options)
            } catch (e: Exception) {
                "Error: ${e.message}"
            }
            mainHandler.post {
                busy = false
                isSearching = false
                stopBlink()
                if (answer.startsWith("Error") || answer.contains("HTTP")) {
                    // Falló: permitir reintento de esta pregunta
                    answeredQuestions.remove(normalizeQuestion(question))
                }
                if (answer.contains("429") || answer.contains("quota", true) ||
                    answer.contains("RESOURCE_EXHAUSTED", true) ||
                    answer.contains("limit", true)
                ) {
                    notifyQuotaExhausted()
                }
                prefs.saveLastAnswer(answer, question.take(120))
                tvFloatAnswer?.text = answer
                broadcast()
            }
        }
    }

    // ---------- FLOAT WINDOW ----------
    private fun showFloat() {
        if (floatView != null) {
            floatView?.visibility = View.VISIBLE
            isFloatVisible = true
            refreshFloatIcons()
            return
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F0121220"))
                cornerRadius = 22f
                setStroke(3, Color.parseColor("#7C4DFF"))
            }
            setPadding(28, 32, 28, 32)
            elevation = 24f
            minimumWidth = 400
            minimumHeight = 220
        }

        // Header: RESPUESTA + dots
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(TextView(this).apply {
            text = "RESPUESTA"
            setTextColor(Color.parseColor("#B388FF"))
            textSize = 12f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        dotsView = TextView(this).apply {
            text = "  ● ● ●"
            setTextColor(Color.parseColor("#FF5252"))
            textSize = 11f
            setPadding(10, 0, 0, 0)
        }
        header.addView(dotsView)
        root.addView(header)

        tvFloatAnswer = TextView(this).apply {
            text = prefs.getLastAnswer().ifBlank { "—" }
            setTextColor(Color.parseColor("#00E676"))
            textSize = 20f
            setPadding(0, 12, 0, 16)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        root.addView(tvFloatAnswer)

        // Icons row
        val icons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        fun iconBtn(res: Int, tint: Int? = Color.parseColor("#E040FB"), onClick: () -> Unit): FrameLayout {
            val size = 72
            val frame = FrameLayout(this).apply {
                layoutParams = LinearLayout.LayoutParams(size, size).apply {
                    marginStart = 8; marginEnd = 8
                }
            }
            frame.addView(View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor("#88B0B0B0"))
                    setStroke(2, Color.parseColor("#DDFFFFFF"))
                }
                layoutParams = FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            })
            frame.addView(ImageView(this).apply {
                setImageResource(res)
                if (tint != null) setColorFilter(tint) else clearColorFilter()
                setPadding(16, 16, 16, 16)
                layoutParams = FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
                isClickable = true
                isFocusable = true
                setOnClickListener { onClick() }
            })
            return frame
        }

        // Play / Pause
        val playRes = if (isRunning) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        val playBtn = iconBtn(playRes) {
            if (isRunning) stopLoop()
            else startActivity(Intent(this, ScreenCaptureActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        playBtn.tag = "play"
        icons.addView(playBtn)

        // P - questions area
        icons.addView(iconBtn(R.drawable.ic_scope_p, null) {
            selectingQuestion = true
            showAreaSelector()
        })

        // O - options area
        icons.addView(iconBtn(R.drawable.ic_scope_o, null) {
            selectingQuestion = false
            showAreaSelector()
        })

        // Gear -> volver a la app
        icons.addView(iconBtn(R.drawable.ic_gear) {
            startActivity(Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            })
        })

        // X close float only
        icons.addView(iconBtn(android.R.drawable.ic_menu_close_clear_cancel) {
            stopLoop()
            removeFloat()
            updateNotification()
            broadcast()
        })

        root.addView(icons)

        floatParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 120
        }

        var ix = 0; var iy = 0; var tx = 0f; var ty = 0f
        root.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    ix = floatParams!!.x; iy = floatParams!!.y
                    tx = e.rawX; ty = e.rawY; true
                }
                MotionEvent.ACTION_MOVE -> {
                    floatParams!!.x = ix + (e.rawX - tx).toInt()
                    floatParams!!.y = iy + (e.rawY - ty).toInt()
                    try { windowManager.updateViewLayout(floatView, floatParams) } catch (_: Exception) {}
                    true
                }
                else -> false
            }
        }

        floatView = root
        isFloatVisible = true
        try { windowManager.addView(root, floatParams) } catch (_: Exception) {}
        startBlink(searching = isSearching)
    }

    private fun refreshFloatIcons() {
        // Rebuild float content without removing window if possible
        if (floatView == null) return
        removeFloat()
        showFloat()
    }

    private fun startBlink(searching: Boolean) {
        stopBlink()
        val color = if (searching) Color.parseColor("#00E676") else Color.parseColor("#FF5252")
        dotsView?.setTextColor(color)
        dotsView?.visibility = View.VISIBLE
        blinkRunnable = object : Runnable {
            override fun run() {
                dotsOn = !dotsOn
                dotsView?.alpha = if (dotsOn) 1f else 0.25f
                mainHandler.postDelayed(this, 450)
            }
        }
        mainHandler.post(blinkRunnable!!)
    }

    private fun stopBlink() {
        blinkRunnable?.let { mainHandler.removeCallbacks(it) }
        blinkRunnable = null
        dotsView?.alpha = 1f
        dotsView?.visibility = View.INVISIBLE
    }

    private fun removeFloat() {
        stopBlink()
        floatView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        floatView = null
        tvFloatAnswer = null
        dotsView = null
        isFloatVisible = false
    }

    // ---------- AREA SELECTOR (does not remove float) ----------
    private fun showAreaSelector() {
        if (areaRoot != null) return
        prefs.let {
            val a = if (selectingQuestion) it.getAreaQuestion() else it.getAreaOptions()
            if (a != null) {
                boxLeft = a[0]; boxTop = a[1]
                boxWidth = (a[2] - a[0]).coerceAtLeast(120)
                boxHeight = (a[3] - a[1]).coerceAtLeast(80)
            }
        }
        val hs = 48
        val pad = hs / 2
        val root = FrameLayout(this)
        val box = View(this).apply {
            background = GradientDrawable().apply {
                setStroke(5, Color.parseColor(if (selectingQuestion) "#448AFF" else "#00E676"))
                setColor(Color.parseColor("#33000000"))
            }
        }
        fun handle() = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#B388FF"))
            }
        }
        val hTL = handle(); val hTR = handle(); val hBL = handle(); val hBR = handle()
        root.addView(box); root.addView(hTL); root.addView(hTR); root.addView(hBL); root.addView(hBR)

        val boxParams = WindowManager.LayoutParams(
            boxWidth + hs, boxHeight + hs,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (boxLeft - pad).coerceAtLeast(0)
            y = (boxTop - pad).coerceAtLeast(0)
        }

        fun layoutChildren() {
            box.layoutParams = FrameLayout.LayoutParams(boxWidth, boxHeight).apply {
                leftMargin = pad; topMargin = pad
            }
            fun place(h: View, lx: Int, ly: Int) {
                h.layoutParams = FrameLayout.LayoutParams(hs, hs).apply {
                    leftMargin = lx; topMargin = ly
                }
            }
            place(hTL, 0, 0)
            place(hTR, boxWidth, 0)
            place(hBL, 0, boxHeight)
            place(hBR, boxWidth, boxHeight)
        }
        layoutChildren()

        fun syncWindow() {
            boxParams.width = boxWidth + hs
            boxParams.height = boxHeight + hs
            boxParams.x = (boxLeft - pad).coerceAtLeast(0)
            boxParams.y = (boxTop - pad).coerceAtLeast(0)
            layoutChildren()
            try { windowManager.updateViewLayout(root, boxParams) } catch (_: Exception) {}
        }

        var dsx = 0f; var dsy = 0f; var sl = 0; var st = 0
        box.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dsx = e.rawX; dsy = e.rawY; sl = boxLeft; st = boxTop; true }
                MotionEvent.ACTION_MOVE -> {
                    boxLeft = max(0, sl + (e.rawX - dsx).toInt())
                    boxTop = max(0, st + (e.rawY - dsy).toInt())
                    syncWindow(); true
                }
                else -> false
            }
        }

        fun setupH(h: View, type: String) {
            var sx = 0f; var sy = 0f; var ol = 0; var ot = 0; var ow = 0; var oh = 0
            h.setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = e.rawX; sy = e.rawY; ol = boxLeft; ot = boxTop; ow = boxWidth; oh = boxHeight; true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                        when (type) {
                            "TL" -> { boxLeft = ol + dx; boxTop = ot + dy; boxWidth = ow - dx; boxHeight = oh - dy }
                            "TR" -> { boxTop = ot + dy; boxWidth = ow + dx; boxHeight = oh - dy }
                            "BL" -> { boxLeft = ol + dx; boxWidth = ow - dx; boxHeight = oh + dy }
                            "BR" -> { boxWidth = ow + dx; boxHeight = oh + dy }
                        }
                        if (boxWidth < 100) boxWidth = 100
                        if (boxHeight < 60) boxHeight = 60
                        if (boxLeft < 0) boxLeft = 0
                        if (boxTop < 0) boxTop = 0
                        syncWindow(); true
                    }
                    else -> false
                }
            }
        }
        setupH(hTL, "TL"); setupH(hTR, "TR"); setupH(hBL, "BL"); setupH(hBR, "BR")

        areaRoot = root
        try { windowManager.addView(root, boxParams) } catch (_: Exception) {}

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(16, 14, 16, 14)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#EE1A1A24"))
                cornerRadius = 16f
            }
        }
        val ok = TextView(this).apply {
            text = "  Confirmar  "
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#00E676"))
            setPadding(36, 20, 36, 20)
            textSize = 15f
            setOnClickListener {
                if (selectingQuestion) {
                    prefs.saveAreaQuestion(boxLeft, boxTop, boxLeft + boxWidth, boxTop + boxHeight)
                } else {
                    prefs.saveAreaOptions(boxLeft, boxTop, boxLeft + boxWidth, boxTop + boxHeight)
                }
                removeArea()
                // No cerrar flotante; volver a app si no hay flotante
                if (!isFloatVisible) {
                    startActivity(Intent(this@TriviaService, MainActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    })
                }
            }
        }
        val cancel = TextView(this).apply {
            text = "  Cancelar  "
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#FF5252"))
            setPadding(36, 20, 36, 20)
            textSize = 15f
            setOnClickListener {
                removeArea()
                if (!isFloatVisible) {
                    startActivity(Intent(this@TriviaService, MainActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    })
                }
            }
        }
        row.addView(ok)
        row.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(14, 1) })
        row.addView(cancel)

        val btnParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = 48
        }
        areaButtons = row
        try { windowManager.addView(row, btnParams) } catch (_: Exception) {}
    }

    private fun removeArea() {
        areaRoot?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        areaRoot = null
        areaButtons?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        areaButtons = null
    }

    override fun onDestroy() {
        isShuttingDown = true
        stopLoop()
        removeFloat()
        removeArea()
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) {}
        try { (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(2) } catch (_: Exception) {}
        try { recognizer.close() } catch (_: Exception) {}
        super.onDestroy()
    }
}
