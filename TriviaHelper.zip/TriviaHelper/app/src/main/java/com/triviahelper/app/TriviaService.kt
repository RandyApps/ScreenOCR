package com.triviahelper.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.*
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.concurrent.thread
import kotlin.math.max

class TriviaService : Service() {

    companion object {
        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
        const val ACTION_SELECT_QUESTION = "ACTION_SELECT_QUESTION"
        const val ACTION_SELECT_OPTIONS = "ACTION_SELECT_OPTIONS"
        const val ACTION_TOGGLE_FLOAT = "ACTION_TOGGLE_FLOAT"
        const val ACTION_STATUS = "com.triviahelper.app.STATUS"
        const val ACTION_CLOSE = "ACTION_CLOSE"

        @Volatile var isRunning = false
        @Volatile var isFloatVisible = false
    }

    private lateinit var windowManager: WindowManager
    private lateinit var prefs: PrefsHelper
    private val mainHandler = Handler(Looper.getMainLooper())
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var ocrThread: HandlerThread? = null
    private var ocrHandler: Handler? = null

    private var screenWidth = 0
    private var screenHeight = 0
    private var densityDpi = 0

    private var floatView: View? = null
    private var floatParams: WindowManager.LayoutParams? = null
    private var tvFloatAnswer: TextView? = null
    private var tvFloatStatus: TextView? = null

    private var areaRoot: View? = null
    private var areaButtons: View? = null
    private var selectingQuestion = true
    private var boxLeft = 80
    private var boxTop = 200
    private var boxWidth = 600
    private var boxHeight = 200

    private var lastQuestionKey = ""
    private var busy = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = PrefsHelper(this)
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
        densityDpi = metrics.densityDpi
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val code = intent.getIntExtra(ScreenCaptureActivity.EXTRA_RESULT_CODE, 0)
                val data = if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableExtra(ScreenCaptureActivity.EXTRA_RESULT_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(ScreenCaptureActivity.EXTRA_RESULT_DATA)
                }
                if (code != 0 && data != null) {
                    startForeground(2, buildNotification("Ayuda activa"))
                    startLoop(code, data)
                }
            }
            ACTION_STOP -> stopLoop()
            ACTION_SELECT_QUESTION -> {
                startForeground(2, buildNotification("Designando pregunta"))
                selectingQuestion = true
                showAreaSelector()
            }
            ACTION_SELECT_OPTIONS -> {
                startForeground(2, buildNotification("Designando opciones"))
                selectingQuestion = false
                showAreaSelector()
            }
            ACTION_TOGGLE_FLOAT -> {
                startForeground(2, buildNotification(if (isRunning) "Ayuda activa" else "Trivia Helper"))
                if (floatView == null) showFloat()
                else {
                    isFloatVisible = !isFloatVisible
                    floatView?.visibility = if (isFloatVisible) View.VISIBLE else View.GONE
                }
            }
            ACTION_CLOSE -> {
                stopLoop()
                removeFloat()
                removeArea()
                try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) {}
                try { (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(2) } catch (_: Exception) {}
                stopSelf()
            }
            else -> startForeground(2, buildNotification("Trivia Helper"))
        }
        return START_NOT_STICKY
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel("trivia_ch", "Trivia Helper", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, TriviaService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, "trivia_ch")
            .setContentTitle("Trivia Helper")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_help)
            .setContentIntent(open)
            .setOngoing(isRunning)
            .addAction(0, "Detener", stop)
            .setColor(Color.parseColor("#7C4DFF"))
            .build()
    }

    private fun broadcast() {
        sendBroadcast(Intent(ACTION_STATUS).setPackage(packageName))
    }

    // ---------- OCR LOOP ----------
    private fun startLoop(resultCode: Int, data: Intent) {
        if (isRunning) return
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = mpm.getMediaProjection(resultCode, data)
        mediaProjection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { mainHandler.post { stopLoop() } }
        }, mainHandler)

        imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "TriviaHelper",
            screenWidth, screenHeight, densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, null
        )

        ocrThread = HandlerThread("trivia-ocr").also { it.start() }
        ocrHandler = Handler(ocrThread!!.looper)

        isRunning = true
        showFloat()
        setFloatStatus("Detectando…")
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .notify(2, buildNotification("Ayuda activa"))
        broadcast()

        ocrHandler?.post(object : Runnable {
            override fun run() {
                if (!isRunning) return
                captureAndSolve()
                ocrHandler?.postDelayed(this, 2500)
            }
        })
    }

    private fun stopLoop() {
        isRunning = false
        try { virtualDisplay?.release() } catch (_: Exception) {}
        try { imageReader?.close() } catch (_: Exception) {}
        try { mediaProjection?.stop() } catch (_: Exception) {}
        virtualDisplay = null
        imageReader = null
        mediaProjection = null
        ocrThread?.quitSafely()
        ocrThread = null
        ocrHandler = null
        setFloatStatus("Detenido")
        try {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .notify(2, buildNotification("Detenido"))
        } catch (_: Exception) {}
        broadcast()
    }

    private fun captureAndSolve() {
        if (busy) return
        val reader = imageReader ?: return
        val image = try { reader.acquireLatestImage() } catch (_: Exception) { null } ?: return
        try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * screenWidth
            val bitmap = Bitmap.createBitmap(
                screenWidth + rowPadding / pixelStride,
                screenHeight,
                Bitmap.Config.ARGB_8888
            )
            bitmap.copyPixelsFromBuffer(buffer)

            val qArea = prefs.getAreaQuestion() ?: return
            val oArea = prefs.getAreaOptions() ?: return

            fun crop(a: IntArray): Bitmap? {
                val l = a[0].coerceIn(0, bitmap.width - 1)
                val t = a[1].coerceIn(0, bitmap.height - 1)
                val r = a[2].coerceIn(l + 1, bitmap.width)
                val b = a[3].coerceIn(t + 1, bitmap.height)
                val w = r - l
                val h = b - t
                if (w < 20 || h < 20) return null
                return Bitmap.createBitmap(bitmap, l, t, w, h)
            }

            val qBmp = crop(qArea)
            val oBmp = crop(oArea)
            bitmap.recycle()
            if (qBmp == null || oBmp == null) {
                qBmp?.recycle(); oBmp?.recycle()
                return
            }

            val qImage = InputImage.fromBitmap(qBmp, 0)
            val oImage = InputImage.fromBitmap(oBmp, 0)

            recognizer.process(qImage)
                .addOnSuccessListener { qResult ->
                    val question = qResult.textBlocks
                        .flatMap { it.lines }
                        .joinToString(" ") { it.text.trim() }
                        .trim()
                    recognizer.process(oImage)
                        .addOnSuccessListener { oResult ->
                            val options = oResult.textBlocks
                                .flatMap { it.lines }
                                .map { it.text.trim() }
                                .filter { it.length > 1 }
                                .distinct()
                            qBmp.recycle()
                            oBmp.recycle()
                            if (question.length < 8 || options.isEmpty()) return@addOnSuccessListener
                            val key = question + "|" + options.joinToString("|")
                            if (key == lastQuestionKey) return@addOnSuccessListener
                            lastQuestionKey = key
                            askGemini(question, options)
                        }
                        .addOnFailureListener { qBmp.recycle(); oBmp.recycle() }
                }
                .addOnFailureListener { qBmp.recycle(); oBmp.recycle() }
        } catch (_: Exception) {
        } finally {
            image.close()
        }
    }

    private fun askGemini(question: String, options: List<String>) {
        if (busy) return
        busy = true
        mainHandler.post { setFloatStatus("Buscando…") }
        val key = prefs.getApiKey()
        thread {
            val answer = try {
                GeminiClient.findAnswer(key, question, options)
            } catch (e: Exception) {
                "Error: ${e.message}"
            }
            mainHandler.post {
                busy = false
                prefs.saveLastAnswer(answer, question.take(120))
                setFloatAnswer(answer)
                setFloatStatus("Listo")
                broadcast()
            }
        }
    }

    // ---------- FLOAT WINDOW ----------
    private fun showFloat() {
        if (floatView != null) {
            floatView?.visibility = View.VISIBLE
            isFloatVisible = true
            return
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F0121220"))
                cornerRadius = 22f
                setStroke(3, Color.parseColor("#7C4DFF"))
            }
            setPadding(28, 22, 28, 22)
            elevation = 20f
        }

        val title = TextView(this).apply {
            text = "RESPUESTA"
            setTextColor(Color.parseColor("#B388FF"))
            textSize = 11f
        }
        tvFloatAnswer = TextView(this).apply {
            text = prefs.getLastAnswer().ifBlank { "—" }
            setTextColor(Color.parseColor("#00E676"))
            textSize = 18f
            setPadding(0, 8, 0, 4)
        }
        tvFloatStatus = TextView(this).apply {
            text = if (isRunning) "Detectando…" else "En espera"
            setTextColor(Color.parseColor("#9E9EB8"))
            textSize = 11f
        }

        root.addView(title)
        root.addView(tvFloatAnswer)
        root.addView(tvFloatStatus)

        floatParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 120
        }

        var ix = 0; var iy = 0; var tx = 0f; var ty = 0f
        root.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    ix = floatParams!!.x; iy = floatParams!!.y
                    tx = e.rawX; ty = e.rawY; true
                }
                MotionEvent.ACTION_MOVE -> {
                    floatParams!!.x = ix + (e.rawX - tx).toInt()
                    floatParams!!.y = iy + (e.rawY - ty).toInt()
                    try { windowManager.updateViewLayout(floatView, floatParams) } catch (_: Exception) {}
                    true
                }
                else -> false
            }
        }

        floatView = root
        isFloatVisible = true
        try { windowManager.addView(root, floatParams) } catch (_: Exception) {}
    }

    private fun setFloatAnswer(text: String) {
        mainHandler.post { tvFloatAnswer?.text = text }
    }

    private fun setFloatStatus(text: String) {
        mainHandler.post { tvFloatStatus?.text = text }
    }

    private fun removeFloat() {
        floatView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        floatView = null
        tvFloatAnswer = null
        tvFloatStatus = null
        isFloatVisible = false
    }

    // ---------- AREA SELECTOR ----------
    private fun showAreaSelector() {
        if (areaRoot != null) return
        prefs.let {
            val a = if (selectingQuestion) it.getAreaQuestion() else it.getAreaOptions()
            if (a != null) {
                boxLeft = a[0]; boxTop = a[1]
                boxWidth = (a[2] - a[0]).coerceAtLeast(120)
                boxHeight = (a[3] - a[1]).coerceAtLeast(80)
            }
        }
        val hs = 48
        val pad = hs / 2
        val root = FrameLayout(this)
        val box = View(this).apply {
            background = GradientDrawable().apply {
                setStroke(5, Color.parseColor(if (selectingQuestion) "#448AFF" else "#00E676"))
                setColor(Color.parseColor("#33000000"))
            }
        }
        fun handle() = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#B388FF"))
            }
        }
        val hTL = handle(); val hTR = handle(); val hBL = handle(); val hBR = handle()
        root.addView(box); root.addView(hTL); root.addView(hTR); root.addView(hBL); root.addView(hBR)

        val boxParams = WindowManager.LayoutParams(
            boxWidth + hs, boxHeight + hs,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (boxLeft - pad).coerceAtLeast(0)
            y = (boxTop - pad).coerceAtLeast(0)
        }

        fun layoutChildren() {
            box.layoutParams = FrameLayout.LayoutParams(boxWidth, boxHeight).apply {
                leftMargin = pad; topMargin = pad
            }
            fun place(h: View, lx: Int, ly: Int) {
                h.layoutParams = FrameLayout.LayoutParams(hs, hs).apply {
                    leftMargin = lx; topMargin = ly
                }
            }
            place(hTL, 0, 0)
            place(hTR, boxWidth, 0)
            place(hBL, 0, boxHeight)
            place(hBR, boxWidth, boxHeight)
        }
        layoutChildren()

        fun syncWindow() {
            boxParams.width = boxWidth + hs
            boxParams.height = boxHeight + hs
            boxParams.x = (boxLeft - pad).coerceAtLeast(0)
            boxParams.y = (boxTop - pad).coerceAtLeast(0)
            layoutChildren()
            try { windowManager.updateViewLayout(root, boxParams) } catch (_: Exception) {}
        }

        var dsx = 0f; var dsy = 0f; var sl = 0; var st = 0
        box.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dsx = e.rawX; dsy = e.rawY; sl = boxLeft; st = boxTop; true }
                MotionEvent.ACTION_MOVE -> {
                    boxLeft = max(0, sl + (e.rawX - dsx).toInt())
                    boxTop = max(0, st + (e.rawY - dsy).toInt())
                    syncWindow(); true
                }
                else -> false
            }
        }

        fun setupH(h: View, type: String) {
            var sx = 0f; var sy = 0f; var ol = 0; var ot = 0; var ow = 0; var oh = 0
            h.setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = e.rawX; sy = e.rawY; ol = boxLeft; ot = boxTop; ow = boxWidth; oh = boxHeight; true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                        when (type) {
                            "TL" -> { boxLeft = ol + dx; boxTop = ot + dy; boxWidth = ow - dx; boxHeight = oh - dy }
                            "TR" -> { boxTop = ot + dy; boxWidth = ow + dx; boxHeight = oh - dy }
                            "BL" -> { boxLeft = ol + dx; boxWidth = ow - dx; boxHeight = oh + dy }
                            "BR" -> { boxWidth = ow + dx; boxHeight = oh + dy }
                        }
                        if (boxWidth < 100) boxWidth = 100
                        if (boxHeight < 60) boxHeight = 60
                        if (boxLeft < 0) boxLeft = 0
                        if (boxTop < 0) boxTop = 0
                        syncWindow(); true
                    }
                    else -> false
                }
            }
        }
        setupH(hTL, "TL"); setupH(hTR, "TR"); setupH(hBL, "BL"); setupH(hBR, "BR")

        areaRoot = root
        try { windowManager.addView(root, boxParams) } catch (_: Exception) {}

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(16, 14, 16, 14)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#EE1A1A24"))
                cornerRadius = 16f
            }
        }
        val ok = TextView(this).apply {
            text = "  Confirmar  "
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#00E676"))
            setPadding(36, 20, 36, 20)
            textSize = 15f
            setOnClickListener {
                if (selectingQuestion) {
                    prefs.saveAreaQuestion(boxLeft, boxTop, boxLeft + boxWidth, boxTop + boxHeight)
                } else {
                    prefs.saveAreaOptions(boxLeft, boxTop, boxLeft + boxWidth, boxTop + boxHeight)
                }
                removeArea()
                startActivity(Intent(this@TriviaService, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                })
            }
        }
        val cancel = TextView(this).apply {
            text = "  Cancelar  "
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#FF5252"))
            setPadding(36, 20, 36, 20)
            textSize = 15f
            setOnClickListener {
                removeArea()
                startActivity(Intent(this@TriviaService, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                })
            }
        }
        row.addView(ok)
        row.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(14, 1) })
        row.addView(cancel)

        val btnParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = 48
        }
        areaButtons = row
        try { windowManager.addView(row, btnParams) } catch (_: Exception) {}
    }

    private fun removeArea() {
        areaRoot?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        areaRoot = null
        areaButtons?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        areaButtons = null
    }

    override fun onDestroy() {
        stopLoop()
        removeFloat()
        removeArea()
        try { recognizer.close() } catch (_: Exception) {}
        super.onDestroy()
    }
}
