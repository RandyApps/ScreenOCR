package com.example.screenocr

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.net.Uri
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var projectionManager: MediaProjectionManager
    private val captureRequest = 1001
    private val overlayRequest = 1002

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 50, 40, 40) }
        val title = TextView(this).apply { text = "Screen OCR Variable\n\nLee una zona de la pantalla y guarda la última detección en un archivo de texto."; textSize = 20f }
        val minBox = CheckBox(this).apply { text = "Exigir mínimo de letras" }
        val minLetters = EditText(this).apply { hint = "Mínimo de letras (ej. 5)"; inputType = 2 }
        val containsBox = CheckBox(this).apply { text = "Exigir que contenga este texto" }
        val containsText = EditText(this).apply { hint = "Texto requerido (ej. Randy)" }
        val start = Button(this).apply { text = "Iniciar detección" }
        val stop = Button(this).apply { text = "Detener detección" }
        val open = Button(this).apply { text = "Abrir última detección" }
        layout.addView(title); layout.addView(minBox); layout.addView(minLetters); layout.addView(containsBox); layout.addView(containsText); layout.addView(start); layout.addView(stop); layout.addView(open)
        setContentView(layout)

        start.setOnClickListener {
            getSharedPreferences("settings", MODE_PRIVATE).edit()
                .putBoolean("min_enabled", minBox.isChecked)
                .putInt("min_letters", minLetters.text.toString().toIntOrNull() ?: 0)
                .putBoolean("contains_enabled", containsBox.isChecked)
                .putString("contains_text", containsText.text.toString())
                .apply()
            if (!Settings.canDrawOverlays(this)) {
                startActivityForResult(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")), overlayRequest)
                return@setOnClickListener
            }
            requestCapture()
        }
        stop.setOnClickListener { stopService(Intent(this, OcrService::class.java)) }
        open.setOnClickListener { openFile() }
    }

    private fun requestCapture() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 77)
        }
        startActivityForResult(projectionManager.createScreenCaptureIntent(), captureRequest)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == overlayRequest) {
            if (Settings.canDrawOverlays(this)) requestCapture()
            return
        }
        if (requestCode == captureRequest && resultCode == Activity.RESULT_OK && data != null) {
            val i = Intent(this, OcrService::class.java).apply {
                putExtra(OcrService.EXTRA_RESULT_CODE, resultCode)
                putExtra(OcrService.EXTRA_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        }
    }

    private fun openFile() {
        val file = java.io.File(getExternalFilesDir(null), "ultima_deteccion.txt")
        if (!file.exists()) file.writeText("Todavía no hay una detección.")
        val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        startActivity(Intent(Intent.ACTION_VIEW).apply { setDataAndType(uri, "text/plain"); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) })
    }
}
