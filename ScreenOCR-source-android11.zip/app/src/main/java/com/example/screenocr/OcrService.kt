package com.example.screenocr

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import kotlin.math.max
import kotlin.math.min

class OcrService : Service() {
    companion object { const val EXTRA_RESULT_CODE="resultCode"; const val EXTRA_DATA="data"; const val CH="ocr" }
    private lateinit var projection: MediaProjection
    private lateinit var reader: ImageReader
    private var display: VirtualDisplay? = null
    private val handler = Handler(Looper.getMainLooper())
    private var processing = false
    private var lastSaved = ""
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private var left=0; private var top=0; private var right=0; private var bottom=0
    private var selecting = true
    private var overlay: SelectionOverlay? = null

    override fun onBind(intent: Intent?) = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) return START_NOT_STICKY
        createChannel()
        startForeground(1, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        val code=intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
        val data=intent.getParcelableExtra<Intent>(EXTRA_DATA) ?: return START_NOT_STICKY
        val pm=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection=pm.getMediaProjection(code,data)
        projection.registerCallback(object: MediaProjection.Callback(){ override fun onStop(){ stopSelf() } }, handler)
        val dm=getSystemService(DISPLAY_SERVICE) as DisplayManager
        val metrics=resources.displayMetrics
        reader=ImageReader.newInstance(metrics.widthPixels, metrics.heightPixels, PixelFormat.RGBA_8888, 2)
        display=projection.createVirtualDisplay("ScreenOCR", metrics.widthPixels, metrics.heightPixels, metrics.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, handler)
        showSelector(metrics.widthPixels, metrics.heightPixels)
        reader.setOnImageAvailableListener({ if (!selecting) processLatest() }, handler)
        return START_NOT_STICKY
    }

    private fun showSelector(w:Int,h:Int){
        handler.post {
            overlay=SelectionOverlay(this,w,h){ l,t,r,b -> left=l; top=t; right=r; bottom=b; selecting=false; overlay?.let{ (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) }; overlay=null }
            val lp=WindowManager.LayoutParams(w,h,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT)
            lp.gravity=Gravity.TOP or Gravity.START
            (getSystemService(WINDOW_SERVICE) as WindowManager).addView(overlay,lp)
        }
    }

    private fun processLatest(){
        if(processing || right<=left || bottom<=top) return
        processing=true
        val img=reader.acquireLatestImage() ?: run { processing=false; return }
        try {
            val plane=img.planes[0]
            val buffer=plane.buffer
            val pixelStride=plane.pixelStride
            val rowStride=plane.rowStride
            val rowPadding=rowStride-pixelStride*reader.width
            val padded=Bitmap.createBitmap(reader.width + rowPadding/pixelStride, reader.height, Bitmap.Config.ARGB_8888)
            padded.copyPixelsFromBuffer(buffer)
            val l=min(left,padded.width-1); val t=min(top,padded.height-1); val r=min(right,padded.width); val b=min(bottom,padded.height)
            if(r>l && b>t){
                val crop=Bitmap.createBitmap(padded,l,t,r-l,b-t)
                TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(InputImage.fromBitmap(crop,0)).addOnSuccessListener{ result ->
                    val text=result.text.trim().replace(Regex("\\s+")," ")
                    val letters=text.count { it.isLetter() }
                    val minOk=!prefs.getBoolean("min_enabled", false) || letters >= prefs.getInt("min_letters", 0)
                    val required=prefs.getString("contains_text", "") ?: ""
                    val containsOk=!prefs.getBoolean("contains_enabled", false) || (required.isNotBlank() && text.contains(required, ignoreCase=true))
                    if(text.isNotEmpty() && minOk && containsOk && text != lastSaved){
                        lastSaved=text
                        File(getExternalFilesDir(null),"ultima_deteccion.txt").writeText("Última detección: $text")
                    }
                }.addOnCompleteListener { crop.recycle(); padded.recycle(); processing=false }
            } else { padded.recycle(); processing=false }
        } catch(_:Exception){ processing=false }
        finally { img.close() }
    }

    private fun notification():Notification{ val pi=PendingIntent.getActivity(this,0,Intent(this,MainActivity::class.java),PendingIntent.FLAG_IMMUTABLE); return Notification.Builder(this,CH).setContentTitle("Screen OCR activo").setContentText("Detectando texto de la región seleccionada").setSmallIcon(com.example.screenocr.R.drawable.ic_launcher).setContentIntent(pi).setOngoing(true).build() }
    private fun createChannel(){ if(Build.VERSION.SDK_INT>=26){ val nm=getSystemService(NOTIFICATION_SERVICE) as NotificationManager; nm.createNotificationChannel(NotificationChannel(CH,"Screen OCR",NotificationManager.IMPORTANCE_LOW)) } }
    override fun onDestroy(){ try{ overlay?.let{(getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it)} }catch(_:Exception){}; display?.release(); reader.close(); if(::projection.isInitialized) projection.stop(); super.onDestroy() }

    class SelectionOverlay(ctx:Context, private val w:Int, private val h:Int, val done:(Int,Int,Int,Int)->Unit):View(ctx){
        private val p=Paint().apply{color=Color.WHITE;style=Paint.Style.STROKE;strokeWidth=5f}; private var sx=0f;private var sy=0f;private var ex=0f;private var ey=0f;private var drawing=false
        override fun onDraw(c:Canvas){ c.drawColor(0x55000000); if(drawing||ex!=sx||ey!=sy){ val l=min(sx,ex);val t=min(sy,ey);val r=max(sx,ex);val b=max(sy,ey); c.drawRect(l,t,r,b,p); } }
        override fun onTouchEvent(e:android.view.MotionEvent):Boolean{ when(e.action){ MotionEvent.ACTION_DOWN->{sx=e.x;sy=e.y;ex=e.x;ey=e.y;drawing=true;invalidate();return true}; MotionEvent.ACTION_MOVE->{ex=e.x;ey=e.y;invalidate();return true}; MotionEvent.ACTION_UP->{ex=e.x;ey=e.y;drawing=false;invalidate(); if(abs(ex-sx)>20&&abs(ey-sy)>20) done(min(sx,ex).toInt(),min(sy,ey).toInt(),max(sx,ex).toInt(),max(sy,ey).toInt()); return true} }; return true }
        private fun abs(x:Float)=kotlin.math.abs(x)
    }
}
