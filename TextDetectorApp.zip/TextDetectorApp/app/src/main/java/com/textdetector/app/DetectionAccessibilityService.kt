package com.textdetector.app

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.concurrent.atomic.AtomicBoolean

class DetectionAccessibilityService : AccessibilityService() {

    companion object {
        var instance: DetectionAccessibilityService? = null
        val isDetecting = AtomicBoolean(false)
        var lastDetectedKey: String = ""
        var lastTriviaKey: String = ""
    }

    private lateinit var prefs: PrefsHelper

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        prefs = PrefsHelper(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!isDetecting.get() || event == null) return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED &&
            event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        if (!::prefs.isInitialized) return

        val root = rootInActiveWindow ?: return

        if (prefs.isIntelligentMode()) {
            handleIntelligentMode(root)
        } else {
            handleNormalMode(root)
        }
    }

    private fun handleNormalMode(root: AccessibilityNodeInfo) {
        val area = prefs.getNormalArea() ?: return
        val target = Rect(area[0], area[1], area[2], area[3])
        val texts = mutableListOf<String>()
        collectTextInArea(root, target, texts)

        if (texts.isEmpty()) return

        // Heuristic: first/longest is usually the name (white), next different one is subtitle
        val unique = texts.map { it.trim() }.filter { it.length > 1 }.distinct()
        if (unique.isEmpty()) return

        val name = unique.maxByOrNull { it.length } ?: unique[0]
        val subtitle = unique.firstOrNull { it != name && it.length > 2 } ?: ""

        val key = "$name|$subtitle"
        if (key != lastDetectedKey) {
            lastDetectedKey = key
            prefs.saveLastDetection(name, subtitle)
            FloatingService.onNewDetection(name, subtitle)
        }
    }

    private fun handleIntelligentMode(root: AccessibilityNodeInfo) {
        // Collect question and options if areas are set
        var question = ""
        var options = listOf<String>()

        prefs.getQuestionArea()?.let { area ->
            val texts = mutableListOf<String>()
            collectTextInArea(root, Rect(area[0], area[1], area[2], area[3]), texts)
            question = texts.joinToString(" ").trim()
        }

        prefs.getOptionsArea()?.let { area ->
            val texts = mutableListOf<String>()
            collectTextInArea(root, Rect(area[0], area[1], area[2], area[3]), texts)
            options = texts.map { it.trim() }.filter { it.length > 1 }.distinct()
        }

        if (question.length > 8) {
            val key = question + "|" + options.joinToString()
            if (key != lastTriviaKey) {
                lastTriviaKey = key
                FloatingService.onTriviaDetected(question, options)
            }
        }
    }

    private fun collectTextInArea(node: AccessibilityNodeInfo?, target: Rect, result: MutableList<String>) {
        if (node == null) return
        val nodeRect = Rect()
        node.getBoundsInScreen(nodeRect)
        if (Rect.intersects(nodeRect, target)) {
            node.text?.toString()?.let { if (it.isNotBlank()) result.add(it) }
            node.contentDescription?.toString()?.let { if (it.isNotBlank()) result.add(it) }
        }
        for (i in 0 until node.childCount) {
            collectTextInArea(node.getChild(i), target, result)
        }
    }

    override fun onInterrupt() {}
    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }
}
