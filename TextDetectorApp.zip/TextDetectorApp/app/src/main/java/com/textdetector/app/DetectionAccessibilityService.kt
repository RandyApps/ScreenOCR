package com.textdetector.app

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.concurrent.atomic.AtomicBoolean

class DetectionAccessibilityService : AccessibilityService() {

    companion object {
        var instance: DetectionAccessibilityService? = null
        val isDetecting = AtomicBoolean(false)
        var lastDetectedText: String = ""
    }

    private lateinit var prefs: PrefsHelper

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        prefs = PrefsHelper(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!isDetecting.get()) return
        if (event == null) return

        // We only care about content changes
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED &&
            event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return

        val root = rootInActiveWindow ?: return
        val area = prefs.getArea()
        if (!prefs.isAreaSet()) return

        val targetRect = Rect(area[0], area[1], area[2], area[3])
        val foundTexts = mutableListOf<String>()

        collectTextInArea(root, targetRect, foundTexts)

        if (foundTexts.isNotEmpty()) {
            // Take the longest or the most relevant text (usually the name is the main one)
            val bestText = foundTexts.maxByOrNull { it.length }?.trim() ?: return

            if (bestText.isNotEmpty() && bestText != lastDetectedText && bestText.length > 2) {
                lastDetectedText = bestText
                prefs.saveLastDetection(bestText)

                // Notify FloatingService to update notification if needed
                FloatingService.updateLastDetection(bestText)
            }
        }
    }

    private fun collectTextInArea(node: AccessibilityNodeInfo?, target: Rect, result: MutableList<String>) {
        if (node == null) return

        val nodeRect = Rect()
        node.getBoundsInScreen(nodeRect)

        // Check if node intersects the target area
        if (Rect.intersects(nodeRect, target)) {
            val text = node.text?.toString()
            if (!text.isNullOrBlank()) {
                result.add(text)
            }
            val desc = node.contentDescription?.toString()
            if (!desc.isNullOrBlank()) {
                result.add(desc)
            }
        }

        for (i in 0 until node.childCount) {
            collectTextInArea(node.getChild(i), target, result)
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }
}
