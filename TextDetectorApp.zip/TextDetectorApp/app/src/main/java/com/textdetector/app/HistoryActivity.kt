package com.textdetector.app

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.textdetector.app.databinding.ActivityHistoryBinding

class HistoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHistoryBinding
    private lateinit var prefs: PrefsHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefs = PrefsHelper(this)

        binding.recyclerHistory.layoutManager = LinearLayoutManager(this)
        binding.recyclerHistory.adapter = HistoryAdapter(prefs.getHistory())

        binding.btnClearHistory.setOnClickListener {
            prefs.clearHistory()
            binding.recyclerHistory.adapter = HistoryAdapter(emptyList())
        }
    }

    class HistoryAdapter(private val items: List<PrefsHelper.HistoryItem>) :
        RecyclerView.Adapter<HistoryAdapter.VH>() {

        class VH(view: View) : RecyclerView.ViewHolder(view) {
            val name: TextView = view.findViewById(android.R.id.text1)
            val sub: TextView = view.findViewById(android.R.id.text2)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context)
                .inflate(android.R.layout.simple_list_item_2, parent, false)
            v.setBackgroundColor(0xFF1E1E1E.toInt())
            v.setPadding(32, 28, 32, 28)
            return VH(v)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val item = items[position]
            holder.name.text = item.name
            holder.name.setTextColor(Color.WHITE)
            holder.name.textSize = 16f
            holder.sub.text = buildString {
                if (item.subtitle.isNotEmpty()) append(item.subtitle)
                if (item.time.isNotEmpty()) {
                    if (isNotEmpty()) append("  •  ")
                    append(item.time)
                }
            }
            holder.sub.setTextColor(0xFFAAAAAA.toInt())
        }

        override fun getItemCount() = items.size
    }
}
