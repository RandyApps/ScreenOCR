package com.textdetector.app

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.textdetector.app.databinding.ActivityHistoryBinding

class HistoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHistoryBinding
    private lateinit var prefs: PrefsHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = PrefsHelper(this)

        binding.recyclerHistory.layoutManager = LinearLayoutManager(this)
        val history = prefs.getHistory()
        binding.recyclerHistory.adapter = HistoryAdapter(history)

        binding.btnClearHistory.setOnClickListener {
            prefs.clearHistory()
            binding.recyclerHistory.adapter = HistoryAdapter(emptyList())
        }
    }

    class HistoryAdapter(private val items: List<PrefsHelper.HistoryItem>) :
        RecyclerView.Adapter<HistoryAdapter.ViewHolder>() {

        class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val tvText: TextView = view.findViewById(android.R.id.text1)
            val tvTime: TextView = view.findViewById(android.R.id.text2)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(android.R.layout.simple_list_item_2, parent, false)
            view.setBackgroundColor(0xFF1E1E1E.toInt())
            view.setPadding(24, 24, 24, 24)
            return ViewHolder(view)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val item = items[position]
            holder.tvText.text = item.text
            holder.tvText.setTextColor(0xFFFFFFFF.toInt())
            holder.tvText.textSize = 16f
            holder.tvTime.text = item.time
            holder.tvTime.setTextColor(0xFFAAAAAA.toInt())
        }

        override fun getItemCount() = items.size
    }
}
