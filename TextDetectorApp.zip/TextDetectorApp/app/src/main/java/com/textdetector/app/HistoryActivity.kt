package com.textdetector.app

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.textdetector.app.databinding.ActivityHistoryBinding

class HistoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHistoryBinding
    private lateinit var prefs: PrefsHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefs = PrefsHelper(this)

        binding.recyclerHistory.layoutManager = LinearLayoutManager(this)
        binding.recyclerHistory.adapter = Adapter(prefs.getHistory())

        binding.btnClearHistory.setOnClickListener {
            prefs.clearHistory()
            binding.recyclerHistory.adapter = Adapter(emptyList())
            finish() // volver a la interfaz principal
        }
    }

    class Adapter(private val items: List<PrefsHelper.HistoryItem>) :
        RecyclerView.Adapter<Adapter.VH>() {

        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val name: TextView = v.findViewById(android.R.id.text1)
            val sub: TextView = v.findViewById(android.R.id.text2)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context)
                .inflate(android.R.layout.simple_list_item_2, parent, false)
            v.setBackgroundColor(0xFF1A1A24.toInt())
            v.setPadding(36, 28, 36, 28)
            return VH(v)
        }

        override fun onBindViewHolder(h: VH, pos: Int) {
            val item = items[pos]
            h.name.text = item.name
            h.name.setTextColor(Color.WHITE)
            h.name.textSize = 16f
            h.sub.text = buildString {
                if (item.subtitle.isNotEmpty()) append(item.subtitle)
                if (item.time.isNotEmpty()) {
                    if (isNotEmpty()) append("  ·  ")
                    append(item.time)
                }
            }
            h.sub.setTextColor(
                if (item.subtitle.isNotEmpty()) item.subtitleColor else 0xFF9E9EB8.toInt()
            )
        }

        override fun getItemCount() = items.size
    }
}
