package com.textdetector.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.*
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.max

class FloatingService : Service() {

    companion object {
        const val ACTION_START_OCR = "ACTION_START_OCR"
        const val ACTION_STOP = "ACTION_STOP"
        const val ACTION_SELECT_AREA = "ACTION_SELECT_AREA"
        const val ACTION_SHOW_BAR = "ACTION_SHOW_BAR"
        const val ACTION_HIDE_BAR = "ACTION_HIDE_BAR"
        const val ACTION_CLOSE = "ACTION_CLOSE"
        const val ACTION_OPEN_APP = "ACTION_OPEN_APP"
        const val ACTION_STATUS_CHANGED = "com.textdetector.app.STATUS_CHANGED"

        @Volatile var isRunning = false
        @Volatile var isBarVisible = false
    }

    private lateinit var windowManager: WindowManager
    private lateinit var prefs: PrefsHelper
    private val mainHandler = Handler(Looper.getMainLooper())

    private var barView: View? = null
    private var barParams: WindowManager.LayoutParams? = null
    private var areaRoot: View? = null

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var ocrThread: HandlerThread? = null
    private var ocrHandler: Handler? = null
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    private var boxLeft = 60
    private var boxTop = 400
    private var boxWidth = 700
    private var boxHeight = 200

    private var lastKey = ""
    private var screenWidth = 1080
    private var screenHeight = 1920
    private var densityDpi = 420

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = PrefsHelper(this)
        val dm = DisplayMetrics()
        windowManager.defaultDisplay.getRealMetrics(dm)
        screenWidth = dm.widthPixels
        screenHeight = dm.heightPixels
        densityDpi = dm.densityDpi
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_OCR -> {
                val code = intent.getIntExtra(ScreenCaptureActivity.EXTRA_RESULT_CODE, 0)
                val data = if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableExtra(ScreenCaptureActivity.EXTRA_RESULT_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(ScreenCaptureActivity.EXTRA_RESULT_DATA)
                }
                if (code != 0 && data != null) {
                    startForeground(1, buildNotification())
                    startOcr(code, data)
                }
            }
            ACTION_STOP -> stopOcr()
            ACTION_SELECT_AREA -> {
                startForeground(1, buildNotification())
                showAreaSelector()
            }
            ACTION_SHOW_BAR -> {
                isBarVisible = true
                showBar()
                updateNotification()
            }
            ACTION_HIDE_BAR -> {
                isBarVisible = false
                removeBar()
                updateNotification()
            }
            ACTION_OPEN_APP -> {
                startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            ACTION_CLOSE -> {
                if (isRunning) stopOcr()
                removeBar()
                removeAreaSelector()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            else -> startForeground(1, buildNotification())
        }
        return START_STICKY
    }

    private fun broadcastStatus() {
        sendBroadcast(Intent(ACTION_STATUS_CHANGED).setPackage(packageName))
    }

    // ---------- OCR ----------
    private fun startOcr(resultCode: Int, data: Intent) {
        if (isRunning) return
        if (!prefs.isAreaSet()) {
            Toast.makeText(this, "Designa el área primero", Toast.LENGTH_SHORT).show()
            return
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = mpm.getMediaProjection(resultCode, data)
        mediaProjection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { mainHandler.post { stopOcr() } }
        }, mainHandler)

        imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "TextDetector",
            screenWidth, screenHeight, densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, null
        )

        ocrThread = HandlerThread("ocr").also { it.start() }
        ocrHandler = Handler(ocrThread!!.looper)

        isRunning = true
        isBarVisible = true
        showBar()
        updateNotification()
        broadcastStatus()
        Toast.makeText(this, "Detección OCR iniciada", Toast.LENGTH_SHORT).show()

        // Capture loop every 1.2s
        ocrHandler?.post(object : Runnable {
            override fun run() {
                if (!isRunning) return
                captureAndOcr()
                ocrHandler?.postDelayed(this, 1200)
            }
        })
    }

    private fun captureAndOcr() {
        val reader = imageReader ?: return
        val image = reader.acquireLatestImage() ?: return
        try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * screenWidth
            val bitmap = Bitmap.createBitmap(
                screenWidth + rowPadding / pixelStride,
                screenHeight,
                Bitmap.Config.ARGB_8888
            )
            bitmap.copyPixelsFromBuffer(buffer)

            val area = prefs.getArea() ?: return
            val l = area[0].coerceIn(0, screenWidth - 1)
            val t = area[1].coerceIn(0, screenHeight - 1)
            val r = area[2].coerceIn(l + 1, screenWidth)
            val b = area[3].coerceIn(t + 1, screenHeight)
            val w = r - l
            val h = b - t
            if (w < 20 || h < 20) return

            val cropped = Bitmap.createBitmap(bitmap, l, t, w, h)
            bitmap.recycle()

            val input = InputImage.fromBitmap(cropped, 0)
            recognizer.process(input)
                .addOnSuccessListener { result ->
                    val lineData = result.textBlocks.flatMap { it.lines }.mapNotNull { line ->
                        val text = line.text?.trim().orEmpty()
                        if (text.length <= 1) return@mapNotNull null
                        val box = line.boundingBox
                        val brightness = if (box != null) sampleRegionBrightness(cropped, box) else 200
                        Triple(text, brightness, if (box != null) sampleRegionColor(cropped, box) else PrefsHelper.DEFAULT_SUB_COLOR)
                    }
                    if (lineData.isEmpty()) {
                        cropped.recycle()
                        return@addOnSuccessListener
                    }
                    // White / brightest text = name (top); other color = subtitle (bottom)
                    val sorted = lineData.sortedByDescending { it.second }
                    val nameEntry = sorted.firstOrNull { it.second >= 170 } ?: sorted.first()
                    val name = nameEntry.first
                    val subEntry = sorted.firstOrNull { it.first != name && it.second < 170 && it.first.length > 2 }
                    val subtitle = subEntry?.first ?: ""
                    val subColor = subEntry?.third ?: PrefsHelper.DEFAULT_SUB_COLOR
                    val key = "$name|$subtitle"
                    if (key != lastKey) {
                        lastKey = key
                        prefs.saveLastDetection(name, subtitle, subColor)
                        mainHandler.post {
                            updateNotification()
                            broadcastStatus()
                        }
                    }
                    cropped.recycle()
                }
                .addOnFailureListener { cropped.recycle() }
        } catch (_: Exception) {
        } finally {
            image.close()
        }
    }

    private fun sampleRegionBrightness(bmp: Bitmap, rect: android.graphics.Rect): Int {
        return try {
            val l = rect.left.coerceIn(0, bmp.width - 1)
            val t = rect.top.coerceIn(0, bmp.height - 1)
            val r = rect.right.coerceIn(l + 1, bmp.width)
            val b = rect.bottom.coerceIn(t + 1, bmp.height)
            var sum = 0L
            var count = 0
            val stepX = max(1, (r - l) / 12)
            val stepY = max(1, (b - t) / 8)
            var y = t
            while (y < b) {
                var x = l
                while (x < r) {
                    val c = bmp.getPixel(x, y)
                    if (Color.alpha(c) > 40) {
                        sum += (Color.red(c) + Color.green(c) + Color.blue(c)) / 3
                        count++
                    }
                    x += stepX
                }
                y += stepY
            }
            if (count == 0) 128 else (sum / count).toInt()
        } catch (_: Exception) { 128 }
    }

    private fun sampleRegionColor(bmp: Bitmap, rect: android.graphics.Rect): Int {
        return try {
            val l = rect.left.coerceIn(0, bmp.width - 1)
            val t = rect.top.coerceIn(0, bmp.height - 1)
            val r = rect.right.coerceIn(l + 1, bmp.width)
            val b = rect.bottom.coerceIn(t + 1, bmp.height)
            var rSum = 0L; var gSum = 0L; var bSum = 0L; var count = 0
            val stepX = max(1, (r - l) / 12)
            val stepY = max(1, (b - t) / 8)
            var y = t
            while (y < b) {
                var x = l
                while (x < r) {
                    val c = bmp.getPixel(x, y)
                    val bright = (Color.red(c) + Color.green(c) + Color.blue(c)) / 3
                    if (Color.alpha(c) > 40 && bright in 35..230) {
                        rSum += Color.red(c); gSum += Color.green(c); bSum += Color.blue(c); count++
                    }
                    x += stepX
                }
                y += stepY
            }
            if (count < 3) PrefsHelper.DEFAULT_SUB_COLOR
            else Color.rgb((rSum / count).toInt(), (gSum / count).toInt(), (bSum / count).toInt())
        } catch (_: Exception) { PrefsHelper.DEFAULT_SUB_COLOR }
    }

    private fun stopOcr() {
        isRunning = false
        try { virtualDisplay?.release() } catch (_: Exception) {}
        try { imageReader?.close() } catch (_: Exception) {}
        try { mediaProjection?.stop() } catch (_: Exception) {}
        virtualDisplay = null
        imageReader = null
        mediaProjection = null
        ocrThread?.quitSafely()
        ocrThread = null
        ocrHandler = null
        isBarVisible = false
        removeBar()
        updateNotification()
        broadcastStatus()
        Toast.makeText(this, "Detección detenida", Toast.LENGTH_SHORT).show()
    }

    // ---------- FLOATING BAR (larger icons, click-safe) ----------
    private fun showBar() {
        if (barView != null) return
        val iconSize = 88
        val pad = 16
        val purple = Color.parseColor("#C77DFF")
        val purpleBg = Color.parseColor("#E61A0A2E")

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(purpleBg)
                cornerRadius = 52f
                setStroke(3, Color.parseColor("#9C27FF"))
            }
            setPadding(12, 18, 12, 18)
            elevation = 20f
        }

        fun icon(res: Int, color: Int, onClick: () -> Unit): ImageView {
            return ImageView(this).apply {
                setImageResource(res)
                setColorFilter(color)
                setPadding(pad, pad, pad, pad)
                layoutParams = LinearLayout.LayoutParams(iconSize, iconSize)
                isClickable = true
                isFocusable = true
                setOnClickListener { onClick() }
            }
        }

        if (isRunning) {
            bar.addView(icon(android.R.drawable.ic_media_pause, purple) {
                stopOcr()
                refreshBarIcons()
            })
        } else {
            bar.addView(icon(android.R.drawable.ic_media_play, purple) {
                startActivity(Intent(this, ScreenCaptureActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            })
        }

        bar.addView(icon(android.R.drawable.ic_menu_view, purple) {
            isBarVisible = false
            removeBar()
            updateNotification()
        })

        bar.addView(icon(android.R.drawable.ic_menu_close_clear_cancel, purple) {
            if (isRunning) stopOcr()
            removeBar()
            removeAreaSelector()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        })

        val move = icon(android.R.drawable.ic_menu_directions, purple) {}
        bar.addView(move)

        barParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 20
            y = 360
        }

        var ix = 0; var iy = 0; var tx = 0f; var ty = 0f
        move.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    ix = barParams!!.x; iy = barParams!!.y
                    tx = e.rawX; ty = e.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    barParams!!.x = ix + (e.rawX - tx).toInt()
                    barParams!!.y = iy + (e.rawY - ty).toInt()
                    try { windowManager.updateViewLayout(barView, barParams) } catch (_: Exception) {}
                    true
                }
                else -> false
            }
        }

        barView = bar
        try { windowManager.addView(bar, barParams) } catch (e: Exception) { e.printStackTrace() }
    }

    private fun refreshBarIcons() {
        if (isBarVisible) {
            removeBar()
            showBar()
        }
    }

    private fun removeBar() {
        barView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        barView = null
    }

    // ---------- AREA SELECTOR (non-blocking full screen — Home/recents work) ----------
    private fun showAreaSelector() {
        if (areaRoot != null) return
        prefs.getArea()?.let {
            boxLeft = it[0]; boxTop = it[1]
            boxWidth = (it[2] - it[0]).coerceAtLeast(120)
            boxHeight = (it[3] - it[1]).coerceAtLeast(80)
        }

        val root = FrameLayout(this)
        // Semi-transparent but we use FLAG_NOT_TOUCH_MODAL so system gestures work better
        root.setBackgroundColor(Color.parseColor("#55000000"))

        val box = View(this).apply {
            background = GradientDrawable().apply {
                setStroke(6, Color.parseColor("#7C4DFF"))
                setColor(Color.parseColor("#337C4DFF"))
            }
        }
        fun handle() = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#7C4DFF"))
            }
        }
        val hTL = handle(); val hTR = handle(); val hBL = handle(); val hBR = handle()
        val hs = 52
        root.addView(box); root.addView(hTL); root.addView(hTR); root.addView(hBL); root.addView(hBR)

        fun update() {
            box.layoutParams = FrameLayout.LayoutParams(boxWidth, boxHeight).apply {
                leftMargin = boxLeft; topMargin = boxTop
            }
            fun place(h: View, x: Int, y: Int) {
                h.layoutParams = FrameLayout.LayoutParams(hs, hs).apply {
                    leftMargin = x - hs / 2; topMargin = y - hs / 2
                }
            }
            place(hTL, boxLeft, boxTop)
            place(hTR, boxLeft + boxWidth, boxTop)
            place(hBL, boxLeft, boxTop + boxHeight)
            place(hBR, boxLeft + boxWidth, boxTop + boxHeight)
        }
        update()

        var dsx = 0f; var dsy = 0f; var sl = 0; var st = 0
        box.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dsx = e.rawX; dsy = e.rawY; sl = boxLeft; st = boxTop; true }
                MotionEvent.ACTION_MOVE -> {
                    boxLeft = max(0, sl + (e.rawX - dsx).toInt())
                    boxTop = max(0, st + (e.rawY - dsy).toInt())
                    update(); true
                }
                else -> false
            }
        }

        fun setupH(h: View, type: String) {
            var sx = 0f; var sy = 0f; var ol = 0; var ot = 0; var ow = 0; var oh = 0
            h.setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = e.rawX; sy = e.rawY; ol = boxLeft; ot = boxTop; ow = boxWidth; oh = boxHeight; true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                        when (type) {
                            "TL" -> { boxLeft = ol + dx; boxTop = ot + dy; boxWidth = ow - dx; boxHeight = oh - dy }
                            "TR" -> { boxTop = ot + dy; boxWidth = ow + dx; boxHeight = oh - dy }
                            "BL" -> { boxLeft = ol + dx; boxWidth = ow - dx; boxHeight = oh + dy }
                            "BR" -> { boxWidth = ow + dx; boxHeight = oh + dy }
                        }
                        if (boxWidth < 100) boxWidth = 100
                        if (boxHeight < 60) boxHeight = 60
                        if (boxLeft < 0) boxLeft = 0
                        if (boxTop < 0) boxTop = 0
                        update(); true
                    }
                    else -> false
                }
            }
        }
        setupH(hTL, "TL"); setupH(hTR, "TR"); setupH(hBL, "BL"); setupH(hBR, "BR")

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(12, 12, 12, 12) }
        val ok = TextView(this).apply {
            text = "  Confirmar  "; setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#00E676")); setPadding(40, 22, 40, 22); textSize = 15f
            setOnClickListener {
                prefs.saveArea(boxLeft, boxTop, boxLeft + boxWidth, boxTop + boxHeight)
                Toast.makeText(this@FloatingService, "Área guardada", Toast.LENGTH_SHORT).show()
                removeAreaSelector()
                if (!isRunning) {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
            }
        }
        val cancel = TextView(this).apply {
            text = "  Cancelar  "; setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#FF5252")); setPadding(40, 22, 40, 22); textSize = 15f
            setOnClickListener {
                removeAreaSelector()
                if (!isRunning) {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
            }
        }
        row.addView(ok)
        row.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(16, 1) })
        row.addView(cancel)
        root.addView(row, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        ).apply { bottomMargin = 72 })

        val info = TextView(this).apply {
            text = "Ajusta el área · Pulsa Inicio para abrir WWE Champions · Luego Confirmar"
            setTextColor(Color.WHITE); textSize = 12f
            setPadding(16, 12, 16, 12)
            setBackgroundColor(Color.parseColor("#CC000000"))
        }
        root.addView(info, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.CENTER_HORIZONTAL
        ).apply { topMargin = 48 })

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        // NOT_FOCUSABLE allows Home button; user can open recents via gesture
        areaRoot = root
        try { windowManager.addView(root, params) } catch (e: Exception) { e.printStackTrace() }
    }

    private fun removeAreaSelector() {
        areaRoot?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        areaRoot = null
    }

    // ---------- NOTIFICATION (icons) ----------
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel("td_ocr", "Text Detector", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(): Notification {
        fun pi(id: Int, action: String) = PendingIntent.getService(
            this, id, Intent(this, FloatingService::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val name = prefs.getLastName()
        val b = NotificationCompat.Builder(this, "td_ocr")
            .setContentTitle("Text Detector")
            .setContentText("Última: $name")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(isRunning)
            .setOnlyAlertOnce(true)
            .setColor(Color.parseColor("#9C27FF"))
            .setColorized(true)

        if (isRunning) {
            b.addAction(android.R.drawable.ic_media_pause, "■", pi(1, ACTION_STOP))
        } else {
            b.addAction(android.R.drawable.ic_media_play, "▶", pi(2, ACTION_OPEN_APP))
        }
        if (isBarVisible) b.addAction(android.R.drawable.ic_menu_view, "👁", pi(3, ACTION_HIDE_BAR))
        else b.addAction(android.R.drawable.ic_menu_view, "👁", pi(4, ACTION_SHOW_BAR))
        b.addAction(android.R.drawable.ic_menu_preferences, "⚙", pi(5, ACTION_OPEN_APP))
        b.addAction(android.R.drawable.ic_menu_close_clear_cancel, "✕", pi(6, ACTION_CLOSE))
        return b.build()
    }

    private fun updateNotification() {
        try {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(1, buildNotification())
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        stopOcr()
        removeBar()
        removeAreaSelector()
        recognizer.close()
        super.onDestroy()
    }
}
