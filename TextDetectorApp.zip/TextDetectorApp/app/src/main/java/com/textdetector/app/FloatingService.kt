package com.textdetector.app

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import kotlin.math.max

class FloatingService : Service() {

    companion object {
        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
        const val ACTION_SELECT_AREA = "ACTION_SELECT_AREA"
        const val ACTION_SHOW_BALL = "ACTION_SHOW_BALL"
        const val ACTION_HIDE_BALL = "ACTION_HIDE_BALL"
        const val ACTION_CLOSE = "ACTION_CLOSE"
        const val ACTION_OPEN_APP = "ACTION_OPEN_APP"
        const val EXTRA_AREA_TYPE = "area_type"
        const val AREA_NORMAL = "normal"
        const val AREA_QUESTION = "question"
        const val AREA_OPTIONS = "options"

        var isRunning = false
        var isBarVisible = true
        private var serviceInstance: FloatingService? = null

        fun onNewDetection(name: String, subtitle: String) {
            serviceInstance?.updateNotification()
        }

        fun onTriviaDetected(question: String, options: List<String>) {
            serviceInstance?.showAnswerWindow(question, options)
        }
    }

    private lateinit var windowManager: WindowManager
    private lateinit var prefs: PrefsHelper
    private var barView: View? = null
    private var areaSelectorView: View? = null
    private var answerView: View? = null
    private var barParams: WindowManager.LayoutParams? = null
    private var currentAreaType = AREA_NORMAL

    // Area selector state
    private var boxLeft = 80
    private var boxTop = 350
    private var boxWidth = 650
    private var boxHeight = 220

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = PrefsHelper(this)
        serviceInstance = this
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                isRunning = true
                DetectionAccessibilityService.isDetecting.set(true)
                startForeground(1, buildNotification())
                if (isBarVisible) showBar()
                updateNotification()
            }
            ACTION_STOP -> {
                isRunning = false
                DetectionAccessibilityService.isDetecting.set(false)
                refreshBar()
                updateNotification()
                Toast.makeText(this, "Detección detenida", Toast.LENGTH_SHORT).show()
            }
            ACTION_SELECT_AREA -> {
                currentAreaType = intent.getStringExtra(EXTRA_AREA_TYPE) ?: AREA_NORMAL
                startForeground(1, buildNotification())
                removeBar()
                showAreaSelector()
            }
            ACTION_SHOW_BALL -> {
                isBarVisible = true
                showBar()
                updateNotification()
            }
            ACTION_HIDE_BALL -> {
                isBarVisible = false
                removeBar()
                updateNotification()
            }
            ACTION_OPEN_APP -> {
                val i = Intent(this, MainActivity::class.java)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            }
            ACTION_CLOSE -> stopEverything()
            else -> {
                startForeground(1, buildNotification())
                if (isBarVisible) showBar()
            }
        }
        return START_STICKY
    }

    private fun stopEverything() {
        DetectionAccessibilityService.isDetecting.set(false)
        isRunning = false
        removeBar()
        removeAreaSelector()
        removeAnswerWindow()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ========== FLOATING BAR ==========
    private fun refreshBar() {
        if (isBarVisible) {
            removeBar()
            showBar()
        }
    }

    private fun showBar() {
        if (barView != null) return
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#E61E1E1E"))
                cornerRadius = 48f
            }
            setPadding(14, 22, 14, 22)
            elevation = 14f
        }
        val size = 70
        fun addIcon(res: Int, color: Int, click: () -> Unit) {
            val iv = ImageView(this).apply {
                setImageResource(res)
                setColorFilter(color)
                setPadding(14, 14, 14, 14)
                layoutParams = LinearLayout.LayoutParams(size, size)
                setOnClickListener { click() }
            }
            bar.addView(iv)
        }

        if (DetectionAccessibilityService.isDetecting.get()) {
            addIcon(android.R.drawable.ic_media_pause, Color.parseColor("#F44336")) {
                isRunning = false
                DetectionAccessibilityService.isDetecting.set(false)
                refreshBar()
                updateNotification()
            }
        } else {
            addIcon(android.R.drawable.ic_media_play, Color.parseColor("#4CAF50")) {
                isRunning = true
                DetectionAccessibilityService.isDetecting.set(true)
                refreshBar()
                updateNotification()
            }
        }
        addIcon(android.R.drawable.ic_menu_view, Color.WHITE) {
            isBarVisible = false
            removeBar()
            updateNotification()
        }
        addIcon(android.R.drawable.ic_menu_close_clear_cancel, Color.parseColor("#F44336")) {
            stopEverything()
        }
        val moveIcon = ImageView(this).apply {
            setImageResource(android.R.drawable.ic_menu_directions)
            setColorFilter(Color.WHITE)
            setPadding(14, 14, 14, 14)
            layoutParams = LinearLayout.LayoutParams(size, size)
        }
        bar.addView(moveIcon)

        barParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 380
        }

        var ix = 0; var iy = 0; var itx = 0f; var ity = 0f
        val dragListener = View.OnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { ix = barParams!!.x; iy = barParams!!.y; itx = e.rawX; ity = e.rawY; true }
                MotionEvent.ACTION_MOVE -> {
                    barParams!!.x = ix + (e.rawX - itx).toInt()
                    barParams!!.y = iy + (e.rawY - ity).toInt()
                    try { windowManager.updateViewLayout(barView, barParams) } catch (_: Exception) {}
                    true
                }
                else -> false
            }
        }
        bar.setOnTouchListener(dragListener)
        moveIcon.setOnTouchListener(dragListener)

        barView = bar
        try { windowManager.addView(bar, barParams) } catch (e: Exception) { e.printStackTrace() }
    }

    private fun removeBar() {
        barView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        barView = null
    }

    // ========== AREA SELECTOR ==========
    private fun showAreaSelector() {
        if (areaSelectorView != null) return
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.parseColor("#66000000"))

        val box = View(this).apply {
            background = GradientDrawable().apply {
                setStroke(5, Color.parseColor("#2196F3"))
                setColor(Color.parseColor("#332196F3"))
            }
        }
        fun handle() = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#2196F3")) }
        }
        val hTL = handle(); val hTR = handle(); val hBL = handle(); val hBR = handle()
        val hSize = 46
        root.addView(box); root.addView(hTL); root.addView(hTR); root.addView(hBL); root.addView(hBR)

        fun update() {
            box.layoutParams = FrameLayout.LayoutParams(boxWidth, boxHeight).apply { leftMargin = boxLeft; topMargin = boxTop }
            fun place(h: View, x: Int, y: Int) {
                h.layoutParams = FrameLayout.LayoutParams(hSize, hSize).apply { leftMargin = x - hSize/2; topMargin = y - hSize/2 }
            }
            place(hTL, boxLeft, boxTop)
            place(hTR, boxLeft + boxWidth, boxTop)
            place(hBL, boxLeft, boxTop + boxHeight)
            place(hBR, boxLeft + boxWidth, boxTop + boxHeight)
        }
        update()

        var dsx = 0f; var dsy = 0f; var sl = 0; var st = 0
        box.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dsx = e.rawX; dsy = e.rawY; sl = boxLeft; st = boxTop; true }
                MotionEvent.ACTION_MOVE -> {
                    boxLeft = max(0, sl + (e.rawX - dsx).toInt())
                    boxTop = max(0, st + (e.rawY - dsy).toInt())
                    update(); true
                }
                else -> false
            }
        }

        fun setupH(h: View, type: String) {
            var sx = 0f; var sy = 0f; var ol = 0; var ot = 0; var ow = 0; var oh = 0
            h.setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ol = boxLeft; ot = boxTop; ow = boxWidth; oh = boxHeight; true }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                        when (type) {
                            "TL" -> { boxLeft = ol + dx; boxTop = ot + dy; boxWidth = ow - dx; boxHeight = oh - dy }
                            "TR" -> { boxTop = ot + dy; boxWidth = ow + dx; boxHeight = oh - dy }
                            "BL" -> { boxLeft = ol + dx; boxWidth = ow - dx; boxHeight = oh + dy }
                            "BR" -> { boxWidth = ow + dx; boxHeight = oh + dy }
                        }
                        if (boxWidth < 100) boxWidth = 100
                        if (boxHeight < 70) boxHeight = 70
                        if (boxLeft < 0) boxLeft = 0
                        if (boxTop < 0) boxTop = 0
                        update(); true
                    }
                    else -> false
                }
            }
        }
        setupH(hTL, "TL"); setupH(hTR, "TR"); setupH(hBL, "BL"); setupH(hBR, "BR")

        val btnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(16, 16, 16, 16) }
        val btnOk = TextView(this).apply {
            text = "  Confirmar  "; setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#4CAF50"))
            setPadding(36, 20, 36, 20); textSize = 15f
            setOnClickListener {
                when (currentAreaType) {
                    AREA_QUESTION -> prefs.saveQuestionArea(boxLeft, boxTop, boxLeft + boxWidth, boxTop + boxHeight)
                    AREA_OPTIONS -> prefs.saveOptionsArea(boxLeft, boxTop, boxLeft + boxWidth, boxTop + boxHeight)
                    else -> prefs.saveNormalArea(boxLeft, boxTop, boxLeft + boxWidth, boxTop + boxHeight)
                }
                Toast.makeText(this@FloatingService, "Área guardada", Toast.LENGTH_SHORT).show()
                removeAreaSelector()
                isBarVisible = true
                showBar()
            }
        }
        val btnCancel = TextView(this).apply {
            text = "  Cancelar  "; setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#F44336"))
            setPadding(36, 20, 36, 20); textSize = 15f
            setOnClickListener { removeAreaSelector(); isBarVisible = true; showBar() }
        }
        btnRow.addView(btnOk)
        btnRow.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(20, 1) })
        btnRow.addView(btnCancel)
        root.addView(btnRow, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = 70 })

        val info = TextView(this).apply {
            text = "Arrastra o ajusta • Puedes cambiar de app"
            setTextColor(Color.WHITE); textSize = 13f; setPadding(18, 12, 18, 12)
            setBackgroundColor(Color.parseColor("#AA000000"))
        }
        root.addView(info, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = 48 })

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        areaSelectorView = root
        try { windowManager.addView(root, params) } catch (e: Exception) { e.printStackTrace() }
    }

    private fun removeAreaSelector() {
        areaSelectorView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        areaSelectorView = null
    }

    // ========== ANSWER WINDOW (Intelligent) ==========
    private fun showAnswerWindow(question: String, options: List<String>) {
        // Simple heuristic answer for now (can be replaced with real AI/search later)
        val answer = if (options.isNotEmpty()) options.first() else "Buscando..."
        removeAnswerWindow()

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F01E1E1E"))
                cornerRadius = 24f
            }
            setPadding(32, 28, 32, 28)
            elevation = 20f
        }
        val title = TextView(this).apply {
            text = "Respuesta"; setTextColor(Color.parseColor("#AAAAAA")); textSize = 13f
        }
        val ans = TextView(this).apply {
            text = answer; setTextColor(Color.WHITE); textSize = 20f; setPadding(0, 12, 0, 12)
        }
        val conf = TextView(this).apply {
            text = if (options.isNotEmpty()) "Basado en opciones detectadas" else "Análisis básico"
            setTextColor(Color.parseColor("#4CAF50")); textSize = 12f
        }
        card.addView(title); card.addView(ans); card.addView(conf)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 180
        }
        answerView = card
        try { windowManager.addView(card, params) } catch (_: Exception) {}
    }

    private fun removeAnswerWindow() {
        answerView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        answerView = null
    }

    // ========== NOTIFICATION ==========
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel("text_detector_channel", "Text Detector", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(): Notification {
        fun pi(code: Int, action: String) = PendingIntent.getService(
            this, code, Intent(this, FloatingService::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val detecting = DetectionAccessibilityService.isDetecting.get()
        val status = if (detecting) "Detectando..." else "Detenido"
        val last = prefs.getLastName()

        val b = NotificationCompat.Builder(this, "text_detector_channel")
            .setContentTitle("Text Detector • $status")
            .setContentText("Última: $last")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setColor(Color.parseColor("#2196F3"))

        if (detecting) b.addAction(android.R.drawable.ic_media_pause, "Stop", pi(1, ACTION_STOP))
        else b.addAction(android.R.drawable.ic_media_play, "Start", pi(2, ACTION_START))

        if (isBarVisible) b.addAction(android.R.drawable.ic_menu_view, "Ocultar", pi(3, ACTION_HIDE_BALL))
        else b.addAction(android.R.drawable.ic_menu_view, "Mostrar", pi(4, ACTION_SHOW_BALL))

        b.addAction(android.R.drawable.ic_menu_preferences, "App", pi(5, ACTION_OPEN_APP))
        b.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Cerrar", pi(6, ACTION_CLOSE))
        return b.build()
    }

    private fun updateNotification() {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(1, buildNotification())
    }

    override fun onDestroy() {
        super.onDestroy()
        removeBar(); removeAreaSelector(); removeAnswerWindow()
        isRunning = false
        serviceInstance = null
    }
}
