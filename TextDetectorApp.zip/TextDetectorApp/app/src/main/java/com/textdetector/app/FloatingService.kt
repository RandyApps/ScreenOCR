package com.textdetector.app

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.core.app.NotificationCompat
import kotlin.math.max

class FloatingService : Service() {

    companion object {
        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
        const val ACTION_SELECT_AREA = "ACTION_SELECT_AREA"
        const val ACTION_SHOW_BALL = "ACTION_SHOW_BALL"
        const val ACTION_HIDE_BALL = "ACTION_HIDE_BALL"
        const val ACTION_CLOSE = "ACTION_CLOSE"
        const val ACTION_OPEN_APP = "ACTION_OPEN_APP"

        var isRunning = false
        var isBallVisible = true
    }

    private lateinit var windowManager: WindowManager
    private lateinit var prefs: PrefsHelper

    private var barView: View? = null
    private var areaSelectorView: View? = null
    private var barParams: WindowManager.LayoutParams? = null

    private var boxLeft = 100
    private var boxTop = 400
    private var boxWidth = 600
    private var boxHeight = 250

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = PrefsHelper(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                isRunning = true
                DetectionAccessibilityService.isDetecting.set(true)
                startForeground(1, buildNotification())
                refreshBar()
                updateNotification()
            }
            ACTION_STOP -> {
                isRunning = false
                DetectionAccessibilityService.isDetecting.set(false)
                refreshBar()
                updateNotification()
                Toast.makeText(this, "Detección detenida", Toast.LENGTH_SHORT).show()
            }
            ACTION_SELECT_AREA -> {
                startForeground(1, buildNotification())
                removeBar()
                showAreaSelector()
            }
            ACTION_SHOW_BALL -> {
                isBallVisible = true
                showBar()
                updateNotification()
            }
            ACTION_HIDE_BALL -> {
                isBallVisible = false
                removeBar()
                updateNotification()
            }
            ACTION_OPEN_APP -> {
                val i = Intent(this, MainActivity::class.java)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            }
            ACTION_CLOSE -> {
                stopEverything()
            }
            else -> {
                startForeground(1, buildNotification())
                if (isBallVisible) showBar()
            }
        }
        return START_STICKY
    }

    private fun stopEverything() {
        DetectionAccessibilityService.isDetecting.set(false)
        isRunning = false
        removeBar()
        removeAreaSelector()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun refreshBar() {
        if (isBallVisible) {
            removeBar()
            showBar()
        }
    }

    private fun showBar() {
        if (barView != null) return

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val bg = GradientDrawable().apply {
                setColor(Color.parseColor("#E61E1E1E"))
                cornerRadius = 48f
            }
            background = bg
            setPadding(12, 20, 12, 20)
            elevation = 12f
        }

        val iconSize = 72
        val iconPadding = 16

        fun addIcon(resId: Int, color: Int, action: () -> Unit): ImageView {
            val iv = ImageView(this).apply {
                setImageResource(resId)
                setColorFilter(color)
                setPadding(iconPadding, iconPadding, iconPadding, iconPadding)
                layoutParams = LinearLayout.LayoutParams(iconSize, iconSize)
                setOnClickListener { action() }
            }
            bar.addView(iv)
            return iv
        }

        if (DetectionAccessibilityService.isDetecting.get()) {
            addIcon(android.R.drawable.ic_media_pause, Color.parseColor("#F44336")) {
                isRunning = false
                DetectionAccessibilityService.isDetecting.set(false)
                refreshBar()
                updateNotification()
                Toast.makeText(this, "Detección detenida", Toast.LENGTH_SHORT).show()
            }
        } else {
            addIcon(android.R.drawable.ic_media_play, Color.parseColor("#4CAF50")) {
                isRunning = true
                DetectionAccessibilityService.isDetecting.set(true)
                refreshBar()
                updateNotification()
                Toast.makeText(this, "Detección iniciada", Toast.LENGTH_SHORT).show()
            }
        }

        addIcon(android.R.drawable.ic_menu_view, Color.WHITE) {
            isBallVisible = false
            removeBar()
            updateNotification()
        }

        addIcon(android.R.drawable.ic_menu_close_clear_cancel, Color.parseColor("#F44336")) {
            stopEverything()
        }

        val moveIcon = addIcon(android.R.drawable.ic_menu_directions, Color.WHITE) {}

        barParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 20
            y = 350
        }

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        bar.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = barParams!!.x
                    initialY = barParams!!.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    barParams!!.x = initialX + (event.rawX - initialTouchX).toInt()
                    barParams!!.y = initialY + (event.rawY - initialTouchY).toInt()
                    try { windowManager.updateViewLayout(barView, barParams) } catch (_: Exception) {}
                    true
                }
                else -> false
            }
        }

        moveIcon.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = barParams!!.x
                    initialY = barParams!!.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    barParams!!.x = initialX + (event.rawX - initialTouchX).toInt()
                    barParams!!.y = initialY + (event.rawY - initialTouchY).toInt()
                    try { windowManager.updateViewLayout(barView, barParams) } catch (_: Exception) {}
                    true
                }
                else -> false
            }
        }

        barView = bar
        try {
            windowManager.addView(bar, barParams)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun removeBar() {
        barView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        barView = null
    }

    private fun showAreaSelector() {
        if (areaSelectorView != null) return

        if (prefs.isAreaSet()) {
            val area = prefs.getArea()
            boxLeft = area[0]
            boxTop = area[1]
            boxWidth = (area[2] - area[0]).coerceAtLeast(120)
            boxHeight = (area[3] - area[1]).coerceAtLeast(80)
        }

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.parseColor("#66000000"))

        val box = View(this).apply {
            background = GradientDrawable().apply {
                setStroke(5, Color.parseColor("#2196F3"))
                setColor(Color.parseColor("#332196F3"))
            }
        }

        fun createHandle(): View {
            return View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor("#2196F3"))
                }
            }
        }

        val handleSize = 48
        val handleTL = createHandle()
        val handleTR = createHandle()
        val handleBL = createHandle()
        val handleBR = createHandle()

        root.addView(box)
        root.addView(handleTL)
        root.addView(handleTR)
        root.addView(handleBL)
        root.addView(handleBR)

        fun updateBoxPosition() {
            val lp = FrameLayout.LayoutParams(boxWidth, boxHeight)
            lp.leftMargin = boxLeft
            lp.topMargin = boxTop
            box.layoutParams = lp

            fun placeHandle(h: View, x: Int, y: Int) {
                val hlp = FrameLayout.LayoutParams(handleSize, handleSize)
                hlp.leftMargin = x - handleSize / 2
                hlp.topMargin = y - handleSize / 2
                h.layoutParams = hlp
            }
            placeHandle(handleTL, boxLeft, boxTop)
            placeHandle(handleTR, boxLeft + boxWidth, boxTop)
            placeHandle(handleBL, boxLeft, boxTop + boxHeight)
            placeHandle(handleBR, boxLeft + boxWidth, boxTop + boxHeight)
        }

        updateBoxPosition()

        var dragStartX = 0f
        var dragStartY = 0f
        var startLeft = 0
        var startTop = 0

        box.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    dragStartX = event.rawX
                    dragStartY = event.rawY
                    startLeft = boxLeft
                    startTop = boxTop
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    boxLeft = max(0, startLeft + (event.rawX - dragStartX).toInt())
                    boxTop = max(0, startTop + (event.rawY - dragStartY).toInt())
                    updateBoxPosition()
                    true
                }
                else -> false
            }
        }

        fun setupHandle(handle: View, type: String) {
            var startX = 0f
            var startY = 0f
            var sLeft = 0
            var sTop = 0
            var sWidth = 0
            var sHeight = 0

            handle.setOnTouchListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = event.rawX
                        startY = event.rawY
                        sLeft = boxLeft
                        sTop = boxTop
                        sWidth = boxWidth
                        sHeight = boxHeight
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - startX).toInt()
                        val dy = (event.rawY - startY).toInt()
                        when (type) {
                            "TL" -> {
                                boxLeft = sLeft + dx
                                boxTop = sTop + dy
                                boxWidth = sWidth - dx
                                boxHeight = sHeight - dy
                            }
                            "TR" -> {
                                boxTop = sTop + dy
                                boxWidth = sWidth + dx
                                boxHeight = sHeight - dy
                            }
                            "BL" -> {
                                boxLeft = sLeft + dx
                                boxWidth = sWidth - dx
                                boxHeight = sHeight + dy
                            }
                            "BR" -> {
                                boxWidth = sWidth + dx
                                boxHeight = sHeight + dy
                            }
                        }
                        if (boxWidth < 120) boxWidth = 120
                        if (boxHeight < 80) boxHeight = 80
                        if (boxLeft < 0) boxLeft = 0
                        if (boxTop < 0) boxTop = 0
                        updateBoxPosition()
                        true
                    }
                    else -> false
                }
            }
        }

        setupHandle(handleTL, "TL")
        setupHandle(handleTR, "TR")
        setupHandle(handleBL, "BL")
        setupHandle(handleBR, "BR")

        val btnContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(20, 16, 20, 16)
        }

        val btnConfirm = android.widget.TextView(this).apply {
            text = "  Confirmar  "
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#4CAF50"))
            setPadding(36, 22, 36, 22)
            textSize = 16f
            setOnClickListener {
                prefs.saveArea(boxLeft, boxTop, boxLeft + boxWidth, boxTop + boxHeight)
                Toast.makeText(this@FloatingService, "Área guardada", Toast.LENGTH_SHORT).show()
                removeAreaSelector()
                isBallVisible = true
                showBar()
                updateNotification()
            }
        }

        val btnCancel = android.widget.TextView(this).apply {
            text = "  Cancelar  "
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#F44336"))
            setPadding(36, 22, 36, 22)
            textSize = 16f
            setOnClickListener {
                removeAreaSelector()
                isBallVisible = true
                showBar()
            }
        }

        btnContainer.addView(btnConfirm)
        btnContainer.addView(View(this).apply {
            layoutParams = LinearLayout.LayoutParams(24, 1)
        })
        btnContainer.addView(btnCancel)

        root.addView(btnContainer, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        ).apply { bottomMargin = 80 })

        val info = android.widget.TextView(this).apply {
            text = "Arrastra el cuadro o las esquinas • Puedes cambiar de app"
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(20, 14, 20, 14)
            setBackgroundColor(Color.parseColor("#AA000000"))
        }
        root.addView(info, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.CENTER_HORIZONTAL
        ).apply { topMargin = 50 })

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )

        areaSelectorView = root
        try {
            windowManager.addView(root, params)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Error: revisa el permiso de superposición", Toast.LENGTH_LONG).show()
        }
    }

    private fun removeAreaSelector() {
        areaSelectorView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        areaSelectorView = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "text_detector_channel",
                "Text Detector",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val showIntent = PendingIntent.getService(
            this, 1,
            Intent(this, FloatingService::class.java).setAction(ACTION_SHOW_BALL),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val hideIntent = PendingIntent.getService(
            this, 2,
            Intent(this, FloatingService::class.java).setAction(ACTION_HIDE_BALL),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val startIntent = PendingIntent.getService(
            this, 3,
            Intent(this, FloatingService::class.java).setAction(ACTION_START),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 4,
            Intent(this, FloatingService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val openIntent = PendingIntent.getService(
            this, 5,
            Intent(this, FloatingService::class.java).setAction(ACTION_OPEN_APP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val closeIntent = PendingIntent.getService(
            this, 6,
            Intent(this, FloatingService::class.java).setAction(ACTION_CLOSE),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val detecting = DetectionAccessibilityService.isDetecting.get()
        val status = if (detecting) "Detectando..." else "Detenido"
        val last = prefs.getLastDetectionFormatted()

        val builder = NotificationCompat.Builder(this, "text_detector_channel")
            .setContentTitle("Text Detector • $status")
            .setContentText("Última: $last")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setColor(Color.parseColor("#2196F3"))

        if (detecting) {
            builder.addAction(android.R.drawable.ic_media_pause, "Stop", stopIntent)
        } else {
            builder.addAction(android.R.drawable.ic_media_play, "Start", startIntent)
        }

        if (isBallVisible) {
            builder.addAction(android.R.drawable.ic_menu_view, "Ocultar", hideIntent)
        } else {
            builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Mostrar", showIntent)
        }

        builder.addAction(android.R.drawable.ic_menu_preferences, "App", openIntent)
        builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Cerrar", closeIntent)

        return builder.build()
    }

    private fun updateNotification() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(1, buildNotification())
    }

    override fun onDestroy() {
        super.onDestroy()
        removeBar()
        removeAreaSelector()
        isRunning = false
    }
}
