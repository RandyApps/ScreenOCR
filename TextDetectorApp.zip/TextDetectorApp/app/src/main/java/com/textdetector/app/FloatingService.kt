package com.textdetector.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import kotlin.math.abs

class FloatingService : Service() {

    companion object {
        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
        const val ACTION_SELECT_AREA = "ACTION_SELECT_AREA"
        const val ACTION_SHOW_BALL = "ACTION_SHOW_BALL"
        const val ACTION_HIDE_BALL = "ACTION_HIDE_BALL"
        const val ACTION_CLOSE = "ACTION_CLOSE"

        var isRunning = false
        private var lastDetectionForNotif = "Ninguna"

        fun updateLastDetection(text: String) {
            lastDetectionForNotif = text
        }
    }

    private lateinit var windowManager: WindowManager
    private lateinit var prefs: PrefsHelper

    private var ballView: View? = null
    private var menuView: View? = null
    private var areaSelectorView: View? = null

    private var ballParams: WindowManager.LayoutParams? = null
    private var isMenuOpen = false
    private var isBallVisible = true

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = PrefsHelper(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                isRunning = true
                DetectionAccessibilityService.isDetecting.set(true)
                startForeground(1, buildNotification())
                showBall()
            }
            ACTION_STOP -> {
                DetectionAccessibilityService.isDetecting.set(false)
                isRunning = false
                updateNotification()
                Toast.makeText(this, "Detección detenida", Toast.LENGTH_SHORT).show()
            }
            ACTION_SELECT_AREA -> {
                startForeground(1, buildNotification())
                showAreaSelector()
            }
            ACTION_SHOW_BALL -> {
                isBallVisible = true
                showBall()
                updateNotification()
            }
            ACTION_HIDE_BALL -> {
                isBallVisible = false
                removeBall()
                updateNotification()
            }
            ACTION_CLOSE -> {
                stopEverything()
            }
        }
        return START_STICKY
    }

    private fun stopEverything() {
        DetectionAccessibilityService.isDetecting.set(false)
        isRunning = false
        removeBall()
        removeMenu()
        removeAreaSelector()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ==================== FLOATING BALL ====================

    private fun showBall() {
        if (ballView != null) return

        val size = 120
        ballView = FrameLayout(this).apply {
            val circle = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#2196F3"))
            }
            background = circle

            val icon = ImageView(this@FloatingService).apply {
                setImageResource(android.R.drawable.ic_menu_view)
                setColorFilter(Color.WHITE)
                layoutParams = FrameLayout.LayoutParams(60, 60, Gravity.CENTER)
            }
            addView(icon)
        }

        ballParams = WindowManager.LayoutParams(
            size, size,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 50
            y = 300
        }

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isClick = true

        ballView?.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = ballParams!!.x
                    initialY = ballParams!!.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isClick = true
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) isClick = false
                    ballParams!!.x = initialX + dx
                    ballParams!!.y = initialY + dy
                    windowManager.updateViewLayout(ballView, ballParams)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (isClick) toggleMenu()
                    true
                }
                else -> false
            }
        }

        try {
            windowManager.addView(ballView, ballParams)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun removeBall() {
        ballView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        ballView = null
        removeMenu()
    }

    // ==================== MENU ====================

    private fun toggleMenu() {
        if (isMenuOpen) removeMenu() else showMenu()
    }

    private fun showMenu() {
        if (menuView != null) return
        isMenuOpen = true

        val menu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#DD1E1E1E"))
            setPadding(24, 16, 24, 16)
            elevation = 12f
        }

        fun addItem(text: String, color: Int, action: () -> Unit) {
            val tv = TextView(this).apply {
                this.text = text
                setTextColor(color)
                textSize = 16f
                setPadding(16, 20, 16, 20)
                setOnClickListener {
                    action()
                    removeMenu()
                }
            }
            menu.addView(tv)
        }

        addItem("▶  Comenzar", Color.parseColor("#4CAF50")) {
            DetectionAccessibilityService.isDetecting.set(true)
            isRunning = true
            updateNotification()
            Toast.makeText(this, "Detección iniciada", Toast.LENGTH_SHORT).show()
        }
        addItem("■  Detener", Color.parseColor("#F44336")) {
            DetectionAccessibilityService.isDetecting.set(false)
            isRunning = false
            updateNotification()
            Toast.makeText(this, "Detección detenida", Toast.LENGTH_SHORT).show()
        }
        addItem("👁  Ocultar bola", Color.WHITE) {
            isBallVisible = false
            removeBall()
            updateNotification()
        }
        addItem("✕  Cerrar", Color.parseColor("#F44336")) {
            stopEverything()
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (ballParams?.x ?: 50) - 20
            y = (ballParams?.y ?: 300) + 130
        }

        menuView = menu
        try {
            windowManager.addView(menu, params)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun removeMenu() {
        menuView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        menuView = null
        isMenuOpen = false
    }

    // ==================== AREA SELECTOR ====================

    private fun showAreaSelector() {
        if (areaSelectorView != null) return

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#88000000"))
        }

        // The resizable box
        val box = View(this).apply {
            background = GradientDrawable().apply {
                setStroke(6, Color.parseColor("#2196F3"))
                setColor(Color.parseColor("#332196F3"))
            }
        }

        val boxParams = FrameLayout.LayoutParams(600, 300).apply {
            gravity = Gravity.CENTER
        }
        root.addView(box, boxParams)

        // Instructions
        val instructions = TextView(this).apply {
            text = "Arrastra y ajusta el área • Luego pulsa Confirmar"
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding(20, 20, 20, 20)
        }
        root.addView(instructions, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        ).apply { bottomMargin = 180 })

        // Buttons container
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(20, 20, 20, 40)
        }

        val btnConfirm = TextView(this).apply {
            text = "  Confirmar  "
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#4CAF50"))
            setPadding(40, 24, 40, 24)
            textSize = 16f
            setOnClickListener {
                // Get absolute position of the box
                val location = IntArray(2)
                box.getLocationOnScreen(location)
                val left = location[0]
                val top = location[1]
                val right = left + box.width
                val bottom = top + box.height
                prefs.saveArea(left, top, right, bottom)
                Toast.makeText(this@FloatingService, "Área guardada", Toast.LENGTH_SHORT).show()
                removeAreaSelector()
                // Return to main or show ball
                val i = Intent(this@FloatingService, MainActivity::class.java)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
                stopSelf()
            }
        }

        val btnCancel = TextView(this).apply {
            text = "  Cancelar  "
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#F44336"))
            setPadding(40, 24, 40, 24)
            textSize = 16f
            setOnClickListener {
                removeAreaSelector()
                val i = Intent(this@FloatingService, MainActivity::class.java)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
                stopSelf()
            }
        }

        buttons.addView(btnConfirm)
        buttons.addView(View(this).apply {
            layoutParams = LinearLayout.LayoutParams(30, 1)
        })
        buttons.addView(btnCancel)

        root.addView(buttons, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        ).apply { bottomMargin = 60 })

        // Make box movable & resizable (simple version: drag to move, corners later if needed)
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        box.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = boxParams.leftMargin
                    initialY = boxParams.topMargin
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    // We need to change gravity to TOP|START for free movement
                    boxParams.gravity = Gravity.TOP or Gravity.START
                    if (boxParams.leftMargin == 0 && boxParams.topMargin == 0) {
                        val loc = IntArray(2)
                        v.getLocationOnScreen(loc)
                        boxParams.leftMargin = loc[0]
                        boxParams.topMargin = loc[1]
                    }
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    boxParams.leftMargin = initialX + (event.rawX - initialTouchX).toInt()
                    boxParams.topMargin = initialY + (event.rawY - initialTouchY).toInt()
                    v.layoutParams = boxParams
                    true
                }
                else -> false
            }
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )

        areaSelectorView = root
        try {
            windowManager.addView(root, params)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun removeAreaSelector() {
        areaSelectorView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        areaSelectorView = null
    }

    // ==================== NOTIFICATION ====================

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "text_detector_channel",
                "Text Detector",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Control de la detección de texto"
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val showIntent = PendingIntent.getService(
            this, 1,
            Intent(this, FloatingService::class.java).setAction(ACTION_SHOW_BALL),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val startIntent = PendingIntent.getService(
            this, 2,
            Intent(this, FloatingService::class.java).setAction(ACTION_START),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 3,
            Intent(this, FloatingService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val closeIntent = PendingIntent.getService(
            this, 4,
            Intent(this, FloatingService::class.java).setAction(ACTION_CLOSE),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val status = if (DetectionAccessibilityService.isDetecting.get()) "Detectando..." else "Detenido"
        val last = PrefsHelper(this).getLastDetectionFormatted()

        return NotificationCompat.Builder(this, "text_detector_channel")
            .setContentTitle("Text Detector - $status")
            .setContentText("Última: $last")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(0, "Ver bola", showIntent)
            .addAction(0, "Comenzar", startIntent)
            .addAction(0, "Detener", stopIntent)
            .addAction(0, "Cerrar", closeIntent)
            .build()
    }

    private fun updateNotification() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(1, buildNotification())
    }

    override fun onDestroy() {
        super.onDestroy()
        removeBall()
        removeMenu()
        removeAreaSelector()
        isRunning = false
    }
}
