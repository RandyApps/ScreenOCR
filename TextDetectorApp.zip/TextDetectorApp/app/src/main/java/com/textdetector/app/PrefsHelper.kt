package com.textdetector.app

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class PrefsHelper(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("text_detector_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_LAST_NAME = "last_name"
        private const val KEY_LAST_SUBTITLE = "last_subtitle"
        private const val KEY_LAST_TIME = "last_time"
        private const val KEY_LAST_SUB_COLOR = "last_sub_color"
        private const val KEY_HISTORY = "history"
        private const val KEY_AREA = "area_normal"
        private const val MAX_HISTORY = 150
        const val DEFAULT_SUB_COLOR = 0xFFFF4081.toInt() // pink fallback
    }

    fun saveLastDetection(name: String, subtitle: String = "", subtitleColor: Int = DEFAULT_SUB_COLOR) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        prefs.edit()
            .putString(KEY_LAST_NAME, name)
            .putString(KEY_LAST_SUBTITLE, subtitle)
            .putString(KEY_LAST_TIME, time)
            .putInt(KEY_LAST_SUB_COLOR, subtitleColor)
            .apply()
        addToHistory(name, subtitle, time, subtitleColor)
    }

    fun getLastName(): String = prefs.getString(KEY_LAST_NAME, null) ?: "Ninguna"
    fun getLastSubtitle(): String = prefs.getString(KEY_LAST_SUBTITLE, "") ?: ""
    fun getLastTime(): String = prefs.getString(KEY_LAST_TIME, "") ?: ""
    fun getLastSubtitleColor(): Int = prefs.getInt(KEY_LAST_SUB_COLOR, DEFAULT_SUB_COLOR)

    fun clearLastDetection() {
        prefs.edit()
            .remove(KEY_LAST_NAME)
            .remove(KEY_LAST_SUBTITLE)
            .remove(KEY_LAST_TIME)
            .remove(KEY_LAST_SUB_COLOR)
            .apply()
    }

    data class HistoryItem(
        val name: String,
        val subtitle: String,
        val time: String,
        val timestamp: Long,
        val subtitleColor: Int = DEFAULT_SUB_COLOR
    )

    private fun addToHistory(name: String, subtitle: String, time: String, subtitleColor: Int) {
        val list = getHistory().toMutableList()
        if (list.isNotEmpty() && list[0].name == name && list[0].subtitle == subtitle) return
        list.add(0, HistoryItem(name, subtitle, time, System.currentTimeMillis(), subtitleColor))
        if (list.size > MAX_HISTORY) list.subList(MAX_HISTORY, list.size).clear()
        saveHistory(list)
    }

    fun getHistory(): List<HistoryItem> {
        val json = prefs.getString(KEY_HISTORY, "[]") ?: "[]"
        val list = mutableListOf<HistoryItem>()
        try {
            val array = JSONArray(json)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    HistoryItem(
                        obj.optString("name", ""),
                        obj.optString("subtitle", ""),
                        obj.optString("time", ""),
                        obj.optLong("timestamp", 0L),
                        obj.optInt("subtitleColor", DEFAULT_SUB_COLOR)
                    )
                )
            }
        } catch (_: Exception) {}
        return list
    }

    private fun saveHistory(list: List<HistoryItem>) {
        val array = JSONArray()
        list.forEach {
            array.put(JSONObject().apply {
                put("name", it.name)
                put("subtitle", it.subtitle)
                put("time", it.time)
                put("timestamp", it.timestamp)
                put("subtitleColor", it.subtitleColor)
            })
        }
        prefs.edit().putString(KEY_HISTORY, array.toString()).apply()
    }

    fun clearHistory() {
        prefs.edit().putString(KEY_HISTORY, "[]").apply()
        clearLastDetection()
    }

    fun saveArea(left: Int, top: Int, right: Int, bottom: Int) {
        prefs.edit().putString(KEY_AREA, "$left,$top,$right,$bottom").apply()
    }

    fun getArea(): IntArray? {
        val v = prefs.getString(KEY_AREA, null) ?: return null
        return try {
            val p = v.split(",").map { it.toInt() }
            intArrayOf(p[0], p[1], p[2], p[3])
        } catch (_: Exception) { null }
    }

    fun isAreaSet(): Boolean = prefs.getString(KEY_AREA, null) != null
}
