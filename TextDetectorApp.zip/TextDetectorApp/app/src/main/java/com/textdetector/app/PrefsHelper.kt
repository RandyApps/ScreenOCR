package com.textdetector.app

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class PrefsHelper(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("text_detector_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_MODE = "app_mode" // "normal" or "intelligent"
        private const val KEY_LAST_NAME = "last_name"
        private const val KEY_LAST_SUBTITLE = "last_subtitle"
        private const val KEY_LAST_TIME = "last_time"
        private const val KEY_HISTORY = "history"
        private const val KEY_AREA_NORMAL = "area_normal"
        private const val KEY_AREA_QUESTION = "area_question"
        private const val KEY_AREA_OPTIONS = "area_options"
        private const val MAX_HISTORY = 150
    }

    // Mode
    fun setMode(mode: String) = prefs.edit().putString(KEY_MODE, mode).apply()
    fun getMode(): String = prefs.getString(KEY_MODE, "normal") ?: "normal"
    fun isIntelligentMode(): Boolean = getMode() == "intelligent"

    // Last detection (Normal mode)
    fun saveLastDetection(name: String, subtitle: String = "") {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        prefs.edit()
            .putString(KEY_LAST_NAME, name)
            .putString(KEY_LAST_SUBTITLE, subtitle)
            .putString(KEY_LAST_TIME, time)
            .apply()
        addToHistory(name, subtitle, time)
    }

    fun getLastName(): String = prefs.getString(KEY_LAST_NAME, null) ?: "Ninguna"
    fun getLastSubtitle(): String = prefs.getString(KEY_LAST_SUBTITLE, "") ?: ""
    fun getLastTime(): String = prefs.getString(KEY_LAST_TIME, "") ?: ""

    fun getLastDetectionFormatted(): String {
        val name = getLastName()
        if (name == "Ninguna") return "Ninguna"
        val sub = getLastSubtitle()
        val time = getLastTime()
        return if (sub.isNotEmpty()) "$name\n$sub • $time" else "$name • $time"
    }

    // History
    data class HistoryItem(
        val name: String,
        val subtitle: String,
        val time: String,
        val timestamp: Long
    )

    private fun addToHistory(name: String, subtitle: String, time: String) {
        val list = getHistory().toMutableList()
        if (list.isNotEmpty() && list[0].name == name && list[0].subtitle == subtitle) return
        list.add(0, HistoryItem(name, subtitle, time, System.currentTimeMillis()))
        if (list.size > MAX_HISTORY) list.subList(MAX_HISTORY, list.size).clear()
        saveHistory(list)
    }

    fun getHistory(): List<HistoryItem> {
        val json = prefs.getString(KEY_HISTORY, "[]") ?: "[]"
        val list = mutableListOf<HistoryItem>()
        try {
            val array = JSONArray(json)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    HistoryItem(
                        obj.optString("name", obj.optString("text", "")),
                        obj.optString("subtitle", ""),
                        obj.optString("time", ""),
                        obj.optLong("timestamp", 0L)
                    )
                )
            }
        } catch (_: Exception) {}
        return list
    }

    private fun saveHistory(list: List<HistoryItem>) {
        val array = JSONArray()
        list.forEach {
            val obj = JSONObject()
            obj.put("name", it.name)
            obj.put("subtitle", it.subtitle)
            obj.put("time", it.time)
            obj.put("timestamp", it.timestamp)
            array.put(obj)
        }
        prefs.edit().putString(KEY_HISTORY, array.toString()).apply()
    }

    fun clearHistory() = prefs.edit().putString(KEY_HISTORY, "[]").apply()

    // Areas
    fun saveArea(key: String, left: Int, top: Int, right: Int, bottom: Int) {
        val value = "$left,$top,$right,$bottom"
        prefs.edit().putString(key, value).apply()
    }

    fun getArea(key: String): IntArray? {
        val value = prefs.getString(key, null) ?: return null
        return try {
            val parts = value.split(",").map { it.toInt() }
            intArrayOf(parts[0], parts[1], parts[2], parts[3])
        } catch (_: Exception) { null }
    }

    fun isAreaSet(key: String): Boolean = prefs.getString(key, null) != null

    fun saveNormalArea(l: Int, t: Int, r: Int, b: Int) = saveArea(KEY_AREA_NORMAL, l, t, r, b)
    fun getNormalArea() = getArea(KEY_AREA_NORMAL)
    fun isNormalAreaSet() = isAreaSet(KEY_AREA_NORMAL)

    fun saveQuestionArea(l: Int, t: Int, r: Int, b: Int) = saveArea(KEY_AREA_QUESTION, l, t, r, b)
    fun getQuestionArea() = getArea(KEY_AREA_QUESTION)
    fun isQuestionAreaSet() = isAreaSet(KEY_AREA_QUESTION)

    fun saveOptionsArea(l: Int, t: Int, r: Int, b: Int) = saveArea(KEY_AREA_OPTIONS, l, t, r, b)
    fun getOptionsArea() = getArea(KEY_AREA_OPTIONS)
    fun isOptionsAreaSet() = isAreaSet(KEY_AREA_OPTIONS)
}
