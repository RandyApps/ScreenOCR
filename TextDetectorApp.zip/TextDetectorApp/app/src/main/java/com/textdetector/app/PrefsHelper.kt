package com.textdetector.app

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class PrefsHelper(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("text_detector_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_LAST_TEXT = "last_text"
        private const val KEY_LAST_TIME = "last_time"
        private const val KEY_HISTORY = "history"
        private const val KEY_AREA_LEFT = "area_left"
        private const val KEY_AREA_TOP = "area_top"
        private const val KEY_AREA_RIGHT = "area_right"
        private const val KEY_AREA_BOTTOM = "area_bottom"
        private const val KEY_AREA_SET = "area_set"
        private const val MAX_HISTORY = 100
    }

    fun saveLastDetection(text: String) {
        val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        prefs.edit()
            .putString(KEY_LAST_TEXT, text)
            .putString(KEY_LAST_TIME, time)
            .apply()

        addToHistory(text, time)
    }

    fun getLastDetectionText(): String {
        return prefs.getString(KEY_LAST_TEXT, null) ?: "Ninguna"
    }

    fun getLastDetectionTime(): String {
        return prefs.getString(KEY_LAST_TIME, "") ?: ""
    }

    fun getLastDetectionFormatted(): String {
        val text = getLastDetectionText()
        val time = getLastDetectionTime()
        return if (text == "Ninguna" || time.isEmpty()) {
            "Ninguna"
        } else {
            "$text [$time]"
        }
    }

    private fun addToHistory(text: String, time: String) {
        val history = getHistory().toMutableList()
        // Avoid duplicates of the exact same text consecutively
        if (history.isNotEmpty() && history[0].text == text) return

        history.add(0, HistoryItem(text, time, System.currentTimeMillis()))
        if (history.size > MAX_HISTORY) {
            history.subList(MAX_HISTORY, history.size).clear()
        }
        saveHistory(history)
    }

    fun getHistory(): List<HistoryItem> {
        val json = prefs.getString(KEY_HISTORY, "[]") ?: "[]"
        val list = mutableListOf<HistoryItem>()
        try {
            val array = JSONArray(json)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    HistoryItem(
                        obj.getString("text"),
                        obj.getString("time"),
                        obj.getLong("timestamp")
                    )
                )
            }
        } catch (_: Exception) {}
        return list
    }

    private fun saveHistory(list: List<HistoryItem>) {
        val array = JSONArray()
        list.forEach {
            val obj = JSONObject()
            obj.put("text", it.text)
            obj.put("time", it.time)
            obj.put("timestamp", it.timestamp)
            array.put(obj)
        }
        prefs.edit().putString(KEY_HISTORY, array.toString()).apply()
    }

    fun clearHistory() {
        prefs.edit().putString(KEY_HISTORY, "[]").apply()
    }

    // Area
    fun saveArea(left: Int, top: Int, right: Int, bottom: Int) {
        prefs.edit()
            .putInt(KEY_AREA_LEFT, left)
            .putInt(KEY_AREA_TOP, top)
            .putInt(KEY_AREA_RIGHT, right)
            .putInt(KEY_AREA_BOTTOM, bottom)
            .putBoolean(KEY_AREA_SET, true)
            .apply()
    }

    fun isAreaSet(): Boolean = prefs.getBoolean(KEY_AREA_SET, false)

    fun getArea(): IntArray {
        return intArrayOf(
            prefs.getInt(KEY_AREA_LEFT, 0),
            prefs.getInt(KEY_AREA_TOP, 0),
            prefs.getInt(KEY_AREA_RIGHT, 0),
            prefs.getInt(KEY_AREA_BOTTOM, 0)
        )
    }

    data class HistoryItem(val text: String, val time: String, val timestamp: Long)
}
