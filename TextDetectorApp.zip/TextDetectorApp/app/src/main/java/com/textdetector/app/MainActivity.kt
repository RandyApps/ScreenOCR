package com.textdetector.app

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.textdetector.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: PrefsHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = PrefsHelper(this)
        updateUI()

        binding.btnDesignateArea.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                requestOverlayPermission()
                return@setOnClickListener
            }
            // Start area selection via FloatingService
            val intent = Intent(this, FloatingService::class.java).apply {
                action = FloatingService.ACTION_SELECT_AREA
            }
            startForegroundService(intent)
            finish() // close main activity while selecting
        }

        binding.btnStart.setOnClickListener {
            if (!isAccessibilityEnabled()) {
                showAccessibilityDialog()
                return@setOnClickListener
            }
            if (!Settings.canDrawOverlays(this)) {
                requestOverlayPermission()
                return@setOnClickListener
            }
            if (!prefs.isAreaSet()) {
                Toast.makeText(this, "Primero designa el área de detección", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            val intent = Intent(this, FloatingService::class.java).apply {
                action = FloatingService.ACTION_START
            }
            startForegroundService(intent)
            Toast.makeText(this, "Detección iniciada", Toast.LENGTH_SHORT).show()
            finish()
        }

        binding.btnStop.setOnClickListener {
            val intent = Intent(this, FloatingService::class.java).apply {
                action = FloatingService.ACTION_STOP
            }
            startService(intent)
            Toast.makeText(this, "Detección detenida", Toast.LENGTH_SHORT).show()
            updateUI()
        }

        binding.btnHistory.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        updateUI()
    }

    private fun updateUI() {
        binding.tvLastDetection.text = prefs.getLastDetectionFormatted()
        // Status is approximate; real status is in the service
        binding.tvStatus.text = if (FloatingService.isRunning) "Servicio activo" else "Servicio detenido"
    }

    private fun isAccessibilityEnabled(): Boolean {
        val am = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabledServices = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_GENERIC)
        return enabledServices.any { it.resolveInfo.serviceInfo.packageName == packageName }
    }

    private fun showAccessibilityDialog() {
        AlertDialog.Builder(this)
            .setTitle("Permiso de Accesibilidad")
            .setMessage("Esta app necesita el permiso de Accesibilidad para poder leer el texto de la zona seleccionada.\n\nSe usará únicamente para detectar el nombre de las superstars.")
            .setPositiveButton("Activar") { _, _ ->
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun requestOverlayPermission() {
        AlertDialog.Builder(this)
            .setTitle("Permiso de Superposición")
            .setMessage("Necesitas permitir que la app se muestre sobre otras aplicaciones (bola flotante y selector de área).")
            .setPositiveButton("Permitir") { _, _ ->
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
