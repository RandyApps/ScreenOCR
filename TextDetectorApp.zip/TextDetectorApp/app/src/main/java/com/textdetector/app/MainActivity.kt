package com.textdetector.app

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.accessibility.AccessibilityManager
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.textdetector.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: PrefsHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefs = PrefsHelper(this)

        setupModeSwitch()
        setupButtons()
        updateUI()
    }

    override fun onResume() {
        super.onResume()
        updateUI()
    }

    private fun setupModeSwitch() {
        val isIntelligent = prefs.isIntelligentMode()
        binding.switchMode.isChecked = isIntelligent
        updateModeUI(isIntelligent)

        binding.switchMode.setOnCheckedChangeListener { _, checked ->
            prefs.setMode(if (checked) "intelligent" else "normal")
            updateModeUI(checked)
        }
    }

    private fun updateModeUI(intelligent: Boolean) {
        binding.tvModeLabel.text = if (intelligent) "Modo Inteligente" else "Modo Normal"
        binding.layoutNormal.visibility = if (intelligent) View.GONE else View.VISIBLE
        binding.layoutIntelligent.visibility = if (intelligent) View.VISIBLE else View.GONE
    }

    private fun setupButtons() {
        // Normal mode
        binding.btnDesignateArea.setOnClickListener {
            if (!checkOverlay()) return@setOnClickListener
            startAreaSelection(FloatingService.AREA_NORMAL)
        }
        binding.btnStart.setOnClickListener {
            if (!checkAccessibility()) return@setOnClickListener
            if (!checkOverlay()) return@setOnClickListener
            if (!prefs.isNormalAreaSet()) {
                Toast.makeText(this, "Primero designa el área de detección", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            startServiceAction(FloatingService.ACTION_START)
            finish()
        }
        binding.btnStop.setOnClickListener {
            startServiceAction(FloatingService.ACTION_STOP)
            updateUI()
        }
        binding.btnHistory.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }

        // Intelligent mode
        binding.btnDesignateQuestion.setOnClickListener {
            if (!checkOverlay()) return@setOnClickListener
            startAreaSelection(FloatingService.AREA_QUESTION)
        }
        binding.btnDesignateOptions.setOnClickListener {
            if (!checkOverlay()) return@setOnClickListener
            startAreaSelection(FloatingService.AREA_OPTIONS)
        }
        binding.btnFullScreen.setOnClickListener {
            Toast.makeText(this, "Modo pantalla completa activado (IA analizará todo)", Toast.LENGTH_SHORT).show()
            // Flag can be stored in prefs if needed
        }
        binding.btnStartIntelligent.setOnClickListener {
            if (!checkAccessibility()) return@setOnClickListener
            if (!checkOverlay()) return@setOnClickListener
            startServiceAction(FloatingService.ACTION_START)
            finish()
        }
    }

    private fun startAreaSelection(areaType: String) {
        val intent = Intent(this, FloatingService::class.java).apply {
            action = FloatingService.ACTION_SELECT_AREA
            putExtra(FloatingService.EXTRA_AREA_TYPE, areaType)
        }
        startForegroundService(intent)
        finish()
    }

    private fun startServiceAction(action: String) {
        val intent = Intent(this, FloatingService::class.java).apply { this.action = action }
        if (action == FloatingService.ACTION_START) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        Toast.makeText(this, if (action == FloatingService.ACTION_START) "Detección iniciada" else "Detección detenida", Toast.LENGTH_SHORT).show()
    }

    private fun updateUI() {
        binding.tvLastName.text = prefs.getLastName()
        val sub = prefs.getLastSubtitle()
        binding.tvLastSubtitle.text = sub
        binding.tvLastSubtitle.visibility = if (sub.isNotEmpty()) View.VISIBLE else View.GONE
        binding.tvLastTime.text = prefs.getLastTime()
        binding.tvStatus.text = if (FloatingService.isRunning) "Servicio activo" else "Servicio detenido"
    }

    private fun checkAccessibility(): Boolean {
        if (isAccessibilityEnabled()) return true
        AlertDialog.Builder(this)
            .setTitle("Permiso de Accesibilidad")
            .setMessage("Necesario para leer el texto de la pantalla.")
            .setPositiveButton("Activar") { _, _ -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            .setNegativeButton("Cancelar", null)
            .show()
        return false
    }

    private fun checkOverlay(): Boolean {
        if (Settings.canDrawOverlays(this)) return true
        AlertDialog.Builder(this)
            .setTitle("Permiso de Superposición")
            .setMessage("Necesario para la barra flotante y el selector de área.")
            .setPositiveButton("Permitir") { _, _ ->
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
            .setNegativeButton("Cancelar", null)
            .show()
        return false
    }

    private fun isAccessibilityEnabled(): Boolean {
        val am = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        return am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_GENERIC)
            .any { it.resolveInfo.serviceInfo.packageName == packageName }
    }
}
