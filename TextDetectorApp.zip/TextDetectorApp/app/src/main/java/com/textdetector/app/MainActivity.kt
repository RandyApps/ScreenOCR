package com.textdetector.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.textdetector.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: PrefsHelper

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            updateUI()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefs = PrefsHelper(this)

        binding.cardDesignate.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                requestOverlay()
                return@setOnClickListener
            }
            startForegroundService(
                Intent(this, FloatingService::class.java).apply {
                    action = FloatingService.ACTION_SELECT_AREA
                }
            )
            moveTaskToBack(true)
        }

        binding.cardToggle.setOnClickListener {
            if (FloatingService.isRunning) {
                startService(Intent(this, FloatingService::class.java).apply {
                    action = FloatingService.ACTION_STOP
                })
            } else {
                if (!Settings.canDrawOverlays(this)) {
                    requestOverlay()
                    return@setOnClickListener
                }
                if (!prefs.isAreaSet()) {
                    Toast.makeText(this, "Primero designa el área", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                startActivity(Intent(this, ScreenCaptureActivity::class.java))
            }
            binding.root.postDelayed({ updateUI() }, 400)
        }

        binding.cardHistory.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }

        binding.cardIcons.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                requestOverlay()
                return@setOnClickListener
            }
            // Toggle visibility WITHOUT remove/add when possible
            val action = if (FloatingService.isBarVisible) {
                FloatingService.ACTION_HIDE_BAR
            } else {
                FloatingService.ACTION_SHOW_BAR
            }
            startForegroundService(
                Intent(this, FloatingService::class.java).apply { this.action = action }
            )
            binding.root.postDelayed({ updateUI() }, 250)
        }
    }

    override fun onResume() {
        super.onResume()
        updateUI()
        val f = IntentFilter(FloatingService.ACTION_STATUS_CHANGED)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(statusReceiver, f, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(statusReceiver, f)
        }
    }

    override fun onPause() {
        super.onPause()
        try { unregisterReceiver(statusReceiver) } catch (_: Exception) {}
    }

    private fun updateUI() {
        binding.tvLastName.text = prefs.getLastName()
        binding.tvLastName.setTextColor(0xFFFFFFFF.toInt())
        val sub = prefs.getLastSubtitle()
        if (sub.isNotEmpty()) {
            binding.tvLastSubtitle.text = sub
            binding.tvLastSubtitle.setTextColor(prefs.getLastSubtitleColor())
            binding.tvLastSubtitle.visibility = View.VISIBLE
        } else {
            binding.tvLastSubtitle.visibility = View.GONE
        }
        val time = prefs.getLastTime()
        binding.tvLastTime.text = if (time.isNotEmpty()) "• $time" else ""

        val running = FloatingService.isRunning
        if (running) {
            binding.tvToggle.text = "Detener"
            binding.iconToggle.setImageResource(android.R.drawable.ic_media_pause)
            binding.iconToggle.setColorFilter(0xFFFF5252.toInt())
            binding.tvStatus.text = "Detectando…"
            setDotColor(0xFF00E676.toInt())
        } else {
            binding.tvToggle.text = "Iniciar"
            binding.iconToggle.setImageResource(android.R.drawable.ic_media_play)
            binding.iconToggle.setColorFilter(0xFF69F0AE.toInt())
            binding.tvStatus.text = "Servicio detenido"
            setDotColor(0xFF8A8AA3.toInt())
        }

        // Eye open / eye with slash
        if (FloatingService.isBarVisible) {
            binding.iconIcons.setImageResource(R.drawable.ic_notif_eye)
            binding.iconIcons.setColorFilter(0xFFFF80AB.toInt())
        } else {
            binding.iconIcons.setImageResource(R.drawable.ic_notif_eye_off)
            binding.iconIcons.setColorFilter(0xFFFF80AB.toInt())
        }
    }

    private fun setDotColor(color: Int) {
        val d = GradientDrawable()
        d.shape = GradientDrawable.OVAL
        d.setColor(color)
        binding.statusDot.background = d
    }

    private fun requestOverlay() {
        AlertDialog.Builder(this)
            .setTitle("Permiso de superposición")
            .setMessage("Necesario para la barra flotante y el selector de área.")
            .setPositiveButton("Permitir") { _, _ ->
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
