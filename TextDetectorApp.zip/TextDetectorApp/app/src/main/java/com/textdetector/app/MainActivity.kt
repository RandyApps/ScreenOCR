package com.textdetector.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.textdetector.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: PrefsHelper

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            updateUI()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefs = PrefsHelper(this)

        binding.btnDesignateArea.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                requestOverlay()
                return@setOnClickListener
            }
            val i = Intent(this, FloatingService::class.java).apply {
                action = FloatingService.ACTION_SELECT_AREA
            }
            startForegroundService(i)
            // Do NOT finish - user can come back; overlay allows navigating
            Toast.makeText(this, "Coloca el área sobre el nombre. Puedes abrir WWE Champions.", Toast.LENGTH_LONG).show()
        }

        binding.btnToggle.setOnClickListener {
            if (FloatingService.isRunning) {
                val i = Intent(this, FloatingService::class.java).apply {
                    action = FloatingService.ACTION_STOP
                }
                startService(i)
            } else {
                if (!Settings.canDrawOverlays(this)) {
                    requestOverlay()
                    return@setOnClickListener
                }
                if (!prefs.isAreaSet()) {
                    Toast.makeText(this, "Primero designa el área de detección", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                // Request screen capture permission then start OCR
                startActivity(Intent(this, ScreenCaptureActivity::class.java))
            }
            binding.root.postDelayed({ updateUI() }, 400)
        }

        binding.btnHistory.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        updateUI()
        val f = IntentFilter(FloatingService.ACTION_STATUS_CHANGED)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(statusReceiver, f, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(statusReceiver, f)
        }
    }

    override fun onPause() {
        super.onPause()
        try { unregisterReceiver(statusReceiver) } catch (_: Exception) {}
    }

    private fun updateUI() {
        binding.tvLastName.text = prefs.getLastName()
        binding.tvLastName.setTextColor(0xFFFFFFFF.toInt())
        val sub = prefs.getLastSubtitle()
        if (sub.isNotEmpty()) {
            binding.tvLastSubtitle.text = sub
            binding.tvLastSubtitle.setTextColor(prefs.getLastSubtitleColor())
            binding.tvLastSubtitle.visibility = View.VISIBLE
        } else {
            binding.tvLastSubtitle.visibility = View.GONE
        }
        val time = prefs.getLastTime()
        binding.tvLastTime.text = if (time.isNotEmpty()) "• $time" else ""

        val running = FloatingService.isRunning
        if (running) {
            binding.btnToggle.text = "Detener Detección"
            binding.btnToggle.setBackgroundResource(R.drawable.bg_btn_red)
            binding.tvStatus.text = "Detectando…"
            setDotColor(0xFF00E676.toInt())
        } else {
            binding.btnToggle.text = "Iniciar Detección"
            binding.btnToggle.setBackgroundResource(R.drawable.bg_btn_green)
            binding.tvStatus.text = "Servicio detenido"
            setDotColor(0xFF8A8AA3.toInt())
        }
    }

    private fun setDotColor(color: Int) {
        val d = GradientDrawable()
        d.shape = GradientDrawable.OVAL
        d.setColor(color)
        binding.statusDot.background = d
    }

    private fun requestOverlay() {
        AlertDialog.Builder(this)
            .setTitle("Permiso de superposición")
            .setMessage("Necesario para la barra flotante y el selector de área.")
            .setPositiveButton("Permitir") { _, _ ->
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
