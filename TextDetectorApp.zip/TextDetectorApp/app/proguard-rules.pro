# Keep everything for now
-keep class com.textdetector.app.** { *; }
