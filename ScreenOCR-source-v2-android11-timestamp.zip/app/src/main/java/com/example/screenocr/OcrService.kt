package com.example.screenocr

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.*
import android.widget.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class OcrService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "data"
        const val CH = "ocr"
        const val ACTION_STOP = "stop"
        const val ACTION_SHOW = "show"
        const val ACTION_HIDE = "hide"
        const val ACTION_RESELECT = "reselect"
        const val ACTION_CLOSE = "close"
        const val ACTION_UPDATE = "update"
    }

    private lateinit var projection: MediaProjection
    private lateinit var reader: ImageReader
    private var display: VirtualDisplay? = null
    private val handler = Handler(Looper.getMainLooper())
    private var processing = false
    private var lastSaved = ""
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private var left=0; private var top=0; private var right=0; private var bottom=0
    private var selecting = true
    private var overlay: SelectionOverlay? = null
    private var bubble: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var controls: LinearLayout? = null
    private lateinit var wm: WindowManager
    private var hidden = false

    override fun onBind(intent: Intent?) = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopOcr(); return START_NOT_STICKY }
            ACTION_CLOSE -> { stopSelf(); return START_NOT_STICKY }
            ACTION_HIDE -> { hideBubble(); return START_STICKY }
            ACTION_SHOW -> { showBubble(); return START_STICKY }
            ACTION_RESELECT -> { selecting=true; showSelector(resources.displayMetrics.widthPixels, resources.displayMetrics.heightPixels); return START_STICKY }
        }
        if (intent == null || !intent.hasExtra(EXTRA_DATA)) return START_STICKY
        createChannel()
        startForeground(1, notification("Selecciona la zona de detección"), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val code=intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
        val data=intent.getParcelableExtra<Intent>(EXTRA_DATA) ?: return START_NOT_STICKY
        val pm=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection=pm.getMediaProjection(code,data)
        projection.registerCallback(object: MediaProjection.Callback(){ override fun onStop(){ stopSelf() } }, handler)

        val metrics=resources.displayMetrics
        reader=ImageReader.newInstance(metrics.widthPixels, metrics.heightPixels, PixelFormat.RGBA_8888, 2)
        display=projection.createVirtualDisplay("ScreenOCR", metrics.widthPixels, metrics.heightPixels, metrics.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, handler)
        reader.setOnImageAvailableListener({ if (!selecting) processLatest() }, handler)

        loadSavedRegion()
        showSelector(metrics.widthPixels, metrics.heightPixels)
        return START_STICKY
    }

    private fun loadSavedRegion() {
        left=prefs.getInt("region_left",0); top=prefs.getInt("region_top",0)
        right=prefs.getInt("region_right",0); bottom=prefs.getInt("region_bottom",0)
        if (right<=left || bottom<=top) selecting=true
    }

    private fun saveRegion() {
        prefs.edit().putInt("region_left",left).putInt("region_top",top)
            .putInt("region_right",right).putInt("region_bottom",bottom).apply()
    }

    private fun showSelector(w:Int,h:Int){
        handler.post {
            try { overlay?.let { wm.removeView(it) } } catch(_:Exception){}
            selecting=true
            overlay=SelectionOverlay(this,w,h,left,top,right,bottom) { l,t,r,b ->
                left=l; top=t; right=r; bottom=b; saveRegion()
                selecting=false
                try { overlay?.let { wm.removeView(it) } } catch(_:Exception){}
                overlay=null
                showBubble()
                updateNotification("Detectando texto en la zona seleccionada")
            }
            val lp=WindowManager.LayoutParams(
                w,h,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity=Gravity.TOP or Gravity.START
            try { wm.addView(overlay,lp) } catch(_:Exception) {}
        }
    }

    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()

    private fun makeButton(text:String, action:()->Unit): Button =
        Button(this).apply {
            this.text=text; textSize=13f; setTextColor(Color.WHITE)
            background=GradientDrawable().apply { setColor(Color.rgb(40,48,62)); cornerRadius=dp(12).toFloat() }
            setOnClickListener { action() }
        }

    private fun showBubble() {
        hidden=false
        if (bubble == null) createBubble() else { bubble?.visibility=View.VISIBLE; controls?.visibility=View.GONE }
    }

        var downX=0f; var downY=0f; var startX=0; var startY=0
        handle.setOnTouchListener { _,e ->
            when(e.action) {
                MotionEvent.ACTION_DOWN -> { downX=e.rawX; downY=e.rawY; startX=bubbleParams?.x ?: 0; startY=bubbleParams?.y ?: 0; true }
                MotionEvent.ACTION_MOVE -> {
                    bubbleParams?.let { p -> p.x=startX+(e.rawX-downX).toInt(); p.y=startY+(e.rawY-downY).toInt(); try{wm.updateViewLayout(container,p)}catch(_:Exception){} }; true
                }
                else -> false
            }
        }
    }

    private fun hideBubble(){ hidden=true; bubble?.visibility=View.GONE; controls?.visibility=View.GONE; updateNotification("OCR activo — usa la notificación para mostrar controles") }

    private fun createBubble(){
        // Reuse the full bubble construction above by invoking the constructor block only once.
        // This method is intentionally empty when the bubble already exists.
        if (bubble == null) {
            val box=LinearLayout(this).apply {
                orientation=LinearLayout.VERTICAL
                setPadding(dp(5),dp(5),dp(5),dp(5))
                background=GradientDrawable().apply { setColor(Color.rgb(25,31,42)); cornerRadius=dp(22).toFloat() }
                elevation=dp(8).toFloat()
            }
            val b=TextView(this).apply {
                text="OCR"; textSize=14f; gravity=Gravity.CENTER; setTextColor(Color.WHITE)
                background=GradientDrawable().apply { setColor(Color.rgb(55,115,220)); shape=GradientDrawable.OVAL }
                setOnClickListener { controls?.visibility = if(controls?.visibility==View.VISIBLE) View.GONE else View.VISIBLE }
            }
            box.addView(b,LinearLayout.LayoutParams(dp(58),dp(58)))
            val c=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; visibility=View.GONE; setPadding(dp(2),dp(4),dp(2),0) }
            c.addView(makeButton("▶ Reanudar") { resumeOcr() },LinearLayout.LayoutParams(dp(110),dp(42)))
            c.addView(makeButton("⏸ Detener") { stopOcr() },LinearLayout.LayoutParams(dp(110),dp(42)))
            c.addView(makeButton("▣ Nueva zona") { selecting=true; showSelector(resources.displayMetrics.widthPixels,resources.displayMetrics.heightPixels) },LinearLayout.LayoutParams(dp(110),dp(42)))
            c.addView(makeButton("— Ocultar") { hideBubble() },LinearLayout.LayoutParams(dp(110),dp(42)))
            c.addView(makeButton("✕ Cerrar") { stopSelf() },LinearLayout.LayoutParams(dp(110),dp(42)))
            box.addView(c); controls=c
            bubble=box
            bubbleParams=WindowManager.LayoutParams(dp(68),WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT).apply {
                gravity=Gravity.TOP or Gravity.START; x=resources.displayMetrics.widthPixels-dp(78); y=resources.displayMetrics.heightPixels/3
            }
            try { wm.addView(box,bubbleParams); addDrag(box,b) } catch(_:Exception) { bubble=null }
        }
    }

    private fun stopOcr(){ selecting=false; updateNotification("OCR detenido"); Toast.makeText(this,"Detección detenida",Toast.LENGTH_SHORT).show() }
    private fun resumeOcr(){ if(right>left && bottom>top){ selecting=false; updateNotification("Detectando texto"); showBubble() } }

    private fun processLatest(){
        if(processing || right<=left || bottom<=top) return
        processing=true
        val img=reader.acquireLatestImage() ?: run { processing=false; return }
        try {
            val plane=img.planes[0]; val buffer=plane.buffer
            val pixelStride=plane.pixelStride; val rowStride=plane.rowStride
            val rowPadding=rowStride-pixelStride*reader.width
            val padded=Bitmap.createBitmap(reader.width+rowPadding/pixelStride,reader.height,Bitmap.Config.ARGB_8888)
            padded.copyPixelsFromBuffer(buffer)
            val l=min(max(left,0),padded.width-1); val t=min(max(top,0),padded.height-1)
            val r=min(max(right,l+1),padded.width); val b=min(max(bottom,t+1),padded.height)
            if(r>l && b>t){
                val crop=Bitmap.createBitmap(padded,l,t,r-l,b-t)
                TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(InputImage.fromBitmap(crop,0)).addOnSuccessListener{ result ->
                    val text=result.text.trim().replace(Regex("\\s+")," ")
                    val letters=text.count { it.isLetter() }
                    val minOk=!prefs.getBoolean("min_enabled",false) || letters>=prefs.getInt("min_letters",0)
                    val required=prefs.getString("contains_text","")?:""
                    val containsOk=!prefs.getBoolean("contains_enabled",false) || (required.isNotBlank() && text.contains(required,ignoreCase=true))
                    if(text.isNotEmpty() && minOk && containsOk && text!=lastSaved){
                        lastSaved=text
                        val detectionTime = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                        prefs.edit()
                            .putString("last_detection", text)
                            .putString("last_detection_time", detectionTime)
                            .apply()
                        File(getExternalFilesDir(null),"ultima_deteccion.txt").writeText("Última detección: $text [$detectionTime]")
                        updateNotification("Última detección: $text [$detectionTime]")
                    }
                }.addOnCompleteListener { crop.recycle(); padded.recycle(); processing=false }
            } else { padded.recycle(); processing=false }
        } catch(_:Exception){ processing=false }
        finally { img.close() }
    }

    private fun pending(action:String):PendingIntent =
        PendingIntent.getService(this,action.hashCode(),Intent(this,OcrService::class.java).setAction(action),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    private fun notification(text:String):Notification =
        Notification.Builder(this,CH).setContentTitle("Screen OCR")
            .setContentText(text).setSmallIcon(R.drawable.ic_launcher).setOngoing(true)
            .addAction(Notification.Action.Builder(null,"Mostrar",pending(ACTION_SHOW)).build())
            .addAction(Notification.Action.Builder(null,"Detener",pending(ACTION_STOP)).build())
            .addAction(Notification.Action.Builder(null,"Cerrar",pending(ACTION_CLOSE)).build())
            .build()

    private fun updateNotification(text:String){
        if(!::projection.isInitialized) return
        try { (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(1,notification(text)) } catch(_:Exception){}
    }

    private fun createChannel(){
        if(Build.VERSION.SDK_INT>=26){
            val nm=getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CH,"Screen OCR",NotificationManager.IMPORTANCE_LOW))
        }
    }

    override fun onDestroy(){
        try{ overlay?.let{wm.removeView(it)} }catch(_:Exception){}
        try{ bubble?.let{wm.removeView(it)} }catch(_:Exception){}
        display?.release(); try{reader.close()}catch(_:Exception){}
        if(::projection.isInitialized) try{projection.stop()}catch(_:Exception){}
        super.onDestroy()
    }

    class SelectionOverlay(ctx:Context,private val w:Int,private val h:Int,
                           initialL:Int,initialT:Int,initialR:Int,initialB:Int,
                           val done:(Int,Int,Int,Int)->Unit):View(ctx){
        private val fill=Paint().apply{color=0x55000000;style=Paint.Style.FILL}
        private val stroke=Paint().apply{color=Color.rgb(80,190,120);style=Paint.Style.STROKE;strokeWidth=dp(3).toFloat()}
        private val handle=Paint().apply{color=Color.WHITE;style=Paint.Style.FILL}
        private var l=if(initialR>initialL) initialL.toFloat() else w*0.2f
        private var t=if(initialB>initialT) initialT.toFloat() else h*0.4f
        private var r=if(initialR>initialL) initialR.toFloat() else w*0.8f
        private var b=if(initialB>initialT) initialB.toFloat() else h*0.55f
        private var mode=0; private var sx=0f;private var sy=0f
        private var ol=0f;private var ot=0f;private var or=0f;private var ob=0f
        private val hs get()=dp(28).toFloat()
        private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
        override fun onDraw(c:Canvas){
            c.drawColor(0x88000000.toInt())
            val rect=RectF(l,t,r,b)
            c.save(); c.clipRect(rect); c.drawColor(0x22000000); c.restore()
            c.drawRect(rect,stroke)
            val pts=arrayOf(floatArrayOf(l,t),floatArrayOf(r,t),floatArrayOf(l,b),floatArrayOf(r,b))
            for(p in pts)c.drawCircle(p[0],p[1],hs/2,handle)
            val tx=Paint().apply{color=Color.WHITE;textSize=dp(15).toFloat();typeface=android.graphics.Typeface.DEFAULT_BOLD}
            c.drawText("Arrastra para mover • esquinas para cambiar tamaño",max(10f,l),max(30f,t-dp(8)),tx)
        }
        private fun hit(x:Float,y:Float):Int{
            if(abs(x-l)<hs && abs(y-t)<hs)return 1
            if(abs(x-r)<hs && abs(y-t)<hs)return 2
            if(abs(x-l)<hs && abs(y-b)<hs)return 3
            if(abs(x-r)<hs && abs(y-b)<hs)return 4
            if(x>l&&x<r&&y>t&&y<b)return 5
            return 0
        }
        override fun onTouchEvent(e:MotionEvent):Boolean{
            when(e.action){
                MotionEvent.ACTION_DOWN->{mode=hit(e.x,e.y);sx=e.x;sy=e.y;ol=l;ot=t;or=r;ob=b;return true}
                MotionEvent.ACTION_MOVE->{
                    val dx=e.x-sx;val dy=e.y-sy
                    when(mode){
                        1->{l=clamp(ol+dx,0f,or-dp(80));t=clamp(ot+dy,0f,ob-dp(80))}
                        2->{r=clamp(or+dx,l+dp(80),w.toFloat());t=clamp(ot+dy,0f,ob-dp(80))}
                        3->{l=clamp(ol+dx,0f,or-dp(80));b=clamp(ob+dy,t+dp(80),h.toFloat())}
                        4->{r=clamp(or+dx,l+dp(80),w.toFloat());b=clamp(ob+dy,t+dp(80),h.toFloat())}
                        5->{val ww=or-ol;val hh=ob-ot;l=clamp(ol+dx,0f,w-ww);r=l+ww;t=clamp(ot+dy,0f,h-hh);b=t+hh}
                    };invalidate();return true
                }
                MotionEvent.ACTION_UP->{if(mode!=0 && r-l>dp(30)&&b-t>dp(30))done(l.toInt(),t.toInt(),r.toInt(),b.toInt());mode=0;return true}
            };return true
        }
        private fun clamp(v:Float,lo:Float,hi:Float)=min(max(v,lo),hi)
    }
}
