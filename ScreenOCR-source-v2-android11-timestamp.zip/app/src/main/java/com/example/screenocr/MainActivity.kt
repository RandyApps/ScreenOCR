package com.example.screenocr

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var projectionManager: MediaProjectionManager
    private val captureRequest = 1001
    private val overlayRequest = 1002
    private var pendingStart = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        buildUi()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun bg(color: Int, radius: Float = 18f): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius.toInt()).toFloat() }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(24))
            setBackgroundColor(Color.rgb(18, 22, 30))
        }

        val title = TextView(this).apply {
            text = "Screen OCR"
            textSize = 28f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        val subtitle = TextView(this).apply {
            text = "Detecta texto de cualquier aplicación y guarda la última detección."
            textSize = 15f
            setTextColor(Color.rgb(190, 198, 210))
            setPadding(0, dp(4), 0, dp(16))
        }

        val lastLabel = TextView(this).apply {
            text = "Última Detección:"
            textSize = 14f
            setTextColor(Color.rgb(150, 165, 185))
        }
        val lastValue = TextView(this).apply {
            text = loadLastDetection()
            textSize = 19f
            setTextColor(Color.WHITE)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = bg(Color.rgb(35, 42, 54), 14f)
        }

        val minBox = CheckBox(this).apply {
            text = "Exigir mínimo de letras"
            setTextColor(Color.WHITE)
            buttonTintList = android.content.res.ColorStateList.valueOf(Color.rgb(80, 190, 120))
        }
        val minLetters = EditText(this).apply {
            hint = "Mínimo de letras (ej. 5)"
            setTextColor(Color.WHITE); setHintTextColor(Color.rgb(135,145,160))
            inputType = 2
            background = bg(Color.rgb(35,42,54), 12f)
            setPadding(dp(12), 0, dp(12), 0)
        }
        val containsBox = CheckBox(this).apply {
            text = "Exigir que contenga este texto"
            setTextColor(Color.WHITE)
            buttonTintList = android.content.res.ColorStateList.valueOf(Color.rgb(80, 190, 120))
        }
        val containsText = EditText(this).apply {
            hint = "Texto requerido (ej. Randy)"
            setTextColor(Color.WHITE); setHintTextColor(Color.rgb(135,145,160))
            background = bg(Color.rgb(35,42,54), 12f)
            setPadding(dp(12), 0, dp(12), 0)
        }

        val select = Button(this).apply {
            text = "▣  Seleccionar zona de detección"
            textSize = 16f
            setTextColor(Color.WHITE)
            background = bg(Color.rgb(55, 115, 220), 16f)
            setPadding(0, dp(4), 0, dp(4))
        }
        val start = Button(this).apply {
            text = "▶  Iniciar detección"
            textSize = 16f
            setTextColor(Color.WHITE)
            background = bg(Color.rgb(40, 170, 105), 16f)
            setPadding(0, dp(4), 0, dp(4))
        }
        val stop = Button(this).apply {
            text = "■  Detener detección"
            textSize = 15f
            setTextColor(Color.WHITE)
            background = bg(Color.rgb(170, 65, 75), 16f)
        }
        val open = Button(this).apply {
            text = "Abrir registro"
            textSize = 14f
            setTextColor(Color.rgb(210,220,235))
            background = bg(Color.rgb(35,42,54), 14f)
        }

        fun add(v: View, top: Int = 8, height: Int = 54) {
            root.addView(v, LinearLayout.LayoutParams(-1, dp(height)).apply { topMargin = dp(top) })
        }

        root.addView(title)
        root.addView(subtitle)
        root.addView(lastLabel)
        root.addView(lastValue, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        add(minBox, 10, 48)
        add(minLetters, 2, 50)
        add(containsBox, 8, 48)
        add(containsText, 2, 50)
        add(select, 14, 58)
        add(start, 10, 58)
        add(stop, 8, 52)
        add(open, 8, 48)
        setContentView(root)

        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        minBox.isChecked = prefs.getBoolean("min_enabled", false)
        minLetters.setText(if (prefs.getInt("min_letters", 0) == 0) "" else prefs.getInt("min_letters", 0).toString())
        containsBox.isChecked = prefs.getBoolean("contains_enabled", false)
        containsText.setText(prefs.getString("contains_text", ""))

        val save = {
            prefs.edit()
                .putBoolean("min_enabled", minBox.isChecked)
                .putInt("min_letters", minLetters.text.toString().toIntOrNull() ?: 0)
                .putBoolean("contains_enabled", containsBox.isChecked)
                .putString("contains_text", containsText.text.toString())
                .apply()
        }

        select.setOnClickListener { save(); pendingStart = true; requestOverlayThenCapture() }
        start.setOnClickListener { save(); pendingStart = true; requestOverlayThenCapture() }
        stop.setOnClickListener { stopService(Intent(this, OcrService::class.java)) }
        open.setOnClickListener { openFile() }
    }

    private fun loadLastDetection(): String {
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val value = prefs.getString("last_detection", null)?.takeIf { it.isNotBlank() }
        if (value == null) return "Ninguna"
        val time = prefs.getString("last_detection_time", "")?.takeIf { it.isNotBlank() }
        return if (time != null) "$value [$time]" else value
    }

    override fun onResume() {
        super.onResume()
        if (::projectionManager.isInitialized) {
            val value = loadLastDetection()
            // Rebuild only when returning from settings is unnecessary; the service/notification is the live UI.
        }
    }

    private fun requestOverlayThenCapture() {
        if (!Settings.canDrawOverlays(this)) {
            startActivityForResult(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")), overlayRequest)
            return
        }
        requestCapture()
    }

    private fun requestCapture() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 77)
        }
        startActivityForResult(projectionManager.createScreenCaptureIntent(), captureRequest)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == overlayRequest) {
            if (Settings.canDrawOverlays(this)) requestCapture()
            return
        }
        if (requestCode == captureRequest && resultCode == Activity.RESULT_OK && data != null) {
            val i = Intent(this, OcrService::class.java).apply {
                putExtra(OcrService.EXTRA_RESULT_CODE, resultCode)
                putExtra(OcrService.EXTRA_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            finish()
        }
    }

    private fun openFile() {
        val file = java.io.File(getExternalFilesDir(null), "ultima_deteccion.txt")
        if (!file.exists()) file.writeText("Última detección: Ninguna")
        val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        startActivity(Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "text/plain")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        })
    }
}
