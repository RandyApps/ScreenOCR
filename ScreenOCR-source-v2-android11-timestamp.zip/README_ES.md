# Screen OCR Variable

App Android que captura la pantalla mediante MediaProjection, permite seleccionar una región y reconoce texto con ML Kit. La última detección válida se guarda en `ultima_deteccion.txt` dentro del almacenamiento privado de la app.

## Importante
- No controla ni toca Klick'r.
- Durante la selección se muestra una capa temporal sobre la pantalla. Después de seleccionar la región, desaparece.
- Android exige un servicio en primer plano y una notificación para mantener la captura activa.
- Si otra app usa contenido protegido (`FLAG_SECURE`), Android puede impedir su captura.

## Crear el APK con GitHub Actions
1. Crea un repositorio nuevo en GitHub.
2. Sube todos los archivos de este proyecto manteniendo las carpetas.
3. Entra en la pestaña **Actions**.
4. Abre **Build APK**.
5. Pulsa **Run workflow** o haz un nuevo commit para iniciarlo.
6. Cuando termine en verde, abre la ejecución y busca **Artifacts**.
7. Descarga `ScreenOCR-debug-apk` y dentro estará `app-debug.apk`.

## Uso
1. Instala el APK.
2. Abre la app.
3. Si Android lo pide, permite **Mostrar sobre otras apps**. Se usa solamente para mostrar temporalmente el selector de región.
4. Pulsa **Iniciar detección**.
5. Concede permiso para capturar la pantalla.
6. Arrastra sobre la zona donde aparece el nombre de la Superstar.
7. La selección desaparece y empieza el OCR.
8. El archivo `ultima_deteccion.txt` se actualiza cuando aparece un texto nuevo que cumple las condiciones.

## Condiciones
- Sin condiciones: acepta cualquier texto detectado.
- Mínimo de letras: cuenta únicamente caracteres que sean letras.
- Texto requerido: exige que el resultado contenga la cadena indicada, sin distinguir mayúsculas/minúsculas.
- Las dos condiciones pueden estar activas a la vez.


## Versión 2
- Selector redimensionable y movible con cuatro esquinas.
- Última detección visible en la app y guardada en `ultima_deteccion.txt`.
- Captura mediante MediaProjection para detectar texto sobre otras aplicaciones.
- Burbuja flotante con reanudar, detener, nueva zona, ocultar y cerrar.
- Notificación persistente con controles.
