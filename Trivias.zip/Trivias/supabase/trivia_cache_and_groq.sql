-- ============================================================
-- Trivias: caché compartida de respuestas + (ver Edge Function)
-- Ejecutar en SQL Editor de Supabase
-- ============================================================

create table if not exists public.trivia_answers (
  question text primary key,
  answer_text text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  hit_count int not null default 0
);

create index if not exists trivia_answers_updated_idx
  on public.trivia_answers (updated_at desc);

alter table public.trivia_answers enable row level security;

-- Sin políticas de SELECT/INSERT directas para anon: solo vía RPC
drop policy if exists trivia_answers_deny_all on public.trivia_answers;
-- RLS on + no policies for anon/authenticated on table = no direct access

create or replace function public.lookup_trivia_answer(p_question text)
returns json
language plpgsql
security definer
set search_path = public
as $fn$
declare
  v_q text := trim(p_question);
  v_ans text;
begin
  if v_q is null or v_q = '' then
    return json_build_object('found', false);
  end if;
  select answer_text into v_ans
  from public.trivia_answers
  where question = v_q
  limit 1;
  if v_ans is null then
    return json_build_object('found', false);
  end if;
  update public.trivia_answers
    set hit_count = hit_count + 1, updated_at = now()
  where question = v_q;
  return json_build_object('found', true, 'answer', v_ans);
end;
$fn$;

create or replace function public.save_trivia_answer(p_question text, p_answer text)
returns json
language plpgsql
security definer
set search_path = public
as $fn$
declare
  v_q text := trim(p_question);
  v_a text := trim(p_answer);
begin
  if v_q is null or v_q = '' or v_a is null or v_a = '' then
    return json_build_object('ok', false);
  end if;
  insert into public.trivia_answers (question, answer_text)
  values (v_q, v_a)
  on conflict (question) do update
    set answer_text = excluded.answer_text,
        updated_at = now();
  return json_build_object('ok', true);
end;
$fn$;

grant execute on function public.lookup_trivia_answer(text) to anon, authenticated;
grant execute on function public.save_trivia_answer(text, text) to anon, authenticated;
