// Supabase Edge Function: groq-trivia
// Verify JWT ON. Reject calls without authenticated user JWT.
// Secrets: GROQ_API_KEYS = "gsk_xxx,gsk_yyy,..." (comma-separated)
// Optional: GROQ_MODEL = openai/gpt-oss-120b

import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const MODEL = Deno.env.get("GROQ_MODEL") ?? "openai/gpt-oss-120b";
const GROQ_URL = "https://api.groq.com/openai/v1/chat/completions";

function corsHeaders() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  };
}

function isAuthenticatedUser(req: Request): boolean {
  const auth = req.headers.get("Authorization") ?? "";
  const m = auth.match(/^Bearer\s+(.+)$/i);
  if (!m) return false;
  const token = m[1].trim();
  if (!token || token.length < 20) return false;
  const parts = token.split(".");
  if (parts.length < 2) return false;
  try {
    const payload = JSON.parse(atob(parts[1].replace(/-/g, "+").replace(/_/g, "/")));
    const role = String(payload.role ?? "");
    if (role === "authenticated") return true;
    if (payload.sub && role !== "anon") return true;
    return false;
  } catch {
    return false;
  }
}

async function callGroq(apiKey: string, prompt: string): Promise<{ ok: boolean; answer?: string; quota?: boolean }> {
  const res = await fetch(GROQ_URL, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: MODEL,
      messages: [{ role: "user", content: prompt }],
      temperature: 0,
      max_completion_tokens: 2048,
      reasoning_effort: "low",
      tool_choice: "required",
      tools: [{ type: "browser_search" }],
    }),
  });
  const text = await res.text();
  if (res.status === 429) return { ok: false, quota: true };
  if (!res.ok) {
    const low = text.toLowerCase();
    if (low.includes("rate") || low.includes("quota") || low.includes("limit")) {
      return { ok: false, quota: true };
    }
    return { ok: false };
  }
  try {
    const json = JSON.parse(text);
    const msg = json?.choices?.[0]?.message ?? {};
    let content = (msg.content ?? "").trim();
    if (!content && msg.reasoning) {
      const lines = String(msg.reasoning).split("\n").map((l: string) => l.trim()).filter(Boolean);
      for (let i = lines.length - 1; i >= 0; i--) {
        const s = lines[i].replace(/^Answer:\s*/i, "").replace(/^The answer is\s*/i, "").trim();
        if (s.length >= 2 && s.length <= 80) {
          content = s;
          break;
        }
      }
    }
    if (!content) return { ok: false };
    const first = content.split(/\r?\n/).map((l: string) => l.trim()).find((l: string) => l.length > 0) ?? content;
    return { ok: true, answer: first.replace(/^["']|["']$/g, "").trim() };
  } catch {
    return { ok: false };
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders() });
  }
  try {
    if (!isAuthenticatedUser(req)) {
      return new Response(JSON.stringify({ error: true, message: "auth required" }), {
        status: 401,
        headers: { ...corsHeaders(), "Content-Type": "application/json" },
      });
    }
    const body = await req.json();
    const prompt = String(body?.prompt ?? "").trim();
    if (!prompt) {
      return new Response(JSON.stringify({ error: true, message: "missing prompt" }), {
        status: 400,
        headers: { ...corsHeaders(), "Content-Type": "application/json" },
      });
    }
    const keys = (Deno.env.get("GROQ_API_KEYS") ?? "")
      .split(",")
      .map((k) => k.trim())
      .filter(Boolean);
    if (keys.length === 0) {
      return new Response(JSON.stringify({ error: true, message: "no groq keys configured" }), {
        status: 500,
        headers: { ...corsHeaders(), "Content-Type": "application/json" },
      });
    }
    for (const key of keys) {
      const r = await callGroq(key, prompt);
      if (r.ok && r.answer) {
        return new Response(JSON.stringify({ answer: r.answer }), {
          headers: { ...corsHeaders(), "Content-Type": "application/json" },
        });
      }
      if (!r.quota) break;
    }
    return new Response(JSON.stringify({ error: true, message: "all keys failed" }), {
      status: 502,
      headers: { ...corsHeaders(), "Content-Type": "application/json" },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: true, message: String(e) }), {
      status: 500,
      headers: { ...corsHeaders(), "Content-Type": "application/json" },
    });
  }
});
