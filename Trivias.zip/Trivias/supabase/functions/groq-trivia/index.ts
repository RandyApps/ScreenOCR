// Supabase Edge Function: groq-trivia
// Deploy: supabase functions deploy groq-trivia --no-verify-jwt
// Secrets: GROQ_API_KEYS = "gsk_xxx,gsk_yyy,..." (comma-separated)
// Optional: GROQ_MODEL = openai/gpt-oss-120b

import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const MODEL = Deno.env.get("GROQ_MODEL") ?? "openai/gpt-oss-120b";
const GROQ_URL = "https://api.groq.com/openai/v1/chat/completions";

function corsHeaders() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  };
}

async function callGroq(apiKey: string, prompt: string): Promise<{ ok: boolean; answer?: string; quota?: boolean }> {
  const res = await fetch(GROQ_URL, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: MODEL,
      messages: [{ role: "user", content: prompt }],
      temperature: 0,
      max_completion_tokens: 2048,
      reasoning_effort: "low",
      tool_choice: "required",
      tools: [{ type: "browser_search" }],
    }),
  });
  const text = await res.text();
  if (res.status === 429) return { ok: false, quota: true };
  if (!res.ok) {
    const low = text.toLowerCase();
    if (low.includes("rate") || low.includes("quota") || low.includes("limit")) {
      return { ok: false, quota: true };
    }
    return { ok: false };
  }
  try {
    const json = JSON.parse(text);
    const msg = json?.choices?.[0]?.message ?? {};
    let content = (msg.content ?? "").trim();
    if (!content && msg.reasoning) {
      const lines = String(msg.reasoning).split("\n").map((l: string) => l.trim()).filter(Boolean);
      for (let i = lines.length - 1; i >= 0; i--) {
        const s = lines[i].replace(/^Answer:\s*/i, "").replace(/^The answer is\s*/i, "").trim();
        if (s.length >= 2 && s.length <= 80) {
          content = s;
          break;
        }
      }
    }
    if (!content) return { ok: false };
    const first = content.split(/\r?\n/).map((l: string) => l.trim()).find((l: string) => l.length > 0) ?? content;
    return { ok: true, answer: first.replace(/^["']|["']$/g, "").trim() };
  } catch {
    return { ok: false };
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders() });
  }
  try {
    const body = await req.json();
    const prompt = String(body?.prompt ?? "").trim();
    if (!prompt) {
      return new Response(JSON.stringify({ error: true, message: "missing prompt" }), {
        status: 400,
        headers: { ...corsHeaders(), "Content-Type": "application/json" },
      });
    }
    const keys = (Deno.env.get("GROQ_API_KEYS") ?? "")
      .split(",")
      .map((k) => k.trim())
      .filter(Boolean);
    if (keys.length === 0) {
      return new Response(JSON.stringify({ error: true, message: "no groq keys configured" }), {
        status: 500,
        headers: { ...corsHeaders(), "Content-Type": "application/json" },
      });
    }
    for (const key of keys) {
      const result = await callGroq(key, prompt);
      if (result.ok && result.answer) {
        return new Response(JSON.stringify({ answer: result.answer }), {
          headers: { ...corsHeaders(), "Content-Type": "application/json" },
        });
      }
      // on quota try next key; on other errors also try next
    }
    return new Response(JSON.stringify({ error: true, message: "all keys failed" }), {
      status: 502,
      headers: { ...corsHeaders(), "Content-Type": "application/json" },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: true, message: String(e) }), {
      status: 500,
      headers: { ...corsHeaders(), "Content-Type": "application/json" },
    });
  }
});
