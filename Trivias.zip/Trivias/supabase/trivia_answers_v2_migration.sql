-- ============================================================
-- Migración: trivia_answers con (question, image_url) único
-- Ejecutar en SQL Editor de Supabase
-- ============================================================
-- Datos viejos: se conservan con image_url = '' e image_file = ''.
-- Cuando esa pregunta vuelva a salir, la app actualizará id/url/file.

-- 1) Añadir columnas si no existen
alter table public.trivia_answers add column if not exists image_url text not null default '';
alter table public.trivia_answers add column if not exists image_file text not null default '';
alter table public.trivia_answers add column if not exists game_question_id text not null default '';

-- 2) Quitar PK antigua solo en question (si existe)
do $$
begin
  if exists (
    select 1 from information_schema.table_constraints
    where table_schema = 'public' and table_name = 'trivia_answers'
      and constraint_type = 'PRIMARY KEY'
  ) then
    alter table public.trivia_answers drop constraint trivia_answers_pkey;
  end if;
exception when others then
  begin
    alter table public.trivia_answers drop constraint if exists trivia_answers_pkey;
  exception when others then null;
  end;
end $$;

-- 3) Asegurar filas existentes con image_url/file vacíos (ya default)
update public.trivia_answers set image_url = coalesce(image_url, '') where image_url is null;
update public.trivia_answers set image_file = coalesce(image_file, '') where image_file is null;

-- 4) Nueva PK compuesta
alter table public.trivia_answers
  add constraint trivia_answers_pkey primary key (question, image_url);

-- 5) Índice por filename para búsqueda parcial
create index if not exists trivia_answers_q_file_idx
  on public.trivia_answers (question, image_file);

-- 6) lookup: pregunta exacta + url exacta, si no filename exacto
create or replace function public.lookup_trivia_answer(
  p_question text,
  p_image_url text default '',
  p_image_file text default ''
)
returns json
language plpgsql
security definer
set search_path = public
as $fn$
declare
  v_q text := trim(p_question);
  v_url text := coalesce(trim(p_image_url), '');
  v_file text := coalesce(trim(p_image_file), '');
  v_ans text;
begin
  if v_q is null or v_q = '' then
    return json_build_object('found', false);
  end if;

  -- 1) Match exacto pregunta + image_url
  select answer_text into v_ans
  from public.trivia_answers
  where question = v_q and image_url = v_url
  limit 1;

  -- 2) Si no, match pregunta + image_file (si hay file)
  if v_ans is null and v_file <> '' then
    select answer_text into v_ans
    from public.trivia_answers
    where question = v_q and image_file = v_file and image_file <> ''
    limit 1;
  end if;

  if v_ans is null then
    return json_build_object('found', false);
  end if;

  update public.trivia_answers
    set hit_count = hit_count + 1, updated_at = now()
  where question = v_q
    and (
      image_url = v_url
      or (v_file <> '' and image_file = v_file)
    );

  return json_build_object('found', true, 'answer', v_ans);
end;
$fn$;

-- 7) save: upsert por (question, image_url); si existía fila vieja solo texto, enriquecer
create or replace function public.save_trivia_answer(
  p_question text,
  p_answer text,
  p_image_url text default '',
  p_image_file text default '',
  p_game_question_id text default ''
)
returns json
language plpgsql
security definer
set search_path = public
as $fn$
declare
  v_q text := trim(p_question);
  v_a text := trim(p_answer);
  v_url text := coalesce(trim(p_image_url), '');
  v_file text := coalesce(trim(p_image_file), '');
  v_gid text := coalesce(trim(p_game_question_id), '');
begin
  if v_q is null or v_q = '' or v_a is null or v_a = '' then
    return json_build_object('ok', false);
  end if;

  -- Upsert principal por (question, image_url)
  insert into public.trivia_answers as t (question, image_url, image_file, game_question_id, answer_text)
  values (v_q, v_url, v_file, v_gid, v_a)
  on conflict (question, image_url) do update
    set answer_text = excluded.answer_text,
        image_file = case when excluded.image_file <> '' then excluded.image_file else t.image_file end,
        game_question_id = case when excluded.game_question_id <> '' then excluded.game_question_id else t.game_question_id end,
        updated_at = now();

  -- Si esta partida trae imagen y existía fila legacy (misma pregunta, image_url '')
  -- con la misma respuesta, enriquecer esa fila con file/id (sin borrar)
  if v_url <> '' then
    update public.trivia_answers
      set image_file = case when image_file = '' and v_file <> '' then v_file else image_file end,
          game_question_id = case when game_question_id = '' and v_gid <> '' then v_gid else game_question_id end,
          updated_at = now()
    where question = v_q and image_url = '' and answer_text = v_a;
  end if;

  -- Si legacy solo-texto (url '') y ahora también sin imagen: ya cubierto por upsert

  -- Si legacy url '' y ahora hay imagen distinta: se insertó fila nueva (OK).
  -- Además, si existe legacy '' y estamos guardando con imagen, actualizar legacy
  -- solo cuando el answer coincide? Mejor: si legacy tiene answer y es la misma pregunta sin imagen,
  -- al reaparecer CON imagen no tocamos legacy salvo enriquecer cuando answer coincide (arriba).

  return json_build_object('ok', true);
end;
$fn$;

-- Compat: sobrecarga antigua de 1-2 args sigue? En Postgres hay que redefinir grants
drop function if exists public.lookup_trivia_answer(text);
-- keep single function with defaults

grant execute on function public.lookup_trivia_answer(text, text, text) to anon, authenticated;
grant execute on function public.save_trivia_answer(text, text, text, text, text) to anon, authenticated;
