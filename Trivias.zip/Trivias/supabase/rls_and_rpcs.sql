-- Trivia Helper — ejecutar TODO este archivo de una sola vez en SQL Editor

-- 1) Quitar politicas abiertas
drop policy if exists "anon all users" on public.users;
drop policy if exists "anon all banned_devices" on public.banned_devices;
drop policy if exists "anon all banned_users" on public.banned_users;
drop policy if exists "Allow all for anon" on public.users;
drop policy if exists "Allow all for anon" on public.banned_devices;
drop policy if exists "Allow all for anon" on public.banned_users;

-- 2) RLS ON
alter table public.users enable row level security;
alter table public.banned_devices enable row level security;
alter table public.banned_users enable row level security;

-- 3) last_seen para online
alter table public.users add column if not exists last_seen timestamptz;

-- 4) Sin acceso directo a tablas
revoke all on table public.users from anon, authenticated;
revoke all on table public.banned_devices from anon, authenticated;
revoke all on table public.banned_users from anon, authenticated;

-- 5) Helpers y RPCs
create or replace function public._is_admin(p_admin_id text)
returns boolean
language sql
stable
security definer
set search_path = public
as $fn$
  select exists (
    select 1 from public.users
    where user_id = p_admin_id and upper(coalesce(role, 'USER')) = 'ADMIN'
  );
$fn$;

create or replace function public.is_banned(p_user_id text, p_device_id text)
returns json
language plpgsql
security definer
set search_path = public
as $fn$
declare
  v_reason text;
begin
  if p_device_id is not null and length(trim(p_device_id)) > 0 then
    select reason into v_reason from public.banned_devices where device_id = p_device_id limit 1;
    if found then
      return json_build_object('banned', true, 'kind', 'DEVICE', 'reason', v_reason);
    end if;
  end if;

  if p_user_id is not null and length(trim(p_user_id)) > 0 then
    select reason into v_reason from public.banned_users where user_id = p_user_id limit 1;
    if found then
      return json_build_object('banned', true, 'kind', 'USER', 'reason', v_reason);
    end if;
  end if;

  return json_build_object('banned', false, 'kind', null, 'reason', null);
end;
$fn$;

create or replace function public.upsert_my_user(
  p_user_id text,
  p_email text,
  p_nombre text,
  p_device_id text
)
returns json
language plpgsql
security definer
set search_path = public
as $fn$
begin
  if p_user_id is null or length(trim(p_user_id)) = 0 then
    raise exception 'user_id required';
  end if;

  insert into public.users (user_id, email, nombre, device_id, role, last_seen)
  values (p_user_id, p_email, p_nombre, p_device_id, 'USER', now())
  on conflict (user_id) do update set
    email = excluded.email,
    nombre = excluded.nombre,
    device_id = excluded.device_id,
    last_seen = now();

  return (
    select json_build_object(
      'user_id', u.user_id,
      'email', u.email,
      'nombre', u.nombre,
      'device_id', u.device_id,
      'role', u.role
    )
    from public.users u where u.user_id = p_user_id
  );
end;
$fn$;

create or replace function public.get_my_role(p_user_id text)
returns text
language sql
stable
security definer
set search_path = public
as $fn$
  select coalesce(
    (select role from public.users where user_id = p_user_id limit 1),
    'USER'
  );
$fn$;

create or replace function public.heartbeat(p_user_id text)
returns json
language plpgsql
security definer
set search_path = public
as $fn$
begin
  if p_user_id is null or length(trim(p_user_id)) = 0 then
    raise exception 'user_id required';
  end if;
  update public.users set last_seen = now() where user_id = p_user_id;
  return json_build_object('ok', true);
end;
$fn$;

create or replace function public.admin_list_users(p_admin_id text)
returns setof public.users
language plpgsql
security definer
set search_path = public
as $fn$
begin
  if not public._is_admin(p_admin_id) then
    raise exception 'forbidden';
  end if;
  return query
    select * from public.users
    order by last_seen desc nulls last, nombre nulls last;
end;
$fn$;

create or replace function public.admin_set_role(
  p_admin_id text,
  p_target_user_id text,
  p_role text
)
returns json
language plpgsql
security definer
set search_path = public
as $fn$
declare
  new_role text;
begin
  if not public._is_admin(p_admin_id) then
    raise exception 'forbidden';
  end if;
  new_role := upper(coalesce(p_role, 'USER'));
  if new_role not in ('USER', 'ADMIN', 'TESTER') then
    raise exception 'invalid role';
  end if;
  update public.users set role = new_role where user_id = p_target_user_id;
  if not found then
    raise exception 'user not found';
  end if;
  return json_build_object('user_id', p_target_user_id, 'role', new_role);
end;
$fn$;

create or replace function public.admin_ban(
  p_admin_id text,
  p_user_id text,
  p_device_id text,
  p_reason text default null
)
returns json
language plpgsql
security definer
set search_path = public
as $fn$
begin
  if not public._is_admin(p_admin_id) then
    raise exception 'forbidden';
  end if;

  if p_user_id is not null and length(trim(p_user_id)) > 0 then
    insert into public.banned_users (user_id, reason, banned_at)
    values (p_user_id, p_reason, now())
    on conflict (user_id) do update
      set reason = excluded.reason, banned_at = now();
  end if;

  if p_device_id is not null and length(trim(p_device_id)) > 0 then
    insert into public.banned_devices (device_id, reason, banned_at)
    values (p_device_id, p_reason, now())
    on conflict (device_id) do update
      set reason = excluded.reason, banned_at = now();
  end if;

  return json_build_object('ok', true);
end;
$fn$;

create or replace function public.admin_unban(
  p_admin_id text,
  p_user_id text,
  p_device_id text
)
returns json
language plpgsql
security definer
set search_path = public
as $fn$
begin
  if not public._is_admin(p_admin_id) then
    raise exception 'forbidden';
  end if;

  if p_user_id is not null and length(trim(p_user_id)) > 0 then
    delete from public.banned_users where user_id = p_user_id;
  end if;

  if p_device_id is not null and length(trim(p_device_id)) > 0 then
    delete from public.banned_devices where device_id = p_device_id;
  end if;

  return json_build_object('ok', true);
end;
$fn$;

create or replace function public.admin_list_bans(p_admin_id text)
returns json
language plpgsql
security definer
set search_path = public
as $fn$
begin
  if not public._is_admin(p_admin_id) then
    raise exception 'forbidden';
  end if;
  return json_build_object(
    'devices', coalesce(
      (select json_agg(row_to_json(d)) from (
        select * from public.banned_devices order by banned_at desc
      ) d),
      '[]'::json
    ),
    'users', coalesce(
      (select json_agg(row_to_json(u)) from (
        select * from public.banned_users order by banned_at desc
      ) u),
      '[]'::json
    )
  );
end;
$fn$;

-- 6) Permisos EXECUTE solo a RPCs
grant execute on function public._is_admin(text) to anon, authenticated;
grant execute on function public.is_banned(text, text) to anon, authenticated;
grant execute on function public.upsert_my_user(text, text, text, text) to anon, authenticated;
grant execute on function public.get_my_role(text) to anon, authenticated;
grant execute on function public.heartbeat(text) to anon, authenticated;
grant execute on function public.admin_list_users(text) to anon, authenticated;
grant execute on function public.admin_set_role(text, text, text) to anon, authenticated;
grant execute on function public.admin_ban(text, text, text, text) to anon, authenticated;
grant execute on function public.admin_unban(text, text, text) to anon, authenticated;
grant execute on function public.admin_list_bans(text) to anon, authenticated;

-- 7) Hacerte ADMIN (cambia el email por el tuyo):
-- update public.users set role = 'ADMIN' where email = 'tu@gmail.com';
