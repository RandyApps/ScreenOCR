-- Trivia Helper — ejecutar TODO este archivo de una sola vez en SQL Editor

-- 1) Quitar politicas abiertas
drop policy if exists "anon all users" on public.users;
drop policy if exists "anon all banned_devices" on public.banned_devices;
drop policy if exists "anon all banned_users" on public.banned_users;
drop policy if exists "Allow all for anon" on public.users;
drop policy if exists "Allow all for anon" on public.banned_devices;
drop policy if exists "Allow all for anon" on public.banned_users;

-- 2) RLS ON
alter table public.users enable row level security;
alter table public.banned_devices enable row level security;
alter table public.banned_users enable row level security;

-- 3) last_seen para online
alter table public.users add column if not exists last_seen timestamptz;

-- 4) Sin acceso directo a tablas
revoke all on table public.users from anon, authenticated;
revoke all on table public.banned_devices from anon, authenticated;
revoke all on table public.banned_users from anon, authenticated;

-- 5) Helpers y RPCs
create or replace function public._is_admin(p_admin_id text)
returns boolean
language sql
stable
security definer
set search_path = public
as $fn$
  select exists (
    select 1 from public.users
    where user_id = p_admin_id and upper(coalesce(role, 'USER')) = 'ADMIN'
  );
$fn$;

create or replace function public.is_banned(p_user_id text, p_device_id text)
returns json
language plpgsql
security definer
set search_path = public
as $fn$
declare
  v_reason text;
begin
  if p_device_id is not null and length(trim(p_device_id)) > 0 then
    select reason into v_reason from public.banned_devices where device_id = p_device_id limit 1;
    if found then
      return json_build_object('banned', true, 'kind', 'DEVICE', 'reason', v_reason);
    end if;
  end if;

  if p_user_id is not null and length(trim(p_user_id)) > 0 then
    select reason into v_reason from public.banned_users where user_id = p_user_id limit 1;
    if found then
      return json_build_object('banned', true, 'kind', 'USER', 'reason', v_reason);
    end if;
  end if;

  return json_build_object('banned', false, 'kind', null, 'reason', null);
end;
$fn$;

create or replace function public.upsert_my_user(
  p_user_id text,
  p_email text,
  p_nombre text,
  p_device_id text
)
returns json
language plpgsql
security definer
set search_path = public
as $fn$
begin
  if p_user_id is null or length(trim(p_user_id)) = 0 then
    raise exception 'user_id required';
  end if;

  insert into public.users (user_id, email, nombre, device_id, role, last_seen)
  values (p_user_id, p_email, p_nombre, p_device_id, 'USER', now())
  on conflict (user_id) do update set
    email = excluded.email,
    nombre = excluded.nombre,
    device_id = excluded.device_id,
    last_seen = now();

  return (
    select json_build_object(
      'user_id', u.user_id,
      'email', u.email,
      'nombre', u.nombre,
      'device_id', u.device_id,
      'role', u.role
    )
    from public.users u where u.user_id = p_user_id
  );
end;
$fn$;

create or replace function public.get_my_role(p_user_id text)
returns text
language sql
stable
security definer
set search_path = public
as $fn$
  select coalesce(
    (select role from public.users where user_id = p_user_id limit 1),
    'USER'
  );
$fn$;

create or replace function public.heartbeat(p_user_id text)
returns json
language plpgsql
security definer
set search_path = public
as $fn$
begin
  if p_user_id is null or length(trim(p_user_id)) = 0 then
    raise exception 'user_id required';
  end if;
  update public.users set last_seen = now() where user_id = p_user_id;
  return json_build_object('ok', true);
end;
$fn$;

create or replace function public.admin_list_users(p_admin_id text)
returns setof public.users
language plpgsql
security definer
set search_path = public
as $fn$
begin
  if not public._is_admin(p_admin_id) then
    raise exception 'forbidden';
  end if;
  return query
    select * from public.users
    order by last_seen desc nulls last, nombre nulls last;
end;
$fn$;

create or replace function public.admin_set_role(
  p_admin_id text,
  p_target_user_id text,
  p_role text
)
returns json
language plpgsql
security definer
set search_path = public
as $fn$
declare
  new_role text;
begin
  if not public._is_admin(p_admin_id) then
    raise exception 'forbidden';
  end if;
  new_role := upper(coalesce(p_role, 'USER'));
  if new_role not in ('USER', 'ADMIN', 'TESTER') then
    raise exception 'invalid role';
  end if;
  update public.users set role = new_role where user_id = p_target_user_id;
  if not found then
    raise exception 'user not found';
  end if;
  return json_build_object('user_id', p_target_user_id, 'role', new_role);
end;
$fn$;

create or replace function public.admin_ban(
  p_admin_id text,
  p_user_id text,
  p_device_id text,
  p_reason text default null
)
returns json
language plpgsql
security definer
set search_path = public
as $fn$
begin
  if not public._is_admin(p_admin_id) then
    raise exception 'forbidden';
  end if;

  if p_user_id is not null and length(trim(p_user_id)) > 0 then
    insert into public.banned_users (user_id, reason, banned_at)
    values (p_user_id, p_reason, now())
    on conflict (user_id) do update
      set reason = excluded.reason, banned_at = now();
  end if;

  if p_device_id is not null and length(trim(p_device_id)) > 0 then
    insert into public.banned_devices (device_id, reason, banned_at)
    values (p_device_id, p_reason, now())
    on conflict (device_id) do update
      set reason = excluded.reason, banned_at = now();
  end if;

  return json_build_object('ok', true);
end;
$fn$;

create or replace function public.admin_unban(
  p_admin_id text,
  p_user_id text,
  p_device_id text
)
returns json
language plpgsql
security definer
set search_path = public
as $fn$
begin
  if not public._is_admin(p_admin_id) then
    raise exception 'forbidden';
  end if;

  if p_user_id is not null and length(trim(p_user_id)) > 0 then
    delete from public.banned_users where user_id = p_user_id;
  end if;

  if p_device_id is not null and length(trim(p_device_id)) > 0 then
    delete from public.banned_devices where device_id = p_device_id;
  end if;

  return json_build_object('ok', true);
end;
$fn$;

create or replace function public.admin_list_bans(p_admin_id text)
returns json
language plpgsql
security definer
set search_path = public
as $fn$
begin
  if not public._is_admin(p_admin_id) then
    raise exception 'forbidden';
  end if;
  return json_build_object(
    'devices', coalesce(
      (select json_agg(row_to_json(d)) from (
        select * from public.banned_devices order by banned_at desc
      ) d),
      '[]'::json
    ),
    'users', coalesce(
      (select json_agg(row_to_json(u)) from (
        select * from public.banned_users order by banned_at desc
      ) u),
      '[]'::json
    )
  );
end;
$fn$;

-- 6) Permisos EXECUTE solo a RPCs
grant execute on function public._is_admin(text) to anon, authenticated;
grant execute on function public.is_banned(text, text) to anon, authenticated;
grant execute on function public.upsert_my_user(text, text, text, text) to anon, authenticated;
grant execute on function public.get_my_role(text) to anon, authenticated;
grant execute on function public.heartbeat(text) to anon, authenticated;
grant execute on function public.admin_list_users(text) to anon, authenticated;
grant execute on function public.admin_set_role(text, text, text) to anon, authenticated;
grant execute on function public.admin_ban(text, text, text, text) to anon, authenticated;
grant execute on function public.admin_unban(text, text, text) to anon, authenticated;
grant execute on function public.admin_list_bans(text) to anon, authenticated;

-- 7) Hacerte ADMIN (cambia el email por el tuyo):
-- update public.users set role = 'ADMIN' where email = 'tu@gmail.com';

-- Access mode: ALL | ADMIN | TESTER
create table if not exists public.app_config (
  key text primary key,
  value text not null
);

insert into public.app_config (key, value)
values ('access_mode', 'ALL')
on conflict (key) do nothing;

create or replace function public.get_access_mode()
returns text
language sql
security definer
as $$
  select coalesce(
    (select value from public.app_config where key = 'access_mode' limit 1),
    'ALL'
  );
$$;

create or replace function public.set_access_mode(p_admin_id text, p_mode text)
returns text
language plpgsql
security definer
as $$
declare
  m text;
begin
  if not exists (
    select 1 from public.users
    where user_id = p_admin_id and upper(coalesce(role, 'USER')) = 'ADMIN'
  ) then
    raise exception 'not allowed';
  end if;
  m := upper(coalesce(p_mode, 'ALL'));
  if m not in ('ALL', 'ADMIN', 'TESTER') then
    raise exception 'invalid mode';
  end if;
  insert into public.app_config (key, value) values ('access_mode', m)
  on conflict (key) do update set value = excluded.value;
  return m;
end;
$$;

grant execute on function public.get_access_mode() to anon, authenticated;
grant execute on function public.set_access_mode(text, text) to anon, authenticated;


-- FIX banned_users columns (error: column user_id does not exist)
create table if not exists public.banned_users (
  user_id text primary key,
  reason text,
  banned_at timestamptz default now()
);

create table if not exists public.banned_devices (
  device_id text primary key,
  reason text,
  banned_at timestamptz default now()
);

do $fix$
begin
  if not exists (
    select 1 from information_schema.columns
    where table_schema = 'public' and table_name = 'banned_users' and column_name = 'user_id'
  ) then
    alter table public.banned_users add column if not exists user_id text;
  end if;
  if not exists (
    select 1 from information_schema.columns
    where table_schema = 'public' and table_name = 'banned_users' and column_name = 'reason'
  ) then
    alter table public.banned_users add column if not exists reason text;
  end if;
  if not exists (
    select 1 from information_schema.columns
    where table_schema = 'public' and table_name = 'banned_users' and column_name = 'banned_at'
  ) then
    alter table public.banned_users add column if not exists banned_at timestamptz default now();
  end if;
end
$fix$;


-- ON CONFLICT specification fix: user_id must be UNIQUE/PK
alter table public.banned_users drop constraint if exists banned_users_pkey;
alter table public.banned_users drop constraint if exists banned_users_user_id_key;
-- remove null user_ids if any
delete from public.banned_users where user_id is null or trim(user_id) = '';
-- ensure unique
do $fix$
begin
  if not exists (
    select 1 from pg_constraint
    where conrelid = 'public.banned_users'::regclass
      and contype in ('u', 'p')
  ) then
    alter table public.banned_users add constraint banned_users_user_id_key unique (user_id);
  end if;
exception when others then
  -- if duplicates exist, keep first
  delete from public.banned_users a
  using public.banned_users b
  where a.ctid < b.ctid and a.user_id = b.user_id;
  begin
    alter table public.banned_users add constraint banned_users_user_id_key unique (user_id);
  exception when others then null;
  end;
end
$fix$;

alter table public.banned_devices drop constraint if exists banned_devices_pkey;
alter table public.banned_devices drop constraint if exists banned_devices_device_id_key;
delete from public.banned_devices where device_id is null or trim(device_id) = '';
do $fix$
begin
  alter table public.banned_devices add constraint banned_devices_device_id_key unique (device_id);
exception when others then null;
end
$fix$;


-- admin_ban DELETE INSERT fix (no ON CONFLICT required)
create or replace function public.admin_ban(
  p_admin_id text,
  p_user_id text,
  p_device_id text,
  p_reason text default null
)
returns json
language plpgsql
security definer
set search_path = public
as $fn$
begin
  if not public._is_admin(p_admin_id) then
    raise exception 'forbidden';
  end if;

  if p_user_id is not null and length(trim(p_user_id)) > 0 then
    delete from public.banned_users where user_id = p_user_id;
    insert into public.banned_users (user_id, reason, banned_at)
    values (p_user_id, coalesce(p_reason, 'banned'), now());
  end if;

  if p_device_id is not null and length(trim(p_device_id)) > 0 then
    delete from public.banned_devices where device_id = p_device_id;
    insert into public.banned_devices (device_id, reason, banned_at)
    values (p_device_id, coalesce(p_reason, 'banned'), now());
  end if;

  return json_build_object(
    'ok', true,
    'user_id', p_user_id,
    'device_id', p_device_id
  );
end;
$fn$;

-- ensure is_banned works
create or replace function public.is_banned(p_user_id text, p_device_id text)
returns json
language plpgsql
security definer
set search_path = public
as $fn$
declare
  v_reason text;
begin
  if p_device_id is not null and length(trim(p_device_id)) > 0 then
    select reason into v_reason from public.banned_devices where device_id = p_device_id limit 1;
    if found then
      return json_build_object('banned', true, 'kind', 'DEVICE', 'reason', v_reason);
    end if;
  end if;

  if p_user_id is not null and length(trim(p_user_id)) > 0 then
    select reason into v_reason from public.banned_users where user_id = p_user_id limit 1;
    if found then
      return json_build_object('banned', true, 'kind', 'USER', 'reason', v_reason);
    end if;
  end if;

  return json_build_object('banned', false);
end;
$fn$;

grant execute on function public.admin_ban(text, text, text, text) to anon, authenticated;
grant execute on function public.is_banned(text, text) to anon, authenticated;


-- FINAL ban fix matching real schema (uid NOT NULL, devices without reason)
drop function if exists public.admin_ban(text, text, text, text);
drop function if exists public.admin_ban(text, text, text, text, text);

create or replace function public.admin_ban(
  p_admin_id text,
  p_user_id text,
  p_device_id text,
  p_reason text default null
)
returns json
language plpgsql
security definer
set search_path = public
as $fn$
begin
  if not public._is_admin(p_admin_id) then
    raise exception 'forbidden';
  end if;

  if p_user_id is not null and length(trim(p_user_id)) > 0 then
    delete from public.banned_users
    where user_id = p_user_id or uid = p_user_id;

    insert into public.banned_users (user_id, uid, reason, banned_at)
    values (
      p_user_id,
      p_user_id,
      coalesce(nullif(trim(p_reason), ''), 'banned'),
      now()
    );
  end if;

  if p_device_id is not null and length(trim(p_device_id)) > 0 then
    delete from public.banned_devices where device_id = p_device_id;
    insert into public.banned_devices (device_id, banned_at)
    values (p_device_id, now());
  end if;

  return json_build_object(
    'ok', true,
    'user_id', p_user_id,
    'device_id', p_device_id
  );
end;
$fn$;

drop function if exists public.admin_unban(text, text, text);

create or replace function public.admin_unban(
  p_admin_id text,
  p_user_id text,
  p_device_id text
)
returns json
language plpgsql
security definer
set search_path = public
as $fn$
begin
  if not public._is_admin(p_admin_id) then
    raise exception 'forbidden';
  end if;

  if p_user_id is not null and length(trim(p_user_id)) > 0 then
    delete from public.banned_users
    where user_id = p_user_id or uid = p_user_id;
  end if;

  if p_device_id is not null and length(trim(p_device_id)) > 0 then
    delete from public.banned_devices where device_id = p_device_id;
  end if;

  return json_build_object('ok', true);
end;
$fn$;

create or replace function public.is_banned(p_user_id text, p_device_id text)
returns json
language plpgsql
security definer
set search_path = public
as $fn$
declare
  v_reason text;
begin
  if p_device_id is not null and length(trim(p_device_id)) > 0 then
    if exists (select 1 from public.banned_devices where device_id = p_device_id) then
      return json_build_object('banned', true, 'kind', 'DEVICE', 'reason', null);
    end if;
  end if;

  if p_user_id is not null and length(trim(p_user_id)) > 0 then
    select reason into v_reason
    from public.banned_users
    where user_id = p_user_id or uid = p_user_id
    limit 1;
    if found then
      return json_build_object('banned', true, 'kind', 'USER', 'reason', v_reason);
    end if;
  end if;

  return json_build_object('banned', false);
end;
$fn$;

grant execute on function public.admin_ban(text, text, text, text) to anon, authenticated;
grant execute on function public.admin_unban(text, text, text) to anon, authenticated;
grant execute on function public.is_banned(text, text) to anon, authenticated;


-- Option A: ADMIN sees all users; TESTER sees only self
create or replace function public._is_admin(p_admin_id text)
returns boolean
language sql
stable
security definer
set search_path = public
as $fn$
  select exists (
    select 1 from public.users
    where user_id = p_admin_id and upper(coalesce(role, 'USER')) = 'ADMIN'
  );
$fn$;

create or replace function public._is_admin_or_tester(p_id text)
returns boolean
language sql
stable
security definer
set search_path = public
as $fn$
  select exists (
    select 1 from public.users
    where user_id = p_id
      and upper(coalesce(role, 'USER')) in ('ADMIN', 'TESTER')
  );
$fn$;

create or replace function public.admin_list_users(p_admin_id text)
returns setof public.users
language plpgsql
security definer
set search_path = public
as $fn$
declare
  v_role text;
begin
  select upper(coalesce(role, 'USER')) into v_role
  from public.users where user_id = p_admin_id limit 1;

  if v_role is null then
    raise exception 'forbidden';
  end if;

  if v_role = 'ADMIN' then
    return query
      select * from public.users
      order by last_seen desc nulls last, nombre nulls last;
  elsif v_role = 'TESTER' then
    return query
      select * from public.users
      where user_id = p_admin_id
      order by last_seen desc nulls last;
  else
    raise exception 'forbidden';
  end if;
end;
$fn$;

grant execute on function public._is_admin(text) to anon, authenticated;
grant execute on function public._is_admin_or_tester(text) to anon, authenticated;
grant execute on function public.admin_list_users(text) to anon, authenticated;
