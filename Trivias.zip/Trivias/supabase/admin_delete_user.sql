-- Ejecutar en Supabase SQL Editor
-- Elimina un usuario de la tabla users (solo admins vía RPC)

create or replace function public.admin_delete_user(p_admin_id text, p_user_id text)
returns json
language plpgsql
security definer
as $$
declare
  admin_role text;
begin
  select role into admin_role from public.users where user_id = p_admin_id limit 1;
  if admin_role is null or upper(admin_role) <> 'ADMIN' then
    raise exception 'not authorized';
  end if;
  if p_user_id is null or length(trim(p_user_id)) = 0 then
    raise exception 'invalid user';
  end if;
  -- no borrar al propio admin
  if p_admin_id = p_user_id then
    raise exception 'cannot delete self';
  end if;
  delete from public.users where user_id = p_user_id;
  return json_build_object('ok', true, 'deleted', p_user_id);
end;
$$;

grant execute on function public.admin_delete_user(text, text) to anon, authenticated, service_role;
