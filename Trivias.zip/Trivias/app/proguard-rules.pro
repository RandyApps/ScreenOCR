# Trivias release
-keep class com.trivias.app.databinding.** { *; }
-keepclassmembers class * implements androidx.viewbinding.ViewBinding {
    public static * inflate(android.view.LayoutInflater);
}
-dontwarn com.google.android.gms.**
-keep class com.google.android.gms.auth.** { *; }
-keepclassmembers class com.trivias.app.PrefsHelper { *; }
