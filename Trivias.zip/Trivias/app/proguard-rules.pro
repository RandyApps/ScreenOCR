# Trivias release
-keepclassmembers class * implements androidx.viewbinding.ViewBinding {
    public static * inflate(android.view.LayoutInflater);
}
-keep class com.trivias.app.databinding.** { *; }
-dontwarn com.google.android.gms.**
-keep class com.google.android.gms.auth.** { *; }
# Keep Prefs keys logic
-keepclassmembers class com.trivias.app.PrefsHelper { *; }
