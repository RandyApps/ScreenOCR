package com.trivias.app

/**
 * Confirmación real de rol con Supabase (no ConnectivityManager).
 * Solo true tras una respuesta exitosa de getUserRole / login.
 * Si la petición falla, pasa a false: no se abre el panel admin.
 * No toca PLAY AGAIN ni el rol local por sí solo.
 */
object RoleServerGate {
    @Volatile
    private var confirmed: Boolean = false

    fun isConfirmed(): Boolean = confirmed

    fun markConfirmed() {
        confirmed = true
    }

    fun markUnconfirmed() {
        confirmed = false
    }
}
