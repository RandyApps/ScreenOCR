package com.trivias.app

import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

/**
 * Sesión Supabase Auth (JWT). Las RPC sensibles y Groq usan este access_token.
 */
object SupabaseAuth {

    @Volatile
    var cachedAccessToken: String? = null
        private set

    data class Session(
        val accessToken: String,
        val refreshToken: String,
        val expiresAtMs: Long,
        val authUserId: String
    )

    fun signInWithGoogleIdToken(idToken: String): Session {
        val url = URL("${SupabaseConfig.URL.trimEnd('/')}/auth/v1/token?grant_type=id_token")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 20000
            readTimeout = 30000
            requestMethod = "POST"
            doOutput = true
            setRequestProperty("apikey", SupabaseConfig.ANON_KEY)
            setRequestProperty("Authorization", "Bearer ${SupabaseConfig.ANON_KEY}")
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "application/json")
        }
        val body = JSONObject()
            .put("provider", "google")
            .put("id_token", idToken)
            .toString()
        try {
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.let {
                BufferedReader(InputStreamReader(it, Charsets.UTF_8)).use { r -> r.readText() }
            }.orEmpty()
            if (code !in 200..299) {
                throw IllegalStateException("Auth $code: ${text.take(200)}")
            }
            return parseSession(JSONObject(text))
        } finally {
            conn.disconnect()
        }
    }

    fun refresh(refreshToken: String): Session {
        val url = URL("${SupabaseConfig.URL.trimEnd('/')}/auth/v1/token?grant_type=refresh_token")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 20000
            readTimeout = 30000
            requestMethod = "POST"
            doOutput = true
            setRequestProperty("apikey", SupabaseConfig.ANON_KEY)
            setRequestProperty("Authorization", "Bearer ${SupabaseConfig.ANON_KEY}")
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "application/json")
        }
        val body = JSONObject().put("refresh_token", refreshToken).toString()
        try {
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.let {
                BufferedReader(InputStreamReader(it, Charsets.UTF_8)).use { r -> r.readText() }
            }.orEmpty()
            if (code !in 200..299) {
                throw IllegalStateException("Refresh $code: ${text.take(200)}")
            }
            return parseSession(JSONObject(text))
        } finally {
            conn.disconnect()
        }
    }

    private fun parseSession(json: JSONObject): Session {
        val access = json.optString("access_token", "")
        val refresh = json.optString("refresh_token", "")
        val expiresIn = json.optLong("expires_in", 3600L)
        val user = json.optJSONObject("user")
        val authUid = user?.optString("id", "") ?: ""
        if (access.isBlank()) throw IllegalStateException("Sin access_token")
        return Session(
            accessToken = access,
            refreshToken = refresh,
            expiresAtMs = System.currentTimeMillis() + (expiresIn * 1000L) - 60_000L,
            authUserId = authUid
        )
    }

    /** Bearer válido: refresca si hace falta. null si no hay sesión. */
    fun validAccessToken(prefs: PrefsHelper): String? {
        var access = prefs.getAccessToken()
        if (access.isBlank()) {
            cachedAccessToken = null
            return null
        }
        val exp = prefs.getTokenExpiresAtMs()
        if (exp > 0 && System.currentTimeMillis() >= exp) {
            val rt = prefs.getRefreshToken()
            if (rt.isBlank()) return null
            return try {
                val s = refresh(rt)
                prefs.saveAuthSession(s.accessToken, s.refreshToken, s.expiresAtMs, s.authUserId)
                cachedAccessToken = s.accessToken
                s.accessToken
            } catch (_: Exception) {
                null
            }
        }
        cachedAccessToken = access
        return access
    }

    fun clearCache() {
        cachedAccessToken = null
    }

    fun applySession(prefs: PrefsHelper, session: Session) {
        prefs.saveAuthSession(session.accessToken, session.refreshToken, session.expiresAtMs, session.authUserId)
        cachedAccessToken = session.accessToken
    }
}
