package com.trivias.app

import android.content.Context
import android.content.SharedPreferences

class PrefsHelper(context: Context) {
    private val p: SharedPreferences =
        context.getSharedPreferences("trivia_helper_prefs", Context.MODE_PRIVATE)

    fun saveApiKey(key: String) = p.edit().putString("api_key", key.trim()).apply()
    fun getApiKey(): String = p.getString("api_key", "") ?: ""
    fun hasApiKey(): Boolean = getApiKey().isNotBlank()

    fun saveAreaQuestion(l: Int, t: Int, r: Int, b: Int) {
        p.edit().putString("aq", "$l,$t,$r,$b").apply()
    }
    fun saveAreaOptions(l: Int, t: Int, r: Int, b: Int) {
        p.edit().putString("ao", "$l,$t,$r,$b").apply()
    }

    fun getAreaQuestion(): IntArray? = parseArea("aq")
    fun getAreaOptions(): IntArray? = parseArea("ao")
    fun isAreasSet(): Boolean = getAreaQuestion() != null && getAreaOptions() != null

    private fun parseArea(key: String): IntArray? {
        val s = p.getString(key, null) ?: return null
        val parts = s.split(",")
        if (parts.size != 4) return null
        return try {
            intArrayOf(parts[0].toInt(), parts[1].toInt(), parts[2].toInt(), parts[3].toInt())
        } catch (_: Exception) {
            null
        }
    }

    fun saveLastAnswer(answer: String, question: String) {
        p.edit().putString("last_answer", answer).putString("last_q", question).apply()
    }
    fun getLastAnswer(): String = p.getString("last_answer", "—") ?: "—"
    fun getLastQuestion(): String = p.getString("last_q", "") ?: ""

    /** "ocr" (default) or "a11y" */
    fun getDetectionMode(): String = p.getString("detection_mode", "ocr") ?: "ocr"
    fun setDetectionMode(mode: String) = p.edit().putString("detection_mode", mode).apply()
    fun isAccessibilityMode(): Boolean = getDetectionMode() == "a11y"

    // --- Auth / users ---
    fun saveUserSession(
        uid: String,
        email: String,
        nombre: String,
        status: String,
        role: String
    ) {
        p.edit()
            .putString("user_uid", uid)
            .putString("user_email", email)
            .putString("user_nombre", nombre)
            .putString("user_status", status)
            .putString("user_role", role)
            .apply()
    }

    fun getUserUid(): String = p.getString("user_uid", "") ?: ""
    fun getUserEmail(): String = p.getString("user_email", "") ?: ""
    fun getUserNombre(): String = p.getString("user_nombre", "") ?: ""
    fun getUserStatus(): String = p.getString("user_status", "") ?: ""
    fun getUserRole(): String = p.getString("user_role", "") ?: ""

    fun isApproved(): Boolean = getUserStatus() == "APPROVED" && getUserUid().isNotBlank()
    fun isAdmin(): Boolean = getUserRole().trim().equals("ADMIN", ignoreCase = true)

    fun isBanned(): Boolean {
        val s = getUserStatus()
        return s == "BANNED" || s == "DEVICE_BANNED"
    }

    fun clearUserSession() {
        p.edit()
            .remove("user_uid")
            .remove("user_email")
            .remove("user_nombre")
            .remove("user_status")
            .remove("user_role")
            .apply()
    }

    /** Auto-click by option id. Default: Manual (false). */
    fun isAutoClickEnabled(): Boolean = p.getBoolean("auto_click_enabled", false)
    fun setAutoClickEnabled(enabled: Boolean) = p.edit().putBoolean("auto_click_enabled", enabled).apply()

    /** Floating ChatGPT test panel visibility. Default: hidden. */
    fun isTestChatPanelVisible(): Boolean = p.getBoolean("test_chat_panel_visible", false)
    fun setTestChatPanelVisible(visible: Boolean) = p.edit().putBoolean("test_chat_panel_visible", visible).apply()

    fun hasSeenAboutOnFirstLogin(): Boolean = p.getBoolean("seen_about_first_login", false)
    fun setSeenAboutOnFirstLogin(v: Boolean) = p.edit().putBoolean("seen_about_first_login", v).apply()

    fun isPendingShowAbout(): Boolean = p.getBoolean("pending_show_about", false)
    fun setPendingShowAbout(v: Boolean) = p.edit().putBoolean("pending_show_about", v).apply()

    fun hasCenteredTestPanel(): Boolean = p.getBoolean("test_panel_centered_session", false)
    fun setCenteredTestPanel(v: Boolean) = p.edit().putBoolean("test_panel_centered_session", v).apply()
}

