package com.trivias.app

import android.content.Context
import android.content.SharedPreferences

class PrefsHelper(context: Context) {
    private val p: SharedPreferences =
        context.getSharedPreferences("trivia_helper_prefs", Context.MODE_PRIVATE)

    fun saveApiKey(key: String) = p.edit().putString("api_key", key.trim()).apply()
    fun getApiKey(): String = p.getString("api_key", "") ?: ""
    fun hasApiKey(): Boolean = getApiKey().isNotBlank()

    fun saveAreaQuestion(l: Int, t: Int, r: Int, b: Int) {
        p.edit().putString("aq", "$l,$t,$r,$b").apply()
    }
    fun saveAreaOptions(l: Int, t: Int, r: Int, b: Int) {
        p.edit().putString("ao", "$l,$t,$r,$b").apply()
    }

    fun getAreaQuestion(): IntArray? = parseArea("aq")
    fun getAreaOptions(): IntArray? = parseArea("ao")
    fun isAreasSet(): Boolean = getAreaQuestion() != null && getAreaOptions() != null

    private fun parseArea(key: String): IntArray? {
        val s = p.getString(key, null) ?: return null
        val parts = s.split(",")
        if (parts.size != 4) return null
        return try {
            intArrayOf(parts[0].toInt(), parts[1].toInt(), parts[2].toInt(), parts[3].toInt())
        } catch (_: Exception) {
            null
        }
    }

    fun saveLastAnswer(answer: String, question: String) {
        p.edit().putString("last_answer", answer).putString("last_q", question).apply()
    }
    fun getLastAnswer(): String = p.getString("last_answer", "—") ?: "—"
    fun getLastQuestion(): String = p.getString("last_q", "") ?: ""

    /** "ocr" (default) or "a11y" */
    fun getDetectionMode(): String = p.getString("detection_mode", "ocr") ?: "ocr"
    fun setDetectionMode(mode: String) = p.edit().putString("detection_mode", mode).apply()
    fun isAccessibilityMode(): Boolean = getDetectionMode() == "a11y"

    // --- Auth / users ---
    fun saveUserSession(
        uid: String,
        email: String,
        nombre: String,
        status: String,
        role: String
    ) {
        p.edit()
            .putString("user_uid", uid)
            .putString("user_email", email)
            .putString("user_nombre", nombre)
            .putString("user_status", status)
            .putString("user_role", role)
            .apply()
    }

    fun getUserUid(): String = p.getString("user_uid", "") ?: ""
    fun getUserEmail(): String = p.getString("user_email", "") ?: ""

    fun setUserEmail(email: String) {
        p.edit().putString("user_email", email.trim()).apply()
    }

    /** Super-admin según servidor (columna is_super_admin / get_my_privileges). No hardcodear email en el APK. */
    fun isSuperAdmin(): Boolean = p.getBoolean("is_super_admin", false)

    fun setSuperAdmin(value: Boolean) {
        p.edit().putBoolean("is_super_admin", value).commit()
    }

    /** @deprecated usar isSuperAdmin() */
    fun isSuperAdminEmail(): Boolean = isSuperAdmin()
    fun getUserNombre(): String = p.getString("user_nombre", "") ?: ""
    fun getUserStatus(): String = p.getString("user_status", "") ?: ""
    fun getUserRole(): String = p.getString("user_role", "") ?: ""

    fun isApproved(): Boolean = getUserStatus() == "APPROVED" && getUserUid().isNotBlank()
    fun isAdmin(): Boolean = getUserRole().trim().equals("ADMIN", ignoreCase = true)
    fun isTester(): Boolean = getUserRole().trim().equals("TESTER", ignoreCase = true)
    fun canAccessAdminPanel(): Boolean = isAdmin() // TESTER ya no tiene acceso al panel admin

    fun isBanned(): Boolean {
        val s = getUserStatus()
        return s == "BANNED" || s == "DEVICE_BANNED"
    }

    fun clearUserSession() {
        p.edit()
            .remove("user_uid")
            .remove("user_email")
            .remove("user_nombre")
            .remove("user_status")
            .remove("user_role")
            .remove("sb_access_token")
            .remove("sb_refresh_token")
            .remove("sb_token_expires_at")
            .remove("sb_auth_uid")
            .remove("is_super_admin")
            .apply()
    }

    fun saveAuthSession(access: String, refresh: String, expiresAtMs: Long, authUid: String) {
        p.edit()
            .putString("sb_access_token", access)
            .putString("sb_refresh_token", refresh)
            .putLong("sb_token_expires_at", expiresAtMs)
            .putString("sb_auth_uid", authUid)
            .commit()
    }

    fun getAccessToken(): String = p.getString("sb_access_token", "") ?: ""
    fun getRefreshToken(): String = p.getString("sb_refresh_token", "") ?: ""
    fun getTokenExpiresAtMs(): Long = p.getLong("sb_token_expires_at", 0L)
    fun getAuthUid(): String = p.getString("sb_auth_uid", "") ?: ""
    fun hasValidAuthSession(): Boolean = getAccessToken().isNotBlank()

    /** Auto-click by option id. Default: Manual (false). */
    fun isAutoClickEnabled(): Boolean = p.getBoolean("auto_click_enabled", true)
    fun setAutoClickEnabled(enabled: Boolean) { p.edit().putBoolean("auto_click_enabled", enabled).commit() }

    fun isPlayAgainEnabled(): Boolean = p.getBoolean("play_again_enabled", false)
    fun setPlayAgainEnabled(enabled: Boolean) { p.edit().putBoolean("play_again_enabled", enabled).commit() }

    fun getLastAccessMode(): String = p.getString("last_access_mode", "ALL") ?: "ALL"
    fun setLastAccessMode(mode: String) { p.edit().putString("last_access_mode", mode).apply() }
    fun isNotifDecorEnabled(): Boolean = p.getBoolean("notif_decor_enabled", true)
    fun setNotifDecorEnabled(enabled: Boolean) { p.edit().putBoolean("notif_decor_enabled", enabled).commit() }

    /** Energy from /user/v2/info. -1 = unknown */
    fun getEnergyCurrent(): Int = p.getInt("energy_current", -1)
    fun getEnergyMax(): Int = p.getInt("energy_max", 3)
    fun getEnergyRefreshAtMs(): Long = p.getLong("energy_refresh_at_ms", 0L)
    fun setEnergyState(current: Int, max: Int, refreshAtMs: Long) {
        p.edit()
            .putInt("energy_current", current)
            .putInt("energy_max", max.coerceAtLeast(1))
            .putLong("energy_refresh_at_ms", refreshAtMs)
            .apply()
    }
    fun clearEnergyState() {
        p.edit().putInt("energy_current", -1).putLong("energy_refresh_at_ms", 0L).apply()
    }

    /** Retry spend limit: 0 = OFF, 25 or 50 webcoins */
    fun getRetryLimit(): Int = p.getInt("retry_webcoin_limit", 0)
    fun setRetryLimit(v: Int) { p.edit().putInt("retry_webcoin_limit", v).commit() }
    /** Último LMT 25/50 antes de apagar REINTENTAR por desactivar AUTO-CLICK */
    fun getRetryLimitSaved(): Int = p.getInt("retry_webcoin_limit_saved", 0)
    fun setRetryLimitSaved(v: Int) { p.edit().putInt("retry_webcoin_limit_saved", v).commit() }

    /** Floating ChatGPT test panel visibility. Default: hidden. */
    fun isTestChatPanelVisible(): Boolean = p.getBoolean("test_chat_panel_visible", false)
    fun setTestChatPanelVisible(visible: Boolean) = p.edit().putBoolean("test_chat_panel_visible", visible).apply()

    fun hasSeenAboutOnFirstLogin(): Boolean = p.getBoolean("seen_about_first_login", false)
    fun setSeenAboutOnFirstLogin(v: Boolean) = p.edit().putBoolean("seen_about_first_login", v).apply()

    fun isPendingShowAbout(): Boolean = p.getBoolean("pending_show_about", false)
    fun setPendingShowAbout(v: Boolean) = p.edit().putBoolean("pending_show_about", v).apply()

    fun hasCenteredTestPanel(): Boolean = p.getBoolean("test_panel_centered_session", false)
    fun setCenteredTestPanel(v: Boolean) = p.edit().putBoolean("test_panel_centered_session", v).apply()

    fun getSeenNewsVersion(): String = p.getString("seen_news_version", "") ?: ""
    fun setSeenNewsVersion(v: String) = p.edit().putString("seen_news_version", v).apply()

    /** true = GROQ first then ChatGPT; false = ChatGPT only */
    fun isGroqMode(): Boolean = p.getBoolean("ai_provider_groq", true)
    fun setGroqMode(v: Boolean) = p.edit().putBoolean("ai_provider_groq", v).apply()
}



