package com.trivias.app

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import kotlin.concurrent.thread

/**
 * Full-screen lock when status is BANNED or DEVICE_BANNED.
 * Polls Supabase; if unbanned, restores session and returns to Main.
 */
class BannedActivity : AppCompatActivity() {
    private val handler = Handler(Looper.getMainLooper())
    private val checker = object : Runnable {
        override fun run() {
            checkUnban()
            handler.postDelayed(this, 3000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(
            android.view.WindowManager.LayoutParams.FLAG_SECURE,
            android.view.WindowManager.LayoutParams.FLAG_SECURE
        )
        setContentView(R.layout.activity_banned)
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(checker)
        handler.post(checker)
    }

    override fun onPause() {
        handler.removeCallbacks(checker)
        super.onPause()
    }

    private fun checkUnban() {
        val prefs = PrefsHelper(this)
        val uid = prefs.getUserUid()
        val deviceId = DeviceIdHelper.get(this)
        if (uid.isBlank() && deviceId.isBlank()) return
        thread {
            val ban = try {
                SupabaseBanClient.checkIfBanned(deviceId, uid)
            } catch (_: Exception) {
                return@thread
            }
            if (!ban.banned) {
                runOnUiThread {
                    val role = prefs.getUserRole().ifBlank { "USER" }
                    prefs.saveUserSession(
                        uid,
                        prefs.getUserEmail(),
                        prefs.getUserNombre(),
                        "APPROVED",
                        role
                    )
                    startActivity(Intent(this, MainActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                    })
                    finish()
                }
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        finishAffinity()
    }
}
