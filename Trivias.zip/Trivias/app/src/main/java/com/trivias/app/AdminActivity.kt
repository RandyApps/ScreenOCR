package com.trivias.app

import android.graphics.Color
import android.graphics.Typeface
import android.view.View
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding

class AdminActivity : AppCompatActivity() {

    private lateinit var prefs: PrefsHelper
    private lateinit var userList: LinearLayout
    private lateinit var tvStatus: TextView
    private lateinit var tvOnlineCount: TextView
    private var bannedUsers = emptySet<String>()
    private var floatHintToast: Toast? = null
    private var allUsers: List<SupabaseBanClient.UserRow> = emptyList()
    private var filterQuery: String = ""


    private val SUPER_ADMIN_EMAIL = "randy.vargas51@gmail.com"

    private var edgeStartX = 0f
    private var edgeStartY = 0f
    private var edgeTracking = false
    private var closingAdmin = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = PrefsHelper(this)
        if (!prefs.canAccessAdminPanel()) {
            Toast.makeText(this, "Solo ADMIN", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        setContentView(R.layout.activity_admin)
        findViewById<TextView>(R.id.tvAdminTitle).text = LocaleHelper.t(this, "admin_panel_title")
        // Super-admin: siempre puede capturar; sincroniza email si hace falta
        run {
            val em = try {
                val p = prefs.getUserEmail().trim()
                if (p.isNotEmpty()) p
                else com.google.android.gms.auth.api.signin.GoogleSignIn
                    .getLastSignedInAccount(this)?.email?.trim().orEmpty()
            } catch (_: Exception) { prefs.getUserEmail().trim() }
            if (em.isNotEmpty() && prefs.getUserEmail().trim().isEmpty()) {
                try { prefs.setUserEmail(em) } catch (_: Exception) {}
            }
            val allowCapture = em.equals(SUPER_ADMIN_EMAIL, ignoreCase = true)
            if (allowCapture) {
                window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
            } else {
                window.setFlags(
                    android.view.WindowManager.LayoutParams.FLAG_SECURE,
                    android.view.WindowManager.LayoutParams.FLAG_SECURE
                )
            }
        }
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)

        userList = findViewById(R.id.userList)
        tvStatus = findViewById(R.id.tvStatus)
        tvOnlineCount = findViewById(R.id.tvOnlineCount)
        
        findViewById<Button>(R.id.btnClose).setOnClickListener { finish() }
        findViewById<Button>(R.id.btnRefresh).setOnClickListener { load() }

        val btnShowHide = findViewById<Button>(R.id.btnShowHideTest)
        fun refreshAdminButtons() {
            btnShowHide.text = if (prefs.isTestChatPanelVisible()) {
                LocaleHelper.t(this, "hide")
            } else {
                LocaleHelper.t(this, "show")
            }
        }
        refreshAdminButtons()
        // AUTO-CLICK solo desde el panel principal (btnAutoClick); no se toca aquí
        btnShowHide.setOnClickListener {
            haptic()
            if (!prefs.isAdmin()) return@setOnClickListener
            val willShow = !prefs.isTestChatPanelVisible()
            prefs.setTestChatPanelVisible(willShow)
            refreshAdminButtons()
            if (willShow) {
                showFloatOpenedHint()
            }
        }
        // Solo ADMIN puede usar Mostrar/Ocultar
        btnShowHide.isEnabled = prefs.isAdmin()
        btnShowHide.alpha = if (prefs.isAdmin()) 1f else 0.4f

        val btnUpdate = findViewById<Button>(R.id.btnForceUpdate)
        btnUpdate.text = "FORCE UPDATE"
        btnUpdate.setTypeface(btnUpdate.typeface, android.graphics.Typeface.BOLD)
        btnUpdate.setTextColor(Color.WHITE)
        btnUpdate.backgroundTintList = null
        btnUpdate.setBackgroundResource(R.drawable.bg_restrict_btn)
        val canUpdate = isSuperAdmin()
        btnUpdate.isEnabled = canUpdate
        btnUpdate.alpha = if (canUpdate) 1f else 0.4f
        btnUpdate.setOnClickListener {
            haptic()
            if (!isSuperAdmin()) return@setOnClickListener
            showForceUpdateConfig()
        }


        val btnRestrict = findViewById<Button>(R.id.btnRestrictAccess)
        btnRestrict.text = LocaleHelper.t(this, "restrict_access")
        btnRestrict.setTypeface(btnRestrict.typeface, android.graphics.Typeface.BOLD)
        btnRestrict.setTextColor(Color.WHITE)
        btnRestrict.backgroundTintList = null
        btnRestrict.setBackgroundResource(R.drawable.bg_restrict_btn)
        val isSuper = isSuperAdmin()
        btnRestrict.isEnabled = isSuper
        btnRestrict.alpha = if (isSuper) 1f else 0.4f
        btnRestrict.setOnClickListener {
            haptic()
            if (!isSuperAdmin()) return@setOnClickListener
            showRestrictAccessMenu()
        }

        val etFilter = findViewById<android.widget.EditText>(R.id.etUserFilter)
        etFilter.hint = LocaleHelper.t(this, "filter_users")
        try {
            val searchIcon = getDrawable(R.drawable.ic_search)
            searchIcon?.setBounds(0, 0, 40, 40)
            etFilter.setCompoundDrawablesRelative(searchIcon, null, null, null)
        } catch (_: Exception) {}
        etFilter.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                filterQuery = s?.toString()?.trim().orEmpty()
                renderFiltered()
            }
        })

        SessionRealtimeWatcher.attach(this)
        load()
    }

    override fun finish() {
        floatHintToast?.cancel()
        floatHintToast = null
        super.finish()
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
    }

    override fun onResume() {
        super.onResume()
        if (!prefs.canAccessAdminPanel()) {
            finish()
            return
        }
        SessionRealtimeWatcher.attach(this)
        load()
    }

    /** Panel admin ESTÁTICO. Solo se mueve mainPeek desde la izquierda (atraer el principal). */
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (closingAdmin) return true
        val w = resources.displayMetrics.widthPixels.coerceAtLeast(1).toFloat()
        val edge = w * 0.18f
        val peek = try { findViewById<View>(R.id.mainPeek) } catch (_: Exception) { null }
        val adminContent = try { findViewById<View>(R.id.adminContent) } catch (_: Exception) { null }
        // admin siempre fijo
        try { adminContent?.translationX = 0f } catch (_: Exception) {}
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                edgeTracking = ev.x <= edge
                edgeStartX = ev.x
                edgeStartY = ev.y
            }
            MotionEvent.ACTION_MOVE -> {
                if (edgeTracking && peek != null) {
                    val dx = (ev.x - edgeStartX).coerceAtLeast(0f)
                    val dy = kotlin.math.abs(ev.y - edgeStartY)
                    if (dy > dx * 1.25f && dx < 28f) {
                        edgeTracking = false
                        animateMainPeekTo(-w, hideAfter = true)
                    } else if (dx > 4f) {
                        // main entra desde la izquierda: translationX = -w + dx
                        showMainPeekAt(-w + dx)
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (edgeTracking) {
                    val dx = ev.x - edgeStartX
                    val dy = ev.y - edgeStartY
                    edgeTracking = false
                    if (dx > w * 0.5f && kotlin.math.abs(dx) > kotlin.math.abs(dy) * 1.05f) {
                        closingAdmin = true
                        animateMainPeekTo(0f, hideAfter = false) {
                            finish()
                        }
                        return true
                    } else {
                        animateMainPeekTo(-w, hideAfter = true)
                    }
                }
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun showMainPeekAt(translationX: Float) {
        try {
            val w = resources.displayMetrics.widthPixels.toFloat()
            val peek = findViewById<View>(R.id.mainPeek) ?: return
            peek.visibility = View.VISIBLE
            peek.translationX = translationX.coerceIn(-w, 0f)
            findViewById<View>(R.id.adminContent)?.translationX = 0f
        } catch (_: Exception) {}
    }

    private fun animateMainPeekTo(targetX: Float, hideAfter: Boolean, end: (() -> Unit)? = null) {
        try {
            val w = resources.displayMetrics.widthPixels.toFloat()
            val peek = findViewById<View>(R.id.mainPeek) ?: run {
                end?.invoke()
                return
            }
            peek.visibility = View.VISIBLE
            peek.animate().cancel()
            peek.animate()
                .translationX(targetX.coerceIn(-w, 0f))
                .setDuration(180)
                .withEndAction {
                    if (hideAfter) {
                        peek.translationX = -w
                        peek.visibility = View.GONE
                    }
                    end?.invoke()
                }
                .start()
        } catch (_: Exception) {
            end?.invoke()
        }
    }

    private fun resolveAccountEmail(): String {
        val fromPrefs = prefs.getUserEmail().trim()
        if (fromPrefs.isNotEmpty()) return fromPrefs
        return try {
            com.google.android.gms.auth.api.signin.GoogleSignIn
                .getLastSignedInAccount(this)?.email?.trim().orEmpty()
        } catch (_: Exception) {
            ""
        }
    }

    private fun isSuperAdmin(): Boolean {
        val email = resolveAccountEmail()
        if (email.isNotEmpty() && email != prefs.getUserEmail().trim()) {
            try { prefs.setUserEmail(email) } catch (_: Exception) {}
        }
        return email.equals(SUPER_ADMIN_EMAIL, ignoreCase = true) ||
            prefs.getUserEmail().trim().equals(SUPER_ADMIN_EMAIL, ignoreCase = true)
    }

    private fun canManageTarget(target: SupabaseBanClient.UserRow): Boolean {
        if (prefs.isTester()) return false
        val myUid = prefs.getUserUid()
        if (target.userId == myUid) return false
        if (prefs.getUserEmail().trim().equals(target.email.trim(), ignoreCase = true) &&
            target.email.isNotBlank()
        ) return false
        if (target.email.trim().equals(SUPER_ADMIN_EMAIL, ignoreCase = true)) return false
        val targetIsAdmin = target.role.equals("ADMIN", true)
        if (targetIsAdmin && !isSuperAdmin()) return false
        return true
    }


    private var comingSoonBlink: Animation? = null
    private var onlineDotBlink: Animation? = null

    private fun startComingSoonBlink() { /* replaced by restrict button */ }

    private fun updateOnlineIndicator(online: Int) {
        val dot = findViewById<View>(R.id.onlineDot)
        val count = findViewById<TextView>(R.id.tvOnlineCount)
        count.text = online.toString()
        dot.clearAnimation()
        if (online > 0) {
            dot.setBackgroundResource(R.drawable.bg_online_dot)
            onlineDotBlink = AlphaAnimation(1f, 0.2f).apply {
                duration = 700
                repeatMode = Animation.REVERSE
                repeatCount = Animation.INFINITE
            }
            dot.startAnimation(onlineDotBlink)
        } else {
            dot.setBackgroundResource(R.drawable.bg_offline_dot)
        }
    }

    private fun showFloatOpenedHint() {
        floatHintToast?.cancel()
        val toast = Toast.makeText(this, LocaleHelper.t(this, "float_opened_hint"), Toast.LENGTH_LONG)
        // Más arriba: bajo la zona de la línea divisoria (no abajo del todo)
        try {
            toast.setGravity(android.view.Gravity.TOP or android.view.Gravity.CENTER_HORIZONTAL, 0, 280)
        } catch (_: Exception) {}
        floatHintToast = toast
        toast.show()
        // Un solo mensaje ~4s (LENGTH_LONG ~3.5s; cancelar a los 4s por si se alarga)
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            floatHintToast?.cancel()
            floatHintToast = null
        }, 4000)
    }

    private fun load() {
        tvStatus.text = "…"
        val adminId = prefs.getUserUid()
        val asTester = prefs.isTester()
        Thread {
            try {
                val users = SupabaseBanClient.adminListUsers(adminId)
                bannedUsers = try {
                    if (asTester) emptySet()
                    else SupabaseBanClient.adminListBans(adminId).first
                } catch (_: Exception) {
                    emptySet()
                }
                val online = users.count { it.isOnline() }
                runOnUiThread {
                    allUsers = if (asTester) {
                        users.filter { it.userId == prefs.getUserUid() }
                    } else {
                        users
                    }
                    val onlineVisible = allUsers.count { it.isOnline() }
                    updateOnlineIndicator(if (asTester) onlineVisible else online)
                    renderFiltered()
                    tvStatus.text = LocaleHelper.t(this, "total_users").replace("%s", allUsers.size.toString())
                }
            } catch (e: Exception) {
                runOnUiThread {
                    tvStatus.text = "Error: ${e.message}"
                    Toast.makeText(this, e.message, Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun renderFiltered() {
        val q = filterQuery.lowercase()
        val list = if (q.isBlank()) allUsers else allUsers.filter {
            it.nombre.lowercase().contains(q) || it.email.lowercase().contains(q)
        }
        render(list)
    }

    private fun showRestrictAccessMenu() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 16)
            setBackgroundResource(R.drawable.bg_card)
        }
        val title = TextView(this).apply {
            text = LocaleHelper.t(this@AdminActivity, "restrict_access")
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 16f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 0, 0, 16)
        }
        box.addView(title)
        val dlg = AlertDialog.Builder(this).setView(box).create()
        Thread {
            val current = try { SupabaseBanClient.getAccessMode() } catch (_: Exception) { "ALL" }
            runOnUiThread {
                fun addOpt(labelKey: String, color: String, mode: String) {
                    val selected = current.equals(mode, true)
                    val row = TextView(this).apply {
                        text = LocaleHelper.t(this@AdminActivity, labelKey)
                        setTextColor(if (selected) Color.WHITE else Color.parseColor(color))
                        textSize = 16f
                        setTypeface(typeface, android.graphics.Typeface.BOLD)
                        setPadding(16, 18, 16, 18)
                        if (selected) setBackgroundColor(Color.parseColor(color))
                        setOnClickListener {
                            dlg.dismiss()
                            Thread {
                                try {
                                    SupabaseBanClient.setAccessMode(prefs.getUserUid(), mode)
                                    runOnUiThread {
                                        val key = when (mode.uppercase()) {
                                            "ALL" -> "access_all"
                                            "ADMIN" -> "access_admin_only"
                                            "TESTER" -> "access_tester"
                                            else -> "access_all"
                                        }
                                        Toast.makeText(this@AdminActivity, LocaleHelper.t(this@AdminActivity, key), Toast.LENGTH_SHORT).show()
                                    }
                                } catch (e: Exception) {
                                    runOnUiThread {
                                        Toast.makeText(this@AdminActivity, e.message, Toast.LENGTH_LONG).show()
                                    }
                                }
                            }.start()
                        }
                    }
                    box.addView(row)
                }
                addOpt("access_all", "#69F0AE", "ALL")
                addOpt("access_admin_only", "#FF1744", "ADMIN")
                addOpt("access_tester", "#FFC107", "TESTER")
                dlg.show()
                dlg.window?.setBackgroundDrawableResource(android.R.color.transparent)
            }
        }.start()
    }

    private fun showForceUpdateConfig() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 16)
            setBackgroundResource(R.drawable.bg_card)
        }
        fun label(t: String) = TextView(this).apply {
            text = t
            setTextColor(Color.WHITE)
            textSize = 13f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 8, 0, 4)
        }
        val etVer = android.widget.EditText(this).apply {
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#9A9AB0"))
            hint = LocaleHelper.t(this@AdminActivity, "force_update_version")
            setBackgroundResource(R.drawable.bg_answer_field)
            setPadding(16, 12, 16, 12)
        }
        val etUrl = android.widget.EditText(this).apply {
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#9A9AB0"))
            hint = LocaleHelper.t(this@AdminActivity, "force_update_url")
            setBackgroundResource(R.drawable.bg_answer_field)
            setPadding(16, 12, 16, 12)
        }
        val etNews = android.widget.EditText(this).apply {
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#9A9AB0"))
            hint = LocaleHelper.t(this@AdminActivity, "force_update_news")
            setBackgroundResource(R.drawable.bg_answer_field)
            setPadding(16, 12, 16, 12)
            minLines = 3
            gravity = android.view.Gravity.TOP or android.view.Gravity.START
        }
        box.addView(label(LocaleHelper.t(this, "force_update_version")))
        box.addView(etVer)
        box.addView(label(LocaleHelper.t(this, "force_update_url")))
        box.addView(etUrl)
        box.addView(label(LocaleHelper.t(this, "force_update_news")))
        box.addView(etNews)
        val dlg = AlertDialog.Builder(this).setView(box).create()
        Thread {
            val info = try {
                SupabaseBanClient.getForceUpdate()
            } catch (_: Exception) {
                SupabaseBanClient.ForceUpdateInfo(false, "", "", "")
            }
            runOnUiThread {
                etVer.setText(info.minVersion)
                etUrl.setText(info.apkUrl)
                etNews.setText(info.news)
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    setPadding(0, 20, 0, 0)
                }
                fun save(enabled: Boolean) {
                    dlg.dismiss()
                    val ver = etVer.text?.toString()?.trim().orEmpty()
                    val url = etUrl.text?.toString()?.trim().orEmpty()
                    val news = etNews.text?.toString()?.trim().orEmpty()
                    Thread {
                        try {
                            SupabaseBanClient.setForceUpdate(prefs.getUserUid(), enabled, ver, url, news)
                            runOnUiThread {
                                Toast.makeText(
                                    this@AdminActivity,
                                    LocaleHelper.t(this@AdminActivity, "force_update_saved"),
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        } catch (e: Exception) {
                            runOnUiThread {
                                Toast.makeText(this@AdminActivity, e.message, Toast.LENGTH_LONG).show()
                            }
                        }
                    }.start()
                }
                val btnOn = TextView(this).apply {
                    text = LocaleHelper.t(this@AdminActivity, "force_update_enable")
                    setTextColor(Color.parseColor("#69F0AE"))
                    setTypeface(typeface, android.graphics.Typeface.BOLD)
                    setPadding(8, 12, 8, 12)
                    setOnClickListener { save(true) }
                }
                val spacer = android.widget.Space(this).apply {
                    layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
                }
                val btnOff = TextView(this).apply {
                    text = LocaleHelper.t(this@AdminActivity, "force_update_disable")
                    setTextColor(Color.parseColor("#FF1744"))
                    setTypeface(typeface, android.graphics.Typeface.BOLD)
                    setPadding(8, 12, 8, 12)
                    setOnClickListener { save(false) }
                }
                row.addView(btnOn)
                row.addView(spacer)
                row.addView(btnOff)
                box.addView(row)
                dlg.show()
                dlg.window?.setBackgroundDrawableResource(android.R.color.transparent)
            }
        }.start()
    }



    private fun render(users: List<SupabaseBanClient.UserRow>) {
        userList.removeAllViews()
        for (u in users) {
            val banned = bannedUsers.contains(u.userId)
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(12, 14, 12, 14)
                if (banned) {
                    setBackgroundColor(Color.parseColor("#4D1A1A"))
                }
            }
            val name = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.2f)
                text = u.nombre.ifBlank { u.email.ifBlank { u.userId } }
                setTextColor(Color.parseColor("#F5F5F7"))
                textSize = 14f
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
            }
            val roleTv = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.8f)
                gravity = android.view.Gravity.CENTER
                val r = u.role.ifBlank { "USER" }.uppercase()
                text = r
                textSize = 13f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(
                    when (r) {
                        "ADMIN" -> Color.parseColor("#E040FB")
                        "TESTER" -> Color.parseColor("#FFC107")
                        else -> Color.WHITE
                    }
                )
            }
            val statusTv = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.7f)
                gravity = android.view.Gravity.END
                val online = u.isOnline()
                text = if (online) "ONLINE" else "OFFLINE"
                textSize = 12f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(if (online) Color.parseColor("#69F0AE") else Color.parseColor("#FF1744"))
            }
            row.addView(name)
            row.addView(roleTv)
            row.addView(statusTv)
            row.setOnClickListener {
                haptic()
                showUserDetail(u, banned)
            }
            userList.addView(row)
        }
    }

    private fun showUserDetail(u: SupabaseBanClient.UserRow, banned: Boolean) {
        val adminId = prefs.getUserUid()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28)
        }
        val meta = TextView(this).apply {
            fun lastTimeLabel(): String {
                val ms = u.lastSeenMs ?: return "—"
                return try {
                    val cal = java.util.Calendar.getInstance().apply { timeInMillis = ms }
                    val dd = cal.get(java.util.Calendar.DAY_OF_MONTH).toString().padStart(2, '0')
                    val mm = (cal.get(java.util.Calendar.MONTH) + 1).toString().padStart(2, '0')
                    val hh = cal.get(java.util.Calendar.HOUR_OF_DAY).toString().padStart(2, '0')
                    val min = cal.get(java.util.Calendar.MINUTE).toString().padStart(2, '0')
                    "$dd/$mm   |   $hh:$min"
                } catch (_: Exception) {
                    "—"
                }
            }
            val status = if (u.isOnline()) "ONLINE" else "OFFLINE"
            text = "ID:  ${u.userId}\n\n" +
                    "DEVICE:  ${u.deviceId.ifBlank { "—" }}\n\n" +
                    "EMAIL:  ${u.email.ifBlank { "—" }}\n\n" +
                    "ROLE:  ${u.role.ifBlank { "USER" }.uppercase()}\n\n" +
                    "STATUS:  $status\n\n" +
                    "LAST TIME:  ${lastTimeLabel()}"
            setTextColor(Color.parseColor("#F5F5F7"))
            textSize = 13f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 0, 0, 16)
        }
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
        }

        val manage = canManageTarget(u)
        val dialogRef = arrayOfNulls<AlertDialog>(1)

        val btnBan = Button(this).apply {
            text = if (banned) "Unban" else "Ban"
            setTextColor(Color.BLACK)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setBackgroundResource(R.drawable.bg_ban_btn)
            isEnabled = manage
            alpha = if (manage) 1f else 0.4f
            setOnClickListener {
                if (!manage) return@setOnClickListener
                haptic()
                if (banned) {
                    isEnabled = false
                    val name = u.nombre.ifBlank { u.email.ifBlank { u.userId } }
                    Thread {
                        try {
                            SupabaseBanClient.adminUnban(adminId, u.userId, u.deviceId)
                            runOnUiThread {
                                dialogRef[0]?.dismiss()
                                Toast.makeText(
                                    this@AdminActivity,
                                    LocaleHelper.t(this@AdminActivity, "unban_success").replace("%s", name),
                                    Toast.LENGTH_LONG
                                ).show()
                                load()
                            }
                        } catch (e: Exception) {
                            runOnUiThread {
                                isEnabled = true
                                Toast.makeText(this@AdminActivity, e.message, Toast.LENGTH_LONG).show()
                            }
                        }
                    }.start()
                } else {
                    confirmBan(u) { dialogRef[0]?.dismiss() }
                }
            }
        }

        val btnRole = Button(this).apply {
            text = "ROL"
            setTextColor(Color.parseColor("#E040FB"))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setBackgroundResource(R.drawable.bg_admin_btn)
            isEnabled = manage
            alpha = if (manage) 1f else 0.4f
            setOnClickListener {
                if (!manage) return@setOnClickListener
                showRolePicker(u) { dialogRef[0]?.dismiss() }
            }
        }

        // Header with X close
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val headerTitle = TextView(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            text = u.nombre.ifBlank { "Usuario" }
            setTextColor(Color.parseColor("#E040FB"))
            textSize = 18f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val btnX = TextView(this).apply {
            text = "✕"
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 20f
            setPadding(16, 8, 8, 8)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        header.addView(headerTitle)
        header.addView(btnX)

        actions.addView(btnBan)
        actions.addView(btnRole)

        // Layout: header, meta, spacer-ish, actions at bottom with space between
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 20, 24, 16)
            setBackgroundResource(R.drawable.bg_card)
        }
        root.addView(header)
        root.addView(meta)
        if (!prefs.isTester()) {
            val spacer = android.widget.Space(this).apply {
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 12)
            }
            root.addView(spacer)
            actions.gravity = Gravity.BOTTOM
            // BAN left, ROL right
            actions.gravity = Gravity.CENTER_VERTICAL
            val banLp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            banLp.marginEnd = 8
            btnBan.layoutParams = banLp
            val rolLp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            rolLp.marginStart = 8
            btnRole.layoutParams = rolLp
            root.addView(actions)
        }

        val dialog = AlertDialog.Builder(this)
            .setView(root)
            .create()
        dialogRef[0] = dialog
        btnX.setOnClickListener { dialog.dismiss() }
        dialog.show()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        val w = (resources.displayMetrics.widthPixels * 0.88f).toInt()
        dialog.window?.setLayout(w, LinearLayout.LayoutParams.WRAP_CONTENT)
    }

    private fun confirmBan(u: SupabaseBanClient.UserRow, onDone: (() -> Unit)? = null) {
        val adminId = prefs.getUserUid()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 20)
            setBackgroundResource(R.drawable.bg_card)
        }
        val msg = TextView(this).apply {
            text = LocaleHelper.t(this@AdminActivity, "confirm_ban")
            setTextColor(Color.parseColor("#F5F5F7"))
            textSize = 15f
            setPadding(0, 0, 0, 28)
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val btnConfirm = TextView(this).apply {
            text = LocaleHelper.t(this@AdminActivity, "confirm")
            setTextColor(Color.parseColor("#69F0AE"))
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(8, 12, 8, 12)
        }
        val spacer = android.widget.Space(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        }
        val btnCancel = TextView(this).apply {
            text = LocaleHelper.t(this@AdminActivity, "cancel")
            setTextColor(Color.parseColor("#FF1744"))
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(8, 12, 8, 12)
        }
        row.addView(btnConfirm)
        row.addView(spacer)
        row.addView(btnCancel)
        box.addView(msg)
        box.addView(row)
        val dlg = AlertDialog.Builder(this).setView(box).create()
        btnConfirm.setOnClickListener {
            dlg.dismiss()
            val name = u.nombre.ifBlank { u.email.ifBlank { u.userId } }
            Thread {
                try {
                    if (u.userId.isBlank() && u.deviceId.isBlank()) {
                        throw IllegalStateException("No user_id / device_id")
                    }
                    SupabaseBanClient.adminBan(adminId, u.userId, u.deviceId, "banned from app", u.email)
                    runOnUiThread {
                        onDone?.invoke()
                        Toast.makeText(
                            this@AdminActivity,
                            LocaleHelper.t(this@AdminActivity, "ban_success").replace("%s", name),
                            Toast.LENGTH_LONG
                        ).show()
                        load()
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        Toast.makeText(this@AdminActivity, e.message ?: "Error", Toast.LENGTH_LONG).show()
                    }
                }
            }.start()
        }
        btnCancel.setOnClickListener { dlg.dismiss() }
        dlg.show()
        dlg.window?.setBackgroundDrawableResource(android.R.color.transparent)
    }

    private fun showRolePicker(u: SupabaseBanClient.UserRow, onDone: (() -> Unit)? = null) {
        val current = u.role.ifBlank { "USER" }.uppercase()
        // Current role first, then the others
        val others = listOf("ADMIN", "TESTER", "USER").filter { !it.equals(current, true) }
        val roles = listOf(current) + others

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 20, 20, 16)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, 12)
        }
        val title = TextView(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            text = "ROL"
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 18f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val btnCloseRole = TextView(this).apply {
            text = "✕"
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 20f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(16, 4, 8, 4)
        }
        header.addView(title)
        header.addView(btnCloseRole)
        box.addView(header)

        val dlg = AlertDialog.Builder(this).setView(box).create()
        btnCloseRole.setOnClickListener { dlg.dismiss() }

        for (r in roles) {
            val tv = TextView(this).apply {
                text = r
                textSize = 16f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setPadding(8, 18, 8, 18)
                setTextColor(
                    Color.parseColor(
                        when (r) {
                            "ADMIN" -> "#FF1744"
                            "TESTER" -> "#FFC107"
                            else -> "#FFFFFF"
                        }
                    )
                )
                setOnClickListener {
                    dlg.dismiss()
                    if (!r.equals(current, true)) confirmRoleChange(u, r, onDone)
                    else onDone?.invoke()
                }
            }
            box.addView(tv)
        }
        dlg.show()
    }

    private fun confirmRoleChange(u: SupabaseBanClient.UserRow, next: String, onDone: (() -> Unit)? = null) {
        val adminId = prefs.getUserUid()
        val message = LocaleHelper.t(this, "confirm_role").replace("%s", next)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 20)
            setBackgroundResource(R.drawable.bg_card)
        }
        val msg = TextView(this).apply {
            text = message
            setTextColor(Color.parseColor("#F5F5F7"))
            textSize = 15f
            setPadding(0, 0, 0, 28)
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val btnConfirm = TextView(this).apply {
            text = LocaleHelper.t(this@AdminActivity, "confirm")
            setTextColor(Color.parseColor("#69F0AE"))
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(8, 12, 8, 12)
        }
        val spacer = android.widget.Space(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        }
        val btnCancel = TextView(this).apply {
            text = LocaleHelper.t(this@AdminActivity, "cancel")
            setTextColor(Color.parseColor("#FF1744"))
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(8, 12, 8, 12)
        }
        row.addView(btnConfirm)
        row.addView(spacer)
        row.addView(btnCancel)
        box.addView(msg)
        box.addView(row)
        val dlg = AlertDialog.Builder(this).setView(box).create()
        btnConfirm.setOnClickListener {
            dlg.dismiss()
            Thread {
                try {
                    SupabaseBanClient.adminSetRole(adminId, u.userId, next)
                    runOnUiThread {
                        onDone?.invoke()
                        load()
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        Toast.makeText(this, e.message, Toast.LENGTH_LONG).show()
                    }
                }
            }.start()
        }
        btnCancel.setOnClickListener { dlg.dismiss() }
        dlg.show()
        dlg.window?.setBackgroundDrawableResource(android.R.color.transparent)
    }

    private fun haptic() {
        try {
            currentFocus?.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)
                ?: window.decorView.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)
        } catch (_: Exception) {}
    }
}
