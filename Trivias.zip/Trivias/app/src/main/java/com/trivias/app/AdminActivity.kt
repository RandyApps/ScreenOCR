package com.trivias.app

import android.graphics.Color
import android.view.View
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding

class AdminActivity : AppCompatActivity() {

    private lateinit var prefs: PrefsHelper
    private lateinit var userList: LinearLayout
    private lateinit var tvStatus: TextView
    private lateinit var tvOnlineCount: TextView
    private var bannedUsers = emptySet<String>()
    private var floatHintToast: Toast? = null
    private var allUsers: List<SupabaseBanClient.UserRow> = emptyList()
    private var filterQuery: String = ""


    private val SUPER_ADMIN_EMAIL = "randy.vargas51@gmail.com"

    private var edgeStartX = 0f
    private var edgeStartY = 0f
    private var edgeTracking = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = PrefsHelper(this)
        if (!prefs.canAccessAdminPanel()) {
            Toast.makeText(this, "Solo ADMIN / TESTER", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        setContentView(R.layout.activity_admin)
        val allowCapture = prefs.getUserEmail().trim().equals(SUPER_ADMIN_EMAIL, ignoreCase = true)
        if (allowCapture) {
            window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        } else {
            window.setFlags(
                android.view.WindowManager.LayoutParams.FLAG_SECURE,
                android.view.WindowManager.LayoutParams.FLAG_SECURE
            )
        }
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)

        userList = findViewById(R.id.userList)
        tvStatus = findViewById(R.id.tvStatus)
        tvOnlineCount = findViewById(R.id.tvOnlineCount)
        
        findViewById<Button>(R.id.btnClose).setOnClickListener { finish() }
        findViewById<Button>(R.id.btnRefresh).setOnClickListener { load() }

        val btnAuto = findViewById<Button>(R.id.btnAutoManual)
        val btnShowHide = findViewById<Button>(R.id.btnShowHideTest)
        fun refreshAdminButtons() {
            btnAuto.text = if (prefs.isAutoClickEnabled()) {
                LocaleHelper.t(this, "mode_automatic")
            } else {
                LocaleHelper.t(this, "mode_manual")
            }
            btnShowHide.text = if (prefs.isTestChatPanelVisible()) {
                LocaleHelper.t(this, "hide")
            } else {
                LocaleHelper.t(this, "show")
            }
        }
        refreshAdminButtons()
        btnAuto.setOnClickListener {
            prefs.setAutoClickEnabled(!prefs.isAutoClickEnabled())
            refreshAdminButtons()
            val msg = if (prefs.isAutoClickEnabled()) LocaleHelper.t(this, "auto_click_on")
            else LocaleHelper.t(this, "auto_click_off")
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        }
        btnShowHide.setOnClickListener {
            val willShow = !prefs.isTestChatPanelVisible()
            prefs.setTestChatPanelVisible(willShow)
            refreshAdminButtons()
            if (willShow) {
                showFloatOpenedHint()
            }
        }


        val btnRestrict = findViewById<Button>(R.id.btnRestrictAccess)
        btnRestrict.text = LocaleHelper.t(this, "restrict_access")
        btnRestrict.setTypeface(btnRestrict.typeface, android.graphics.Typeface.BOLD)
        val isSuper = isSuperAdmin()
        btnRestrict.isEnabled = isSuper
        btnRestrict.alpha = if (isSuper) 1f else 0.4f
        btnRestrict.setOnClickListener {
            if (!isSuperAdmin()) return@setOnClickListener
            showRestrictAccessMenu()
        }

        val etFilter = findViewById<android.widget.EditText>(R.id.etUserFilter)
        etFilter.hint = LocaleHelper.t(this, "filter_users")
        try {
            val searchIcon = getDrawable(R.drawable.ic_search)
            searchIcon?.setBounds(0, 0, 40, 40)
            etFilter.setCompoundDrawablesRelative(searchIcon, null, null, null)
        } catch (_: Exception) {}
        etFilter.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                filterQuery = s?.toString()?.trim().orEmpty()
                renderFiltered()
            }
        })

        SessionRealtimeWatcher.attach(this)
        load()
    }

    override fun finish() {
        floatHintToast?.cancel()
        floatHintToast = null
        super.finish()
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
    }

    override fun onResume() {
        super.onResume()
        if (!prefs.canAccessAdminPanel()) {
            finish()
            return
        }
        SessionRealtimeWatcher.attach(this)
        load()
    }

    /** Deslizar de izquierda a derecha para volver */
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        val w = resources.displayMetrics.widthPixels.coerceAtLeast(1)
        val edge = w * 0.18f
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                edgeTracking = ev.x <= edge
                edgeStartX = ev.x
                edgeStartY = ev.y
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (edgeTracking) {
                    val dx = ev.x - edgeStartX
                    val dy = ev.y - edgeStartY
                    if (dx > 80 && kotlin.math.abs(dx) > kotlin.math.abs(dy) * 1.1f) {
                        finish()
                        return true
                    }
                }
                edgeTracking = false
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun isSuperAdmin(): Boolean =
        prefs.getUserEmail().trim().equals(SUPER_ADMIN_EMAIL, ignoreCase = true)

    private fun canManageTarget(target: SupabaseBanClient.UserRow): Boolean {
        if (prefs.isTester()) return false
        val myUid = prefs.getUserUid()
        if (target.userId == myUid) return false
        if (prefs.getUserEmail().trim().equals(target.email.trim(), ignoreCase = true) &&
            target.email.isNotBlank()
        ) return false
        if (target.email.trim().equals(SUPER_ADMIN_EMAIL, ignoreCase = true)) return false
        val targetIsAdmin = target.role.equals("ADMIN", true)
        if (targetIsAdmin && !isSuperAdmin()) return false
        return true
    }


    private var comingSoonBlink: Animation? = null
    private var onlineDotBlink: Animation? = null

    private fun startComingSoonBlink() { /* replaced by restrict button */ }

    private fun updateOnlineIndicator(online: Int) {
        val dot = findViewById<View>(R.id.onlineDot)
        val count = findViewById<TextView>(R.id.tvOnlineCount)
        count.text = online.toString()
        dot.clearAnimation()
        if (online > 0) {
            dot.setBackgroundResource(R.drawable.bg_online_dot)
            onlineDotBlink = AlphaAnimation(1f, 0.2f).apply {
                duration = 700
                repeatMode = Animation.REVERSE
                repeatCount = Animation.INFINITE
            }
            dot.startAnimation(onlineDotBlink)
        } else {
            dot.setBackgroundResource(R.drawable.bg_offline_dot)
        }
    }

    private fun showFloatOpenedHint() {
        floatHintToast?.cancel()
        val toast = Toast.makeText(this, LocaleHelper.t(this, "float_opened_hint"), Toast.LENGTH_LONG)
        // Más arriba: bajo la zona de la línea divisoria (no abajo del todo)
        try {
            toast.setGravity(android.view.Gravity.TOP or android.view.Gravity.CENTER_HORIZONTAL, 0, 280)
        } catch (_: Exception) {}
        floatHintToast = toast
        toast.show()
        // Un solo mensaje ~4s (LENGTH_LONG ~3.5s; cancelar a los 4s por si se alarga)
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            floatHintToast?.cancel()
            floatHintToast = null
        }, 4000)
    }

    private fun load() {
        tvStatus.text = "…"
        val adminId = prefs.getUserUid()
        Thread {
            try {
                val users = SupabaseBanClient.adminListUsers(adminId)
                val bans = SupabaseBanClient.adminListBans(adminId)
                bannedUsers = bans.first
                val online = users.count { it.isOnline() }
                runOnUiThread {
                    allUsers = if (prefs.isTester()) {
                        users.filter { it.userId == prefs.getUserUid() }
                    } else {
                        users
                    }
                    val onlineVisible = allUsers.count { it.isOnline() }
                    updateOnlineIndicator(if (prefs.isTester()) onlineVisible else online)
                    renderFiltered()
                    tvStatus.text = LocaleHelper.t(this, "total_users").replace("%s", allUsers.size.toString())
                }
            } catch (e: Exception) {
                runOnUiThread {
                    tvStatus.text = "Error: ${e.message}"
                    Toast.makeText(this, e.message, Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun renderFiltered() {
        val q = filterQuery.lowercase()
        val list = if (q.isBlank()) allUsers else allUsers.filter {
            it.nombre.lowercase().contains(q) || it.email.lowercase().contains(q)
        }
        render(list)
    }

    private fun showRestrictAccessMenu() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 16)
        }
        val title = TextView(this).apply {
            text = LocaleHelper.t(this@AdminActivity, "restrict_access")
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 16f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 0, 0, 16)
        }
        box.addView(title)
        val dlg = AlertDialog.Builder(this).setView(box).create()
        fun addOpt(labelKey: String, color: String, mode: String) {
            val tv = TextView(this).apply {
                text = LocaleHelper.t(this@AdminActivity, labelKey)
                setTextColor(Color.parseColor(color))
                textSize = 16f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setPadding(8, 18, 8, 18)
                setOnClickListener {
                    dlg.dismiss()
                    Thread {
                        try {
                            SupabaseBanClient.setAccessMode(prefs.getUserUid(), mode)
                            runOnUiThread {
                                Toast.makeText(this@AdminActivity, mode, Toast.LENGTH_SHORT).show()
                            }
                        } catch (e: Exception) {
                            runOnUiThread {
                                Toast.makeText(this@AdminActivity, e.message, Toast.LENGTH_LONG).show()
                            }
                        }
                    }.start()
                }
            }
            box.addView(tv)
        }
        addOpt("access_all", "#69F0AE", "ALL")
        addOpt("access_admin_only", "#FF1744", "ADMIN")
        addOpt("access_tester", "#FFC107", "TESTER")
        dlg.show()
    }

    private fun render(users: List<SupabaseBanClient.UserRow>) {
        userList.removeAllViews()
        val adminId = prefs.getUserUid()
        for (u in users) {
            val banned = bannedUsers.contains(u.userId) ||
                    (u.deviceId.isNotBlank() && bannedUsers.contains(u.deviceId))
            val online = u.isOnline()

            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(14)
                setBackgroundColor(Color.parseColor(if (banned) "#3A1520" else "#1A1A28"))
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.bottomMargin = 8
                layoutParams = lp
                gravity = Gravity.CENTER_VERTICAL
                isClickable = true
                isFocusable = true
                setOnClickListener { showUserDetail(u, banned) }
            }

            val name = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                text = u.nombre.ifBlank { u.email.ifBlank { "—" } }
                setTextColor(Color.parseColor("#F5F5F7"))
                textSize = 14f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                maxLines = 1
            }
            val roleStr = u.role.ifBlank { "USER" }.uppercase()
            val role = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                text = roleStr
                setTextColor(Color.parseColor(when (roleStr) {
                    "ADMIN" -> "#E040FB"
                    "TESTER" -> "#FFC107"
                    else -> "#FFFFFF"
                }))
                textSize = 13f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                gravity = Gravity.CENTER
            }
            val status = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                text = if (online) "ONLINE" else "OFFLINE"
                setTextColor(Color.parseColor(if (online) "#69F0AE" else "#FF1744"))
                textSize = 12f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                gravity = Gravity.END
            }
            card.addView(name)
            card.addView(role)
            card.addView(status)
            userList.addView(card)
        }
    }

    private fun showUserDetail(u: SupabaseBanClient.UserRow, banned: Boolean) {
        val adminId = prefs.getUserUid()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28)
        }
        val meta = TextView(this).apply {
            text = "id: ${u.userId}\ndevice: ${u.deviceId.ifBlank { "—" }}\n${u.email}\nrole: ${u.role}\n" +
                    if (u.isOnline()) "ONLINE" else "OFFLINE"
            setTextColor(Color.parseColor("#F5F5F7"))
            textSize = 13f
            setPadding(0, 0, 0, 16)
        }
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
        }

        val manage = canManageTarget(u)

        val btnBan = Button(this).apply {
            text = if (banned) "Unban" else "Ban"
            setTextColor(Color.BLACK)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setBackgroundResource(R.drawable.bg_ban_btn)
            isEnabled = manage
            alpha = if (manage) 1f else 0.4f
            setOnClickListener {
                if (!manage) return@setOnClickListener
                if (banned) {
                    // Unban without extra confirm (user only asked confirm for ban)
                    isEnabled = false
                    Thread {
                        try {
                            SupabaseBanClient.adminUnban(adminId, u.userId, u.deviceId)
                            runOnUiThread { load() }
                        } catch (e: Exception) {
                            runOnUiThread {
                                isEnabled = true
                                Toast.makeText(this@AdminActivity, e.message, Toast.LENGTH_LONG).show()
                            }
                        }
                    }.start()
                } else {
                    confirmBan(u)
                }
            }
        }

        val btnRole = Button(this).apply {
            text = "ROL"
            setTextColor(Color.parseColor("#E040FB"))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setBackgroundResource(R.drawable.bg_admin_btn)
            isEnabled = manage
            alpha = if (manage) 1f else 0.4f
            setOnClickListener {
                if (!manage) return@setOnClickListener
                showRolePicker(u)
            }
        }

        // Header with X close
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val headerTitle = TextView(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            text = u.nombre.ifBlank { "Usuario" }
            setTextColor(Color.parseColor("#E040FB"))
            textSize = 18f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val btnX = TextView(this).apply {
            text = "✕"
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 20f
            setPadding(16, 8, 8, 8)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        header.addView(headerTitle)
        header.addView(btnX)

        actions.addView(btnBan)
        actions.addView(btnRole)

        // Layout: header, meta, spacer-ish, actions at bottom with space between
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 20, 24, 16)
            setBackgroundResource(R.drawable.bg_card)
        }
        root.addView(header)
        root.addView(meta)
        if (!prefs.isTester()) {
            val spacer = android.widget.Space(this).apply {
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 12)
            }
            root.addView(spacer)
            actions.gravity = Gravity.BOTTOM
            // BAN left, ROL right
            actions.gravity = Gravity.CENTER_VERTICAL
            val banLp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            banLp.marginEnd = 8
            btnBan.layoutParams = banLp
            val rolLp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            rolLp.marginStart = 8
            btnRole.layoutParams = rolLp
            root.addView(actions)
        }

        val dialog = AlertDialog.Builder(this)
            .setView(root)
            .create()
        btnX.setOnClickListener { dialog.dismiss() }
        dialog.show()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        // compact width
        val w = (resources.displayMetrics.widthPixels * 0.88f).toInt()
        dialog.window?.setLayout(w, LinearLayout.LayoutParams.WRAP_CONTENT)
    }

    private fun confirmBan(u: SupabaseBanClient.UserRow) {
        val adminId = prefs.getUserUid()
        // Negative = izquierda (Confirmar), Positive = derecha (Cancelar)
        val dlg = AlertDialog.Builder(this)
            .setMessage(LocaleHelper.t(this, "confirm_ban"))
            .setNegativeButton(LocaleHelper.t(this, "confirm")) { _, _ ->
                Thread {
                    try {
                        SupabaseBanClient.adminBan(adminId, u.userId, u.deviceId, "banned from app")
                        runOnUiThread { load() }
                    } catch (e: Exception) {
                        runOnUiThread {
                            Toast.makeText(this, e.message, Toast.LENGTH_LONG).show()
                        }
                    }
                }.start()
            }
            .setPositiveButton(LocaleHelper.t(this, "cancel"), null)
            .show()
        dlg.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(Color.parseColor("#69F0AE"))
        dlg.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(Color.parseColor("#FF1744"))
    }

    private fun showRolePicker(u: SupabaseBanClient.UserRow) {
        val current = u.role.ifBlank { "USER" }.uppercase()
        // Current role first, then the others
        val others = listOf("ADMIN", "TESTER", "USER").filter { !it.equals(current, true) }
        val roles = listOf(current) + others

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 20, 20, 16)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, 12)
        }
        val title = TextView(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            text = "ROL"
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 18f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val btnCloseRole = TextView(this).apply {
            text = "✕"
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 20f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(16, 4, 8, 4)
        }
        header.addView(title)
        header.addView(btnCloseRole)
        box.addView(header)

        val dlg = AlertDialog.Builder(this).setView(box).create()
        btnCloseRole.setOnClickListener { dlg.dismiss() }

        for (r in roles) {
            val tv = TextView(this).apply {
                text = r
                textSize = 16f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setPadding(8, 18, 8, 18)
                setTextColor(
                    Color.parseColor(
                        when (r) {
                            "ADMIN" -> "#FF1744"
                            "TESTER" -> "#FFC107"
                            else -> "#FFFFFF"
                        }
                    )
                )
                setOnClickListener {
                    dlg.dismiss()
                    if (!r.equals(current, true)) confirmRoleChange(u, r)
                }
            }
            box.addView(tv)
        }
        dlg.show()
    }

    private fun confirmRoleChange(u: SupabaseBanClient.UserRow, next: String) {
        val adminId = prefs.getUserUid()
        val msg = LocaleHelper.t(this, "confirm_role").replace("%s", next)
        // Negative = izquierda (Confirmar), Positive = derecha (Cancelar)
        val dlg = AlertDialog.Builder(this)
            .setMessage(msg)
            .setNegativeButton(LocaleHelper.t(this, "confirm")) { _, _ ->
                Thread {
                    try {
                        SupabaseBanClient.adminSetRole(adminId, u.userId, next)
                        runOnUiThread { load() }
                    } catch (e: Exception) {
                        runOnUiThread {
                            Toast.makeText(this, e.message, Toast.LENGTH_LONG).show()
                        }
                    }
                }.start()
            }
            .setPositiveButton(LocaleHelper.t(this, "cancel"), null)
            .show()
        dlg.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(Color.parseColor("#69F0AE"))
        dlg.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(Color.parseColor("#FF1744"))
    }
}
