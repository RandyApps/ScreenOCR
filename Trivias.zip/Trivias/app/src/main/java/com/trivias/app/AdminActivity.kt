package com.trivias.app

import android.graphics.Color
import android.view.View
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding

class AdminActivity : AppCompatActivity() {

    private lateinit var prefs: PrefsHelper
    private lateinit var userList: LinearLayout
    private lateinit var tvStatus: TextView
    private lateinit var tvOnlineCount: TextView
    private var bannedUsers = emptySet<String>()
    private var floatHintToast: Toast? = null

    private val SUPER_ADMIN_EMAIL = "randy.vargas51@gmail.com"

    private var edgeStartX = 0f
    private var edgeStartY = 0f
    private var edgeTracking = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = PrefsHelper(this)
        if (!prefs.canAccessAdminPanel()) {
            Toast.makeText(this, "Solo ADMIN / TESTER", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        setContentView(R.layout.activity_admin)
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)

        userList = findViewById(R.id.userList)
        tvStatus = findViewById(R.id.tvStatus)
        tvOnlineCount = findViewById(R.id.tvOnlineCount)
        findViewById<TextView>(R.id.tvComingSoon).text = LocaleHelper.t(this, "coming_soon")
        startComingSoonBlink()

        findViewById<Button>(R.id.btnClose).setOnClickListener { finish() }
        findViewById<Button>(R.id.btnRefresh).setOnClickListener { load() }

        val btnAuto = findViewById<Button>(R.id.btnAutoManual)
        val btnShowHide = findViewById<Button>(R.id.btnShowHideTest)
        fun refreshAdminButtons() {
            btnAuto.text = if (prefs.isAutoClickEnabled()) {
                LocaleHelper.t(this, "mode_automatic")
            } else {
                LocaleHelper.t(this, "mode_manual")
            }
            btnShowHide.text = if (prefs.isTestChatPanelVisible()) {
                LocaleHelper.t(this, "hide")
            } else {
                LocaleHelper.t(this, "show")
            }
        }
        refreshAdminButtons()
        btnAuto.setOnClickListener {
            prefs.setAutoClickEnabled(!prefs.isAutoClickEnabled())
            refreshAdminButtons()
            val msg = if (prefs.isAutoClickEnabled()) LocaleHelper.t(this, "auto_click_on")
            else LocaleHelper.t(this, "auto_click_off")
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        }
        btnShowHide.setOnClickListener {
            val willShow = !prefs.isTestChatPanelVisible()
            prefs.setTestChatPanelVisible(willShow)
            refreshAdminButtons()
            if (willShow) {
                showFloatOpenedHint()
            }
        }

        SessionRealtimeWatcher.attach(this)
        load()
    }

    override fun finish() {
        floatHintToast?.cancel()
        floatHintToast = null
        super.finish()
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
    }

    override fun onResume() {
        super.onResume()
        if (!prefs.canAccessAdminPanel()) {
            finish()
            return
        }
        SessionRealtimeWatcher.attach(this)
        load()
    }

    /** Deslizar de izquierda a derecha para volver */
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        val w = resources.displayMetrics.widthPixels.coerceAtLeast(1)
        val edge = w * 0.18f
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                edgeTracking = ev.x <= edge
                edgeStartX = ev.x
                edgeStartY = ev.y
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (edgeTracking) {
                    val dx = ev.x - edgeStartX
                    val dy = ev.y - edgeStartY
                    if (dx > 80 && kotlin.math.abs(dx) > kotlin.math.abs(dy) * 1.1f) {
                        finish()
                        return true
                    }
                }
                edgeTracking = false
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun isSuperAdmin(): Boolean =
        prefs.getUserEmail().trim().equals(SUPER_ADMIN_EMAIL, ignoreCase = true)

    private fun canManageTarget(target: SupabaseBanClient.UserRow): Boolean {
        if (prefs.isTester()) return false
        val myUid = prefs.getUserUid()
        if (target.userId == myUid) return false
        if (prefs.getUserEmail().trim().equals(target.email.trim(), ignoreCase = true) &&
            target.email.isNotBlank()
        ) return false
        if (target.email.trim().equals(SUPER_ADMIN_EMAIL, ignoreCase = true)) return false
        val targetIsAdmin = target.role.equals("ADMIN", true)
        if (targetIsAdmin && !isSuperAdmin()) return false
        return true
    }


    private var comingSoonBlink: Animation? = null
    private var onlineDotBlink: Animation? = null

    private fun startComingSoonBlink() {
        val tv = findViewById<TextView>(R.id.tvComingSoon)
        comingSoonBlink = AlphaAnimation(1f, 0.25f).apply {
            duration = 800
            repeatMode = Animation.REVERSE
            repeatCount = Animation.INFINITE
        }
        tv.startAnimation(comingSoonBlink)
    }

    private fun updateOnlineIndicator(online: Int) {
        val dot = findViewById<View>(R.id.onlineDot)
        val count = findViewById<TextView>(R.id.tvOnlineCount)
        count.text = online.toString()
        dot.clearAnimation()
        if (online > 0) {
            dot.setBackgroundResource(R.drawable.bg_online_dot)
            onlineDotBlink = AlphaAnimation(1f, 0.2f).apply {
                duration = 700
                repeatMode = Animation.REVERSE
                repeatCount = Animation.INFINITE
            }
            dot.startAnimation(onlineDotBlink)
        } else {
            dot.setBackgroundResource(R.drawable.bg_offline_dot)
        }
    }

    private fun showFloatOpenedHint() {
        floatHintToast?.cancel()
        floatHintToast = Toast.makeText(this, LocaleHelper.t(this, "float_opened_hint"), Toast.LENGTH_LONG)
        floatHintToast?.show()
        // LENGTH_LONG ~3.5s; schedule a second show stretch to ~5s feel via Handler
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            if (!isFinishing) {
                floatHintToast?.cancel()
                floatHintToast = Toast.makeText(this, LocaleHelper.t(this, "float_opened_hint"), Toast.LENGTH_SHORT)
                floatHintToast?.show()
            }
        }, 3500)
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            floatHintToast?.cancel()
        }, 5500)
    }

    private fun load() {
        tvStatus.text = "…"
        val adminId = prefs.getUserUid()
        Thread {
            try {
                val users = SupabaseBanClient.adminListUsers(adminId)
                val bans = SupabaseBanClient.adminListBans(adminId)
                bannedUsers = bans.first
                val online = users.count { it.isOnline() }
                runOnUiThread {
                    val visible = if (prefs.isTester()) {
                        users.filter { it.userId == prefs.getUserUid() }
                    } else {
                        users
                    }
                    val onlineVisible = visible.count { it.isOnline() }
                    updateOnlineIndicator(if (prefs.isTester()) onlineVisible else online)
                    render(visible)
                    tvStatus.text = LocaleHelper.t(this, "total_users").replace("%s", visible.size.toString())
                }
            } catch (e: Exception) {
                runOnUiThread {
                    tvStatus.text = "Error: ${e.message}"
                    Toast.makeText(this, e.message, Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun render(users: List<SupabaseBanClient.UserRow>) {
        userList.removeAllViews()
        val adminId = prefs.getUserUid()
        for (u in users) {
            val banned = bannedUsers.contains(u.userId) ||
                    (u.deviceId.isNotBlank() && bannedUsers.contains(u.deviceId))
            val online = u.isOnline()

            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(14)
                setBackgroundColor(Color.parseColor(if (banned) "#3A1520" else "#1A1A28"))
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.bottomMargin = 8
                layoutParams = lp
                gravity = Gravity.CENTER_VERTICAL
                isClickable = true
                isFocusable = true
                setOnClickListener { showUserDetail(u, banned) }
            }

            val name = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                text = u.nombre.ifBlank { u.email.ifBlank { "—" } }
                setTextColor(Color.parseColor("#F5F5F7"))
                textSize = 14f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                maxLines = 1
            }
            val roleStr = u.role.ifBlank { "USER" }.uppercase()
            val role = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                text = roleStr
                setTextColor(Color.parseColor(when (roleStr) {
                    "ADMIN" -> "#E040FB"
                    "TESTER" -> "#FFC107"
                    else -> "#FFFFFF"
                }))
                textSize = 13f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                gravity = Gravity.CENTER
            }
            val status = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                text = if (online) "ONLINE" else "OFFLINE"
                setTextColor(Color.parseColor(if (online) "#69F0AE" else "#FF1744"))
                textSize = 12f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                gravity = Gravity.END
            }
            card.addView(name)
            card.addView(role)
            card.addView(status)
            userList.addView(card)
        }
    }

    private fun showUserDetail(u: SupabaseBanClient.UserRow, banned: Boolean) {
        val adminId = prefs.getUserUid()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28)
        }
        val title = TextView(this).apply {
            text = u.nombre.ifBlank { "Usuario" }
            setTextColor(Color.parseColor("#E040FB"))
            textSize = 18f
            setPadding(0, 0, 0, 12)
        }
        val meta = TextView(this).apply {
            text = "id: ${u.userId}\ndevice: ${u.deviceId.ifBlank { "—" }}\n${u.email}\nrole: ${u.role}\n" +
                    if (u.isOnline()) "ONLINE" else "OFFLINE"
            setTextColor(Color.parseColor("#F5F5F7"))
            textSize = 13f
            setPadding(0, 0, 0, 16)
        }
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
        }

        val manage = canManageTarget(u)

        val btnBan = Button(this).apply {
            text = if (banned) "Unban" else "Ban"
            setTextColor(Color.BLACK)
            setBackgroundResource(R.drawable.bg_ban_btn)
            isEnabled = manage
            alpha = if (manage) 1f else 0.4f
            setOnClickListener {
                if (!manage) return@setOnClickListener
                if (banned) {
                    // Unban without extra confirm (user only asked confirm for ban)
                    isEnabled = false
                    Thread {
                        try {
                            SupabaseBanClient.adminUnban(adminId, u.userId, u.deviceId)
                            runOnUiThread { load() }
                        } catch (e: Exception) {
                            runOnUiThread {
                                isEnabled = true
                                Toast.makeText(this@AdminActivity, e.message, Toast.LENGTH_LONG).show()
                            }
                        }
                    }.start()
                } else {
                    confirmBan(u)
                }
            }
        }

        val btnRole = Button(this).apply {
            text = "ROL"
            setTextColor(Color.parseColor("#E040FB"))
            setBackgroundResource(R.drawable.bg_admin_btn)
            isEnabled = manage
            alpha = if (manage) 1f else 0.4f
            setOnClickListener {
                if (!manage) return@setOnClickListener
                showRolePicker(u)
            }
        }

        actions.addView(btnBan)
        actions.addView(btnRole)
        box.addView(title)
        box.addView(meta)
        if (!prefs.isTester()) {
            box.addView(actions)
        }

        AlertDialog.Builder(this)
            .setView(box)
            .setNegativeButton(LocaleHelper.t(this, "cancel"), null)
            .show()
    }

    private fun confirmBan(u: SupabaseBanClient.UserRow) {
        val adminId = prefs.getUserUid()
        val dlg = AlertDialog.Builder(this)
            .setMessage(LocaleHelper.t(this, "confirm_ban"))
            .setPositiveButton(LocaleHelper.t(this, "confirm")) { _, _ ->
                Thread {
                    try {
                        SupabaseBanClient.adminBan(adminId, u.userId, u.deviceId, "banned from app")
                        runOnUiThread { load() }
                    } catch (e: Exception) {
                        runOnUiThread {
                            Toast.makeText(this, e.message, Toast.LENGTH_LONG).show()
                        }
                    }
                }.start()
            }
            .setNegativeButton(LocaleHelper.t(this, "cancel"), null)
            .show()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(Color.parseColor("#69F0AE"))
        dlg.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(Color.parseColor("#FF1744"))
    }

    private fun showRolePicker(u: SupabaseBanClient.UserRow) {
        val current = u.role.ifBlank { "USER" }.uppercase()
        val roles = arrayOf("ADMIN", "TESTER", "USER")
        val dlg = AlertDialog.Builder(this)
            .setTitle("ROL")
            .setItems(roles) { _, which ->
                val next = roles[which]
                if (next.equals(current, true)) return@setItems
                confirmRoleChange(u, next)
            }
            .show()
        // Color items: can't easily color list items post-show without custom adapter;
        // use a simple custom approach
        try {
            val list = dlg.listView
            list?.post {
                for (i in 0 until (list.childCount)) {
                    val tv = list.getChildAt(i) as? TextView ?: continue
                    val isCurrent = roles[i].equals(current, true)
                    tv.setTextColor(Color.parseColor(if (isCurrent) "#69F0AE" else "#FF1744"))
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun confirmRoleChange(u: SupabaseBanClient.UserRow, next: String) {
        val adminId = prefs.getUserUid()
        val msg = LocaleHelper.t(this, "confirm_role").replace("%s", next)
        val dlg = AlertDialog.Builder(this)
            .setMessage(msg)
            .setPositiveButton(LocaleHelper.t(this, "confirm")) { _, _ ->
                Thread {
                    try {
                        SupabaseBanClient.adminSetRole(adminId, u.userId, next)
                        runOnUiThread { load() }
                    } catch (e: Exception) {
                        runOnUiThread {
                            Toast.makeText(this, e.message, Toast.LENGTH_LONG).show()
                        }
                    }
                }.start()
            }
            .setNegativeButton(LocaleHelper.t(this, "cancel"), null)
            .show()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(Color.parseColor("#69F0AE"))
        dlg.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(Color.parseColor("#FF1744"))
    }
}
