package com.trivias.app

import android.graphics.Color
import android.graphics.Typeface
import android.view.View
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding
import androidx.core.content.ContextCompat

class AdminController(
    private val host: AppCompatActivity,
    private val root: View
) {
    private fun <T : View> fid(id: Int): T = root.findViewById(id)


    private lateinit var prefs: PrefsHelper
    private lateinit var userList: LinearLayout
    private lateinit var tvStatus: TextView
    private lateinit var tvOnlineCount: TextView
    private var bannedUsers = emptySet<String>()
    private var floatHintToast: Toast? = null
    private var allUsers: List<SupabaseBanClient.UserRow> = emptyList()
    private var filterQuery: String = ""
    private var openUserDetailDialog: AlertDialog? = null
    private var openChildDialog: AlertDialog? = null
    /** false = filas grises / ocultas al entrar al panel */
    private var usersListVisible: Boolean = false
    /** home | users | database | logs | activity */
    private var contentMode: String = "home"
    private var listCacheTrivia: List<SupabaseBanClient.TriviaItem> = emptyList()
    private var listCacheErrors: List<SupabaseBanClient.ErrorItem> = emptyList()
    private var listCacheAudit: List<SupabaseBanClient.AuditItem> = emptyList()
    private var dbEditArmed: Boolean = false
    private var filterBarOpen: Boolean = false
    /** null | ban | role | delete */
    private var selectMode: String? = null
    private var currentAccessMode: String = "ALL"
    private val usersRefreshHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val usersRefreshIntervalMs = 20_000L
    private val usersRefreshRunnable = object : Runnable {
        override fun run() {
            try {
                if (contentMode == "users") load()
            } catch (_: Exception) {}
            if (contentMode == "users") {
                usersRefreshHandler.postDelayed(this, usersRefreshIntervalMs)
            }
        }
    }



    private var edgeStartX = 0f
    private var edgeStartY = 0f
    private var edgeTracking = false
    private var closingAdmin = false
    var onClose: (() -> Unit)? = null
    var onShowHideChanged: (() -> Unit)? = null
    var onPlayAgainChanged: (() -> Unit)? = null

    fun bind() {
        prefs = PrefsHelper(host)
        val role = prefs.getUserRole()
        if (!role.equals("ADMIN", ignoreCase = true)) {
            Toast.makeText(host, "Solo ADMIN", Toast.LENGTH_SHORT).show()
            return
        }
        usersListVisible = false
        filterBarOpen = false
        selectMode = null
        currentAccessMode = try { prefs.getLastAccessMode() } catch (_: Exception) { "ALL" }
        try { refreshRestrictButtonColor() } catch (_: Exception) {}

        fid<TextView>(R.id.tvAdminTitle).let { t ->
            t.text = LocaleHelper.t(host, "admin_panel_title")
            t.setTypeface(t.typeface, android.graphics.Typeface.BOLD)
            t.gravity = Gravity.CENTER
        }
        try {
            val ver = try {
                val pi = host.packageManager.getPackageInfo(host.packageName, 0)
                pi.versionName ?: "1.0.96"
            } catch (_: Exception) { "1.0.96" }
            val tvVer = fid<TextView>(R.id.tvAdminVersion)
            tvVer.text = if (ver.startsWith("v")) ver else "v$ver"
            tvVer.setTypeface(tvVer.typeface, android.graphics.Typeface.BOLD)
            tvVer.setTextColor(Color.WHITE)
        } catch (_: Exception) {}
        run {
            val em = try {
                val p = prefs.getUserEmail().trim()
                if (p.isNotEmpty()) p
                else com.google.android.gms.auth.api.signin.GoogleSignIn
                    .getLastSignedInAccount(host)?.email?.trim().orEmpty()
            } catch (_: Exception) { prefs.getUserEmail().trim() }
            if (em.isNotEmpty() && prefs.getUserEmail().trim().isEmpty()) {
                try { prefs.setUserEmail(em) } catch (_: Exception) {}
            }
            val allowCapture = prefs.isSuperAdmin()
            if (allowCapture) {
                host.window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
            } else {
                host.window.setFlags(
                    android.view.WindowManager.LayoutParams.FLAG_SECURE,
                    android.view.WindowManager.LayoutParams.FLAG_SECURE
                )
            }
        }

        userList = fid(R.id.userList)
        tvStatus = fid(R.id.tvStatus)
        tvOnlineCount = fid(R.id.tvOnlineCount)

        fid<TextView>(R.id.btnClose).let { closeBtn ->
            closeBtn.background = ContextCompat.getDrawable(host, R.drawable.bg_admin_close)
            closeBtn.backgroundTintList = null
            closeBtn.setTextColor(Color.WHITE)
            closeBtn.setOnClickListener {
                haptic()
                requestClose()
            }
        }

        // MONITOR — solo super admin (servidor también valida)
        fid<View>(R.id.btnMonitor).setOnClickListener {
            haptic()
            if (!isSuperAdmin()) {
                Toast.makeText(host, LocaleHelper.t(host, "not_authorized"), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            openMonitorPanel()
        }
        try {
            fid<TextView>(R.id.tvMonitorLabel)?.text = LocaleHelper.t(host, "monitor")
        } catch (_: Exception) {}

        // FORCE UPDATE
        fid<View>(R.id.btnForceUpdate).alpha = 1f
        fid<View>(R.id.btnForceUpdate).setOnClickListener {
            haptic()
            if (!isSuperAdmin()) {
                Toast.makeText(host, LocaleHelper.t(host, "not_authorized_function"), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            showForceUpdateConfig()
        }
        fid<TextView>(R.id.tvForceUpdateLabel)?.text = "FORCE UPDATE"

        // PLAY AGAIN: solo ADMIN puede activarlo; default OFF
        if (!prefs.isAdmin() && prefs.isPlayAgainEnabled()) {
            prefs.setPlayAgainEnabled(false)
        }
        updatePlayAgainButton()
        fid<View>(R.id.btnPlayAgain).setOnClickListener {
            haptic()
            if (!prefs.isAdmin()) {
                prefs.setPlayAgainEnabled(false)
                updatePlayAgainButton()
                Toast.makeText(host, LocaleHelper.t(host, "not_authorized_function"), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            prefs.setPlayAgainEnabled(!prefs.isPlayAgainEnabled())
            updatePlayAgainButton()
            try { onPlayAgainChanged?.invoke() } catch (_: Exception) {}
        }

        // MOSTRAR float panel
        refreshShowHideButton()
        fid<View>(R.id.btnShowHideTest).setOnClickListener {
            haptic()
            if (!prefs.isAdmin()) return@setOnClickListener
            val willShow = !prefs.isTestChatPanelVisible()
            prefs.setTestChatPanelVisible(willShow)
            refreshShowHideButton()
            onShowHideChanged?.invoke()
            if (willShow) showFloatOpenedHint()
        }

        // Restrict access
        val btnRestrict = fid<View>(R.id.btnRestrictAccess)
        try {
            fid<TextView>(R.id.tvRestrictLabel).text = LocaleHelper.t(host, "restrict_access")
            fid<TextView>(R.id.tvRestrictLabel).setTypeface(
                fid<TextView>(R.id.tvRestrictLabel).typeface, Typeface.BOLD
            )
            fid<TextView>(R.id.tvRestrictLabel).setTextColor(Color.WHITE)
        } catch (_: Exception) {}
        btnRestrict.backgroundTintList = null
        btnRestrict.alpha = 1f
        btnRestrict.isEnabled = true
        btnRestrict.setOnClickListener {
            haptic()
            if (!isSuperAdmin()) {
                Toast.makeText(host, LocaleHelper.t(host, "not_authorized_function"), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            showRestrictAccessMenu()
        }
        refreshRestrictButtonColor()

        // Toolbar inside list — modes USERS/DATABASE/LOGS/ACTIVITY (super-admin)
        fid<android.widget.ImageButton>(R.id.btnToggleUsersVisible).setOnClickListener {
            haptic()
            if (!isSuperAdmin()) {
                Toast.makeText(host, LocaleHelper.t(host, "not_authorized_function"), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            // undo-2: volver al home de la barrita
            showHomeMode()
        }
        fid<android.widget.ImageButton>(R.id.btnToolbarSearch).setOnClickListener {
            haptic()
            if (!isSuperAdmin()) {
                Toast.makeText(host, LocaleHelper.t(host, "not_authorized_function"), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (contentMode == "users" || contentMode == "database") {
                enterFilterBar()
            }
        }
        fid<View>(R.id.btnToolbarBan).setOnClickListener {
            haptic()
            if (!isSuperAdmin()) {
                Toast.makeText(host, LocaleHelper.t(host, "not_authorized_function"), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (contentMode == "users") openUserPicker("ban")
        }
        fid<View>(R.id.btnToolbarRole).setOnClickListener {
            haptic()
            if (!isSuperAdmin()) {
                Toast.makeText(host, LocaleHelper.t(host, "not_authorized_function"), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (contentMode == "users") openUserPicker("role")
        }
        fid<android.widget.ImageButton>(R.id.btnToolbarDelete).setOnClickListener {
            haptic()
            if (!isSuperAdmin()) {
                Toast.makeText(host, LocaleHelper.t(host, "not_authorized_function"), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            when (contentMode) {
                "users" -> openUserPicker("delete")
                "logs" -> confirmClearLogs("errors")
                "activity" -> confirmClearLogs("audit")
                "database" -> {
                    dbEditArmed = true
                    Toast.makeText(host, LocaleHelper.t(host, "mon_edit_pick"), Toast.LENGTH_SHORT).show()
                }
            }
        }
        fid<android.widget.ImageButton>(R.id.btnFilterClose).setOnClickListener {
            haptic()
            exitFilterBar()
        }
        try {
            fid<View>(R.id.userListScroll).setOnTouchListener { _, ev ->
                if (filterBarOpen && ev.action == android.view.MotionEvent.ACTION_DOWN) {
                    exitFilterBar()
                    true
                } else false
            }
        } catch (_: Exception) {}
        try {
            fid<View>(R.id.userList).setOnClickListener {
                if (filterBarOpen) exitFilterBar()
            }
        } catch (_: Exception) {}
        try {
            fid<TextView>(R.id.btnPickerClose).let { b ->
                b.background = ContextCompat.getDrawable(host, R.drawable.bg_admin_close)
                b.backgroundTintList = null
                b.setOnClickListener {
                    haptic()
                    closeUserPicker()
                }
            }
        } catch (_: Exception) {}

        val etFilter = fid<android.widget.EditText>(R.id.etUserFilter)
        etFilter.hint = LocaleHelper.t(host, "filter_users")
        etFilter.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                filterQuery = s?.toString()?.trim().orEmpty()
                renderFiltered()
            }
        })

        updateToolbarState()
        startAdminBorderAnimations()
        SessionRealtimeWatcher.attach(host)
        // No auto-refresh until USERS mode is open
        try { usersRefreshHandler.removeCallbacks(usersRefreshRunnable) } catch (_: Exception) {}
        showHomeMode()
    }

    fun stopUsersRefresh() {
        try { usersRefreshHandler.removeCallbacks(usersRefreshRunnable) } catch (_: Exception) {}
    }

    fun dismissAllDialogs() {
        try { openUserDetailDialog?.dismiss() } catch (_: Exception) {}
        openUserDetailDialog = null
        try { openChildDialog?.dismiss() } catch (_: Exception) {}
        openChildDialog = null
        try { closeUserPicker() } catch (_: Exception) {}
    }

    fun refreshShowHideButton() {
        try {
            val visible = prefs.isTestChatPanelVisible()
            val label = fid<TextView>(R.id.tvShowHideLabel)
            // Visible => botón dice OCULTAR + ojo tachado; oculto => MOSTRAR + ojo abierto
            label.text = (if (visible) {
                LocaleHelper.t(host, "hide")
            } else {
                LocaleHelper.t(host, "show")
            }).uppercase(java.util.Locale.getDefault())
            label.setTypeface(label.typeface, Typeface.BOLD)
            try {
                fid<android.widget.ImageView>(R.id.imgShowHideIcon).setImageResource(
                    if (visible) R.drawable.ic_lucide_eye_off else R.drawable.ic_lucide_eye
                )
            } catch (_: Exception) {}
        } catch (_: Exception) {}
    }

    private fun updatePlayAgainButton() {
        try {
            if (!prefs.isAdmin() && prefs.isPlayAgainEnabled()) {
                prefs.setPlayAgainEnabled(false)
            }
            val on = prefs.isPlayAgainEnabled() && prefs.isAdmin()
            val btn = fid<View>(R.id.btnPlayAgain)
            btn.setBackgroundResource(if (on) R.drawable.bg_admin_btn_green else R.drawable.bg_admin_btn_red)
            fid<TextView>(R.id.tvPlayAgainOnOff).let { tv ->
                tv.text = if (on) "ON" else "OFF"
                tv.setTypeface(tv.typeface, Typeface.BOLD)
            }
            fid<TextView>(R.id.tvPlayAgainLabel).let { tv ->
                tv.text = "PLAY AGAIN"
                tv.setTypeface(tv.typeface, Typeface.BOLD)
            }
            // OFF/red button -> green play icon; ON/green button -> red play icon
            try {
                fid<android.widget.ImageView>(R.id.imgPlayAgainIcon).setImageResource(
                    if (on) R.drawable.ic_play_again_on else R.drawable.ic_play_again_off
                )
            } catch (_: Exception) {}
        } catch (_: Exception) {}
    }

    /** Refresco público (p. ej. al reabrir panel o al perder rol). */
    fun refreshPlayAgainButton() {
        updatePlayAgainButton()
    }

    private fun refreshRestrictButtonColor() {
        try {
            val btn = fid<View>(R.id.btnRestrictAccess)
            btn.backgroundTintList = null
            val bg = when (currentAccessMode.uppercase()) {
                "ADMIN" -> R.drawable.bg_restrict_admin
                "TESTER" -> R.drawable.bg_restrict_tester
                else -> R.drawable.bg_restrict_all
            }
            btn.setBackgroundResource(bg)
            try {
                val tv = fid<TextView>(R.id.tvRestrictLabel)
                tv.setTextColor(Color.WHITE)
                tv.setTypeface(tv.typeface, Typeface.BOLD)
                tv.setTextColor(0xFFFFFFFF.toInt())
            } catch (_: Exception) {}
        } catch (_: Exception) {}
    }

    private fun updateToolbarState() {
        try {
            val eye = fid<android.widget.ImageButton>(R.id.btnToggleUsersVisible)
            val search = fid<android.widget.ImageButton>(R.id.btnToolbarSearch)
            val role = fid<View>(R.id.btnToolbarRole)
            val ban = fid<View>(R.id.btnToolbarBan)
            val del = fid<android.widget.ImageButton>(R.id.btnToolbarDelete)
            val homeBar = try { fid<LinearLayout>(R.id.userModeHomeBar) } catch (_: Exception) { null }

            if (contentMode == "home") {
                homeBar?.visibility = View.VISIBLE
                eye.visibility = View.GONE
                search.visibility = View.GONE
                role.visibility = View.GONE
                ban.visibility = View.GONE
                del.visibility = View.GONE
            } else {
                homeBar?.visibility = View.GONE
                eye.visibility = View.VISIBLE
                eye.setImageResource(R.drawable.ic_lucide_undo_2)
                eye.alpha = 1f
                eye.isEnabled = true
                when (contentMode) {
                    "users" -> {
                        search.visibility = View.VISIBLE
                        role.visibility = View.VISIBLE
                        ban.visibility = View.VISIBLE
                        del.visibility = View.VISIBLE
                        del.setImageResource(R.drawable.ic_trash)
                        search.alpha = 1f; role.alpha = 1f; ban.alpha = 1f; del.alpha = 1f
                        search.isEnabled = true; role.isEnabled = true; ban.isEnabled = true; del.isEnabled = true
                    }
                    "database" -> {
                        search.visibility = View.VISIBLE
                        role.visibility = View.GONE
                        ban.visibility = View.GONE
                        del.visibility = View.VISIBLE
                        del.setImageResource(R.drawable.ic_lucide_pencil)
                        search.alpha = 1f; del.alpha = 1f
                        search.isEnabled = true; del.isEnabled = true
                    }
                    "logs", "activity" -> {
                        search.visibility = View.GONE
                        role.visibility = View.GONE
                        ban.visibility = View.GONE
                        del.visibility = View.VISIBLE
                        del.setImageResource(R.drawable.ic_trash)
                        del.alpha = 1f
                        del.isEnabled = true
                    }
                }
            }
        } catch (_: Exception) {}
    }




    private fun enterFilterBar() {
        filterBarOpen = true
        try {
            fid<View>(R.id.userToolbar).visibility = View.GONE
            fid<View>(R.id.userFilterBar).visibility = View.VISIBLE
            fid<android.widget.EditText>(R.id.etUserFilter).requestFocus()
        } catch (_: Exception) {}
    }

    private fun exitFilterBar() {
        filterBarOpen = false
        filterQuery = ""
        try {
            fid<android.widget.EditText>(R.id.etUserFilter).setText("")
            fid<View>(R.id.userFilterBar).visibility = View.GONE
            fid<View>(R.id.userToolbar).visibility = View.VISIBLE
        } catch (_: Exception) {}
        renderFiltered()
    }

    private fun openUserPicker(mode: String) {
        selectMode = mode
        try {
            val overlay = fid<View>(R.id.userPickerOverlay)
            val list = fid<LinearLayout>(R.id.userPickerList)
            list.removeAllViews()
            val title = fid<TextView>(R.id.tvPickerTitle)
            title.text = when (mode) {
                "ban" -> LocaleHelper.t(host, "picker_ban")
                "role" -> LocaleHelper.t(host, "picker_role")
                "delete" -> LocaleHelper.t(host, "picker_delete")
                else -> LocaleHelper.t(host, "picker_ban")
            }
            title.setTypeface(title.typeface, Typeface.BOLD)
            val q = filterQuery.lowercase()
            val src = if (q.isBlank()) allUsers else allUsers.filter {
                it.nombre.lowercase().contains(q) || it.email.lowercase().contains(q)
            }
            for (u in src) {
                val banned = bannedUsers.contains(u.userId)
                val row = LinearLayout(host).apply {
                    orientation = LinearLayout.HORIZONTAL
                    setPadding(12, 14, 12, 14)
                    // Rojo de baneado solo si el listado está visible (no en modo spoiler)
                    setBackgroundColor(
                        if (usersListVisible && banned) Color.parseColor("#3A1520") else Color.TRANSPARENT
                    )
                }
                val name = TextView(host).apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.2f)
                    text = u.nombre.ifBlank { u.email.ifBlank { u.userId } }
                    setTextColor(Color.parseColor("#F5F5F7"))
                    textSize = 14f
                    setTypeface(typeface, Typeface.BOLD)
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                }
                val roleTv = TextView(host).apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.8f)
                    gravity = Gravity.CENTER
                    val r = u.role.ifBlank { "USER" }.uppercase()
                    text = r
                    textSize = 13f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(
                        when (r) {
                            "ADMIN" -> Color.parseColor("#E040FB")
                            "TESTER" -> Color.parseColor("#FFC107")
                            else -> Color.WHITE
                        }
                    )
                }
                row.addView(name)
                row.addView(roleTv)
                row.setOnClickListener {
                    haptic()
                    val m = selectMode
                    closeUserPicker()
                    when (m) {
                        "ban" -> handleBanPick(u)
                        "role" -> handleRolePick(u)
                        "delete" -> confirmDeleteUser(u)
                    }
                }
                list.addView(row)
            }
            overlay.visibility = View.VISIBLE
        } catch (_: Exception) {}
    }

    private fun closeUserPicker() {
        selectMode = null
        try {
            fid<View>(R.id.userPickerOverlay).visibility = View.GONE
            fid<LinearLayout>(R.id.userPickerList).removeAllViews()
        } catch (_: Exception) {}
        updateToolbarState()
    }

    private fun startAdminBorderAnimations() {
        try {
            val purple = Color.parseColor("#E040FB")
            val cyan = Color.parseColor("#00E5FF")
            val red = Color.parseColor("#B71C1C") // same as NOTIFICACIONES OFF
            attachRotatingBorder(fid(R.id.userListCard), purple, cyan, 4500L, cornerDp = 16f)
            attachRotatingBorder(fid(R.id.userToolbarCard), red, purple, 3500L, cornerDp = 4f)
        } catch (_: Exception) {}
    }

    private fun attachRotatingBorder(view: View, c1: Int, c2: Int, durationMs: Long, cornerDp: Float = 16f) {
        try {
            val density = host.resources.displayMetrics.density
            val stroke = (2.5f * density).toInt().coerceAtLeast(2)
            val radius = cornerDp * density
            try { (view.tag as? android.animation.ValueAnimator)?.cancel() } catch (_: Exception) {}
            // No reemplazar el fondo: solo dibujar el anillo en foreground (esquinas limpias)
            val anim = android.animation.ValueAnimator.ofFloat(0f, 360f).apply {
                duration = durationMs
                repeatCount = android.animation.ValueAnimator.INFINITE
                interpolator = android.view.animation.LinearInterpolator()
                addUpdateListener { a ->
                    val angle = a.animatedValue as Float
                    try {
                        val w = view.width
                        val h = view.height
                        if (w <= 2 || h <= 2) return@addUpdateListener
                        val bmp = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888)
                        val canvas = android.graphics.Canvas(bmp)
                        val shader = android.graphics.SweepGradient(
                            w / 2f, h / 2f,
                            intArrayOf(c1, c2, c1),
                            floatArrayOf(0f, 0.5f, 1f)
                        )
                        val mat = android.graphics.Matrix()
                        mat.postRotate(angle, w / 2f, h / 2f)
                        shader.setLocalMatrix(mat)
                        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
                        paint.shader = shader
                        paint.style = android.graphics.Paint.Style.STROKE
                        paint.strokeWidth = stroke.toFloat()
                        paint.strokeJoin = android.graphics.Paint.Join.ROUND
                        paint.strokeCap = android.graphics.Paint.Cap.ROUND
                        val inset = stroke / 2f + 0.5f
                        val rr = android.graphics.RectF(inset, inset, w - inset, h - inset)
                        val r2 = (radius - inset).coerceAtLeast(1f)
                        canvas.drawRoundRect(rr, r2, r2, paint)
                        view.foreground = android.graphics.drawable.BitmapDrawable(host.resources, bmp)
                    } catch (_: Exception) {}
                }
            }
            anim.start()
            view.tag = anim
            // Clip de contenido interno sin cortar el anillo: padding mínimo no; clip children del contenedor
            try {
                view.clipToOutline = false
            } catch (_: Exception) {}
        } catch (_: Exception) {}
    }


    fun applyLocaleToUi() {
        try {
            val title = fid<TextView>(R.id.tvAdminTitle)
            title.text = LocaleHelper.t(host, "admin_panel_title")
            title.setTypeface(title.typeface, Typeface.BOLD)
            title.gravity = Gravity.CENTER
            try {
                val ver = try {
                    val pi = host.packageManager.getPackageInfo(host.packageName, 0)
                    pi.versionName ?: "1.0.96"
                } catch (_: Exception) { "1.0.96" }
                fid<TextView>(R.id.tvAdminVersion).text = if (ver.startsWith("v")) ver else "v$ver"
            } catch (_: Exception) {}
            refreshShowHideButton()
            try { fid<TextView>(R.id.tvForceUpdateLabel).text = "FORCE UPDATE" } catch (_: Exception) {}
            try { fid<TextView>(R.id.tvMonitorLabel).text = LocaleHelper.t(host, "monitor") } catch (_: Exception) {}
            try { fid<TextView>(R.id.tvPlayAgainLabel).text = "PLAY AGAIN" } catch (_: Exception) {}
            try { updatePlayAgainButton() } catch (_: Exception) {}
            val btnRestrict = fid<View>(R.id.btnRestrictAccess)
            try { fid<TextView>(R.id.tvRestrictLabel).text = LocaleHelper.t(host, "restrict_access") } catch (_: Exception) {}
            try { fid<TextView>(R.id.tvRestrictLabel).setTypeface(fid<TextView>(R.id.tvRestrictLabel).typeface, Typeface.BOLD) } catch (_: Exception) {}
            btnRestrict.backgroundTintList = null
            refreshRestrictButtonColor()
            try {
                fid<android.widget.EditText>(R.id.etUserFilter).hint = LocaleHelper.t(host, "filter_users")
            } catch (_: Exception) {}
            try { load() } catch (_: Exception) {}
        } catch (_: Exception) {}
    }

    fun requestClose() {
        floatHintToast?.cancel()
        floatHintToast = null
        try { closeUserPicker() } catch (_: Exception) {}
        try { censorUsersListOnClose() } catch (_: Exception) {}
        onClose?.invoke()
    }

    /** Al salir del panel: dejar listado censurado para que no se vea al volver a entrar. */
    fun censorUsersListOnClose() {
        usersListVisible = false
        filterBarOpen = false
        selectMode = null
        try { closeUserPicker() } catch (_: Exception) {}
        try { exitFilterBar() } catch (_: Exception) {}
        try { updateToolbarState() } catch (_: Exception) {}
        try { renderFiltered() } catch (_: Exception) {}
    }

    fun onHostResume() {
        if (!prefs.isAdmin() || !prefs.canAccessAdminPanel()) {
            onClose?.invoke()
            return
        }
        SessionRealtimeWatcher.attach(host)
        // Cada vez que se entra al panel: listado censurado / no visible
        usersListVisible = false
        filterBarOpen = false
        selectMode = null
        try { closeUserPicker() } catch (_: Exception) {}
        try { exitFilterBar() } catch (_: Exception) {}
        try { updateToolbarState() } catch (_: Exception) {}
        applyLocaleToUi()
        try { renderFiltered() } catch (_: Exception) {}
    }

    private fun animateMainPeekTo(targetX: Float, hideAfter: Boolean, end: (() -> Unit)? = null) {
        try {
            val w = host.resources.displayMetrics.widthPixels.toFloat()
            val peek = fid<View>(R.id.mainPeek) ?: run {
                end?.invoke()
                return
            }
            peek.visibility = View.VISIBLE
            peek.animate().cancel()
            peek.animate()
                .translationX(targetX.coerceIn(-w, 0f))
                .setDuration(180)
                .withEndAction {
                    if (hideAfter) {
                        peek.translationX = -w
                        peek.visibility = View.GONE
                    }
                    end?.invoke()
                }
                .start()
        } catch (_: Exception) {
            end?.invoke()
        }
    }

    private fun resolveAccountEmail(): String {
        val fromPrefs = prefs.getUserEmail().trim()
        if (fromPrefs.isNotEmpty()) return fromPrefs
        return try {
            com.google.android.gms.auth.api.signin.GoogleSignIn
                .getLastSignedInAccount(host)?.email?.trim().orEmpty()
        } catch (_: Exception) {
            ""
        }
    }



    private var monitorOverlay: android.widget.FrameLayout? = null
    private var monitorTab = 0 // 0 actividad 1 errors 2 database

    private fun openMonitorPanel() {
        if (!isSuperAdmin()) {
            Toast.makeText(host, LocaleHelper.t(host, "not_authorized"), Toast.LENGTH_SHORT).show()
            return
        }
        closeMonitorPanel()
        val dm = host.resources.displayMetrics
        val overlay = android.widget.FrameLayout(host).apply {
            layoutParams = android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT
            )
            setBackgroundResource(R.drawable.bg_root)
            elevation = 40f
            isClickable = true
            isFocusable = true
        }
        val rootLl = LinearLayout(host).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT
            )
            setPadding(16, 28, 16, 16)
        }
        // Header
        val header = LinearLayout(host).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        val tvTitle = TextView(host).apply {
            text = LocaleHelper.t(host, "monitor")
            setTextColor(Color.parseColor("#E040FB"))
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            gravity = Gravity.CENTER
        }
        val btnClose = android.widget.ImageView(host).apply {
            setImageResource(R.drawable.ic_notif_close)
            setBackgroundResource(R.drawable.bg_admin_close)
            setPadding(18, 18, 18, 18)
            layoutParams = LinearLayout.LayoutParams(48, 48)
            setOnClickListener { haptic(); closeMonitorPanel() }
        }
        header.addView(tvTitle)
        header.addView(btnClose)

        // Tabs
        val tabs = LinearLayout(host).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                56
            ).also { it.topMargin = 14 }
        }
        val tabAct = TextView(host)
        val tabErr = TextView(host)
        val tabDb = TextView(host)
        fun styleTab(tv: TextView, label: String, bg: Int, weight: Float = 1f) {
            tv.text = label
            tv.setTextColor(Color.WHITE)
            tv.textSize = 11f
            tv.setTypeface(tv.typeface, Typeface.BOLD)
            tv.gravity = Gravity.CENTER
            tv.setBackgroundResource(bg)
            tv.setPadding(6, 12, 6, 12)
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, weight)
            lp.marginEnd = 6
            tv.layoutParams = lp
        }
        fun paintTabs() {
            styleTab(tabAct, LocaleHelper.t(host, "monitor_actividad"), R.drawable.bg_monitor_actividad)
            styleTab(tabErr, "ERROR LOGS", R.drawable.bg_admin_btn_red)
            styleTab(tabDb, "DATABASE", R.drawable.bg_btn_grid)
            (tabDb.layoutParams as LinearLayout.LayoutParams).marginEnd = 0
            tabAct.alpha = if (monitorTab == 0) 1f else 0.55f
            tabErr.alpha = if (monitorTab == 1) 1f else 0.55f
            tabDb.alpha = if (monitorTab == 2) 1f else 0.55f
        }
        paintTabs()
        tabs.addView(tabAct)
        tabs.addView(tabErr)
        tabs.addView(tabDb)

        // Action bar
        val actionBar = LinearLayout(host).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.topMargin = 10 }
        }
        val btnBorrar = TextView(host).apply {
            text = LocaleHelper.t(host, "monitor_borrar")
            setTextColor(Color.WHITE)
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            setBackgroundResource(R.drawable.bg_admin_btn_red)
            setPadding(20, 12, 20, 12)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        val btnFiltrar = TextView(host).apply {
            text = LocaleHelper.t(host, "monitor_filtrar")
            setTextColor(Color.WHITE)
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            setBackgroundResource(R.drawable.bg_admin_btn_blue)
            setPadding(20, 12, 20, 12)
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        actionBar.addView(btnBorrar)
        actionBar.addView(btnFiltrar)

        val etFilter = android.widget.EditText(host).apply {
            hint = LocaleHelper.t(host, "monitor_filter_hint")
            setHintTextColor(Color.parseColor("#888888"))
            setTextColor(Color.WHITE)
            setSingleLine(true)
            visibility = View.GONE
            setBackgroundResource(R.drawable.bg_answer_field)
            setPadding(20, 14, 20, 14)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.topMargin = 8 }
        }

        val status = TextView(host).apply {
            text = "…"
            setTextColor(Color.parseColor("#AAAAAA"))
            textSize = 12f
            setPadding(4, 10, 4, 6)
        }
        val listBox = LinearLayout(host).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(8, 8, 8, 8)
        }
        val scroll = android.widget.ScrollView(host).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
            setBackgroundResource(R.drawable.bg_card)
            addView(listBox)
        }

        fun fmtDate(iso: String): String {
            // expect 2026-11-25T02:54:00 or similar
            return try {
                val s = iso.replace("T", " ").replace("Z", "")
                val datePart = s.take(10) // yyyy-mm-dd
                val timePart = if (s.length >= 16) s.substring(11, 16) else ""
                val p = datePart.split("-")
                if (p.size == 3) "${p[2]} / ${p[1]} / ${p[0]} / $timePart" else iso
            } catch (_: Exception) { iso }
        }

        fun displayName(name: String, fallback: String): String {
            val n = name.trim()
            if (n.isNotEmpty()) return n
            val f = fallback.trim()
            return if (f.isNotEmpty()) f else "?"
        }

        fun auditSummary(item: SupabaseBanClient.AuditItem): Pair<String, Int> {
            val who = displayName(item.targetName, item.targetUserId)
            val act = item.action.lowercase()
            val det = item.detail.lowercase()
            return when {
                act.contains("unban") -> LocaleHelper.t(host, "mon_msg_unbanned").replace("%s", who) to Color.parseColor("#00E676")
                act.contains("ban") -> LocaleHelper.t(host, "mon_msg_banned").replace("%s", who) to Color.parseColor("#FF1744")
                act.contains("delete") -> LocaleHelper.t(host, "mon_msg_deleted").replace("%s", who) to Color.parseColor("#FF1744")
                act.contains("set_role") || act.contains("role") -> {
                    val role = Regex("role\\s*=\\s*(\\w+)", RegexOption.IGNORE_CASE).find(item.detail)?.groupValues?.getOrNull(1)
                        ?: det.substringAfter("role=", "").trim().uppercase().ifBlank { "USER" }
                    val r = role.uppercase()
                    val msg = LocaleHelper.t(host, "mon_msg_role").replace("%s", who).replace("%r", r)
                    val col = when (r) {
                        "ADMIN" -> Color.parseColor("#00E676")
                        "TESTER" -> Color.parseColor("#FFEB3B")
                        else -> Color.WHITE
                    }
                    msg to col
                }
                else -> "${item.action}: $who" to Color.WHITE
            }
        }

        fun errorSummary(item: SupabaseBanClient.ErrorItem): Pair<String, Int> {
            val who = displayName(item.userName, item.userId)
            val src = item.source.lowercase()
            val msg = item.message.lowercase()
            val text = when {
                src.contains("groq") && (msg.contains("quota") || msg.contains("limit") || msg.contains("429")) ->
                    LocaleHelper.t(host, "mon_msg_groq_quota").replace("%s", who)
                src.contains("groq") ->
                    LocaleHelper.t(host, "mon_msg_groq_error").replace("%s", who)
                else ->
                    LocaleHelper.t(host, "mon_msg_error_generic").replace("%s", who).replace("%e", item.source.ifBlank { "app" })
            }
            return text to Color.parseColor("#FF1744")
        }

        fun showConfirmClear(messageKey: String, onOk: () -> Unit) {
            val box = LinearLayout(host).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(28, 24, 28, 20)
                setBackgroundResource(R.drawable.bg_card)
            }
            val msg = TextView(host).apply {
                text = LocaleHelper.t(host, messageKey)
                setTextColor(Color.parseColor("#F5F5F7"))
                textSize = 15f
                setPadding(0, 0, 0, 28)
            }
            val row = LinearLayout(host).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val btnConfirm = TextView(host).apply {
                text = LocaleHelper.t(host, "confirm")
                setTextColor(Color.parseColor("#69F0AE"))
                textSize = 15f
                setTypeface(typeface, Typeface.BOLD)
                setPadding(8, 12, 8, 12)
            }
            val spacer = android.widget.Space(host).apply {
                layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
            }
            val btnCancel = TextView(host).apply {
                text = LocaleHelper.t(host, "cancel")
                setTextColor(Color.parseColor("#FF1744"))
                textSize = 15f
                setTypeface(typeface, Typeface.BOLD)
                setPadding(8, 12, 8, 12)
            }
            row.addView(btnConfirm)
            row.addView(spacer)
            row.addView(btnCancel)
            box.addView(msg)
            box.addView(row)
            val dlg = AlertDialog.Builder(host).setView(box).create()
            btnConfirm.setOnClickListener { haptic(); dlg.dismiss(); onOk() }
            btnCancel.setOnClickListener { haptic(); dlg.dismiss() }
            dlg.show()
        }

        fun showDetailDialog(
            titleColor: Int,
            lines: List<Pair<String, Int>>,
            onDelete: (() -> Unit)?
        ) {
            val box = LinearLayout(host).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(20, 16, 20, 20)
                setBackgroundResource(R.drawable.bg_card)
            }
            val top = LinearLayout(host).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            if (onDelete != null) {
                val trash = android.widget.ImageView(host).apply {
                    setImageResource(R.drawable.ic_trash)
                    setPadding(10, 10, 10, 10)
                    layoutParams = LinearLayout.LayoutParams(44, 44)
                    setOnClickListener {
                        haptic()
                        showConfirmClear("monitor_delete_row_confirm") {
                            onDelete()
                        }
                    }
                }
                top.addView(trash)
            } else {
                top.addView(android.widget.Space(host).apply {
                    layoutParams = LinearLayout.LayoutParams(44, 44)
                })
            }
            val spacer = android.widget.Space(host).apply {
                layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
            }
            top.addView(spacer)
            val x = android.widget.ImageView(host).apply {
                setImageResource(R.drawable.ic_notif_close)
                setBackgroundResource(R.drawable.bg_admin_close)
                setPadding(14, 14, 14, 14)
                layoutParams = LinearLayout.LayoutParams(44, 44)
            }
            top.addView(x)
            box.addView(top)
            lines.forEach { (text, color) ->
                val tv = TextView(host).apply {
                    this.text = text
                    setTextColor(color)
                    textSize = 14f
                    setTypeface(typeface, Typeface.BOLD)
                    setPadding(4, 10, 4, 4)
                }
                box.addView(tv)
            }
            val dlg = AlertDialog.Builder(host).setView(box).create()
            x.setOnClickListener { haptic(); dlg.dismiss() }
            dlg.show()
        }

        fun addDateLine(container: LinearLayout, iso: String) {
            val row = LinearLayout(host).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(4, 8, 4, 4)
            }
            val iv = android.widget.ImageView(host).apply {
                setImageResource(R.drawable.ic_clock)
                layoutParams = LinearLayout.LayoutParams(28, 28)
            }
            val tv = TextView(host).apply {
                text = "  " + fmtDate(iso)
                setTextColor(Color.parseColor("#CCCCCC"))
                textSize = 13f
                setTypeface(typeface, Typeface.BOLD)
            }
            row.addView(iv)
            row.addView(tv)
            container.addView(row)
        }

        fun reload() {
            status.text = "…"
            listBox.removeAllViews()
            val q = etFilter.text?.toString()?.trim().orEmpty()
            Thread {
                try {
                    when (monitorTab) {
                        0 -> {
                            val items = SupabaseBanClient.superAdminListAudit(q)
                            host.runOnUiThread {
                                if (items.isEmpty()) {
                                    listBox.addView(TextView(host).apply {
                                        text = LocaleHelper.t(host, "monitor_empty")
                                        setTextColor(Color.parseColor("#888888"))
                                        setPadding(16, 24, 16, 24)
                                    })
                                } else {
                                    items.forEach { item ->
                                        val (summary, col) = auditSummary(item)
                                        val row = TextView(host).apply {
                                            text = summary
                                            setTextColor(col)
                                            textSize = 14f
                                            setTypeface(typeface, Typeface.BOLD)
                                            setPadding(16, 18, 16, 18)
                                            setBackgroundColor(Color.parseColor("#1A1A1A"))
                                            setOnClickListener {
                                                haptic()
                                                val lines = mutableListOf<Pair<String, Int>>()
                                                lines.add(summary to col)
                                                lines.add(
                                                    LocaleHelper.t(host, "mon_changed_by").replace("%s", displayName(item.actor, item.actor))
                                                        to Color.WHITE
                                                )
                                                showDetailDialog(col, lines, onDelete = {
                                                    Thread {
                                                        try {
                                                            SupabaseBanClient.superAdminDeleteAudit(item.id)
                                                            host.runOnUiThread { reload() }
                                                        } catch (e: Exception) {
                                                            host.runOnUiThread {
                                                                Toast.makeText(host, e.message ?: "error", Toast.LENGTH_LONG).show()
                                                            }
                                                        }
                                                    }.start()
                                                })
                                                // inject date into dialog - reopen with date by custom
                                            }
                                        }
                                        // detail with date properly
                                        row.setOnClickListener {
                                            haptic()
                                            val box = LinearLayout(host).apply {
                                                orientation = LinearLayout.VERTICAL
                                                setPadding(20, 16, 20, 20)
                                                setBackgroundResource(R.drawable.bg_card)
                                            }
                                            val top = LinearLayout(host).apply {
                                                orientation = LinearLayout.HORIZONTAL
                                                gravity = Gravity.CENTER_VERTICAL
                                            }
                                            val trash = android.widget.ImageView(host).apply {
                                                setImageResource(R.drawable.ic_trash)
                                                setPadding(10, 10, 10, 10)
                                                layoutParams = LinearLayout.LayoutParams(44, 44)
                                            }
                                            val sp = android.widget.Space(host).apply {
                                                layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
                                            }
                                            val x = android.widget.ImageView(host).apply {
                                                setImageResource(R.drawable.ic_notif_close)
                                                setBackgroundResource(R.drawable.bg_admin_close)
                                                setPadding(14, 14, 14, 14)
                                                layoutParams = LinearLayout.LayoutParams(44, 44)
                                            }
                                            top.addView(trash); top.addView(sp); top.addView(x)
                                            box.addView(top)
                                            box.addView(TextView(host).apply {
                                                text = summary
                                                setTextColor(col)
                                                textSize = 14f
                                                setTypeface(typeface, Typeface.BOLD)
                                                setPadding(4, 10, 4, 4)
                                            })
                                            box.addView(TextView(host).apply {
                                                text = LocaleHelper.t(host, "mon_changed_by").replace("%s", displayName(item.actor, item.actor))
                                                setTextColor(Color.WHITE)
                                                textSize = 14f
                                                setTypeface(typeface, Typeface.BOLD)
                                                setPadding(4, 8, 4, 4)
                                            })
                                            addDateLine(box, item.createdAt)
                                            val dlg = AlertDialog.Builder(host).setView(box).create()
                                            x.setOnClickListener { haptic(); dlg.dismiss() }
                                            trash.setOnClickListener {
                                                haptic()
                                                showConfirmClear("monitor_delete_row_confirm") {
                                                    dlg.dismiss()
                                                    Thread {
                                                        try {
                                                            SupabaseBanClient.superAdminDeleteAudit(item.id)
                                                            host.runOnUiThread { reload() }
                                                        } catch (e: Exception) {
                                                            host.runOnUiThread {
                                                                Toast.makeText(host, e.message ?: "error", Toast.LENGTH_LONG).show()
                                                            }
                                                        }
                                                    }.start()
                                                }
                                            }
                                            dlg.show()
                                        }
                                        listBox.addView(row)
                                        listBox.addView(View(host).apply {
                                            layoutParams = LinearLayout.LayoutParams(
                                                LinearLayout.LayoutParams.MATCH_PARENT, 1
                                            )
                                            setBackgroundColor(Color.parseColor("#333333"))
                                        })
                                    }
                                }
                                status.text = LocaleHelper.t(host, "monitor_loaded")
                            }
                        }
                        1 -> {
                            val items = SupabaseBanClient.superAdminListErrors(q)
                            host.runOnUiThread {
                                if (items.isEmpty()) {
                                    listBox.addView(TextView(host).apply {
                                        text = LocaleHelper.t(host, "monitor_empty")
                                        setTextColor(Color.parseColor("#888888"))
                                        setPadding(16, 24, 16, 24)
                                    })
                                } else {
                                    items.forEach { item ->
                                        val (summary, col) = errorSummary(item)
                                        val row = TextView(host).apply {
                                            text = summary
                                            setTextColor(col)
                                            textSize = 14f
                                            setTypeface(typeface, Typeface.BOLD)
                                            setPadding(16, 18, 16, 18)
                                            setBackgroundColor(Color.parseColor("#1A1A1A"))
                                        }
                                        row.setOnClickListener {
                                            haptic()
                                            val box = LinearLayout(host).apply {
                                                orientation = LinearLayout.VERTICAL
                                                setPadding(20, 16, 20, 20)
                                                setBackgroundResource(R.drawable.bg_card)
                                            }
                                            val top = LinearLayout(host).apply {
                                                orientation = LinearLayout.HORIZONTAL
                                                gravity = Gravity.CENTER_VERTICAL
                                            }
                                            val trash = android.widget.ImageView(host).apply {
                                                setImageResource(R.drawable.ic_trash)
                                                setPadding(10, 10, 10, 10)
                                                layoutParams = LinearLayout.LayoutParams(44, 44)
                                            }
                                            val sp = android.widget.Space(host).apply {
                                                layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
                                            }
                                            val x = android.widget.ImageView(host).apply {
                                                setImageResource(R.drawable.ic_notif_close)
                                                setBackgroundResource(R.drawable.bg_admin_close)
                                                setPadding(14, 14, 14, 14)
                                                layoutParams = LinearLayout.LayoutParams(44, 44)
                                            }
                                            top.addView(trash); top.addView(sp); top.addView(x)
                                            box.addView(top)
                                            box.addView(TextView(host).apply {
                                                text = summary
                                                setTextColor(col)
                                                textSize = 14f
                                                setTypeface(typeface, Typeface.BOLD)
                                                setPadding(4, 10, 4, 4)
                                            })
                                            box.addView(TextView(host).apply {
                                                text = LocaleHelper.t(host, "mon_details").replace("%s", item.message.ifBlank { item.source })
                                                setTextColor(Color.WHITE)
                                                textSize = 14f
                                                setTypeface(typeface, Typeface.BOLD)
                                                setPadding(4, 8, 4, 4)
                                            })
                                            addDateLine(box, item.createdAt)
                                            val dlg = AlertDialog.Builder(host).setView(box).create()
                                            x.setOnClickListener { haptic(); dlg.dismiss() }
                                            trash.setOnClickListener {
                                                haptic()
                                                showConfirmClear("monitor_delete_row_confirm") {
                                                    dlg.dismiss()
                                                    Thread {
                                                        try {
                                                            SupabaseBanClient.superAdminDeleteError(item.id)
                                                            host.runOnUiThread { reload() }
                                                        } catch (e: Exception) {
                                                            host.runOnUiThread {
                                                                Toast.makeText(host, e.message ?: "error", Toast.LENGTH_LONG).show()
                                                            }
                                                        }
                                                    }.start()
                                                }
                                            }
                                            dlg.show()
                                        }
                                        listBox.addView(row)
                                        listBox.addView(View(host).apply {
                                            layoutParams = LinearLayout.LayoutParams(
                                                LinearLayout.LayoutParams.MATCH_PARENT, 1
                                            )
                                            setBackgroundColor(Color.parseColor("#333333"))
                                        })
                                    }
                                }
                                status.text = LocaleHelper.t(host, "monitor_loaded")
                            }
                        }
                        else -> {
                            val items = SupabaseBanClient.superAdminListTrivia(q)
                            host.runOnUiThread {
                                if (items.isEmpty()) {
                                    listBox.addView(TextView(host).apply {
                                        text = LocaleHelper.t(host, "monitor_empty")
                                        setTextColor(Color.parseColor("#888888"))
                                        setPadding(16, 24, 16, 24)
                                    })
                                } else {
                                    items.forEach { item ->
                                        val row = TextView(host).apply {
                                            text = item.question.ifBlank { "(—)" }
                                            setTextColor(Color.WHITE)
                                            textSize = 14f
                                            setTypeface(typeface, Typeface.BOLD)
                                            setPadding(16, 18, 16, 18)
                                            setBackgroundColor(Color.parseColor("#1A1A1A"))
                                        }
                                        row.setOnClickListener {
                                            haptic()
                                            val box = LinearLayout(host).apply {
                                                orientation = LinearLayout.VERTICAL
                                                setPadding(20, 16, 20, 20)
                                                setBackgroundResource(R.drawable.bg_card)
                                            }
                                            val top = LinearLayout(host).apply {
                                                orientation = LinearLayout.HORIZONTAL
                                                gravity = Gravity.CENTER_VERTICAL
                                            }
                                            val sp = android.widget.Space(host).apply {
                                                layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
                                            }
                                            val x = android.widget.ImageView(host).apply {
                                                setImageResource(R.drawable.ic_notif_close)
                                                setBackgroundResource(R.drawable.bg_admin_close)
                                                setPadding(14, 14, 14, 14)
                                                layoutParams = LinearLayout.LayoutParams(44, 44)
                                            }
                                            top.addView(sp); top.addView(x)
                                            box.addView(top)
                                            fun addLine(label: String, value: String) {
                                                box.addView(TextView(host).apply {
                                                    text = "$label: $value"
                                                    setTextColor(Color.WHITE)
                                                    textSize = 13f
                                                    setTypeface(typeface, Typeface.BOLD)
                                                    setPadding(4, 6, 4, 4)
                                                })
                                            }
                                            addLine("Question", item.question)
                                            addLine("Image url", item.imageUrl.ifBlank { "—" })
                                            addLine("Image file name", item.imageFile.ifBlank { "—" })
                                            addLine("Answer", item.answer)
                                            if (item.gameQuestionId.isNotBlank()) addLine("game_question_id", item.gameQuestionId)
                                            box.addView(TextView(host).apply {
                                                text = LocaleHelper.t(host, "mon_added_by").replace("%s", item.createdBy.ifBlank { "—" })
                                                setTextColor(Color.parseColor("#69F0AE"))
                                                textSize = 14f
                                                setTypeface(typeface, Typeface.BOLD)
                                                setPadding(4, 12, 4, 4)
                                            })
                                            addDateLine(box, item.createdAt)
                                            val dlg = AlertDialog.Builder(host).setView(box).create()
                                            x.setOnClickListener { haptic(); dlg.dismiss() }
                                            dlg.show()
                                        }
                                        listBox.addView(row)
                                        listBox.addView(View(host).apply {
                                            layoutParams = LinearLayout.LayoutParams(
                                                LinearLayout.LayoutParams.MATCH_PARENT, 1
                                            )
                                            setBackgroundColor(Color.parseColor("#333333"))
                                        })
                                    }
                                }
                                status.text = LocaleHelper.t(host, "monitor_loaded")
                            }
                        }
                    }
                } catch (e: Exception) {
                    host.runOnUiThread {
                        status.text = LocaleHelper.t(host, "not_authorized")
                        listBox.addView(TextView(host).apply {
                            text = e.message ?: "error"
                            setTextColor(Color.parseColor("#FF1744"))
                            setPadding(16, 16, 16, 16)
                        })
                    }
                }
            }.start()
        }

        fun applyTabUi() {
            paintTabs()
            when (monitorTab) {
                0 -> {
                    btnBorrar.visibility = View.VISIBLE
                    btnFiltrar.visibility = View.GONE
                    etFilter.visibility = View.GONE
                }
                1 -> {
                    btnBorrar.visibility = View.VISIBLE
                    btnFiltrar.visibility = View.GONE
                    etFilter.visibility = View.GONE
                }
                else -> {
                    btnBorrar.visibility = View.GONE
                    btnFiltrar.visibility = View.VISIBLE
                    // keep filter visibility as user left it unless switching in
                    if (etFilter.visibility != View.VISIBLE) btnFiltrar.visibility = View.VISIBLE
                }
            }
            reload()
        }

        tabAct.setOnClickListener { haptic(); monitorTab = 0; etFilter.setText(""); applyTabUi() }
        tabErr.setOnClickListener { haptic(); monitorTab = 1; etFilter.setText(""); applyTabUi() }
        tabDb.setOnClickListener { haptic(); monitorTab = 2; etFilter.setText(""); applyTabUi() }

        btnBorrar.setOnClickListener {
            haptic()
            val key = if (monitorTab == 0) "monitor_clear_audit_confirm" else "monitor_clear_errors_confirm"
            showConfirmClear(key) {
                Thread {
                    try {
                        if (monitorTab == 0) SupabaseBanClient.superAdminClearAudit()
                        else SupabaseBanClient.superAdminClearErrors()
                        host.runOnUiThread { reload() }
                    } catch (e: Exception) {
                        host.runOnUiThread {
                            Toast.makeText(host, e.message ?: "error", Toast.LENGTH_LONG).show()
                        }
                    }
                }.start()
            }
        }

        btnFiltrar.setOnClickListener {
            haptic()
            btnFiltrar.visibility = View.GONE
            etFilter.visibility = View.VISIBLE
            etFilter.requestFocus()
        }
        // tap outside filter: use overlay click on list to close filter
        scroll.setOnTouchListener { _, _ ->
            if (monitorTab == 2 && etFilter.visibility == View.VISIBLE) {
                etFilter.visibility = View.GONE
                btnFiltrar.visibility = View.VISIBLE
            }
            false
        }
        etFilter.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) { reload() }
        })

        rootLl.addView(header)
        rootLl.addView(tabs)
        rootLl.addView(actionBar)
        rootLl.addView(etFilter)
        rootLl.addView(status)
        rootLl.addView(scroll)
        overlay.addView(rootLl)

        val parent = host.findViewById<android.view.ViewGroup>(android.R.id.content)
        parent.addView(overlay)
        monitorOverlay = overlay
        monitorTab = 0
        applyTabUi()
    }

    private fun closeMonitorPanel() {
        try {
            monitorOverlay?.let { ov ->
                (ov.parent as? android.view.ViewGroup)?.removeView(ov)
            }
        } catch (_: Exception) {}
        monitorOverlay = null
    }


    private fun requireSuperAdmin(): Boolean {
        if (isSuperAdmin()) return true
        Toast.makeText(host, LocaleHelper.t(host, "not_authorized_function"), Toast.LENGTH_SHORT).show()
        return false
    }

    private fun stopUsersPeriodicRefresh() {
        try { usersRefreshHandler.removeCallbacks(usersRefreshRunnable) } catch (_: Exception) {}
    }

    private fun startUsersPeriodicRefresh() {
        stopUsersPeriodicRefresh()
        try {
            usersRefreshHandler.postDelayed(usersRefreshRunnable, usersRefreshIntervalMs)
        } catch (_: Exception) {}
    }

    private fun ensureModeHomeBar() {
        try {
            if (try { fid<LinearLayout>(R.id.userModeHomeBar); true } catch (_: Exception) { false }) return
            val toolbarCard = fid<android.widget.FrameLayout>(R.id.userToolbarCard)
            val bar = LinearLayout(host).apply {
                id = R.id.userModeHomeBar
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = android.widget.FrameLayout.LayoutParams(
                    android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                    android.widget.FrameLayout.LayoutParams.MATCH_PARENT
                )
                setBackgroundColor(Color.parseColor("#16121F"))
                setPadding(4, 0, 4, 0)
            }
            fun mk(label: String, onClick: () -> Unit): TextView {
                return TextView(host).apply {
                    text = label
                    setTextColor(Color.WHITE)
                    textSize = 10f
                    setTypeface(typeface, Typeface.BOLD)
                    gravity = Gravity.CENTER
                    setPadding(2, 8, 2, 8)
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
                    setOnClickListener {
                        haptic()
                        if (!requireSuperAdmin()) return@setOnClickListener
                        onClick()
                    }
                }
            }
            bar.addView(mk("USERS") { openUsersMode() })
            bar.addView(mk("DATABASE") { openDatabaseMode() })
            bar.addView(mk("LOGS") { openLogsMode() })
            bar.addView(mk("ACTIVITY") { openActivityMode() })
            toolbarCard.addView(bar)
        } catch (_: Exception) {}
    }

    private fun showHomeMode() {
        contentMode = "home"
        usersListVisible = false
        selectMode = null
        dbEditArmed = false
        exitFilterBar()
        stopUsersPeriodicRefresh()
        ensureModeHomeBar()
        updateToolbarState()
        renderFiltered()
    }

    private fun openUsersMode() {
        contentMode = "users"
        usersListVisible = true
        dbEditArmed = false
        exitFilterBar()
        ensureModeHomeBar()
        updateToolbarState()
        load() // refresh inmediato
        startUsersPeriodicRefresh()
        renderFiltered()
    }

    private fun openDatabaseMode() {
        contentMode = "database"
        usersListVisible = false
        stopUsersPeriodicRefresh()
        exitFilterBar()
        updateToolbarState()
        tvStatus.text = "…"
        Thread {
            try {
                listCacheTrivia = SupabaseBanClient.superAdminListTrivia("")
                host.runOnUiThread {
                    tvStatus.text = LocaleHelper.t(host, "monitor_loaded")
                    renderFiltered()
                }
            } catch (e: Exception) {
                host.runOnUiThread {
                    tvStatus.text = e.message ?: "error"
                    listCacheTrivia = emptyList()
                    renderFiltered()
                }
            }
        }.start()
    }

    private fun openLogsMode() {
        contentMode = "logs"
        usersListVisible = false
        stopUsersPeriodicRefresh()
        exitFilterBar()
        updateToolbarState()
        tvStatus.text = "…"
        Thread {
            try {
                listCacheErrors = SupabaseBanClient.superAdminListErrors("")
                host.runOnUiThread {
                    tvStatus.text = LocaleHelper.t(host, "monitor_loaded")
                    renderFiltered()
                }
            } catch (e: Exception) {
                host.runOnUiThread {
                    tvStatus.text = e.message ?: "error"
                    listCacheErrors = emptyList()
                    renderFiltered()
                }
            }
        }.start()
    }

    private fun openActivityMode() {
        contentMode = "activity"
        usersListVisible = false
        stopUsersPeriodicRefresh()
        exitFilterBar()
        updateToolbarState()
        tvStatus.text = "…"
        Thread {
            try {
                listCacheAudit = SupabaseBanClient.superAdminListAudit("")
                host.runOnUiThread {
                    tvStatus.text = LocaleHelper.t(host, "monitor_loaded")
                    renderFiltered()
                }
            } catch (e: Exception) {
                host.runOnUiThread {
                    tvStatus.text = e.message ?: "error"
                    listCacheAudit = emptyList()
                    renderFiltered()
                }
            }
        }.start()
    }

    private fun confirmClearLogs(kind: String) {
        val box = LinearLayout(host).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 20)
            setBackgroundResource(R.drawable.bg_card)
        }
        val msg = TextView(host).apply {
            text = LocaleHelper.t(host, if (kind == "audit") "monitor_clear_audit_confirm" else "monitor_clear_errors_confirm")
            setTextColor(Color.parseColor("#F5F5F7"))
            textSize = 15f
            setPadding(0, 0, 0, 28)
        }
        val row = LinearLayout(host).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val btnConfirm = TextView(host).apply {
            text = LocaleHelper.t(host, "confirm")
            setTextColor(Color.parseColor("#69F0AE"))
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(8, 12, 8, 12)
        }
        val spacer = android.widget.Space(host).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        }
        val btnCancel = TextView(host).apply {
            text = LocaleHelper.t(host, "cancel")
            setTextColor(Color.parseColor("#FF1744"))
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(8, 12, 8, 12)
        }
        row.addView(btnConfirm)
        row.addView(spacer)
        row.addView(btnCancel)
        box.addView(msg)
        box.addView(row)
        val dlg = AlertDialog.Builder(host).setView(box).create()
        btnConfirm.setOnClickListener {
            haptic()
            dlg.dismiss()
            Thread {
                try {
                    if (kind == "audit") SupabaseBanClient.superAdminClearAudit()
                    else SupabaseBanClient.superAdminClearErrors()
                    host.runOnUiThread {
                        if (kind == "audit") openActivityMode() else openLogsMode()
                    }
                } catch (e: Exception) {
                    host.runOnUiThread {
                        Toast.makeText(host, e.message ?: "error", Toast.LENGTH_LONG).show()
                    }
                }
            }.start()
        }
        btnCancel.setOnClickListener { haptic(); dlg.dismiss() }
        dlg.show()
    }


    private fun isSuperAdmin(): Boolean = prefs.isSuperAdmin()

    private fun canManageTarget(target: SupabaseBanClient.UserRow): Boolean {
        if (prefs.isTester()) return false
        val myUid = prefs.getUserUid()
        if (target.userId == myUid) return false
        if (prefs.getUserEmail().trim().equals(target.email.trim(), ignoreCase = true) &&
            target.email.isNotBlank()
        ) return false
        if (target.isSuperAdmin) return false
        val targetIsAdmin = target.role.equals("ADMIN", true)
        if (targetIsAdmin && !isSuperAdmin()) return false
        return true
    }


    private var comingSoonBlink: Animation? = null
    private var onlineDotBlink: Animation? = null

    private fun startComingSoonBlink() { /* replaced by restrict button */ }

    private fun updateOnlineIndicator(online: Int) {
        val dot = fid<View>(R.id.onlineDot)
        val count = fid<TextView>(R.id.tvOnlineCount)
        count.text = online.toString()
        dot.clearAnimation()
        if (online > 0) {
            dot.setBackgroundResource(R.drawable.bg_online_dot)
            onlineDotBlink = AlphaAnimation(1f, 0.2f).apply {
                duration = 700
                repeatMode = Animation.REVERSE
                repeatCount = Animation.INFINITE
            }
            dot.startAnimation(onlineDotBlink)
        } else {
            dot.setBackgroundResource(R.drawable.bg_offline_dot)
        }
    }

    private fun showFloatOpenedHint() {
        floatHintToast?.cancel()
        val toast = Toast.makeText(host, LocaleHelper.t(host, "float_opened_hint"), Toast.LENGTH_LONG)
        // Más arriba: bajo la zona de la línea divisoria (no abajo del todo)
        try {
            toast.setGravity(android.view.Gravity.TOP or android.view.Gravity.CENTER_HORIZONTAL, 0, 280)
        } catch (_: Exception) {}
        floatHintToast = toast
        toast.show()
        // Un solo mensaje ~4s (LENGTH_LONG ~3.5s; cancelar a los 4s por si se alarga)
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            floatHintToast?.cancel()
            floatHintToast = null
        }, 4000)
    }

    private fun load() {
        tvStatus.text = "…"
        val adminId = prefs.getUserUid()
        val asTester = prefs.isTester()
        Thread {
            try {
                // Mantener last_seen fresco mientras el admin está en el panel (auto 20s)
                try {
                    if (adminId.isNotBlank()) SupabaseBanClient.heartbeat(adminId)
                } catch (_: Exception) {}
                val users = SupabaseBanClient.adminListUsers(adminId)
                bannedUsers = try {
                    if (asTester) emptySet()
                    else SupabaseBanClient.adminListBans(adminId).first
                } catch (_: Exception) {
                    emptySet()
                }
                val online = users.count { it.isOnline() }
                val accessMode = try { SupabaseBanClient.getAccessModeOrNull() } catch (_: Exception) { null }
                host.runOnUiThread {
                    if (accessMode != null) {
                        currentAccessMode = accessMode
                        try { prefs.setLastAccessMode(accessMode) } catch (_: Exception) {}
                    }
                    refreshRestrictButtonColor()
                    allUsers = if (asTester) {
                        users.filter { it.userId == prefs.getUserUid() }
                    } else {
                        users
                    }
                    val onlineVisible = allUsers.count { it.isOnline() }
                    updateOnlineIndicator(if (asTester) onlineVisible else online)
                    renderFiltered()
                    tvStatus.text = LocaleHelper.t(host, "total_users").replace("%s", allUsers.size.toString())
                }
            } catch (e: Exception) {
                host.runOnUiThread {
                    // No mostrar errores técnicos de red (DNS/hostname)
                    tvStatus.text = LocaleHelper.t(host, "admin_needs_internet")
                }
            }
        }.start()
    }

    private fun renderFiltered() {
        when (contentMode) {
            "home" -> renderHomeCensor()
            "users" -> {
                val q = filterQuery.lowercase()
                val list = if (q.isBlank()) allUsers else allUsers.filter {
                    it.nombre.lowercase().contains(q) || it.email.lowercase().contains(q)
                }
                usersListVisible = true
                render(list)
            }
            "database" -> renderDatabaseList()
            "logs" -> renderLogsList()
            "activity" -> renderActivityList()
            else -> renderHomeCensor()
        }
    }

    private fun renderHomeCensor() {
        userList.removeAllViews()
        val box = android.widget.FrameLayout(host).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#2A2A2A"))
            minimumHeight = (220 * host.resources.displayMetrics.density).toInt()
        }
        // big censor block
        val censor = View(host).apply {
            layoutParams = android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#3A3A3A"))
        }
        box.addView(censor)
        userList.addView(box)
    }

    private fun fmtClockTime(iso: String): String {
        return try {
            val s = iso.replace("T", " ").replace("Z", "")
            val datePart = s.take(10)
            val timePart = if (s.length >= 16) s.substring(11, 16) else ""
            val p = datePart.split("-")
            val d = if (p.size == 3) "${p[2]} / ${p[1]} / ${p[0]}" else datePart
            d to timePart
            "$d / $timePart"
        } catch (_: Exception) { iso }
    }

    private fun addClockRow(box: LinearLayout, iso: String) {
        val row = LinearLayout(host).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(4, 8, 4, 4)
        }
        val formatted = try {
            val s = iso.replace("T", " ").replace("Z", "")
            val datePart = s.take(10)
            val timePart = if (s.length >= 16) s.substring(11, 16) else ""
            val p = datePart.split("-")
            val d = if (p.size == 3) "${p[2]} / ${p[1]} / ${p[0]}" else datePart
            Pair(d, timePart)
        } catch (_: Exception) { Pair(iso, "") }
        row.addView(TextView(host).apply {
            text = formatted.first + " / "
            setTextColor(Color.parseColor("#CCCCCC"))
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
        })
        row.addView(android.widget.ImageView(host).apply {
            setImageResource(R.drawable.ic_clock)
            layoutParams = LinearLayout.LayoutParams(26, 26)
        })
        row.addView(TextView(host).apply {
            text = " " + formatted.second
            setTextColor(Color.parseColor("#CCCCCC"))
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
        })
        box.addView(row)
    }

    private fun emptyBlue(v: String): Pair<String, Int> {
        val t = v.trim()
        return if (t.isEmpty() || t == "—") ("EMPTY" to Color.parseColor("#40C4FF")) else (t to Color.WHITE)
    }

    private fun renderDatabaseList() {
        userList.removeAllViews()
        val q = filterQuery.lowercase()
        val items = if (q.isBlank()) listCacheTrivia else listCacheTrivia.filter {
            it.question.lowercase().contains(q) || it.answer.lowercase().contains(q) ||
                it.imageUrl.lowercase().contains(q) || it.imageFile.lowercase().contains(q)
        }
        if (items.isEmpty()) {
            userList.addView(TextView(host).apply {
                text = LocaleHelper.t(host, "monitor_empty")
                setTextColor(Color.parseColor("#888888"))
                setPadding(16, 24, 16, 24)
            })
            return
        }
        items.forEach { item ->
            val row = TextView(host).apply {
                text = item.question.ifBlank { "(—)" }
                setTextColor(Color.WHITE)
                textSize = 14f
                setTypeface(typeface, Typeface.BOLD)
                setPadding(12, 16, 12, 16)
                setBackgroundColor(Color.parseColor("#1A1A1A"))
                setOnClickListener {
                    haptic()
                    showTriviaDetail(item)
                }
            }
            userList.addView(row)
            userList.addView(View(host).apply {
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1)
                setBackgroundColor(Color.parseColor("#333333"))
            })
        }
    }

    private fun showTriviaDetail(item: SupabaseBanClient.TriviaItem) {
        val box = LinearLayout(host).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 16, 20, 20)
            setBackgroundResource(R.drawable.bg_card)
        }
        val top = LinearLayout(host).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        top.addView(android.widget.Space(host).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        })
        val x = android.widget.ImageView(host).apply {
            setImageResource(R.drawable.ic_notif_close)
            setBackgroundResource(R.drawable.bg_admin_close)
            setPadding(14, 14, 14, 14)
            layoutParams = LinearLayout.LayoutParams(44, 44)
        }
        top.addView(x)
        box.addView(top)
        fun line(label: String, value: String, forceBlueEmpty: Boolean = false) {
            val (txt, col) = if (forceBlueEmpty) emptyBlue(value) else (value to Color.WHITE)
            box.addView(TextView(host).apply {
                text = "$label: $txt"
                setTextColor(col)
                textSize = 13f
                setTypeface(typeface, Typeface.BOLD)
                setPadding(4, 6, 4, 4)
            })
        }
        line("Question", item.question)
        line("Image url", item.imageUrl, true)
        line("Image file name", item.imageFile, true)
        line("Answer", item.answer)
        line("game_question_id", item.gameQuestionId, true)
        val by = item.createdBy.trim().ifBlank { "Unknown!" }
        box.addView(TextView(host).apply {
            text = LocaleHelper.t(host, "mon_added_by").replace("%s", by)
            setTextColor(Color.parseColor("#69F0AE"))
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(4, 12, 4, 4)
        })
        addClockRow(box, item.createdAt)
        val dlg = AlertDialog.Builder(host).setView(box).create()
        x.setOnClickListener { haptic(); dlg.dismiss() }
        dlg.show()
        dbEditArmed = false
    }

    private fun auditSummary(item: SupabaseBanClient.AuditItem): Pair<String, Int> {
        val who = item.targetName.trim().ifBlank { item.targetUserId.trim().ifBlank { "?" } }
        val act = item.action.lowercase()
        return when {
            act.contains("unban") -> LocaleHelper.t(host, "mon_msg_unbanned").replace("%s", who) to Color.parseColor("#00E676")
            act.contains("ban") -> LocaleHelper.t(host, "mon_msg_banned").replace("%s", who) to Color.parseColor("#FF1744")
            act.contains("delete") -> LocaleHelper.t(host, "mon_msg_deleted").replace("%s", who) to Color.parseColor("#FF1744")
            act.contains("set_role") || act.contains("role") -> {
                val role = Regex("role\s*=\s*(\w+)", RegexOption.IGNORE_CASE).find(item.detail)?.groupValues?.getOrNull(1)
                    ?: item.detail.substringAfter("role=", "").trim().uppercase().ifBlank { "USER" }
                val r = role.uppercase()
                val msg = LocaleHelper.t(host, "mon_msg_role").replace("%s", who).replace("%r", r)
                val col = when (r) {
                    "ADMIN" -> Color.parseColor("#00E676")
                    "TESTER" -> Color.parseColor("#FFEB3B")
                    else -> Color.WHITE
                }
                msg to col
            }
            else -> "${item.action}: $who" to Color.WHITE
        }
    }

    private fun renderActivityList() {
        userList.removeAllViews()
        if (listCacheAudit.isEmpty()) {
            userList.addView(TextView(host).apply {
                text = LocaleHelper.t(host, "monitor_empty")
                setTextColor(Color.parseColor("#888888"))
                setPadding(16, 24, 16, 24)
            })
            return
        }
        listCacheAudit.forEach { item ->
            val (summary, col) = auditSummary(item)
            val row = TextView(host).apply {
                text = summary
                setTextColor(col)
                textSize = 14f
                setTypeface(typeface, Typeface.BOLD)
                setPadding(12, 16, 12, 16)
                setBackgroundColor(Color.parseColor("#1A1A1A"))
                setOnClickListener {
                    haptic()
                    val box = LinearLayout(host).apply {
                        orientation = LinearLayout.VERTICAL
                        setPadding(20, 16, 20, 20)
                        setBackgroundResource(R.drawable.bg_card)
                    }
                    val top = LinearLayout(host).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                    }
                    val trash = android.widget.ImageView(host).apply {
                        setImageResource(R.drawable.ic_trash)
                        setPadding(10, 10, 10, 10)
                        layoutParams = LinearLayout.LayoutParams(44, 44)
                    }
                    top.addView(trash)
                    top.addView(android.widget.Space(host).apply {
                        layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
                    })
                    val x = android.widget.ImageView(host).apply {
                        setImageResource(R.drawable.ic_notif_close)
                        setBackgroundResource(R.drawable.bg_admin_close)
                        setPadding(14, 14, 14, 14)
                        layoutParams = LinearLayout.LayoutParams(44, 44)
                    }
                    top.addView(x)
                    box.addView(top)
                    box.addView(TextView(host).apply {
                        text = summary
                        setTextColor(col)
                        textSize = 14f
                        setTypeface(typeface, Typeface.BOLD)
                        setPadding(4, 10, 4, 4)
                    })
                    box.addView(TextView(host).apply {
                        text = LocaleHelper.t(host, "mon_changed_by").replace("%s", item.actor.ifBlank { "?" })
                        setTextColor(Color.WHITE)
                        textSize = 14f
                        setTypeface(typeface, Typeface.BOLD)
                        setPadding(4, 8, 4, 4)
                    })
                    addClockRow(box, item.createdAt)
                    val dlg = AlertDialog.Builder(host).setView(box).create()
                    x.setOnClickListener { haptic(); dlg.dismiss() }
                    trash.setOnClickListener {
                        haptic()
                        confirmClearLogs("row_audit")
                        // simple delete row:
                        dlg.dismiss()
                        Thread {
                            try {
                                SupabaseBanClient.superAdminDeleteAudit(item.id)
                                host.runOnUiThread { openActivityMode() }
                            } catch (e: Exception) {
                                host.runOnUiThread {
                                    Toast.makeText(host, e.message ?: "error", Toast.LENGTH_LONG).show()
                                }
                            }
                        }.start()
                    }
                    dlg.show()
                }
            }
            userList.addView(row)
            userList.addView(View(host).apply {
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1)
                setBackgroundColor(Color.parseColor("#333333"))
            })
        }
    }

    private fun renderLogsList() {
        userList.removeAllViews()
        if (listCacheErrors.isEmpty()) {
            userList.addView(TextView(host).apply {
                text = LocaleHelper.t(host, "monitor_empty")
                setTextColor(Color.parseColor("#888888"))
                setPadding(16, 24, 16, 24)
            })
            return
        }
        listCacheErrors.forEach { item ->
            val who = item.userName.ifBlank { item.userId.ifBlank { "?" } }
            val summary = when {
                item.source.lowercase().contains("groq") && item.message.lowercase().let { it.contains("quota") || it.contains("limit") || it.contains("429") } ->
                    LocaleHelper.t(host, "mon_msg_groq_quota").replace("%s", who)
                item.source.lowercase().contains("groq") ->
                    LocaleHelper.t(host, "mon_msg_groq_error").replace("%s", who)
                else ->
                    LocaleHelper.t(host, "mon_msg_error_generic").replace("%s", who).replace("%e", item.source.ifBlank { "app" })
            }
            val col = Color.parseColor("#FF1744")
            val row = TextView(host).apply {
                text = summary
                setTextColor(col)
                textSize = 14f
                setTypeface(typeface, Typeface.BOLD)
                setPadding(12, 16, 12, 16)
                setBackgroundColor(Color.parseColor("#1A1A1A"))
                setOnClickListener {
                    haptic()
                    val box = LinearLayout(host).apply {
                        orientation = LinearLayout.VERTICAL
                        setPadding(20, 16, 20, 20)
                        setBackgroundResource(R.drawable.bg_card)
                    }
                    val top = LinearLayout(host).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                    }
                    val trash = android.widget.ImageView(host).apply {
                        setImageResource(R.drawable.ic_trash)
                        setPadding(10, 10, 10, 10)
                        layoutParams = LinearLayout.LayoutParams(44, 44)
                    }
                    top.addView(trash)
                    top.addView(android.widget.Space(host).apply {
                        layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
                    })
                    val x = android.widget.ImageView(host).apply {
                        setImageResource(R.drawable.ic_notif_close)
                        setBackgroundResource(R.drawable.bg_admin_close)
                        setPadding(14, 14, 14, 14)
                        layoutParams = LinearLayout.LayoutParams(44, 44)
                    }
                    top.addView(x)
                    box.addView(top)
                    box.addView(TextView(host).apply {
                        text = summary
                        setTextColor(col)
                        textSize = 14f
                        setTypeface(typeface, Typeface.BOLD)
                        setPadding(4, 10, 4, 4)
                    })
                    box.addView(TextView(host).apply {
                        text = LocaleHelper.t(host, "mon_details").replace("%s", item.message.ifBlank { item.source })
                        setTextColor(Color.WHITE)
                        textSize = 14f
                        setTypeface(typeface, Typeface.BOLD)
                        setPadding(4, 8, 4, 4)
                    })
                    addClockRow(box, item.createdAt)
                    val dlg = AlertDialog.Builder(host).setView(box).create()
                    x.setOnClickListener { haptic(); dlg.dismiss() }
                    trash.setOnClickListener {
                        haptic()
                        dlg.dismiss()
                        Thread {
                            try {
                                SupabaseBanClient.superAdminDeleteError(item.id)
                                host.runOnUiThread { openLogsMode() }
                            } catch (e: Exception) {
                                host.runOnUiThread {
                                    Toast.makeText(host, e.message ?: "error", Toast.LENGTH_LONG).show()
                                }
                            }
                        }.start()
                    }
                    dlg.show()
                }
            }
            userList.addView(row)
            userList.addView(View(host).apply {
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1)
                setBackgroundColor(Color.parseColor("#333333"))
            })
        }
    }


    private fun showRestrictAccessMenu() {
        val box = LinearLayout(host).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 16)
            setBackgroundResource(R.drawable.bg_card)
        }
        val title = TextView(host).apply {
            text = LocaleHelper.t(host, "restrict_access")
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 16f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 0, 0, 16)
        }
        box.addView(title)
        val dlg = AlertDialog.Builder(host).setView(box).create()
        Thread {
            val current = try { SupabaseBanClient.getAccessModeOrNull() ?: prefs.getLastAccessMode() } catch (_: Exception) { prefs.getLastAccessMode() }
            host.runOnUiThread {
                fun addOpt(labelKey: String, color: String, mode: String) {
                    val selected = current.equals(mode, true)
                    val row = TextView(host).apply {
                        text = LocaleHelper.t(host, labelKey)
                        setTextColor(if (selected) Color.WHITE else Color.parseColor(color))
                        textSize = 16f
                        setTypeface(typeface, android.graphics.Typeface.BOLD)
                        setPadding(16, 18, 16, 18)
                        if (selected) setBackgroundColor(Color.parseColor(color))
                        setOnClickListener {
                            dlg.dismiss()
                            Thread {
                                try {
                                    SupabaseBanClient.setAccessMode(prefs.getUserUid(), mode)
                                    host.runOnUiThread {
                                        currentAccessMode = mode
                                        try { prefs.setLastAccessMode(mode) } catch (_: Exception) {}
                                        refreshRestrictButtonColor()
                                    }
                                    host.runOnUiThread {
                                        val key = when (mode.uppercase()) {
                                            "ALL" -> "access_all"
                                            "ADMIN" -> "access_admin_only"
                                            "TESTER" -> "access_tester"
                                            else -> "access_all"
                                        }
                                        Toast.makeText(host, LocaleHelper.t(host, key), Toast.LENGTH_SHORT).show()
                                    }
                                } catch (e: Exception) {
                                    host.runOnUiThread {
                                        Toast.makeText(host, e.message, Toast.LENGTH_LONG).show()
                                    }
                                }
                            }.start()
                        }
                    }
                    box.addView(row)
                }
                addOpt("access_all", "#69F0AE", "ALL")
                addOpt("access_admin_only", "#FF1744", "ADMIN")
                addOpt("access_tester", "#FFC107", "TESTER")
                currentAccessMode = current
                refreshRestrictButtonColor()
                dlg.show()
                dlg.window?.setBackgroundDrawableResource(android.R.color.transparent)
            }
        }.start()
    }

    private fun showForceUpdateConfig() {
        val box = LinearLayout(host).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 16)
            setBackgroundResource(R.drawable.bg_card)
        }
        fun label(t: String) = TextView(host).apply {
            text = t
            setTextColor(Color.WHITE)
            textSize = 13f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 8, 0, 4)
        }
        val etVer = android.widget.EditText(host).apply {
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#9A9AB0"))
            hint = LocaleHelper.t(host, "force_update_version")
            setBackgroundResource(R.drawable.bg_answer_field)
            setPadding(16, 12, 16, 12)
        }
        val etUrl = android.widget.EditText(host).apply {
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#9A9AB0"))
            hint = LocaleHelper.t(host, "force_update_url")
            setBackgroundResource(R.drawable.bg_answer_field)
            setPadding(16, 12, 16, 12)
        }
        val etNews = android.widget.EditText(host).apply {
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#9A9AB0"))
            hint = LocaleHelper.t(host, "force_update_news")
            setBackgroundResource(R.drawable.bg_answer_field)
            setPadding(16, 12, 16, 12)
            minLines = 3
            gravity = android.view.Gravity.TOP or android.view.Gravity.START
        }
        box.addView(label(LocaleHelper.t(host, "force_update_version")))
        box.addView(etVer)
        box.addView(label(LocaleHelper.t(host, "force_update_url")))
        box.addView(etUrl)
        box.addView(label(LocaleHelper.t(host, "force_update_news")))
        box.addView(etNews)
        val dlg = AlertDialog.Builder(host).setView(box).create()
        Thread {
            val info = try {
                SupabaseBanClient.getForceUpdate()
            } catch (_: Exception) {
                SupabaseBanClient.ForceUpdateInfo(false, "", "", "")
            }
            host.runOnUiThread {
                etVer.setText(info.minVersion)
                etUrl.setText(info.apkUrl)
                etNews.setText(info.news)
                val row = LinearLayout(host).apply {
                    orientation = LinearLayout.HORIZONTAL
                    setPadding(0, 20, 0, 0)
                }
                fun save(enabled: Boolean) {
                    dlg.dismiss()
                    val ver = etVer.text?.toString()?.trim().orEmpty()
                    val url = etUrl.text?.toString()?.trim().orEmpty()
                    val news = etNews.text?.toString()?.trim().orEmpty()
                    Thread {
                        try {
                            SupabaseBanClient.setForceUpdate(prefs.getUserUid(), enabled, ver, url, news)
                            host.runOnUiThread {
                                Toast.makeText(
                                    host,
                                    LocaleHelper.t(host, "force_update_saved"),
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        } catch (e: Exception) {
                            host.runOnUiThread {
                                Toast.makeText(host, e.message, Toast.LENGTH_LONG).show()
                            }
                        }
                    }.start()
                }
                val btnOn = TextView(host).apply {
                    text = LocaleHelper.t(host, "force_update_enable")
                    setTextColor(Color.parseColor("#69F0AE"))
                    setTypeface(typeface, android.graphics.Typeface.BOLD)
                    setPadding(8, 12, 8, 12)
                    setOnClickListener { save(true) }
                }
                val spacer = android.widget.Space(host).apply {
                    layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
                }
                val btnOff = TextView(host).apply {
                    text = LocaleHelper.t(host, "force_update_disable")
                    setTextColor(Color.parseColor("#FF1744"))
                    setTypeface(typeface, android.graphics.Typeface.BOLD)
                    setPadding(8, 12, 8, 12)
                    setOnClickListener { save(false) }
                }
                row.addView(btnOn)
                row.addView(spacer)
                row.addView(btnOff)
                box.addView(row)
                dlg.show()
                dlg.window?.setBackgroundDrawableResource(android.R.color.transparent)
            }
        }.start()
    }



    private fun render(users: List<SupabaseBanClient.UserRow>) {
        userList.removeAllViews()
        for (u in users) {
            val banned = bannedUsers.contains(u.userId)
            val row = LinearLayout(host).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(12, 14, 12, 14)
                // Rojo de baneado SOLO cuando el listado está visible (sin censura)
                if (usersListVisible && banned) {
                    setBackgroundColor(Color.parseColor("#4D1A1A"))
                } else {
                    setBackgroundColor(Color.TRANSPARENT)
                }
            }
            val name = TextView(host).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.2f)
                text = u.nombre.ifBlank { u.email.ifBlank { u.userId } }
                setTextColor(Color.parseColor("#F5F5F7"))
                textSize = 14f
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
            }
            val roleTv = TextView(host).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.8f)
                gravity = android.view.Gravity.CENTER
                val r = u.role.ifBlank { "USER" }.uppercase()
                text = r
                textSize = 13f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(
                    when (r) {
                        "ADMIN" -> Color.parseColor("#E040FB")
                        "TESTER" -> Color.parseColor("#FFC107")
                        else -> Color.WHITE
                    }
                )
            }
            val statusTv = TextView(host).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.7f)
                gravity = android.view.Gravity.END
                val online = u.isOnline()
                text = if (online) "ONLINE" else "OFFLINE"
                textSize = 12f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(if (online) Color.parseColor("#69F0AE") else Color.parseColor("#FF1744"))
            }
            if (!usersListVisible) {
                // Censura real tipo spoiler: barra gris sin texto; sin borde/fondo rojo
                row.setBackgroundColor(Color.TRANSPARENT)
                row.background = null
                row.removeAllViews()
                val spoiler = View(host).apply {
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        (28 * host.resources.displayMetrics.density).toInt()
                    )
                    setBackgroundResource(R.drawable.bg_spoiler_row)
                }
                row.addView(spoiler)
                row.isClickable = false
                row.isEnabled = false
                row.setOnClickListener(null)
            } else {
                row.addView(name)
                row.addView(roleTv)
                row.addView(statusTv)
                row.setOnClickListener {
                    haptic()
                    showUserDetail(u, banned)
                }
            }
            userList.addView(row)
        }
    }

    private fun confirmDeleteUser(u: SupabaseBanClient.UserRow) {
        if (!isSuperAdmin()) {
            Toast.makeText(host, LocaleHelper.t(host, "not_authorized_function"), Toast.LENGTH_SHORT).show()
            return
        }
        if (isSelfUser(u) || isTargetSuperAdmin(u) && isSelfUser(u)) {
            Toast.makeText(host, LocaleHelper.t(host, "cannot_delete_self"), Toast.LENGTH_SHORT).show()
            return
        }
        if (isSelfUser(u)) {
            Toast.makeText(host, LocaleHelper.t(host, "cannot_delete_self"), Toast.LENGTH_SHORT).show()
            return
        }
        val name = u.nombre.ifBlank { u.email.ifBlank { u.userId } }
        val box = LinearLayout(host).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 20)
            setBackgroundResource(R.drawable.bg_card)
        }
        val msg = TextView(host).apply {
            text = when (LocaleHelper.getLang(host)) {
                "es" -> "¿Eliminar a $name de la lista?"
                "pt" -> "Excluir $name da lista?"
                "id" -> "Hapus $name dari daftar?"
                else -> "Delete $name from the list?"
            }
            setTextColor(Color.parseColor("#F5F5F7"))
            textSize = 15f
            setPadding(0, 0, 0, 28)
        }
        val row = LinearLayout(host).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val btnConfirm = TextView(host).apply {
            text = LocaleHelper.t(host, "confirm")
            setTextColor(Color.parseColor("#69F0AE"))
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(8, 12, 8, 12)
        }
        val spacer = android.widget.Space(host).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        }
        val btnCancel = TextView(host).apply {
            text = LocaleHelper.t(host, "cancel")
            setTextColor(Color.parseColor("#FF1744"))
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(8, 12, 8, 12)
        }
        row.addView(btnConfirm)
        row.addView(spacer)
        row.addView(btnCancel)
        box.addView(msg)
        box.addView(row)
        val dlg = AlertDialog.Builder(host).setView(box).create()
        btnConfirm.setOnClickListener {
            haptic()
            dlg.dismiss()
            val adminId = prefs.getUserUid()
            Thread {
                try {
                    SupabaseBanClient.adminDeleteUser(adminId, u.userId)
                    host.runOnUiThread {
                        val name = u.nombre.ifBlank { u.email.ifBlank { u.userId } }
                        Toast.makeText(host, LocaleHelper.t(host, "user_deleted").replace("%s", name), Toast.LENGTH_SHORT).show()
                        load()
                    }
                } catch (e: Exception) {
                    host.runOnUiThread {
                        val raw = e.message.orEmpty()
                        if (raw.contains("cannot delete self", ignoreCase = true)) {
                            Toast.makeText(host, LocaleHelper.t(host, "cannot_delete_self"), Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(host, raw.ifBlank { "Error" }, Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }.start()
        }
        btnCancel.setOnClickListener { haptic(); dlg.dismiss() }
        dlg.show()
        dlg.window?.setBackgroundDrawableResource(android.R.color.transparent)
    }

    private fun showUserDetail(u: SupabaseBanClient.UserRow, banned: Boolean) {
        val adminId = prefs.getUserUid()
        val box = LinearLayout(host).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28)
        }
        val meta = TextView(host).apply {
            fun lastTimeLabel(): String {
                val ms = u.lastSeenMs ?: return "—"
                return try {
                    val cal = java.util.Calendar.getInstance().apply { timeInMillis = ms }
                    val dd = cal.get(java.util.Calendar.DAY_OF_MONTH).toString().padStart(2, '0')
                    val mm = (cal.get(java.util.Calendar.MONTH) + 1).toString().padStart(2, '0')
                    val hh = cal.get(java.util.Calendar.HOUR_OF_DAY).toString().padStart(2, '0')
                    val min = cal.get(java.util.Calendar.MINUTE).toString().padStart(2, '0')
                    "$dd/$mm   |   $hh:$min"
                } catch (_: Exception) {
                    "—"
                }
            }
            val status = if (u.isOnline()) "ONLINE" else "OFFLINE"
            text = "ID:  ${u.userId}\n\n" +
                    "DEVICE:  ${u.deviceId.ifBlank { "—" }}\n\n" +
                    "EMAIL:  ${u.email.ifBlank { "—" }}\n\n" +
                    "ROLE:  ${u.role.ifBlank { "USER" }.uppercase()}\n\n" +
                    "STATUS:  $status\n\n" +
                    "LAST TIME:  ${lastTimeLabel()}"
            setTextColor(Color.parseColor("#F5F5F7"))
            textSize = 13f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 0, 0, 16)
        }
        val actions = LinearLayout(host).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
        }

        val manage = canManageTarget(u)
        val dialogRef = arrayOfNulls<AlertDialog>(1)

        val btnBan = Button(host).apply {
            text = if (banned) "Unban" else "Ban"
            setTextColor(Color.BLACK)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setBackgroundResource(R.drawable.bg_ban_btn)
            isEnabled = manage
            alpha = if (manage) 1f else 0.4f
            setOnClickListener {
                if (!manage) return@setOnClickListener
                haptic()
                if (banned) {
                    // Desbanear también requiere confirmación (Confirm/Cancel con vibración)
                    confirmUnban(u) { dialogRef[0]?.dismiss() }
                } else {
                    confirmBan(u) { dialogRef[0]?.dismiss() }
                }
            }
        }

        val btnRole = Button(host).apply {
            text = "ROL"
            setTextColor(Color.parseColor("#E040FB"))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setBackgroundResource(R.drawable.bg_admin_btn)
            // No clickable en fila propia ni en super admin (incluye el propio super admin)
            isEnabled = manage
            alpha = if (manage) 1f else 0.4f
            setOnClickListener {
                if (!manage) return@setOnClickListener
                haptic()
                if (isSelfUser(u)) {
                    Toast.makeText(host, LocaleHelper.t(host, "cannot_change_own_role"), Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                if (isTargetSuperAdmin(u)) {
                    Toast.makeText(host, LocaleHelper.t(host, "cannot_change_this_admin_role"), Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                if (!manage) {
                    Toast.makeText(host, LocaleHelper.t(host, "cannot_change_this_admin_role"), Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                showRolePicker(u) { dialogRef[0]?.dismiss() }
            }
        }

        // Header with X close
        val header = LinearLayout(host).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val headerTitle = TextView(host).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            text = u.nombre.ifBlank { "Usuario" }
            setTextColor(Color.parseColor("#E040FB"))
            textSize = 18f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val btnX = TextView(host).apply {
            text = "✕"
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 20f
            setPadding(16, 8, 8, 8)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        header.addView(headerTitle)
        header.addView(btnX)

        actions.addView(btnBan)
        actions.addView(btnRole)

        // Layout: header, meta, spacer-ish, actions at bottom with space between
        val root = LinearLayout(host).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 20, 24, 16)
            setBackgroundResource(R.drawable.bg_card)
        }
        root.addView(header)
        root.addView(meta)
        if (!prefs.isTester()) {
            val spacer = android.widget.Space(host).apply {
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 12)
            }
            root.addView(spacer)
            actions.gravity = Gravity.BOTTOM
            // BAN left, ROL right
            actions.gravity = Gravity.CENTER_VERTICAL
            val banLp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            banLp.marginEnd = 8
            btnBan.layoutParams = banLp
            val rolLp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            rolLp.marginStart = 8
            btnRole.layoutParams = rolLp
            root.addView(actions)
        }

        val dialog = AlertDialog.Builder(host)
            .setView(root)
            .create()
        dialogRef[0] = dialog
        openUserDetailDialog?.dismiss()
        openUserDetailDialog = dialog
        btnX.setOnClickListener {
            haptic()
            dialog.dismiss()
            if (openUserDetailDialog === dialog) openUserDetailDialog = null
        }
        dialog.setOnDismissListener {
            if (openUserDetailDialog === dialog) openUserDetailDialog = null
        }
        dialog.show()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        val w = (host.resources.displayMetrics.widthPixels * 0.88f).toInt()
        dialog.window?.setLayout(w, LinearLayout.LayoutParams.WRAP_CONTENT)
    }


    private fun isSelfUser(u: SupabaseBanClient.UserRow): Boolean {
        val myUid = prefs.getUserUid()
        if (myUid.isNotBlank() && u.userId == myUid) return true
        val myEmail = prefs.getUserEmail().trim()
        if (myEmail.isNotBlank() && u.email.trim().equals(myEmail, ignoreCase = true)) return true
        return false
    }

    private fun isTargetSuperAdmin(u: SupabaseBanClient.UserRow): Boolean {
        return u.isSuperAdmin
    }

    private fun handleBanPick(u: SupabaseBanClient.UserRow) {
        if (isSelfUser(u) || isTargetSuperAdmin(u) && isSelfUser(u)) {
            Toast.makeText(host, LocaleHelper.t(host, "cannot_ban_self"), Toast.LENGTH_SHORT).show()
            return
        }
        if (isTargetSuperAdmin(u)) {
            Toast.makeText(host, LocaleHelper.t(host, "cannot_ban_this_admin"), Toast.LENGTH_SHORT).show()
            return
        }
        if (isSelfUser(u)) {
            Toast.makeText(host, LocaleHelper.t(host, "cannot_ban_self"), Toast.LENGTH_SHORT).show()
            return
        }
        val banned = bannedUsers.contains(u.userId)
        if (banned) confirmUnban(u) { load() } else confirmBan(u) { load() }
    }

    private fun handleRolePick(u: SupabaseBanClient.UserRow) {
        if (isSelfUser(u)) {
            Toast.makeText(host, LocaleHelper.t(host, "cannot_change_own_role"), Toast.LENGTH_SHORT).show()
            return
        }
        if (isTargetSuperAdmin(u)) {
            Toast.makeText(host, LocaleHelper.t(host, "cannot_change_this_admin_role"), Toast.LENGTH_SHORT).show()
            return
        }
        if (!canManageTarget(u)) {
            Toast.makeText(host, LocaleHelper.t(host, "cannot_change_this_admin_role"), Toast.LENGTH_SHORT).show()
            return
        }
        showRolePicker(u) { load() }
    }

    private fun confirmUnban(u: SupabaseBanClient.UserRow, onDone: (() -> Unit)? = null) {
        val adminId = prefs.getUserUid()
        val name = u.nombre.ifBlank { u.email.ifBlank { u.userId } }
        val message = LocaleHelper.t(host, "unban_success").replace("%s", name).let {
            // reuse confirm style: ask first
            "¿Desbanear a $name?"
        }
        // localized soft confirm - use confirm + name
        val box = LinearLayout(host).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 20)
            setBackgroundResource(R.drawable.bg_card)
        }
        val msg = TextView(host).apply {
            text = "Unban: $name"
            setTextColor(Color.parseColor("#F5F5F7"))
            textSize = 15f
            setPadding(0, 0, 0, 28)
        }
        // Prefer existing confirm_ban inverted message if any - use simple
        try {
            msg.text = LocaleHelper.t(host, "confirm").let { c ->
                when (LocaleHelper.getLang(host)) {
                    "es" -> "¿Desbanear a $name?"
                    "pt" -> "Desbanir $name?"
                    "id" -> "Buka blokir $name?"
                    else -> "Unban $name?"
                }
            }
        } catch (_: Exception) {}
        val row = LinearLayout(host).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val btnConfirm = TextView(host).apply {
            text = LocaleHelper.t(host, "confirm")
            setTextColor(Color.parseColor("#69F0AE"))
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(8, 12, 8, 12)
        }
        val spacer = android.widget.Space(host).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        }
        val btnCancel = TextView(host).apply {
            text = LocaleHelper.t(host, "cancel")
            setTextColor(Color.parseColor("#FF1744"))
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(8, 12, 8, 12)
        }
        row.addView(btnConfirm)
        row.addView(spacer)
        row.addView(btnCancel)
        box.addView(msg)
        box.addView(row)
        val dlg = AlertDialog.Builder(host).setView(box).create()
        btnConfirm.setOnClickListener {
            haptic()
            dlg.dismiss()
            Thread {
                try {
                    SupabaseBanClient.adminUnban(adminId, u.userId, u.deviceId)
                    host.runOnUiThread {
                        onDone?.invoke()
                        Toast.makeText(
                            host,
                            LocaleHelper.t(host, "unban_success").replace("%s", name),
                            Toast.LENGTH_LONG
                        ).show()
                        load()
                    }
                } catch (e: Exception) {
                    host.runOnUiThread {
                        Toast.makeText(host, e.message ?: "Error", Toast.LENGTH_LONG).show()
                    }
                }
            }.start()
        }
        btnCancel.setOnClickListener { haptic(); dlg.dismiss() }
        dlg.show()
        dlg.window?.setBackgroundDrawableResource(android.R.color.transparent)
    }

    private fun confirmBan(u: SupabaseBanClient.UserRow, onDone: (() -> Unit)? = null) {
        if (isSelfUser(u)) {
            Toast.makeText(host, LocaleHelper.t(host, "cannot_ban_self"), Toast.LENGTH_SHORT).show()
            return
        }
        if (isTargetSuperAdmin(u)) {
            Toast.makeText(host, LocaleHelper.t(host, "cannot_ban_this_admin"), Toast.LENGTH_SHORT).show()
            return
        }
        val adminId = prefs.getUserUid()
        val box = LinearLayout(host).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 20)
            setBackgroundResource(R.drawable.bg_card)
        }
        val msg = TextView(host).apply {
            text = LocaleHelper.t(host, "confirm_ban")
            setTextColor(Color.parseColor("#F5F5F7"))
            textSize = 15f
            setPadding(0, 0, 0, 28)
        }
        val row = LinearLayout(host).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val btnConfirm = TextView(host).apply {
            text = LocaleHelper.t(host, "confirm")
            setTextColor(Color.parseColor("#69F0AE"))
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(8, 12, 8, 12)
        }
        val spacer = android.widget.Space(host).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        }
        val btnCancel = TextView(host).apply {
            text = LocaleHelper.t(host, "cancel")
            setTextColor(Color.parseColor("#FF1744"))
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(8, 12, 8, 12)
        }
        row.addView(btnConfirm)
        row.addView(spacer)
        row.addView(btnCancel)
        box.addView(msg)
        box.addView(row)
        val dlg = AlertDialog.Builder(host).setView(box).create()
        btnConfirm.setOnClickListener {
            haptic()
            dlg.dismiss()
            val name = u.nombre.ifBlank { u.email.ifBlank { u.userId } }
            Thread {
                try {
                    if (u.userId.isBlank() && u.deviceId.isBlank()) {
                        throw IllegalStateException("No user_id / device_id")
                    }
                    SupabaseBanClient.adminBan(adminId, u.userId, u.deviceId, "banned from app", u.email)
                    host.runOnUiThread {
                        onDone?.invoke()
                        Toast.makeText(
                            host,
                            LocaleHelper.t(host, "ban_success").replace("%s", name),
                            Toast.LENGTH_LONG
                        ).show()
                        load()
                    }
                } catch (e: Exception) {
                    host.runOnUiThread {
                        Toast.makeText(host, e.message ?: "Error", Toast.LENGTH_LONG).show()
                    }
                }
            }.start()
        }
        btnCancel.setOnClickListener { haptic(); dlg.dismiss() }
        dlg.show()
        dlg.window?.setBackgroundDrawableResource(android.R.color.transparent)
    }

    private fun showRolePicker(u: SupabaseBanClient.UserRow, onDone: (() -> Unit)? = null) {
        val current = u.role.ifBlank { "USER" }.uppercase()
        // Current role first, then the others
        val baseRoles = if (isSuperAdmin()) {
            listOf("ADMIN", "TESTER", "USER")
        } else {
            listOf("TESTER", "USER") // otros admin no pueden asignar ADMIN
        }
        val others = baseRoles.filter { !it.equals(current, true) }
        val roles = listOf(current) + others

        val box = LinearLayout(host).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 20, 20, 16)
        }
        val header = LinearLayout(host).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, 12)
        }
        val title = TextView(host).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            text = "ROL"
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 18f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val btnCloseRole = TextView(host).apply {
            text = "✕"
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 20f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(16, 4, 8, 4)
        }
        header.addView(title)
        header.addView(btnCloseRole)
        box.addView(header)

        val dlg = AlertDialog.Builder(host).setView(box).create()
        btnCloseRole.setOnClickListener { dlg.dismiss() }

        for (r in roles) {
            val tv = TextView(host).apply {
                text = r
                textSize = 16f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setPadding(8, 18, 8, 18)
                setTextColor(
                    Color.parseColor(
                        when (r) {
                            "ADMIN" -> "#FF1744"
                            "TESTER" -> "#FFC107"
                            else -> "#FFFFFF"
                        }
                    )
                )
                setOnClickListener {
                    haptic()
                    dlg.dismiss()
                    if (r.equals(current, true)) {
                        onDone?.invoke()
                        return@setOnClickListener
                    }
                    if (isSelfUser(u)) {
                        Toast.makeText(host, LocaleHelper.t(host, "cannot_change_own_role"), Toast.LENGTH_SHORT).show()
                        return@setOnClickListener
                    }
                    if (isTargetSuperAdmin(u)) {
                        Toast.makeText(host, LocaleHelper.t(host, "cannot_change_this_admin_role"), Toast.LENGTH_SHORT).show()
                        return@setOnClickListener
                    }
                    if (!canManageTarget(u)) {
                        Toast.makeText(host, LocaleHelper.t(host, "cannot_change_this_admin_role"), Toast.LENGTH_SHORT).show()
                        return@setOnClickListener
                    }
                    if (r.equals("ADMIN", true) && !isSuperAdmin()) return@setOnClickListener
                    confirmRoleChange(u, r, onDone)
                }
            }
            box.addView(tv)
        }
        dlg.show()
    }

    private fun confirmRoleChange(u: SupabaseBanClient.UserRow, next: String, onDone: (() -> Unit)? = null) {
        val adminId = prefs.getUserUid()
        val message = LocaleHelper.t(host, "confirm_role").replace("%s", next)
        val box = LinearLayout(host).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 20)
            setBackgroundResource(R.drawable.bg_card)
        }
        val msg = TextView(host).apply {
            text = message
            setTextColor(Color.parseColor("#F5F5F7"))
            textSize = 15f
            setPadding(0, 0, 0, 28)
        }
        val row = LinearLayout(host).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val btnConfirm = TextView(host).apply {
            text = LocaleHelper.t(host, "confirm")
            setTextColor(Color.parseColor("#69F0AE"))
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(8, 12, 8, 12)
        }
        val spacer = android.widget.Space(host).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        }
        val btnCancel = TextView(host).apply {
            text = LocaleHelper.t(host, "cancel")
            setTextColor(Color.parseColor("#FF1744"))
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(8, 12, 8, 12)
        }
        row.addView(btnConfirm)
        row.addView(spacer)
        row.addView(btnCancel)
        box.addView(msg)
        box.addView(row)
        val dlg = AlertDialog.Builder(host).setView(box).create()
        btnConfirm.setOnClickListener {
            haptic()
            if (!canManageTarget(u)) {
                dlg.dismiss()
                return@setOnClickListener
            }
            if (next.equals("ADMIN", true) && !isSuperAdmin()) {
                dlg.dismiss()
                return@setOnClickListener
            }
            dlg.dismiss()
            Thread {
                try {
                    SupabaseBanClient.adminSetRole(adminId, u.userId, next)
                    host.runOnUiThread {
                        onDone?.invoke()
                        load()
                    }
                } catch (e: Exception) {
                    host.runOnUiThread {
                        Toast.makeText(host, e.message, Toast.LENGTH_LONG).show()
                    }
                }
            }.start()
        }
        btnCancel.setOnClickListener { haptic(); dlg.dismiss() }
        dlg.show()
        dlg.window?.setBackgroundDrawableResource(android.R.color.transparent)
    }

    private fun haptic() {
        try {
            host.currentFocus?.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)
                ?: host.window.decorView.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)
        } catch (_: Exception) {}
    }
}
