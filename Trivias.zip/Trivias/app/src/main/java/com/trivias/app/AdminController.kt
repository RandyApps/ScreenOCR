package com.trivias.app

import android.graphics.Color
import android.graphics.Typeface
import android.view.View
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding
import androidx.core.content.ContextCompat

class AdminController(
    private val host: AppCompatActivity,
    private val root: View
) {
    private fun <T : View> fid(id: Int): T = root.findViewById(id)


    private lateinit var prefs: PrefsHelper
    private lateinit var userList: LinearLayout
    private lateinit var tvStatus: TextView
    private lateinit var tvOnlineCount: TextView
    private var bannedUsers = emptySet<String>()
    private var floatHintToast: Toast? = null
    private var allUsers: List<SupabaseBanClient.UserRow> = emptyList()
    private var filterQuery: String = ""


    private val SUPER_ADMIN_EMAIL = "randy.vargas51@gmail.com"

    private var edgeStartX = 0f
    private var edgeStartY = 0f
    private var edgeTracking = false
    private var closingAdmin = false
    var onClose: (() -> Unit)? = null
    var onShowHideChanged: (() -> Unit)? = null

    fun bind() {
        prefs = PrefsHelper(host)
        val role = prefs.getUserRole()
        if (!role.equals("ADMIN", ignoreCase = true)) {
            Toast.makeText(host, "Solo ADMIN", Toast.LENGTH_SHORT).show()
            return
        }
        fid<TextView>(R.id.tvAdminTitle).text = LocaleHelper.t(host, "admin_panel_title")
        // Super-admin: siempre puede capturar; sincroniza email si hace falta
        run {
            val em = try {
                val p = prefs.getUserEmail().trim()
                if (p.isNotEmpty()) p
                else com.google.android.gms.auth.api.signin.GoogleSignIn
                    .getLastSignedInAccount(host)?.email?.trim().orEmpty()
            } catch (_: Exception) { prefs.getUserEmail().trim() }
            if (em.isNotEmpty() && prefs.getUserEmail().trim().isEmpty()) {
                try { prefs.setUserEmail(em) } catch (_: Exception) {}
            }
            val allowCapture = em.equals(SUPER_ADMIN_EMAIL, ignoreCase = true)
            if (allowCapture) {
                host.window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
            } else {
                host.window.setFlags(
                    android.view.WindowManager.LayoutParams.FLAG_SECURE,
                    android.view.WindowManager.LayoutParams.FLAG_SECURE
                )
            }
        }
        // overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)

        userList = fid(R.id.userList)
        tvStatus = fid(R.id.tvStatus)
        tvOnlineCount = fid(R.id.tvOnlineCount)
        
        fid<Button>(R.id.btnClose).setOnClickListener { requestClose() }
        fid<Button>(R.id.btnRefresh).setOnClickListener { load() }

        val btnShowHide = fid<Button>(R.id.btnShowHideTest)
        refreshShowHideButton()
        // AUTO-CLICK solo desde el panel principal (btnAutoClick); no se toca aquí
        btnShowHide.setOnClickListener {
            haptic()
            if (!prefs.isAdmin()) return@setOnClickListener
            val willShow = !prefs.isTestChatPanelVisible()
            prefs.setTestChatPanelVisible(willShow)
            refreshShowHideButton()
            onShowHideChanged?.invoke()
            if (willShow) {
                showFloatOpenedHint()
            }
        }
        // Solo ADMIN puede usar Mostrar/Ocultar
        btnShowHide.isEnabled = prefs.isAdmin()
        btnShowHide.alpha = if (prefs.isAdmin()) 1f else 0.4f

        val btnUpdate = fid<Button>(R.id.btnForceUpdate)
        btnUpdate.text = LocaleHelper.t(host, "btn_update")
        btnUpdate.setTypeface(btnUpdate.typeface, android.graphics.Typeface.BOLD)
        btnUpdate.setTextColor(Color.WHITE)
        btnUpdate.backgroundTintList = null
        btnUpdate.setBackgroundResource(R.drawable.bg_restrict_btn)
        val canUpdate = isSuperAdmin()
        btnUpdate.isEnabled = canUpdate
        btnUpdate.alpha = if (canUpdate) 1f else 0.4f
        btnUpdate.setOnClickListener {
            haptic()
            if (!isSuperAdmin()) return@setOnClickListener
            showForceUpdateConfig()
        }


        val btnRestrict = fid<Button>(R.id.btnRestrictAccess)
        btnRestrict.text = LocaleHelper.t(host, "restrict_access")
        btnRestrict.setTypeface(btnRestrict.typeface, android.graphics.Typeface.BOLD)
        btnRestrict.setTextColor(Color.WHITE)
        btnRestrict.backgroundTintList = null
        btnRestrict.setBackgroundResource(R.drawable.bg_restrict_btn)
        val isSuper = isSuperAdmin()
        btnRestrict.isEnabled = isSuper
        btnRestrict.alpha = if (isSuper) 1f else 0.4f
        btnRestrict.setOnClickListener {
            haptic()
            if (!isSuperAdmin()) return@setOnClickListener
            showRestrictAccessMenu()
        }

        val etFilter = fid<android.widget.EditText>(R.id.etUserFilter)
        etFilter.hint = LocaleHelper.t(host, "filter_users")
        try {
            val searchIcon = ContextCompat.getDrawable(host, R.drawable.ic_search)
            searchIcon?.setBounds(0, 0, 40, 40)
            etFilter.setCompoundDrawablesRelative(searchIcon, null, null, null)
        } catch (_: Exception) {}
        etFilter.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                filterQuery = s?.toString()?.trim().orEmpty()
                renderFiltered()
            }
        })

        SessionRealtimeWatcher.attach(host)
        load()
    }

    fun refreshShowHideButton() {
        try {
            val btn = fid<Button>(R.id.btnShowHideTest) ?: return
            btn.text = if (prefs.isTestChatPanelVisible()) {
                LocaleHelper.t(host, "hide")
            } else {
                LocaleHelper.t(host, "show")
            }
        } catch (_: Exception) {}
    }

    fun requestClose() {
        floatHintToast?.cancel()
        floatHintToast = null
        onClose?.invoke()
    }

    fun onHostResume() {
        if (!prefs.canAccessAdminPanel()) {
            onClose?.invoke()
            return
        }
        SessionRealtimeWatcher.attach(host)
        refreshShowHideButton()
        load()
    }

    // Swipe lo gestiona MainActivity (paneles reales)

    private fun animateMainPeekTo(targetX: Float, hideAfter: Boolean, end: (() -> Unit)? = null) {
        try {
            val w = host.resources.displayMetrics.widthPixels.toFloat()
            val peek = fid<View>(R.id.mainPeek) ?: run {
                end?.invoke()
                return
            }
            peek.visibility = View.VISIBLE
            peek.animate().cancel()
            peek.animate()
                .translationX(targetX.coerceIn(-w, 0f))
                .setDuration(180)
                .withEndAction {
                    if (hideAfter) {
                        peek.translationX = -w
                        peek.visibility = View.GONE
                    }
                    end?.invoke()
                }
                .start()
        } catch (_: Exception) {
            end?.invoke()
        }
    }

    private fun resolveAccountEmail(): String {
        val fromPrefs = prefs.getUserEmail().trim()
        if (fromPrefs.isNotEmpty()) return fromPrefs
        return try {
            com.google.android.gms.auth.api.signin.GoogleSignIn
                .getLastSignedInAccount(host)?.email?.trim().orEmpty()
        } catch (_: Exception) {
            ""
        }
    }

    private fun isSuperAdmin(): Boolean {
        val email = resolveAccountEmail()
        if (email.isNotEmpty() && email != prefs.getUserEmail().trim()) {
            try { prefs.setUserEmail(email) } catch (_: Exception) {}
        }
        return email.equals(SUPER_ADMIN_EMAIL, ignoreCase = true) ||
            prefs.getUserEmail().trim().equals(SUPER_ADMIN_EMAIL, ignoreCase = true)
    }

    private fun canManageTarget(target: SupabaseBanClient.UserRow): Boolean {
        if (prefs.isTester()) return false
        val myUid = prefs.getUserUid()
        if (target.userId == myUid) return false
        if (prefs.getUserEmail().trim().equals(target.email.trim(), ignoreCase = true) &&
            target.email.isNotBlank()
        ) return false
        if (target.email.trim().equals(SUPER_ADMIN_EMAIL, ignoreCase = true)) return false
        val targetIsAdmin = target.role.equals("ADMIN", true)
        if (targetIsAdmin && !isSuperAdmin()) return false
        return true
    }


    private var comingSoonBlink: Animation? = null
    private var onlineDotBlink: Animation? = null

    private fun startComingSoonBlink() { /* replaced by restrict button */ }

    private fun updateOnlineIndicator(online: Int) {
        val dot = fid<View>(R.id.onlineDot)
        val count = fid<TextView>(R.id.tvOnlineCount)
        count.text = online.toString()
        dot.clearAnimation()
        if (online > 0) {
            dot.setBackgroundResource(R.drawable.bg_online_dot)
            onlineDotBlink = AlphaAnimation(1f, 0.2f).apply {
                duration = 700
                repeatMode = Animation.REVERSE
                repeatCount = Animation.INFINITE
            }
            dot.startAnimation(onlineDotBlink)
        } else {
            dot.setBackgroundResource(R.drawable.bg_offline_dot)
        }
    }

    private fun showFloatOpenedHint() {
        floatHintToast?.cancel()
        val toast = Toast.makeText(host, LocaleHelper.t(host, "float_opened_hint"), Toast.LENGTH_LONG)
        // Más arriba: bajo la zona de la línea divisoria (no abajo del todo)
        try {
            toast.setGravity(android.view.Gravity.TOP or android.view.Gravity.CENTER_HORIZONTAL, 0, 280)
        } catch (_: Exception) {}
        floatHintToast = toast
        toast.show()
        // Un solo mensaje ~4s (LENGTH_LONG ~3.5s; cancelar a los 4s por si se alarga)
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            floatHintToast?.cancel()
            floatHintToast = null
        }, 4000)
    }

    private fun load() {
        tvStatus.text = "…"
        val adminId = prefs.getUserUid()
        val asTester = prefs.isTester()
        Thread {
            try {
                val users = SupabaseBanClient.adminListUsers(adminId)
                bannedUsers = try {
                    if (asTester) emptySet()
                    else SupabaseBanClient.adminListBans(adminId).first
                } catch (_: Exception) {
                    emptySet()
                }
                val online = users.count { it.isOnline() }
                host.runOnUiThread {
                    allUsers = if (asTester) {
                        users.filter { it.userId == prefs.getUserUid() }
                    } else {
                        users
                    }
                    val onlineVisible = allUsers.count { it.isOnline() }
                    updateOnlineIndicator(if (asTester) onlineVisible else online)
                    renderFiltered()
                    tvStatus.text = LocaleHelper.t(host, "total_users").replace("%s", allUsers.size.toString())
                }
            } catch (e: Exception) {
                host.runOnUiThread {
                    tvStatus.text = "Error: ${e.message}"
                    Toast.makeText(host, e.message, Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun renderFiltered() {
        val q = filterQuery.lowercase()
        val list = if (q.isBlank()) allUsers else allUsers.filter {
            it.nombre.lowercase().contains(q) || it.email.lowercase().contains(q)
        }
        render(list)
    }

    private fun showRestrictAccessMenu() {
        val box = LinearLayout(host).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 16)
            setBackgroundResource(R.drawable.bg_card)
        }
        val title = TextView(host).apply {
            text = LocaleHelper.t(host, "restrict_access")
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 16f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 0, 0, 16)
        }
        box.addView(title)
        val dlg = AlertDialog.Builder(host).setView(box).create()
        Thread {
            val current = try { SupabaseBanClient.getAccessMode() } catch (_: Exception) { "ALL" }
            host.runOnUiThread {
                fun addOpt(labelKey: String, color: String, mode: String) {
                    val selected = current.equals(mode, true)
                    val row = TextView(host).apply {
                        text = LocaleHelper.t(host, labelKey)
                        setTextColor(if (selected) Color.WHITE else Color.parseColor(color))
                        textSize = 16f
                        setTypeface(typeface, android.graphics.Typeface.BOLD)
                        setPadding(16, 18, 16, 18)
                        if (selected) setBackgroundColor(Color.parseColor(color))
                        setOnClickListener {
                            dlg.dismiss()
                            Thread {
                                try {
                                    SupabaseBanClient.setAccessMode(prefs.getUserUid(), mode)
                                    host.runOnUiThread {
                                        Toast.makeText(host, mode, Toast.LENGTH_SHORT).show()
                                    }
                                } catch (e: Exception) {
                                    host.runOnUiThread {
                                        Toast.makeText(host, e.message, Toast.LENGTH_LONG).show()
                                    }
                                }
                            }.start()
                        }
                    }
                    box.addView(row)
                }
                addOpt("access_all", "#69F0AE", "ALL")
                addOpt("access_admin_only", "#FF1744", "ADMIN")
                addOpt("access_tester", "#FFC107", "TESTER")
                dlg.show()
                dlg.window?.setBackgroundDrawableResource(android.R.color.transparent)
            }
        }.start()
    }

    private fun showForceUpdateConfig() {
        val box = LinearLayout(host).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 16)
            setBackgroundResource(R.drawable.bg_card)
        }
        fun label(t: String) = TextView(host).apply {
            text = t
            setTextColor(Color.WHITE)
            textSize = 13f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 8, 0, 4)
        }
        val etVer = android.widget.EditText(host).apply {
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#9A9AB0"))
            hint = LocaleHelper.t(host, "force_update_version")
            setBackgroundResource(R.drawable.bg_answer_field)
            setPadding(16, 12, 16, 12)
        }
        val etUrl = android.widget.EditText(host).apply {
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#9A9AB0"))
            hint = LocaleHelper.t(host, "force_update_url")
            setBackgroundResource(R.drawable.bg_answer_field)
            setPadding(16, 12, 16, 12)
        }
        val etNews = android.widget.EditText(host).apply {
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#9A9AB0"))
            hint = LocaleHelper.t(host, "force_update_news")
            setBackgroundResource(R.drawable.bg_answer_field)
            setPadding(16, 12, 16, 12)
            minLines = 3
            gravity = android.view.Gravity.TOP or android.view.Gravity.START
        }
        box.addView(label(LocaleHelper.t(host, "force_update_version")))
        box.addView(etVer)
        box.addView(label(LocaleHelper.t(host, "force_update_url")))
        box.addView(etUrl)
        box.addView(label(LocaleHelper.t(host, "force_update_news")))
        box.addView(etNews)
        val dlg = AlertDialog.Builder(host).setView(box).create()
        Thread {
            val info = try {
                SupabaseBanClient.getForceUpdate()
            } catch (_: Exception) {
                SupabaseBanClient.ForceUpdateInfo(false, "", "", "")
            }
            host.runOnUiThread {
                etVer.setText(info.minVersion)
                etUrl.setText(info.apkUrl)
                etNews.setText(info.news)
                val row = LinearLayout(host).apply {
                    orientation = LinearLayout.HORIZONTAL
                    setPadding(0, 20, 0, 0)
                }
                fun save(enabled: Boolean) {
                    dlg.dismiss()
                    val ver = etVer.text?.toString()?.trim().orEmpty()
                    val url = etUrl.text?.toString()?.trim().orEmpty()
                    val news = etNews.text?.toString()?.trim().orEmpty()
                    Thread {
                        try {
                            SupabaseBanClient.setForceUpdate(prefs.getUserUid(), enabled, ver, url, news)
                            host.runOnUiThread {
                                Toast.makeText(
                                    host,
                                    LocaleHelper.t(host, "force_update_saved"),
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        } catch (e: Exception) {
                            host.runOnUiThread {
                                Toast.makeText(host, e.message, Toast.LENGTH_LONG).show()
                            }
                        }
                    }.start()
                }
                val btnOn = TextView(host).apply {
                    text = LocaleHelper.t(host, "force_update_enable")
                    setTextColor(Color.parseColor("#69F0AE"))
                    setTypeface(typeface, android.graphics.Typeface.BOLD)
                    setPadding(8, 12, 8, 12)
                    setOnClickListener { save(true) }
                }
                val spacer = android.widget.Space(host).apply {
                    layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
                }
                val btnOff = TextView(host).apply {
                    text = LocaleHelper.t(host, "force_update_disable")
                    setTextColor(Color.parseColor("#FF1744"))
                    setTypeface(typeface, android.graphics.Typeface.BOLD)
                    setPadding(8, 12, 8, 12)
                    setOnClickListener { save(false) }
                }
                row.addView(btnOn)
                row.addView(spacer)
                row.addView(btnOff)
                box.addView(row)
                dlg.show()
                dlg.window?.setBackgroundDrawableResource(android.R.color.transparent)
            }
        }.start()
    }



    private fun render(users: List<SupabaseBanClient.UserRow>) {
        userList.removeAllViews()
        for (u in users) {
            val banned = bannedUsers.contains(u.userId)
            val row = LinearLayout(host).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(12, 14, 12, 14)
                if (banned) {
                    setBackgroundColor(Color.parseColor("#4D1A1A"))
                }
            }
            val name = TextView(host).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.2f)
                text = u.nombre.ifBlank { u.email.ifBlank { u.userId } }
                setTextColor(Color.parseColor("#F5F5F7"))
                textSize = 14f
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
            }
            val roleTv = TextView(host).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.8f)
                gravity = android.view.Gravity.CENTER
                val r = u.role.ifBlank { "USER" }.uppercase()
                text = r
                textSize = 13f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(
                    when (r) {
                        "ADMIN" -> Color.parseColor("#E040FB")
                        "TESTER" -> Color.parseColor("#FFC107")
                        else -> Color.WHITE
                    }
                )
            }
            val statusTv = TextView(host).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.7f)
                gravity = android.view.Gravity.END
                val online = u.isOnline()
                text = if (online) "ONLINE" else "OFFLINE"
                textSize = 12f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(if (online) Color.parseColor("#69F0AE") else Color.parseColor("#FF1744"))
            }
            row.addView(name)
            row.addView(roleTv)
            row.addView(statusTv)
            row.setOnClickListener {
                haptic()
                showUserDetail(u, banned)
            }
            userList.addView(row)
        }
    }

    private fun showUserDetail(u: SupabaseBanClient.UserRow, banned: Boolean) {
        val adminId = prefs.getUserUid()
        val box = LinearLayout(host).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28)
        }
        val meta = TextView(host).apply {
            fun lastTimeLabel(): String {
                val ms = u.lastSeenMs ?: return "—"
                return try {
                    val cal = java.util.Calendar.getInstance().apply { timeInMillis = ms }
                    val dd = cal.get(java.util.Calendar.DAY_OF_MONTH).toString().padStart(2, '0')
                    val mm = (cal.get(java.util.Calendar.MONTH) + 1).toString().padStart(2, '0')
                    val hh = cal.get(java.util.Calendar.HOUR_OF_DAY).toString().padStart(2, '0')
                    val min = cal.get(java.util.Calendar.MINUTE).toString().padStart(2, '0')
                    "$dd/$mm   |   $hh:$min"
                } catch (_: Exception) {
                    "—"
                }
            }
            val status = if (u.isOnline()) "ONLINE" else "OFFLINE"
            text = "ID:  ${u.userId}\n\n" +
                    "DEVICE:  ${u.deviceId.ifBlank { "—" }}\n\n" +
                    "EMAIL:  ${u.email.ifBlank { "—" }}\n\n" +
                    "ROLE:  ${u.role.ifBlank { "USER" }.uppercase()}\n\n" +
                    "STATUS:  $status\n\n" +
                    "LAST TIME:  ${lastTimeLabel()}"
            setTextColor(Color.parseColor("#F5F5F7"))
            textSize = 13f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 0, 0, 16)
        }
        val actions = LinearLayout(host).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
        }

        val manage = canManageTarget(u)
        val dialogRef = arrayOfNulls<AlertDialog>(1)

        val btnBan = Button(host).apply {
            text = if (banned) "Unban" else "Ban"
            setTextColor(Color.BLACK)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setBackgroundResource(R.drawable.bg_ban_btn)
            isEnabled = manage
            alpha = if (manage) 1f else 0.4f
            setOnClickListener {
                if (!manage) return@setOnClickListener
                haptic()
                if (banned) {
                    isEnabled = false
                    val name = u.nombre.ifBlank { u.email.ifBlank { u.userId } }
                    Thread {
                        try {
                            SupabaseBanClient.adminUnban(adminId, u.userId, u.deviceId)
                            host.runOnUiThread {
                                dialogRef[0]?.dismiss()
                                Toast.makeText(
                                    host,
                                    LocaleHelper.t(host, "unban_success").replace("%s", name),
                                    Toast.LENGTH_LONG
                                ).show()
                                load()
                            }
                        } catch (e: Exception) {
                            host.runOnUiThread {
                                isEnabled = true
                                Toast.makeText(host, e.message, Toast.LENGTH_LONG).show()
                            }
                        }
                    }.start()
                } else {
                    confirmBan(u) { dialogRef[0]?.dismiss() }
                }
            }
        }

        val btnRole = Button(host).apply {
            text = "ROL"
            setTextColor(Color.parseColor("#E040FB"))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setBackgroundResource(R.drawable.bg_admin_btn)
            isEnabled = manage
            alpha = if (manage) 1f else 0.4f
            setOnClickListener {
                if (!manage) return@setOnClickListener
                showRolePicker(u) { dialogRef[0]?.dismiss() }
            }
        }

        // Header with X close
        val header = LinearLayout(host).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val headerTitle = TextView(host).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            text = u.nombre.ifBlank { "Usuario" }
            setTextColor(Color.parseColor("#E040FB"))
            textSize = 18f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val btnX = TextView(host).apply {
            text = "✕"
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 20f
            setPadding(16, 8, 8, 8)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        header.addView(headerTitle)
        header.addView(btnX)

        actions.addView(btnBan)
        actions.addView(btnRole)

        // Layout: header, meta, spacer-ish, actions at bottom with space between
        val root = LinearLayout(host).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 20, 24, 16)
            setBackgroundResource(R.drawable.bg_card)
        }
        root.addView(header)
        root.addView(meta)
        if (!prefs.isTester()) {
            val spacer = android.widget.Space(host).apply {
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 12)
            }
            root.addView(spacer)
            actions.gravity = Gravity.BOTTOM
            // BAN left, ROL right
            actions.gravity = Gravity.CENTER_VERTICAL
            val banLp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            banLp.marginEnd = 8
            btnBan.layoutParams = banLp
            val rolLp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            rolLp.marginStart = 8
            btnRole.layoutParams = rolLp
            root.addView(actions)
        }

        val dialog = AlertDialog.Builder(host)
            .setView(root)
            .create()
        dialogRef[0] = dialog
        btnX.setOnClickListener { dialog.dismiss() }
        dialog.show()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        val w = (host.resources.displayMetrics.widthPixels * 0.88f).toInt()
        dialog.window?.setLayout(w, LinearLayout.LayoutParams.WRAP_CONTENT)
    }

    private fun confirmBan(u: SupabaseBanClient.UserRow, onDone: (() -> Unit)? = null) {
        val adminId = prefs.getUserUid()
        val box = LinearLayout(host).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 20)
            setBackgroundResource(R.drawable.bg_card)
        }
        val msg = TextView(host).apply {
            text = LocaleHelper.t(host, "confirm_ban")
            setTextColor(Color.parseColor("#F5F5F7"))
            textSize = 15f
            setPadding(0, 0, 0, 28)
        }
        val row = LinearLayout(host).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val btnConfirm = TextView(host).apply {
            text = LocaleHelper.t(host, "confirm")
            setTextColor(Color.parseColor("#69F0AE"))
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(8, 12, 8, 12)
        }
        val spacer = android.widget.Space(host).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        }
        val btnCancel = TextView(host).apply {
            text = LocaleHelper.t(host, "cancel")
            setTextColor(Color.parseColor("#FF1744"))
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(8, 12, 8, 12)
        }
        row.addView(btnConfirm)
        row.addView(spacer)
        row.addView(btnCancel)
        box.addView(msg)
        box.addView(row)
        val dlg = AlertDialog.Builder(host).setView(box).create()
        btnConfirm.setOnClickListener {
            dlg.dismiss()
            val name = u.nombre.ifBlank { u.email.ifBlank { u.userId } }
            Thread {
                try {
                    if (u.userId.isBlank() && u.deviceId.isBlank()) {
                        throw IllegalStateException("No user_id / device_id")
                    }
                    SupabaseBanClient.adminBan(adminId, u.userId, u.deviceId, "banned from app", u.email)
                    host.runOnUiThread {
                        onDone?.invoke()
                        Toast.makeText(
                            host,
                            LocaleHelper.t(host, "ban_success").replace("%s", name),
                            Toast.LENGTH_LONG
                        ).show()
                        load()
                    }
                } catch (e: Exception) {
                    host.runOnUiThread {
                        Toast.makeText(host, e.message ?: "Error", Toast.LENGTH_LONG).show()
                    }
                }
            }.start()
        }
        btnCancel.setOnClickListener { dlg.dismiss() }
        dlg.show()
        dlg.window?.setBackgroundDrawableResource(android.R.color.transparent)
    }

    private fun showRolePicker(u: SupabaseBanClient.UserRow, onDone: (() -> Unit)? = null) {
        val current = u.role.ifBlank { "USER" }.uppercase()
        // Current role first, then the others
        val others = listOf("ADMIN", "TESTER", "USER").filter { !it.equals(current, true) }
        val roles = listOf(current) + others

        val box = LinearLayout(host).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 20, 20, 16)
        }
        val header = LinearLayout(host).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, 12)
        }
        val title = TextView(host).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            text = "ROL"
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 18f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val btnCloseRole = TextView(host).apply {
            text = "✕"
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 20f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(16, 4, 8, 4)
        }
        header.addView(title)
        header.addView(btnCloseRole)
        box.addView(header)

        val dlg = AlertDialog.Builder(host).setView(box).create()
        btnCloseRole.setOnClickListener { dlg.dismiss() }

        for (r in roles) {
            val tv = TextView(host).apply {
                text = r
                textSize = 16f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setPadding(8, 18, 8, 18)
                setTextColor(
                    Color.parseColor(
                        when (r) {
                            "ADMIN" -> "#FF1744"
                            "TESTER" -> "#FFC107"
                            else -> "#FFFFFF"
                        }
                    )
                )
                setOnClickListener {
                    dlg.dismiss()
                    if (!r.equals(current, true)) confirmRoleChange(u, r, onDone)
                    else onDone?.invoke()
                }
            }
            box.addView(tv)
        }
        dlg.show()
    }

    private fun confirmRoleChange(u: SupabaseBanClient.UserRow, next: String, onDone: (() -> Unit)? = null) {
        val adminId = prefs.getUserUid()
        val message = LocaleHelper.t(host, "confirm_role").replace("%s", next)
        val box = LinearLayout(host).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 20)
            setBackgroundResource(R.drawable.bg_card)
        }
        val msg = TextView(host).apply {
            text = message
            setTextColor(Color.parseColor("#F5F5F7"))
            textSize = 15f
            setPadding(0, 0, 0, 28)
        }
        val row = LinearLayout(host).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val btnConfirm = TextView(host).apply {
            text = LocaleHelper.t(host, "confirm")
            setTextColor(Color.parseColor("#69F0AE"))
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(8, 12, 8, 12)
        }
        val spacer = android.widget.Space(host).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        }
        val btnCancel = TextView(host).apply {
            text = LocaleHelper.t(host, "cancel")
            setTextColor(Color.parseColor("#FF1744"))
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(8, 12, 8, 12)
        }
        row.addView(btnConfirm)
        row.addView(spacer)
        row.addView(btnCancel)
        box.addView(msg)
        box.addView(row)
        val dlg = AlertDialog.Builder(host).setView(box).create()
        btnConfirm.setOnClickListener {
            dlg.dismiss()
            Thread {
                try {
                    SupabaseBanClient.adminSetRole(adminId, u.userId, next)
                    host.runOnUiThread {
                        onDone?.invoke()
                        load()
                    }
                } catch (e: Exception) {
                    host.runOnUiThread {
                        Toast.makeText(host, e.message, Toast.LENGTH_LONG).show()
                    }
                }
            }.start()
        }
        btnCancel.setOnClickListener { dlg.dismiss() }
        dlg.show()
        dlg.window?.setBackgroundDrawableResource(android.R.color.transparent)
    }

    private fun haptic() {
        try {
            host.currentFocus?.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)
                ?: host.window.decorView.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)
        } catch (_: Exception) {}
    }
}
