package com.trivias.app

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import kotlin.concurrent.thread

class LoginActivity : AppCompatActivity() {

    private lateinit var prefs: PrefsHelper
    private lateinit var googleClient: GoogleSignInClient
    private lateinit var progress: ProgressBar
    private lateinit var tvStatus: TextView
    private lateinit var btnGoogle: View

    private val signInLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        val task = GoogleSignIn.getSignedInAccountFromIntent(data)
        try {
            val account = task.getResult(ApiException::class.java)
            val idToken = account.idToken
            val uid = account.id ?: ""
            val email = account.email ?: ""
            val nombre = account.displayName ?: email.ifBlank { "Usuario" }
            if (idToken.isNullOrBlank()) {
                setLoading(false)
                tvStatus.text = "Falta ID token. Configura GOOGLE_WEB_CLIENT_ID en SupabaseConfig."
                return@registerForActivityResult
            }
            if (uid.isBlank()) {
                setLoading(false)
                tvStatus.text = "No se pudo obtener el ID de Google"
                return@registerForActivityResult
            }
            registerWithBackend(uid, email, nombre, idToken)
        } catch (e: ApiException) {
            setLoading(false)
            tvStatus.text = "Error de Google (${e.statusCode})"
        } catch (e: Exception) {
            setLoading(false)
            tvStatus.text = "Error: ${e.message}"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = PrefsHelper(this)
        applyScreenCapturePolicy()

        if (prefs.isBanned()) {
            goBanned()
            return
        }

        // Sesión local + JWT de Supabase → main (sin mostrar login ni un frame)
        if (prefs.isApproved() && prefs.hasValidAuthSession()) {
            // Validar token en background; no montar UI de Google
            thread {
                try {
                    SupabaseAuth.validAccessToken(prefs)
                } catch (_: Exception) {}
            }
            goMain()
            return
        }

        // Aprobado pero sin JWT (app antigua) → forzar re-login
        if (prefs.isApproved() && !prefs.hasValidAuthSession()) {
            prefs.clearUserSession()
        }

        showLoginUi()
    }

    private fun showLoginUi() {
        setContentView(R.layout.activity_login)
        progress = findViewById(R.id.progress)
        tvStatus = findViewById(R.id.tvStatus)
        btnGoogle = findViewById(R.id.btnGoogleSignIn)

        val webClientId = SupabaseConfig.GOOGLE_WEB_CLIENT_ID.trim()
        if (webClientId.isEmpty()) {
            tvStatus.text = "Configura GOOGLE_WEB_CLIENT_ID (Client ID web de Google) en SupabaseConfig.kt"
        }

        val gsoBuilder = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestProfile()
        if (webClientId.isNotEmpty()) {
            gsoBuilder.requestIdToken(webClientId)
        }
        googleClient = GoogleSignIn.getClient(this, gsoBuilder.build())

        btnGoogle.setOnClickListener {
            tvStatus.text = ""
            if (SupabaseConfig.GOOGLE_WEB_CLIENT_ID.trim().isEmpty()) {
                tvStatus.text = "Falta GOOGLE_WEB_CLIENT_ID en SupabaseConfig.kt"
                return@setOnClickListener
            }
            setLoading(true)
            signInLauncher.launch(googleClient.signInIntent)
        }
    }

    private fun registerWithBackend(uid: String, email: String, nombre: String, idToken: String) {
        setLoading(true)
        thread {
            try {
                // 1) Sesión Supabase Auth (JWT)
                val session = SupabaseAuth.signInWithGoogleIdToken(idToken)
                SupabaseAuth.applySession(prefs, session)

                val deviceId = DeviceIdHelper.get(this@LoginActivity)

                // 2) Ban check (puede usar JWT ya cacheado)
                val ban = try {
                    SupabaseBanClient.checkIfBanned(deviceId, uid, email)
                } catch (_: Exception) {
                    SupabaseBanClient.BanResult(banned = false, checkFailed = true)
                }
                if (ban.checkFailed) {
                    runOnUiThread {
                        setLoading(false)
                        tvStatus.text = LocaleHelper.t(this@LoginActivity, "ban_check_failed")
                    }
                    return@thread
                }
                if (ban.banned) {
                    val status = if (ban.kind == "DEVICE") "DEVICE_BANNED" else "BANNED"
                    prefs.saveUserSession(uid, email, nombre, status, "")
                    runOnUiThread {
                        setLoading(false)
                        goBanned()
                    }
                    return@thread
                }

                // 3) Upsert + rol (RPC autenticadas)
                val role = try {
                    SupabaseBanClient.upsertUser(uid, email, nombre, deviceId)
                } catch (_: Exception) {
                    try {
                        SupabaseBanClient.getUserRole(uid)
                    } catch (_: Exception) {
                        "USER"
                    }
                }

                val finalRole = role.ifBlank { "USER" }
                val mode = try {
                    SupabaseBanClient.getAccessModeOrNull()
                } catch (_: Exception) {
                    null
                }
                runOnUiThread {
                    setLoading(false)
                    val roleOk = if (mode == null) {
                        finalRole.equals("ADMIN", ignoreCase = true)
                    } else {
                        SupabaseBanClient.roleAllowedForMode(finalRole, mode)
                    }
                    if (!roleOk) {
                        tvStatus.text = LocaleHelper.t(this, "access_denied")
                        try {
                            googleClient.signOut()
                        } catch (_: Exception) {}
                        SupabaseAuth.clearCache()
                        prefs.clearUserSession()
                        return@runOnUiThread
                    }
                    try {
                        if (mode != null) prefs.setLastAccessMode(mode)
                    } catch (_: Exception) {}
                    prefs.saveUserSession(uid, email, nombre, "APPROVED", finalRole)
                    try { SupabaseBanClient.fetchAndStorePrivileges(prefs) } catch (_: Exception) {}
                    RoleServerGate.markConfirmed()
                    if (!prefs.hasSeenAboutOnFirstLogin()) {
                        prefs.setPendingShowAbout(true)
                    }
                    goMain()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    setLoading(false)
                    tvStatus.text = "Error de sesión: ${e.message?.take(120) ?: "desconocido"}"
                    SupabaseAuth.clearCache()
                }
            }
        }
    }

    private fun setLoading(loading: Boolean) {
        try {
            progress.visibility = if (loading) View.VISIBLE else View.GONE
            btnGoogle.isEnabled = !loading
            btnGoogle.alpha = if (loading) 0.5f else 1f
        } catch (_: Exception) {}
    }

    private fun goMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private fun goBanned() {
        startActivity(Intent(this, BannedActivity::class.java))
        finish()
    }

    private fun applyScreenCapturePolicy() {
        val allow = try {
            if (::prefs.isInitialized) prefs.isSuperAdmin() else false
        } catch (_: Exception) {
            false
        }
        if (allow) {
            window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        } else {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE
            )
        }
    }
}

