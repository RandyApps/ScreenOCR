package com.trivias.app

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import kotlin.concurrent.thread

class LoginActivity : AppCompatActivity() {

    private lateinit var prefs: PrefsHelper
    private lateinit var googleClient: GoogleSignInClient
    private lateinit var progress: ProgressBar
    private lateinit var tvStatus: TextView
    private lateinit var btnGoogle: View

    private val signInLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        val task = GoogleSignIn.getSignedInAccountFromIntent(data)
        try {
            val account = task.getResult(ApiException::class.java)
            val uid = account.id ?: account.idToken ?: ""
            val email = account.email ?: ""
            val nombre = account.displayName ?: email.ifBlank { "Usuario" }
            if (uid.isBlank()) {
                setLoading(false)
                tvStatus.text = "No se pudo obtener el ID de Google"
                return@registerForActivityResult
            }
            registerWithBackend(uid, email, nombre)
        } catch (e: ApiException) {
            setLoading(false)
            tvStatus.text = "Error de Google (${e.statusCode})"
        } catch (e: Exception) {
            setLoading(false)
            tvStatus.text = "Error: ${e.message}"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        prefs = PrefsHelper(this)

        // Already banned → lock screen
        if (prefs.isBanned()) {
            goBanned()
            return
        }
        // Already approved → main app (refrescar email de Google si falta)
        if (prefs.isApproved()) {
            try {
                val acc = com.google.android.gms.auth.api.signin.GoogleSignIn.getLastSignedInAccount(this)
                val em = acc?.email?.trim().orEmpty()
                if (em.isNotEmpty() && prefs.getUserEmail().trim().isEmpty()) {
                    prefs.setUserEmail(em)
                } else if (em.isNotEmpty()) {
                    prefs.setUserEmail(em)
                }
            } catch (_: Exception) {}
            goMain()
            return
        }

        setContentView(R.layout.activity_login)
        progress = findViewById(R.id.progress)
        tvStatus = findViewById(R.id.tvStatus)
        btnGoogle = findViewById(R.id.btnGoogleSignIn)

        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestProfile()
            .build()
        googleClient = GoogleSignIn.getClient(this, gso)

        // Silent: already signed in with Google
        val existing = GoogleSignIn.getLastSignedInAccount(this)
        if (existing != null && !existing.isExpired) {
            val uid = existing.id ?: ""
            val email = existing.email ?: ""
            val nombre = existing.displayName ?: email
            if (uid.isNotBlank()) {
                setLoading(true)
                registerWithBackend(uid, email, nombre)
            }
        }

        btnGoogle.setOnClickListener {
            tvStatus.text = ""
            setLoading(true)
            signInLauncher.launch(googleClient.signInIntent)
        }
    }

    private fun registerWithBackend(uid: String, email: String, nombre: String) {
        setLoading(true)
        val deviceId = DeviceIdHelper.get(this)
        thread {
            // 1) Ban check on Supabase (source of truth)
            val ban = try {
                SupabaseBanClient.checkIfBanned(deviceId, uid)
            } catch (_: Exception) {
                SupabaseBanClient.BanResult(false)
            }
            if (ban.banned) {
                runOnUiThread {
                    setLoading(false)
                    try { googleClient.signOut() } catch (_: Exception) {}
                    val status = if (ban.kind == "DEVICE") "DEVICE_BANNED" else "BANNED"
                    prefs.saveUserSession(uid, email, nombre, status, "")
                    goBanned()
                }
                return@thread
            }

            // 2) Upsert user in Supabase (role default USER; keeps ADMIN if already set)
            val role = try {
                SupabaseBanClient.upsertUser(uid, email, nombre, deviceId)
            } catch (_: Exception) {
                try { SupabaseBanClient.getUserRole(uid) } catch (_: Exception) { "USER" }
            }

            val finalRole = role.ifBlank { "USER" }
            val mode = try { SupabaseBanClient.getAccessMode() } catch (_: Exception) { "ALL" }
            runOnUiThread {
                setLoading(false)
                if (!SupabaseBanClient.roleAllowedForMode(finalRole, mode)) {
                    tvStatus.text = LocaleHelper.t(this, "access_denied")
                    try { googleClient.signOut() } catch (_: Exception) {}
                    return@runOnUiThread
                }
                prefs.saveUserSession(uid, email, nombre, "APPROVED", finalRole)
                if (!prefs.hasSeenAboutOnFirstLogin()) {
                    prefs.setPendingShowAbout(true)
                }
                goMain()
            }
        }
    }

    private fun setLoading(loading: Boolean) {
        progress.visibility = if (loading) View.VISIBLE else View.GONE
        btnGoogle.isEnabled = !loading
        btnGoogle.alpha = if (loading) 0.5f else 1f
    }

    private fun goMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private fun goBanned() {
        startActivity(Intent(this, BannedActivity::class.java))
        finish()
    }
}
