package com.trivias.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import java.lang.ref.WeakReference
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Polling ~3s: ban + rol + heartbeat.
 * Tablas cerradas con RLS → no hay postgres Realtime con anon;
 * este watcher da efecto "en tiempo real" para ban/rol.
 */
object SessionRealtimeWatcher {
    private val running = AtomicBoolean(false)
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private var activityRef: WeakReference<Activity>? = null
    private var appCtx: Context? = null

    private val tick = object : Runnable {
        override fun run() {
            if (!running.get()) return
            val ctx = appCtx ?: return
            executor.execute {
                try {
                    val prefs = PrefsHelper(ctx)
                    val uid = prefs.getUserUid()
                    val deviceId = DeviceIdHelper.get(ctx)
                    if (uid.isBlank()) return@execute

                    try { SupabaseBanClient.heartbeat(uid) } catch (_: Exception) {}

                    val ban = try {
                        SupabaseBanClient.checkIfBanned(deviceId, uid, prefs.getUserEmail())
                    } catch (_: Exception) {
                        SupabaseBanClient.BanResult(false)
                    }
                    if (ban.banned) {
                        val status = if (ban.kind == "DEVICE") "DEVICE_BANNED" else "BANNED"
                        prefs.saveUserSession(
                            uid, prefs.getUserEmail(), prefs.getUserNombre(), status, prefs.getUserRole()
                        )
                        main.post {
                            val act = activityRef?.get()
                            val c = act ?: ctx
                            // No detection service in Trivias
                            val i = Intent(c, BannedActivity::class.java).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                            }
                            c.startActivity(i)
                            act?.finishAffinity()
                        }
                        return@execute
                    }

                    val role = try {
                        SupabaseBanClient.getUserRole(uid)
                    } catch (_: Exception) {
                        "" // red/error: no cambiar rol local
                    }
                    // Solo actualizar prefs si el servidor respondió un rol real
                    if (role.isNotBlank() && role != prefs.getUserRole()) {
                        prefs.saveUserSession(
                            uid, prefs.getUserEmail(), prefs.getUserNombre(), "APPROVED", role
                        )
                    }
                    val effectiveRole = role.ifBlank { prefs.getUserRole() }
                    // PLAY AGAIN off solo si el SERVIDOR confirmó que ya no es ADMIN
                    // (role en blanco = fallo de red → dejar PLAY AGAIN como estaba)
                    if (role.isNotBlank() && !role.equals("ADMIN", ignoreCase = true)) {
                        try {
                            if (prefs.isPlayAgainEnabled()) prefs.setPlayAgainEnabled(false)
                        } catch (_: Exception) {}
                    }
                    main.post {
                        val act = activityRef?.get()
                        val canPanel = effectiveRole.equals("ADMIN", true)
                        if (!canPanel) {
                            when (act) {
                                is AdminActivity -> act.finish()
                                is MainActivity -> {
                                    // Solo forzar off si el servidor confirmó pérdida de ADMIN
                                    if (role.isNotBlank()) {
                                        act.forcePlayAgainOff("role_lost_watcher")
                                    }
                                    act.kickFromAdminPanelIfNeeded()
                                }
                            }
                        }
                    }
                    // Access mode restriction (real-time)
                    val mode = try {
                        SupabaseBanClient.getAccessMode()
                    } catch (_: Exception) {
                        "ALL"
                    }
                    if (!SupabaseBanClient.roleAllowedForMode(effectiveRole, mode)) {
                        main.post {
                            val act = activityRef?.get()
                            val c = act ?: ctx
                            val i = Intent(c, LoginActivity::class.java).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                            }
                            try {
                                prefs.clearUserSession()
                            } catch (_: Exception) {}
                            c.startActivity(i)
                            act?.finishAffinity()
                        }
                        return@execute
                    }
                } catch (_: Exception) {
                }
            }
            main.postDelayed(this, 3500L)
        }
    }

    fun start(activity: Activity) {
        appCtx = activity.applicationContext
        activityRef = WeakReference(activity)
        if (running.compareAndSet(false, true)) {
            main.removeCallbacks(tick)
            main.post(tick)
        } else {
            activityRef = WeakReference(activity)
        }
    }

    fun attach(activity: Activity) {
        activityRef = WeakReference(activity)
        appCtx = activity.applicationContext
        if (!running.get()) start(activity)
    }

    fun stop() {
        running.set(false)
        main.removeCallbacks(tick)
    }
}
