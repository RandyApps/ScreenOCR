package com.trivias.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

object EnergyScheduler {
    private const val REQ = 71001

    fun schedule(context: Context, triggerAtMs: Long) {
        if (triggerAtMs <= 0L) {
            cancel(context)
            return
        }
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(context)
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMs, pi)
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, triggerAtMs, pi)
            }
        } catch (_: Exception) {
            try { am.set(AlarmManager.RTC_WAKEUP, triggerAtMs, pi) } catch (_: Exception) {}
        }
    }

    fun cancel(context: Context) {
        try {
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.cancel(pending(context))
        } catch (_: Exception) {}
    }

    private fun pending(context: Context): PendingIntent {
        val i = Intent(context, EnergyAlarmReceiver::class.java).setAction(EnergyAlarmReceiver.ACTION_ALARM)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        return PendingIntent.getBroadcast(context, REQ, i, flags)
    }
}
