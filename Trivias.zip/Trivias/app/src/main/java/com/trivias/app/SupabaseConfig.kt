package com.trivias.app

/**
 * Supabase project (bans + roles). Change here if the project changes.
 */
object SupabaseConfig {
    const val URL = "https://rhiiepwoehdpkwkfyiqo.supabase.co"
    const val ANON_KEY = "sb_publishable_M-TP2bex7H5qa7wLDcR9Jw_XIJ-zuQD"

    const val TABLE_BANNED_DEVICES = "banned_devices"
    const val TABLE_BANNED_USERS = "banned_users"
    const val TABLE_USERS = "users"
}
