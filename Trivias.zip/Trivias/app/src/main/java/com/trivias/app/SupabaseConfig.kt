package com.trivias.app

/**
 * Configuración Supabase.
 *
 * IMPORTANTE (v1.1.0): pega aquí el Client ID de tu cliente OAuth **Aplicación web**
 * de Google Cloud (el mismo que configuraste en Supabase → Authentication → Google).
 * Formato: 123456789-xxxx.apps.googleusercontent.com
 * NO pongas el Client Secret en la app.
 */
object SupabaseConfig {
    const val URL = "https://rhiiepwoehdpkwkfyiqo.supabase.co"
    const val ANON_KEY = "sb_publishable_M-TP2bex7H5qa7wLDcR9Jw_XIJ-zuQD"

    /**
     * Client ID web de Google (público). Obligatorio para login seguro v1.1.0.
     * Si está vacío, el login mostrará un error pidiendo configurarlo.
     */
    const val GOOGLE_WEB_CLIENT_ID = "49423071191-f854eo8psvk7gp6tsr7911atdeuh70mc.apps.googleusercontent.com"

    const val TABLE_BANNED_DEVICES = "banned_devices"
    const val TABLE_BANNED_USERS = "banned_users"
    const val TABLE_USERS = "users"
}
