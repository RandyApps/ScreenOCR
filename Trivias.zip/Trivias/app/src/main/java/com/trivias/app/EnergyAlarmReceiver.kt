package com.trivias.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Disparado cuando llega energyRefreshDate: +1 energía, notifica si NOTIFICACIONES ON,
 * y reprograma la siguiente carga de 8h si aún no está al máximo.
 */
class EnergyAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val prefs = PrefsHelper(context)
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) {
            val at = prefs.getEnergyRefreshAtMs()
            if (at > System.currentTimeMillis()) EnergyScheduler.schedule(context, at)
            return
        }
        var cur = prefs.getEnergyCurrent()
        val max = prefs.getEnergyMax().coerceAtLeast(3)
        if (cur < 0) cur = 0
        if (cur < max) {
            cur += 1
            val nextAt = if (cur < max) System.currentTimeMillis() + 8L * 60L * 60L * 1000L else 0L
            prefs.setEnergyState(cur, max, nextAt)
            if (prefs.isNotifDecorEnabled()) {
                EnergyNotifier.showEnergyRestored(context, cur, max)
            }
            if (nextAt > 0L) {
                EnergyScheduler.schedule(context, nextAt)
            } else {
                EnergyScheduler.cancel(context)
            }
        }
        try {
            context.sendBroadcast(Intent(ACTION_ENERGY_UPDATED).setPackage(context.packageName))
        } catch (_: Exception) {}
    }

    companion object {
        const val ACTION_ENERGY_UPDATED = "com.trivias.app.ENERGY_UPDATED"
        const val ACTION_ALARM = "com.trivias.app.ENERGY_ALARM"
    }
}
