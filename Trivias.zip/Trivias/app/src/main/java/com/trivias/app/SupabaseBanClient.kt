package com.trivias.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

/**
 * Cliente Supabase vía RPC (tablas cerradas al anon).
 * Llamar desde hilo de fondo.
 */
object SupabaseBanClient {

    // Super-admin: solo en Supabase (is_super_admin). Nada de email/device en el APK.

    data class BanResult(
        val banned: Boolean,
        val kind: String? = null,
        val reason: String? = null,
        val checkFailed: Boolean = false
    )

    data class UserRow(
        val userId: String,
        val email: String,
        val nombre: String,
        val deviceId: String,
        val role: String,
        val lastSeenMs: Long?,
        val isSuperAdmin: Boolean = false
    ) {
        fun isOnline(nowMs: Long = System.currentTimeMillis()): Boolean {
            val ls = lastSeenMs ?: return false
            return nowMs - ls < 90_000L // 90 s
        }
    }

    fun checkIfBanned(deviceId: String, userId: String?, email: String? = null): BanResult {
        // Exenciones super-admin: solo en SQL (is_banned). Sin hardcode en el APK.
        return try {
            val body = JSONObject()
                .put("p_user_id", userId ?: "")
                .put("p_device_id", deviceId)
            val json = rpc("is_banned", body)
            val banned = json.optBoolean("banned", false)
            val kind = if (json.isNull("kind")) null else json.optString("kind", null)
            BanResult(
                banned = banned,
                kind = kind,
                reason = if (json.isNull("reason")) null else json.optString("reason", null),
                checkFailed = false
            )
        } catch (_: Exception) {
            BanResult(banned = false, checkFailed = true)
        }
    }

    fun upsertUser(userId: String, email: String, nombre: String, deviceId: String): String {
        val body = JSONObject()
            .put("p_user_id", userId)
            .put("p_email", email)
            .put("p_nombre", nombre)
            .put("p_device_id", deviceId)
        val json = rpc("upsert_my_user", body)
        try { heartbeat(userId) } catch (_: Exception) {}
        return json.optString("role", "USER").ifBlank { "USER" }
    }

    fun getUserRole(userId: String): String {
        if (userId.isBlank()) return ""
        return try {
            var raw = rpcRaw("get_my_role", JSONObject().put("p_user_id", userId)).trim()
            if (raw.length >= 2) {
                val a = raw.first()
                val b = raw.last()
                if ((a == '"' && b == '"') || (a == '\'' && b == '\'')) {
                    raw = raw.substring(1, raw.length - 1).trim()
                }
            }
            raw = raw.uppercase()
            if (raw.isBlank() || raw == "NULL" || raw == "NONE") "" else raw
        } catch (_: Exception) {
            // Fallo de red: no inventar USER; el caller conserva el rol local
            ""
        }
    }

    fun heartbeat(userId: String) {
        if (userId.isBlank()) return
        rpc("heartbeat", JSONObject().put("p_user_id", userId))
    }

    fun adminListUsers(adminId: String): List<UserRow> {
        val text = rpcRaw("admin_list_users", JSONObject().put("p_admin_id", adminId))
        val arr = try {
            JSONArray(text)
        } catch (_: Exception) {
            return emptyList()
        }
        val out = ArrayList<UserRow>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(
                UserRow(
                    userId = o.optString("user_id", ""),
                    email = o.optString("email", ""),
                    nombre = o.optString("nombre", ""),
                    deviceId = o.optString("device_id", ""),
                    role = o.optString("role", "USER").ifBlank { "USER" },
                    lastSeenMs = parseTs(o.optString("last_seen", null)),
                    isSuperAdmin = o.optBoolean("is_super_admin", false)
                )
            )
        }
        return out
    }

    fun adminListBans(adminId: String): Pair<Set<String>, Set<String>> {
        val json = rpc("admin_list_bans", JSONObject().put("p_admin_id", adminId))
        val users = mutableSetOf<String>()
        val devices = mutableSetOf<String>()
        val uArr = json.optJSONArray("users")
        if (uArr != null) {
            for (i in 0 until uArr.length()) {
                val o = uArr.getJSONObject(i)
                val id = o.optString("user_id", "").ifBlank { o.optString("uid", "") }
                if (id.isNotBlank()) users.add(id)
            }
        }
        val dArr = json.optJSONArray("devices")
        if (dArr != null) {
            for (i in 0 until dArr.length()) {
                devices.add(dArr.getJSONObject(i).optString("device_id", ""))
            }
        }
        return users to devices
    }

    fun adminBan(adminId: String, userId: String, deviceId: String?, reason: String?, targetEmail: String? = null) {
        // Reglas super-admin en SQL (admin_ban)
        val body = JSONObject()
            .put("p_admin_id", adminId)
            .put("p_user_id", userId)
            .put("p_device_id", deviceId?.trim().orEmpty())
            .put("p_reason", reason ?: "banned from app panel")
        val json = rpc("admin_ban", body)
        if (json.has("ok") && !json.optBoolean("ok", false)) {
            val err = json.optString("error", json.toString())
            throw IllegalStateException(err.ifBlank { "admin_ban failed" })
        }
        if (json.has("error") && json.optString("error").isNotBlank()) {
            throw IllegalStateException(json.optString("error"))
        }
    }

    fun adminUnban(adminId: String, userId: String, deviceId: String?) {
        val body = JSONObject()
            .put("p_admin_id", adminId)
            .put("p_user_id", userId)
            .put("p_device_id", deviceId ?: "")
        rpc("admin_unban", body)
    }

    fun adminSetRole(adminId: String, targetUserId: String, role: String) {
        val body = JSONObject()
            .put("p_admin_id", adminId)
            .put("p_target_user_id", targetUserId)
            .put("p_role", role)
        rpc("admin_set_role", body)
    }

    fun adminDeleteUser(adminId: String, userId: String) {
        if (userId.isBlank()) throw IllegalStateException("userId vacío")
        val body = JSONObject()
            .put("p_admin_id", adminId)
            .put("p_user_id", userId)
        rpc("admin_delete_user", body)
    }

    private fun parseTs(s: String?): Long? {
        if (s.isNullOrBlank() || s == "null") return null
        return try {
            val cleaned = s.replace(" ", "T")
            // Accept ISO-8601 with or without millis / offset
            val patterns = arrayOf(
                "yyyy-MM-dd'T'HH:mm:ss.SSSSSSXXX",
                "yyyy-MM-dd'T'HH:mm:ss.SSSXXX",
                "yyyy-MM-dd'T'HH:mm:ssXXX",
                "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
                "yyyy-MM-dd'T'HH:mm:ss'Z'"
            )
            for (pat in patterns) {
                try {
                    val sdf = java.text.SimpleDateFormat(pat, java.util.Locale.US)
                    sdf.timeZone = java.util.TimeZone.getTimeZone("UTC")
                    return sdf.parse(cleaned)?.time
                } catch (_: Exception) { }
            }
            // Fallback: strip to epoch-ish via Instant if available
            try {
                java.time.Instant.parse(cleaned).toEpochMilli()
            } catch (_: Exception) {
                null
            }
        } catch (_: Exception) {
            null
        }
    }


    /** Busca por pregunta exacta + image_url (o image_file si no hay match de url). */
    /** Parte answer_text por | y elige la que coincida con alguna opción de la trivia. */
    fun pickAnswerForOptions(rawAnswer: String, optionTexts: List<String>): String? {
        val parts = rawAnswer.split("|")
            .map { it.trim() }
            .filter { it.isNotEmpty() }
        if (parts.isEmpty()) return null
        if (optionTexts.isEmpty()) return parts.first()
        // 1) coincidencia exacta (ignore case)
        for (p in parts) {
            val hit = optionTexts.firstOrNull { it.equals(p, ignoreCase = true) }
            if (hit != null) return hit
        }
        // 2) parcial
        for (p in parts) {
            val hit = optionTexts.firstOrNull {
                it.contains(p, ignoreCase = true) || p.contains(it, ignoreCase = true)
            }
            if (hit != null) return hit
        }
        return null
    }

    fun mergeAnswerTexts(existing: String?, newAnswer: String): String {
        val neu = newAnswer.trim()
        if (neu.isEmpty()) return existing?.trim().orEmpty()
        if (existing.isNullOrBlank()) return neu
        val parts = existing.split("|").map { it.trim() }.filter { it.isNotEmpty() }.toMutableList()
        if (parts.none { it.equals(neu, ignoreCase = true) }) {
            parts.add(neu)
        }
        return parts.joinToString(" | ")
    }

    fun lookupTriviaAnswer(
        question: String,
        imageUrl: String = "",
        imageFile: String = ""
    ): String? {
        val q = question.trim()
        if (q.isEmpty()) return null
        return try {
            val body = JSONObject()
                .put("p_question", q)
                .put("p_image_url", imageUrl.trim())
                .put("p_image_file", imageFile.trim())
            val json = rpc("lookup_trivia_answer", body)
            if (json.optBoolean("found", false)) {
                json.optString("answer", "").trim().takeIf { it.isNotEmpty() }
            } else null
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Guarda pregunta + respuesta. Si ya existe la misma pregunta (misma image_url)
     * y la respuesta es distinta, se AÑADE con separador " | " sin borrar la anterior.
     */
    fun saveTriviaAnswer(
        question: String,
        answerText: String,
        imageUrl: String = "",
        imageFile: String = "",
        gameQuestionId: String = ""
    ): Boolean {
        val q = question.trim()
        val a = answerText.trim()
        if (q.isEmpty() || a.isEmpty()) return false
        return try {
            val existing = lookupTriviaAnswer(q, imageUrl, imageFile)
            val merged = mergeAnswerTexts(existing, a)
            val body = JSONObject()
                .put("p_question", q)
                .put("p_answer", merged)
                .put("p_image_url", imageUrl.trim())
                .put("p_image_file", imageFile.trim())
                .put("p_game_question_id", gameQuestionId.trim())
            val json = rpc("save_trivia_answer", body)
            json.optBoolean("ok", false)
        } catch (_: Exception) {
            false
        }
    }


    /** Rol + is_super_admin desde el servidor (JWT). */
    fun fetchAndStorePrivileges(prefs: PrefsHelper): Boolean {
        return try {
            val json = rpc("get_my_privileges", JSONObject())
            prefs.setSuperAdmin(json.optBoolean("is_super_admin", false))
            val role = json.optString("role", "").trim()
            if (role.isNotBlank()) {
                val uid = prefs.getUserUid()
                if (uid.isNotBlank() && role != prefs.getUserRole()) {
                    prefs.saveUserSession(
                        uid,
                        prefs.getUserEmail(),
                        prefs.getUserNombre(),
                        prefs.getUserStatus().ifBlank { "APPROVED" },
                        role
                    )
                }
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun rpc(fn: String, body: JSONObject): JSONObject {
        val text = rpcRaw(fn, body)
        if (text.isBlank()) return JSONObject()
        return try {
            JSONObject(text)
        } catch (_: Exception) {
            JSONObject()
        }
    }

    private fun rpcRaw(fn: String, body: JSONObject): String {
        val url = URL("${SupabaseConfig.URL.trimEnd('/')}/rest/v1/rpc/$fn")
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 20000
        conn.readTimeout = 20000
        conn.requestMethod = "POST"
        conn.doOutput = true
        conn.instanceFollowRedirects = true
        // JWT de usuario si hay sesión; si no, anon (solo para RPCs públicas como is_banned)
        val bearer = SupabaseAuth.cachedAccessToken?.takeIf { it.isNotBlank() } ?: SupabaseConfig.ANON_KEY
        conn.setRequestProperty("apikey", SupabaseConfig.ANON_KEY)
        conn.setRequestProperty("Authorization", "Bearer $bearer")
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("Accept", "application/json")
        OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.let { BufferedReader(InputStreamReader(it, Charsets.UTF_8)).use { r -> r.readText() } } ?: ""
        conn.disconnect()
        if (code !in 200..299) {
            throw IllegalStateException("Supabase RPC $fn HTTP $code: $text")
        }
        return text
    }

    fun getAccessMode(): String {
        return try {
            var raw = rpcRaw("get_access_mode", JSONObject()).trim()
            if (raw.startsWith("\"")) raw = raw.trim('"')
            raw.ifBlank { "ALL" }.uppercase()
        } catch (_: Exception) {
            "ALL"
        }
    }

    fun setAccessMode(adminId: String, mode: String): String {
        val body = JSONObject()
            .put("p_admin_id", adminId)
            .put("p_mode", mode)
        var raw = rpcRaw("set_access_mode", body).trim()
        if (raw.startsWith("\"")) raw = raw.trim('"')
        return raw.ifBlank { mode }.uppercase()
    }

    fun roleAllowedForMode(role: String, mode: String): Boolean {
        val r = role.uppercase()
        return when (mode.uppercase()) {
            "ADMIN" -> r == "ADMIN"
            "TESTER" -> r == "ADMIN" || r == "TESTER"
            else -> true
        }
    }


    data class ForceUpdateInfo(
        val enabled: Boolean,
        val minVersion: String,
        val apkUrl: String,
        val news: String
    )

    fun getForceUpdate(): ForceUpdateInfo {
        return try {
            val raw = rpcRaw("get_force_update", JSONObject()).trim()
            val json = try {
                if (raw.startsWith("{")) JSONObject(raw) else JSONObject()
            } catch (_: Exception) {
                JSONObject()
            }
            val en = json.optString("enabled", "false").trim().equals("true", true) ||
                json.optBoolean("enabled", false)
            ForceUpdateInfo(
                enabled = en,
                minVersion = json.optString("min_version", "").trim(),
                apkUrl = json.optString("apk_url", "").trim(),
                news = json.optString("news", "").trim()
            )
        } catch (_: Exception) {
            ForceUpdateInfo(false, "", "", "")
        }
    }

    fun setForceUpdate(
        adminId: String,
        enabled: Boolean,
        minVersion: String,
        apkUrl: String,
        news: String = ""
    ): Boolean {
        val body = JSONObject()
            .put("p_admin_id", adminId)
            .put("p_enabled", enabled)
            .put("p_min_version", minVersion)
            .put("p_apk_url", apkUrl)
            .put("p_news", news)
        rpcRaw("set_force_update", body)
        return true
    }

}
