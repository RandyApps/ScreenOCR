package com.trivias.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

object GroqClient {
    /**
     * Tries each Groq key in order. On 429 / quota / rate limit, switches to the next key.
     * Returns the assistant text, or null if all keys failed (caller should fall back to ChatGPT).
     */
    fun ask(promptAndQuestion: String): String? {
        val bodyBase = JSONObject()
            .put("model", GroqKeys.MODEL)
            .put(
                "messages",
                JSONArray().put(
                    JSONObject()
                        .put("role", "user")
                        .put("content", promptAndQuestion)
                )
            )
            .put("temperature", 0)
            .put("max_tokens", 128)

        for (key in GroqKeys.groqKeys) {
            if (key.isBlank()) continue
            try {
                val result = requestOnce(key, bodyBase.toString())
                when (result) {
                    is Result.Ok -> {
                        val text = result.text.trim()
                        if (text.isNotEmpty()) return text
                    }
                    is Result.Quota -> continue // next key
                    is Result.Other -> continue
                }
            } catch (_: Exception) {
                continue
            }
        }
        return null
    }

    private sealed class Result {
        data class Ok(val text: String) : Result()
        object Quota : Result()
        object Other : Result()
    }

    private fun requestOnce(apiKey: String, body: String): Result {
        val url = URL(GroqKeys.ENDPOINT)
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 20000
        conn.readTimeout = 30000
        conn.requestMethod = "POST"
        conn.doOutput = true
        conn.setRequestProperty("Authorization", "Bearer $apiKey")
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("Accept", "application/json")
        OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.let { BufferedReader(InputStreamReader(it, Charsets.UTF_8)).use { r -> r.readText() } } ?: ""
        conn.disconnect()

        if (code == 429) return Result.Quota
        if (code !in 200..299) {
            val low = text.lowercase()
            if ("rate" in low || "quota" in low || "limit" in low || "429" in low) return Result.Quota
            return Result.Other
        }
        return try {
            val json = JSONObject(text)
            val choices = json.optJSONArray("choices")
            val content = choices
                ?.optJSONObject(0)
                ?.optJSONObject("message")
                ?.optString("content", "")
                ?.trim()
                .orEmpty()
            if (content.isEmpty()) Result.Other else Result.Ok(content)
        } catch (_: Exception) {
            Result.Other
        }
    }
}
