package com.trivias.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

/**
 * Groq chat completions with server-side [browser_search].
 * Docs: https://console.groq.com/docs/browser-search
 *       https://console.groq.com/docs/tool-use/built-in-tools
 *
 * The tool runs on Groq's servers (single request). tool_choice=required
 * forces a real web search before answering.
 */
object GroqClient {

    fun ask(promptAndQuestion: String): String? {
        val bodyBase = buildRequestBody(promptAndQuestion)

        for (key in GroqKeys.groqKeys) {
            if (key.isBlank()) continue
            try {
                when (val result = requestOnce(key, bodyBase)) {
                    is Result.Ok -> {
                        val cleaned = cleanAnswer(result.text)
                        if (cleaned.isNotEmpty()) return cleaned
                    }
                    is Result.QuotaMinute, is Result.QuotaDay -> continue
                    is Result.Other -> continue
                }
            } catch (_: Exception) {
                continue
            }
        }
        return null
    }

    private fun buildRequestBody(promptAndQuestion: String): String {
        return JSONObject()
            .put("model", GroqKeys.MODEL)
            .put(
                "messages",
                JSONArray().put(
                    JSONObject()
                        .put("role", "user")
                        .put("content", promptAndQuestion)
                )
            )
            .put("temperature", 0)
            .put("max_completion_tokens", 2048)
            // Docs recommend low reasoning with browser_search to save tokens
            .put("reasoning_effort", "low")
            // Force real web search (server-side); not a prompt instruction
            .put("tool_choice", "required")
            .put(
                "tools",
                JSONArray().put(JSONObject().put("type", "browser_search"))
            )
            .toString()
    }

    private sealed class Result {
        data class Ok(val text: String, val usedBrowserSearch: Boolean) : Result()
        /** RPM / TPM — wait or rotate key */
        object QuotaMinute : Result()
        /** RPD / TPD — daily cap */
        object QuotaDay : Result()
        object Other : Result()
    }

    private fun requestOnce(apiKey: String, body: String): Result {
        val url = URL(GroqKeys.ENDPOINT)
        val conn = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 30000
            // Browser search can take longer (server-side tool loop)
            readTimeout = 120000
            requestMethod = "POST"
            doOutput = true
            setRequestProperty("Authorization", "Bearer $apiKey")
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "application/json")
        }
        try {
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.let {
                BufferedReader(InputStreamReader(it, Charsets.UTF_8)).use { r -> r.readText() }
            }.orEmpty()

            if (code == 429) {
                return classify429(text, conn)
            }
            if (code !in 200..299) {
                val low = text.lowercase()
                if ("rate" in low || "quota" in low || "limit" in low) {
                    return if ("day" in low || "daily" in low || "rpd" in low || "tpd" in low)
                        Result.QuotaDay else Result.QuotaMinute
                }
                return Result.Other
            }

            val json = try {
                JSONObject(text)
            } catch (_: Exception) {
                return Result.Other
            }
            val message = json.optJSONArray("choices")
                ?.optJSONObject(0)
                ?.optJSONObject("message")
                ?: return Result.Other

            val usedSearch = messageHasBrowserSearch(message)

            val content = message.optString("content", "").trim()
            if (content.isNotEmpty()) {
                return Result.Ok(content, usedSearch)
            }

            val reasoning = message.optString("reasoning", "").trim()
            if (reasoning.isNotEmpty()) {
                val fromReasoning = extractFromReasoning(reasoning)
                if (fromReasoning.isNotEmpty()) {
                    return Result.Ok(fromReasoning, usedSearch)
                }
            }
            return Result.Other
        } finally {
            conn.disconnect()
        }
    }

    /** Prefer daily vs per-minute when the error body mentions it. */
    private fun classify429(body: String, conn: HttpURLConnection): Result {
        val low = body.lowercase()
        val remainingReq = conn.getHeaderField("x-ratelimit-remaining-requests")
        // Groq docs: remaining-requests tracks RPD
        if ("day" in low || "daily" in low || "rpd" in low || "tpd" in low ||
            remainingReq == "0"
        ) {
            return Result.QuotaDay
        }
        return Result.QuotaMinute
    }

    private fun messageHasBrowserSearch(message: JSONObject): Boolean {
        val executed = message.optJSONArray("executed_tools")
        if (executed != null) {
            for (i in 0 until executed.length()) {
                val t = executed.optJSONObject(i) ?: continue
                val type = t.optString("type", "")
                val name = t.optString("name", "")
                if (type == "browser_search" || name.contains("browser", ignoreCase = true)) {
                    return true
                }
            }
        }
        val toolCalls = message.optJSONArray("tool_calls")
        if (toolCalls != null) {
            for (i in 0 until toolCalls.length()) {
                val t = toolCalls.optJSONObject(i) ?: continue
                val fn = t.optJSONObject("function")
                val name = fn?.optString("name", "") ?: t.optString("type", "")
                if (name.contains("browser", ignoreCase = true) ||
                    name.contains("search", ignoreCase = true)
                ) {
                    return true
                }
            }
        }
        return false
    }

    private fun extractFromReasoning(reasoning: String): String {
        val lines = reasoning.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .toList()
        for (line in lines.asReversed()) {
            val s = line
                .removePrefix("Answer:")
                .removePrefix("answer:")
                .removePrefix("Final answer:")
                .removePrefix("The answer is")
                .trim()
                .trim('"', '\'', '.', ':', '-')
                .trim()
            if (s.isEmpty()) continue
            if (s.length in 2..80 && !looksLikeReasoning(s)) return s
        }
        return ""
    }

    private fun looksLikeReasoning(s: String): Boolean {
        val low = s.lowercase()
        if (s.length > 60) return true
        val markers = listOf(
            "we need", "let's", "i think", "because", "however",
            "the question", "options:", "according to", "probably", "search"
        )
        return markers.any { it in low }
    }

    private fun cleanAnswer(raw: String): String {
        val first = raw.lineSequence()
            .map { it.trim() }
            .firstOrNull { it.isNotEmpty() }
            ?: return ""
        return first
            .removePrefix("Answer:")
            .removePrefix("answer:")
            .trim()
            .trim('"', '\'')
            .trim()
    }
}
