package com.trivias.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

object GroqClient {
    /**
     * Tries each Groq key in order. On 429 / quota / rate limit, switches to the next key.
     * Returns the assistant text, or null if all keys failed (caller should fall back to ChatGPT).
     *
     * Note: openai/gpt-oss-20b often puts long "reasoning" and a short "content".
     * We accept either, and extract a short final answer.
     */
    fun ask(promptAndQuestion: String): String? {
        val bodyBase = JSONObject()
            .put("model", GroqKeys.MODEL)
            .put(
                "messages",
                JSONArray().put(
                    JSONObject()
                        .put("role", "user")
                        .put("content", promptAndQuestion)
                )
            )
            .put("temperature", 0)
            .put("max_completion_tokens", 4096)

        for (key in GroqKeys.groqKeys) {
            if (key.isBlank()) continue
            try {
                when (val result = requestOnce(key, bodyBase.toString())) {
                    is Result.Ok -> {
                        val cleaned = cleanAnswer(result.text)
                        if (cleaned.isNotEmpty()) return cleaned
                    }
                    is Result.Quota -> continue
                    is Result.Other -> continue
                }
            } catch (_: Exception) {
                continue
            }
        }
        return null
    }

    private sealed class Result {
        data class Ok(val text: String) : Result()
        object Quota : Result()
        object Other : Result()
    }

    private fun requestOnce(apiKey: String, body: String): Result {
        val url = URL(GroqKeys.ENDPOINT)
        val conn = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 25000
            readTimeout = 60000
            requestMethod = "POST"
            doOutput = true
            setRequestProperty("Authorization", "Bearer $apiKey")
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "application/json")
        }
        try {
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.let {
                BufferedReader(InputStreamReader(it, Charsets.UTF_8)).use { r -> r.readText() }
            }.orEmpty()

            if (code == 429) return Result.Quota
            if (code !in 200..299) {
                val low = text.lowercase()
                if ("rate" in low || "quota" in low || "limit" in low || "429" in low) return Result.Quota
                return Result.Other
            }

            val json = try {
                JSONObject(text)
            } catch (_: Exception) {
                return Result.Other
            }
            val message = json.optJSONArray("choices")
                ?.optJSONObject(0)
                ?.optJSONObject("message")
                ?: return Result.Other

            // gpt-oss: final answer usually in content; reasoning is long chain-of-thought
            val content = message.optString("content", "").trim()
            if (content.isNotEmpty()) return Result.Ok(content)

            val reasoning = message.optString("reasoning", "").trim()
            if (reasoning.isNotEmpty()) {
                val fromReasoning = extractFromReasoning(reasoning)
                if (fromReasoning.isNotEmpty()) return Result.Ok(fromReasoning)
            }
            return Result.Other
        } finally {
            conn.disconnect()
        }
    }

    /** Prefer short final lines; ignore long reasoning prose. */
    private fun extractFromReasoning(reasoning: String): String {
        val lines = reasoning.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .toList()
        // Look from the end for a short answer-like line
        for (line in lines.asReversed()) {
            val s = line
                .removePrefix("Answer:")
                .removePrefix("answer:")
                .removePrefix("Final answer:")
                .removePrefix("The answer is")
                .trim()
                .trim('"', '\'', '.', ':', '-')
                .trim()
            if (s.isEmpty()) continue
            if (s.length in 2..80 && !looksLikeReasoning(s)) return s
        }
        return ""
    }

    private fun looksLikeReasoning(s: String): Boolean {
        val low = s.lowercase()
        if (s.length > 60) return true
        val markers = listOf(
            "we need", "let's", "i think", "because", "however",
            "the question", "options:", "according to", "probably"
        )
        return markers.any { it in low }
    }

    private fun cleanAnswer(raw: String): String {
        val first = raw.lineSequence()
            .map { it.trim() }
            .firstOrNull { it.isNotEmpty() }
            ?: return ""
        return first
            .removePrefix("Answer:")
            .removePrefix("answer:")
            .trim()
            .trim('"', '\'')
            .trim()
    }
}
