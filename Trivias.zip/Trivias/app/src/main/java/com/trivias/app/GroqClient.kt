package com.trivias.app

import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

/**
 * Cliente de IA vía Supabase Edge Function (proxy a Groq).
 * Las API keys de Groq viven solo en secrets de Supabase, nunca en el APK.
 */
object GroqClient {

    fun ask(promptAndQuestion: String): String? {
        return try {
            val url = URL("${SupabaseConfig.URL.trimEnd('/')}/functions/v1/${GroqKeys.EDGE_FUNCTION}")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 30000
                readTimeout = 120000
                requestMethod = "POST"
                doOutput = true
                setRequestProperty("Authorization", "Bearer ${SupabaseConfig.ANON_KEY}")
                setRequestProperty("apikey", SupabaseConfig.ANON_KEY)
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Accept", "application/json")
            }
            val body = JSONObject().put("prompt", promptAndQuestion).toString()
            try {
                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = stream?.let {
                    BufferedReader(InputStreamReader(it, Charsets.UTF_8)).use { r -> r.readText() }
                }.orEmpty()
                if (code !in 200..299) return null
                val json = try {
                    JSONObject(text)
                } catch (_: Exception) {
                    return cleanAnswer(text)
                }
                if (json.optBoolean("error", false)) return null
                val answer = json.optString("answer", "").trim()
                    .ifBlank { json.optString("content", "").trim() }
                val cleaned = cleanAnswer(answer)
                if (cleaned.isNotEmpty()) cleaned else null
            } finally {
                conn.disconnect()
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun cleanAnswer(raw: String): String {
        val first = raw.lineSequence()
            .map { it.trim() }
            .firstOrNull { it.isNotEmpty() }
            ?: return ""
        return first
            .removePrefix("Answer:")
            .removePrefix("answer:")
            .trim()
            .trim('"', ''')
            .trim()
    }
}
