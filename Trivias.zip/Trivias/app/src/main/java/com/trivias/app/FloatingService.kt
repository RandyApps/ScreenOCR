package com.trivias.app
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.*
import android.widget.Button
import android.widget.TextView

class FloatingService : Service() {
    companion object {
        var instancia: FloatingService? = null
        fun actualizarTexto(texto: String) {
            instancia?.actualizarTextoInterno(texto)
        }
    }
    private lateinit var windowManager: WindowManager
    private lateinit var floatingView: View
    private var txtRespuesta: TextView? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instancia = this
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        floatingView = LayoutInflater.from(this).inflate(R.layout.layout_floating, null)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 0
        params.y = 100
        windowManager.addView(floatingView, params)

        txtRespuesta = floatingView.findViewById<TextView>(R.id.txtRespuesta)
        txtRespuesta?.text = MainActivity.ultimaRespuesta

        floatingView.findViewById<Button>(R.id.btnObtener).setOnClickListener {
            txtRespuesta?.text = MainActivity.ultimaRespuesta
        }
        floatingView.findViewById<Button>(R.id.btnClose).setOnClickListener {
            stopSelf()
        }

        val root = floatingView.findViewById<View>(R.id.rootLayout)
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        root.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - initialTouchX).toInt()
                    params.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager.updateViewLayout(floatingView, params)
                    true
                }
                else -> false
            }
        }
    }
    fun actualizarTextoInterno(texto: String) {
        txtRespuesta?.post { txtRespuesta?.text = texto }
    }
    override fun onDestroy() {
        super.onDestroy()
        instancia = null
        if (::floatingView.isInitialized) windowManager.removeView(floatingView)
    }
}