package com.trivias.app
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class FloatingService : Service() {
    private lateinit var windowManager: WindowManager
    private lateinit var floatingView: android.view.View

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        floatingView = LayoutInflater.from(this).inflate(R.layout.layout_floating, null)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 0
        params.y = 100
        windowManager.addView(floatingView, params)

        val btn = floatingView.findViewById<Button>(R.id.btnObtener)
        val txt = floatingView.findViewById<TextView>(R.id.txtRespuesta)

        btn.setOnClickListener {
            txt.text = "Obteniendo token..."
            // Aquí luego pondremos la lógica de sacar token de WebView
            // Por ahora solo prueba que la ventana funciona
            // Cuando logees, usaremos JS para sacar localStorage
            Toast.makeText(this, "Ventana activa. Logeate y entra a trivia", Toast.LENGTH_LONG).show()
            // Ejemplo: Aquí iría evaluateJavascript para obtener refreshToken
            txt.text = "Listo! Aquí mostraremos la respuesta de la trivia"
        }
    }
    override fun onDestroy() {
        super.onDestroy()
        if (::floatingView.isInitialized) windowManager.removeView(floatingView)
    }
}