package com.trivias.app

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.*
import android.view.*
import android.widget.*

class FloatingService : Service() {
    private var windowManager: WindowManager? = null
    private var floatingView: View? = null
    private lateinit var txtRespuesta: TextView

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        floatingView = LayoutInflater.from(this).inflate(R.layout.overlay_layout, null)
        txtRespuesta = floatingView!!.findViewById(R.id.txtRespuesta)
        floatingView!!.findViewById<TextView>(R.id.txtToken).text = ""
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 20; params.y = 200
        floatingView!!.findViewById<Button>(R.id.btnObtener).setOnClickListener { obtenerRespuestaReal() }
        var ix=0; var iy=0; var itx=0f; var ity=0f
        floatingView!!.setOnTouchListener { _, e ->
            when(e.action){
                MotionEvent.ACTION_DOWN->{ix=params.x; iy=params.y; itx=e.rawX; ity=e.rawY; true}
                MotionEvent.ACTION_MOVE->{params.x=ix+(e.rawX-itx).toInt(); params.y=iy+(e.rawY-ity).toInt(); windowManager?.updateViewLayout(floatingView,params); true}
                else->false
            }
        }
        windowManager?.addView(floatingView, params)
    }

    private fun obtenerRespuestaReal(){
        txtRespuesta.text = "Extrayendo..."
        val wv = MainActivity.webView ?: return

        val js = """
            (function(){
                var html = document.documentElement.innerHTML;
                var body = document.body.innerHTML;
                var result = "";
                
                // 1. Busca patrones donde el servidor esconde la respuesta
                var patterns = [
                    /correctAnswer["']?\s*[:=]\s*["']([^"']+)["']/i,
                    /correct_answer["']?\s*[:=]\s*["']([^"']+)["']/i,
                    /"answer"\s*:\s*"([^"]+)"/i,
                    /isCorrect[^>]*>([^<]+)</i,
                    /data-correct="true"[^>]*>([^<]+)</i,
                    /correct["']?\s*:\s*true[^}]*?text["']?\s*:\s*["']([^"']+)["']/i
                ];
                
                for(var p of patterns){
                    var m = html.match(p);
                    if(m && m[1] && m[1].length < 40){
                        result = m[1];
                        break;
                    }
                }
                
                // 2. Si no, busca en variables JS globales
                if(!result){
                    if(window.__TRIVIA_DATA__ && window.__TRIVIA_DATA__.correctAnswer) result = window.__TRIVIA_DATA__.correctAnswer;
                    if(window.triviaData && window.triviaData.answer) result = window.triviaData.answer;
                    if(window.correctAnswer) result = window.correctAnswer;
                }
                
                // 3. Si no, busca el boton que tiene marca de correcto (aunque este oculto)
                if(!result){
                    var btns = document.querySelectorAll('[data-correct="true"], [data-is-correct="true"], .correct, [correct]');
                    if(btns.length > 0) result = btns[0].innerText;
                }

                return result || "NO_ENCONTRADA::" + html.substring(0,2000);
            })();
        """.trimIndent()

        Handler(Looper.getMainLooper()).post{
            wv.evaluateJavascript(js){ res ->
                var clean = res.replace("\"","").trim()
                clean = clean.replace("\\\"","\"").replace("\\n"," ").replace("\\u003C","<")
                if(clean.startsWith("NO_ENCONTRADA")){
                    txtRespuesta.text = "No la escondieron aquí\nMándame el HTML"
                } else {
                    txtRespuesta.text = clean // Aquí te va a salir "Ronda Rousey" para esa pregunta, y la que sea para las demás
                }
            }
        }
    }

    override fun onDestroy(){ super.onDestroy(); floatingView?.let{ windowManager?.removeView(it)} }
}