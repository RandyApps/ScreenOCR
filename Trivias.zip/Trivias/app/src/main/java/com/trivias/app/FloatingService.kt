package com.trivias.app

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class FloatingService : Service() {
    private var windowManager: WindowManager? = null
    private var floatingView: android.view.View? = null
    private lateinit var txtRespuesta: TextView
    private lateinit var txtToken: TextView

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        floatingView = LayoutInflater.from(this).inflate(R.layout.overlay_layout, null)
        txtRespuesta = floatingView!!.findViewById(R.id.txtRespuesta)
        txtToken = floatingView!!.findViewById(R.id.txtToken)
        txtToken.text = "" // ya no mostramos token

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START; params.x = 20; params.y = 200
        
        floatingView!!.findViewById<Button>(R.id.btnObtener).setOnClickListener { obtenerRespuesta() }
        
        var initialX=0; var initialY=0; var initialTouchX=0f; var initialTouchY=0f
        floatingView!!.setOnTouchListener { _, e ->
            when(e.action){
                MotionEvent.ACTION_DOWN->{initialX=params.x;initialY=params.y;initialTouchX=e.rawX;initialTouchY=e.rawY;true}
                MotionEvent.ACTION_MOVE->{params.x=initialX+(e.rawX-initialTouchX).toInt();params.y=initialY+(e.rawY-initialTouchY).toInt();windowManager?.updateViewLayout(floatingView,params);true}
                else->false
            }
        }
        try{ windowManager?.addView(floatingView, params) }catch(e:Exception){ Toast.makeText(this,"Da permiso flotante",Toast.LENGTH_LONG).show()}
    }

    private fun obtenerRespuesta(){
        txtRespuesta.text = "..."
        val webView = MainActivity.webView ?: return

        val js = "(function(){ var t=document.documentElement.innerText||''; var m=t.match(/Question\\s*\\d+\\s*\\/\\s*\\d+\\s*([\\s\\S]{5,200}\\?)/i); return m?m[1]:t.substring(0,500); })();"

        Handler(Looper.getMainLooper()).post{
            webView.evaluateJavascript(js){ result ->
                var clean = result
                if(clean.startsWith("\"")) clean = clean.substring(1, clean.length-1)
                clean = clean.replace("\\n"," ").replace("\\\"","").trim()
                val lower = clean.lowercase()

                // AQUÍ VA LA RESPUESTA LIMPIA - SOLO EL NOMBRE
                val respuestaFinal = when {
                    lower.contains("seth rollins") && lower.contains("october 31") -> "Austin Theory"
                    lower.contains("bobby lashley") && lower.contains("miz") && lower.contains("finn") -> "Austin Theory"
                    // Agrega más trivias aquí cuando te salgan
                    else -> "Austin Theory" // Para esta trivia específica
                }
                
                txtRespuesta.text = respuestaFinal
            }
        }