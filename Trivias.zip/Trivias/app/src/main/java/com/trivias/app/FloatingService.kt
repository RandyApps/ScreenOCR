private fun obtenerRespuestaReal(){
    txtRespuesta.text = "..."
    val wv = MainActivity.webView ?: return
    
    val js = """
        (function(){
            var token = localStorage.getItem('_captured_token') || localStorage.getItem('token') || localStorage.getItem('authToken') || sessionStorage.getItem('token') || '';
            if(!token){
                var m = document.documentElement.innerHTML.match(/eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+/);
                if(m) token = m[0];
            }
            return (token||'').replace('Bearer ','');
        })();
    """.trimIndent()

    Handler(Looper.getMainLooper()).post{
        wv.evaluateJavascript(js){ result ->
            var token = result.replace("\"","").trim()
            if(token.length < 20){
                token = MainActivity.lastToken
            }
            if(token.length < 20){
                txtRespuesta.text = "Inicia una trivia primero"
                return@evaluateJavascript
            }
            MainActivity.lastToken = token
            txtRespuesta.text = "Consultando..."

            Thread {
                try {
                    // ENDPOINT QUE YA TENÍAMOS - No necesita pregunta
                    val urls = arrayOf(
                        "https://www.wwechampions.com/api/v2/trivia/questions/current",
                        "https://www.wwechampions.com/api/trivia/active",
                        "https://www.wwechampions.com/api/v2/trivia/current"
                    )
                    var finalAns = ""
                    for(apiUrl in urls){
                        try {
                            val conn = URL(apiUrl).openConnection() as HttpURLConnection
                            conn.requestMethod = "GET"
                            conn.setRequestProperty("Authorization", "Bearer $token")
                            conn.setRequestProperty("Content-Type", "application/json")
                            conn.connectTimeout = 5000
                            if(conn.responseCode == 200){
                                val resp = conn.inputStream.bufferedReader().readText()
                                val j = JSONObject(resp)
                                // Intenta sacar la respuesta - estos son los campos que usa WWE Champions
                                finalAns = j.optString("correctAnswer")
                                    .ifEmpty { j.optString("correct_answer") }
                                    .ifEmpty { j.optString("answer") }
                                    .ifEmpty { j.optJSONObject("data")?.optString("correctAnswer") ?: "" }
                                    .ifEmpty { j.optJSONObject("question")?.optString("correctAnswer") ?: "" }
                                if(finalAns.isNotEmpty()) break
                            }
                        } catch(e:Exception){ continue }
                    }
                    Handler(Looper.getMainLooper()).post{
                        txtRespuesta.text = if(finalAns.isNotEmpty()) finalAns else "No devolvió respuesta"
                    }
                } catch(e:Exception){
                    Handler(Looper.getMainLooper()).post{ txtRespuesta.text = "Error: ${e.message}" }
                }
            }.start()
        }
    }
}