package com.trivias.app

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import java.util.regex.Pattern

class FloatingService : Service() {
    private var windowManager: WindowManager? = null
    private var floatingView: android.view.View? = null
    private lateinit var txtRespuesta: TextView
    private lateinit var txtToken: TextView

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        floatingView = LayoutInflater.from(this).inflate(R.layout.overlay_layout, null)
        txtRespuesta = floatingView!!.findViewById(R.id.txtRespuesta)
        txtToken = floatingView!!.findViewById(R.id.txtToken)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START; params.x = 0; params.y = 200

        floatingView!!.findViewById<Button>(R.id.btnObtener).setOnClickListener {
            obtenerRespuesta()
        }

        var initialX = 0; var initialY = 0; var initialTouchX = 0f; var initialTouchY = 0f
        floatingView!!.setOnTouchListener { _, event ->
            when(event.action){
                MotionEvent.ACTION_DOWN -> { initialX=params.x; initialY=params.y; initialTouchX=event.rawX; initialTouchY=event.rawY; true}
                MotionEvent.ACTION_MOVE -> { params.x=initialX+(event.rawX-initialTouchX).toInt(); params.y=initialY+(event.rawY-initialTouchY).toInt(); windowManager?.updateViewLayout(floatingView, params); true}
                else -> false
            }
        }
        try { windowManager?.addView(floatingView, params) } catch(e:Exception){ Toast.makeText(this,"Da permiso flotante",Toast.LENGTH_LONG).show()}
    }

    private fun obtenerRespuesta(){
        txtRespuesta.text = "Leyendo trivia..."
        val webView = MainActivity.webView
        if(webView == null){ txtRespuesta.text = "Abre la web primero"; return }

        // 1. Extraemos todo el texto de la página y el localStorage (donde suele estar el token)
        val js = """
            (function(){
                var body = document.documentElement.innerText || '';
                var token = localStorage.getItem('token') || localStorage.getItem('authToken') || sessionStorage.getItem('token') || '';
                // Busca cualquier JWT en el código
                var html = document.documentElement.innerHTML;
                var m = html.match(/eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+/);
                if(m) token = m[0];
                return JSON.stringify({text: body.substring(0,8000), token: token});
            })();
        """.trimIndent()

        Handler(Looper.getMainLooper()).post {
            webView.evaluateJavascript(js) { result ->
                try {
                    val clean = android.util.Log.getStackTraceString(Exception(result))
                    // result viene con comillas escapadas
                    val jsonStr = result.replace("\\\"","\"").replace("\"{","{").replace("}\"","}").trim('"')
                    // parseo simple
                    val tokenRegex = Pattern.compile("\"token\":\"([^\"]+)\"").matcher(result)
                    val token = if(tokenRegex.find()) tokenRegex.group(1) else "NO_TOKEN"
                    val textRegex = Pattern.compile("\"text\":\"(.*?)\"").matcher(result)
                    var pageText = if(textRegex.find()) textRegex.group(1) else result

                    txtToken.text = "Token: ${token.take(20)}..."
                    
                    // 2. AQUÍ PONES TU LÓGICA DE RESPUESTA
                    // Ejemplo: si tu API es https://tu-api.com/respuesta
                    // Por ahora hago extracción simple de pregunta
                    procesarTrivia(pageText, token)

                } catch (e:Exception){ txtRespuesta.text = "Error: ${e.message}" }
            }
        }
    }

    private fun procesarTrivia(pageText: String, token: String){
        // ESTA ES LA PARTE QUE TÚ TIENES QUE CONECTAR A TU BACKEND
        // Por ahora te muestro la pregunta detectada y cómo llamar a tu API
        
        // Limpia texto para encontrar la pregunta (ejemplo)
        val pregunta = pageText.substring(0, minOf(300, pageText.length))
            .replace("\\n"," ").replace("\\u003C","")

        txtRespuesta.text = "Pregunta detectada:\n$pregunta\n\nToken OK.\n\nLlamando a API..."

        // --- EJEMPLO DE LLAMADA A TU API ---
        // Reemplaza "https://TU_API.com/getAnswer" por tu servidor real
        // donde envías token + pregunta y te devuelve la respuesta
        
        Thread {
            try {
                val url = java.net.URL("https://api.wwechampions.com/api/trivia/answer") // CAMBIA ESTO
                val conn = url.openConnection() as java.net.HttpURLConnection
                conn.requestMethod = "POST"
                conn.setRequestProperty("Authorization", "Bearer $token")
                conn.setRequestProperty("Content-Type", "application/json")
                conn.doOutput = true
                val body = """{"question":"$pregunta"}"""
                conn.outputStream.write(body.toByteArray())
                
                val resp = conn.inputStream.bufferedReader().readText()
                Handler(Looper.getMainLooper()).post {
                    txtRespuesta.text = "RESPUESTA: $resp"
                }
            } catch (e:Exception){
                Handler(Looper.getMainLooper()).post {
                    // Si no tienes API aún, muestra esto para que veas que sí extrae todo
                    txtRespuesta.text = "Token:\n$token\n\nPregunta:\n$pregunta\n\n(Conecta tu API en FloatingService linea 95)"
                }
            }
        }.start()
    }

    override fun onDestroy() { super.onDestroy(); floatingView?.let { windowManager?.removeView(it) } }
}