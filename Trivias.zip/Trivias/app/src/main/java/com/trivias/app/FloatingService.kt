package com.trivias.app

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.*
import android.view.*
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class FloatingService : Service() {
    private var windowManager: WindowManager? = null
    private var floatingView: View? = null
    private lateinit var txtRespuesta: TextView

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        floatingView = LayoutInflater.from(this).inflate(R.layout.overlay_layout, null)
        txtRespuesta = floatingView!!.findViewById(R.id.txtRespuesta)
        floatingView!!.findViewById<TextView>(R.id.txtToken).text = ""
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 20
        params.y = 200
        floatingView!!.findViewById<Button>(R.id.btnObtener).setOnClickListener { obtenerRespuestaReal() }
        var ix = 0; var iy = 0; var itx = 0f; var ity = 0f
        floatingView!!.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { ix = params.x; iy = params.y; itx = e.rawX; ity = e.rawY; true }
                MotionEvent.ACTION_MOVE -> { params.x = ix + (e.rawX - itx).toInt(); params.y = iy + (e.rawY - ity).toInt(); windowManager?.updateViewLayout(floatingView, params); true }
                else -> false
            }
        }
        windowManager?.addView(floatingView, params)
    }

    private fun obtenerRespuestaReal() {
        txtRespuesta.text = "..."
        val wv = MainActivity.webView ?: return
        val js = "(function(){ var t=localStorage.getItem('_captured_token')||localStorage.getItem('token')||localStorage.getItem('authToken')||sessionStorage.getItem('token')||''; if(!t){var m=document.documentElement.innerHTML.match(/eyJ[A-Za-z0-9_-]+\\.[A-Za-z0-9_-]+\\.[A-Za-z0-9_-]+/); if(m) t=m[0];} return (t||'').replace('Bearer ',''); })();"
        
        Handler(Looper.getMainLooper()).post {
            wv.evaluateJavascript(js) { result ->
                var token = result.replace("\"", "").trim()
                if (token.length < 20) token = MainActivity.lastToken
                if (token.length < 20) { txtRespuesta.text = "Inicia trivia primero"; return@evaluateJavascript }
                MainActivity.lastToken = token
                txtRespuesta.text = "Consultando..."

                Thread {
                    try {
                        val urls = arrayOf(
                            "https://prod-api-new.wwechampions.com/api/v2/trivia/questions/current",
                            "https://prod-api-new.wwechampions.com/api/trivia/active",
                            "https://prod-api-new.wwechampions.com/api/v2/trivia/current",
                            "https://prod-api-new.wwechampions.com/trivia/current",
                            "https://prod-api-new.wwechampions.com