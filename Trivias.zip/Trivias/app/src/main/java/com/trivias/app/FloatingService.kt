package com.trivias.app
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.*
import android.widget.Button
import android.widget.TextView

class FloatingService : Service() {
    companion object {
        private var txtRespuesta: TextView? = null
        fun actualizarTexto(texto: String) {
            txtRespuesta?.post { txtRespuesta?.text = texto }
        }
    }

    private lateinit var windowManager: WindowManager
    private lateinit var floatingView: View

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        floatingView = LayoutInflater.from(this).inflate(R.layout.layout_floating, null)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 0
        params.y = 100
        windowManager.addView(floatingView, params)

        val btn = floatingView.findViewById<Button>(R.id.btnObtener)
        txtRespuesta = floatingView.findViewById<TextView>(R.id.txtRespuesta)
        txtRespuesta?.text = MainActivity.ultimaRespuesta

        btn.setOnClickListener {
            txtRespuesta?.text = MainActivity.ultimaRespuesta
            // Re-inyectar por si se perdió
            (MainActivity.instancia as? MainActivity)?.let {
                // No podemos llamar privado, pero el fetch ya está hook
                txtRespuesta?.text = "Escuchando...\n${MainActivity.ultimaRespuesta}"
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::floatingView.isInitialized) windowManager.removeView(floatingView)
    }
}