package com.trivias.app

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.*
import android.view.*
import android.widget.*

class FloatingService : Service() {
    private var windowManager: WindowManager? = null
    private var floatingView: View? = null
    private lateinit var txtRespuesta: TextView
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        floatingView = LayoutInflater.from(this).inflate(R.layout.overlay_layout, null)
        txtRespuesta = floatingView!!.findViewById(R.id.txtRespuesta)
        floatingView!!.findViewById<TextView>(R.id.txtToken).text = ""
        val params = WindowManager.LayoutParams(-2,-2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
        params.gravity = Gravity.TOP or Gravity.START; params.x=20; params.y=200
        floatingView!!.findViewById<Button>(R.id.btnObtener).setOnClickListener { obtener() }
        windowManager?.addView(floatingView, params)
    }
    private fun obtener(){
        txtRespuesta.text = "..."
        val wv = MainActivity.webView ?: return
        wv.evaluateJavascript("localStorage.getItem('_CORRECTA') || ''") { r ->
            val ans = r.replace("\"","").trim()
            txtRespuesta.text = if(ans.length>1 && ans!="null") ans else "Dale PLAY y espera 1 seg luego OBTENER"
        }
    }
    override fun onDestroy(){ super.onDestroy(); floatingView?.let{ windowManager?.removeView(it)} }
}