package com.trivias.app

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    companion object { var webView: WebView? = null }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        val btnPermiso = findViewById<Button>(R.id.btnPermiso)
        val btnFlotante = findViewById<Button>(R.id.btnFlotante)
        val webViewLocal = findViewById<WebView>(R.id.webView)
        webView = webViewLocal
        
        webViewLocal.settings.javaScriptEnabled = true
        webViewLocal.settings.domStorageEnabled = true
        
        // ESTO ES LO QUE FALTA PARA ROBARLA ANTES
        webViewLocal.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                view?.evaluateJavascript("""
                (function(){
                    var _fetch = window.fetch;
                    window.fetch = function(){
                        return _fetch.apply(this, arguments).then(function(r){
                            var c = r.clone();
                            c.text().then(function(t){
                                if(t.includes("correctAnswer")){
                                    try{
                                        var j=JSON.parse(t);
                                        var a=j.correctAnswer || j.data?.correctAnswer || "";
                                        if(a) localStorage.setItem('_CORRECTA', a);
                                    }catch(e){}
                                }
                            });
                            return r;
                        });
                    };
                })();
                """.trimIndent(), null)
            }
        }
        webViewLocal.loadUrl("https://www.wwechampions.com/trivia")

        btnPermiso.setOnClickListener {
            Toast.makeText(this, "Click PERMISO", Toast.LENGTH_SHORT).show()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                startActivity(intent)
            }
        }

        btnFlotante.setOnClickListener {
            Toast.makeText(this, "Click FLOTANTE", Toast.LENGTH_SHORT).show()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Primero dale a PERMISO", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            startService(Intent(this, FloatingService::class.java))
        }
    }
}