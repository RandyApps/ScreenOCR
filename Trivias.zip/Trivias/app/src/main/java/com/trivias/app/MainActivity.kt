package com.trivias.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.*
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    companion object {
        var webView: WebView? = null
        var lastToken: String = ""
        var lastTriviaId: String = ""
        var lastApiUrl: String = ""
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val wv = findViewById<WebView>(R.id.webView)
        webView = wv
        
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        
        // ESTE CÓDIGO INYECTA UN ESPIA EN LA PÁGINA
        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                // Interceptamos todos los fetch para robar el token y la url de la API
                view?.evaluateJavascript("""
                (function() {
                    const origFetch = window.fetch;
                    window.fetch = async function(...args) {
                        let url = args[0];
                        let opts = args[1] || {};
                        // Guardamos token y url de trivia
                        if(url.toString().includes('trivia') || url.toString().includes('api')) {
                            window.AndroidLog && window.AndroidLog.log(url.toString());
                            if(opts.headers && opts.headers['Authorization']){
                                localStorage.setItem('_captured_token', opts.headers['Authorization']);
                            }
                        }
                        let res = await origFetch.apply(this, args);
                        return res;
                    };
                    // También para XHR
                    const open = XMLHttpRequest.prototype.open;
                    XMLHttpRequest.prototype.open = function(m,u){ this._url=u; return open.apply(this, arguments); }
                    const send = XMLHttpRequest.prototype.send;
                    XMLHttpRequest.prototype.send = function(){
                        if(this._url && this._url.includes('trivia')){
                            console.log('TRIVIA_URL:'+this._url);
                        }
                        return send.apply(this, arguments);
                    }
                })();
                """.trimIndent(), null)
            }
        }
        wv.webChromeClient = object : WebChromeClient(){
            override fun onConsoleMessage(msg: ConsoleMessage?): Boolean {
                val txt = msg?.message() ?: ""
                if(txt.startsWith("TRIVIA_URL:")){
                    lastApiUrl = txt.replace("TRIVIA_URL:","")
                }
                return super.onConsoleMessage(msg)
            }
        }
        wv.addJavascriptInterface(JsBridge(), "AndroidBridge")

        wv.loadUrl("https://www.wwechampions.com")

        findViewById<Button>(R.id.btnPermiso).setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        findViewById<Button>(R.id.btnAbrir).setOnClickListener {
            startService(Intent(this, FloatingService::class.java))
        }
    }

    class JsBridge {
        @JavascriptInterface
        fun onTokenCaptured(token: String, triviaId: String, apiUrl: String){
            lastToken = token
            lastTriviaId = triviaId
            lastApiUrl = apiUrl
        }
    }
}