package com.trivias.app

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    companion object {
        var webView: WebView? = null
        var lastToken: String = ""
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        webView = findViewById(R.id.webView)
        webView!!.settings.javaScriptEnabled = true
        webView!!.settings.domStorageEnabled = true

        webView!!.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                view?.evaluateJavascript("""
                (function(){
                    // Intercepta fetch
                    var _fetch = window.fetch;
                    window.fetch = function(){
                        return _fetch.apply(this, arguments).then(function(r){
                            var c = r.clone();
                            c.text().then(function(t){
                                if(t.includes("correctAnswer")){
                                    try{
                                        var j=JSON.parse(t);
                                        var a=j.correctAnswer || j.correct_answer || j.data?.correctAnswer || "";
                                        if(a) localStorage.setItem('_CORRECTA', a);
                                    }catch(e){}
                                }
                            });
                            return r;
                        });
                    };
                    // Intercepta XHR
                    var _open = XMLHttpRequest.prototype.open;
                    XMLHttpRequest.prototype.open = function(){
                        this.addEventListener('load', function(){
                            try{
                                var t=this.responseText;
                                if(t && t.includes("correctAnswer")){
                                    var j=JSON.parse(t);
                                    var a=j.correctAnswer || j.correct_answer || j.data?.correctAnswer || "";
                                    if(a) localStorage.setItem('_CORRECTA', a);
                                }
                            }catch(e){}
                        });
                        return _open.apply(this, arguments);
                    };
                })();
                """.trimIndent(), null)
            }
        }
        webView!!.loadUrl("https://www.wwechampions.com/trivia")
    }
}