package com.trivias.app
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.*
import android.widget.Button
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.browser.customtabs.CustomTabsIntent

class MainActivity : AppCompatActivity() {
    companion object {
        var instancia: MainActivity? = null
        var ultimaRespuesta: String = "Esperando trivia..."
    }
    private lateinit var webView: WebView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instancia = this
        setContentView(R.layout.activity_main)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.addJavascriptInterface(WebAppInterface(), "AndroidTrivias")

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                val js = """
                    (function(){
                        if(window.triviaInterceptado) return;
                        window.triviaInterceptado = true;
                        AndroidTrivias.mostrarLog("🔍 Buscando trivia...");
                        
                        const enviar = (data) => {
                            try {
                                let d = data.data || data;
                                AndroidTrivias.mostrarLog("📦 JSON: " + JSON.stringify(d).substring(0,120));
                                if(d.options && d.rightAnswer){
                                    let correcto = d.options.find(o => o.id == d.rightAnswer);
                                    let nombre = correcto ? correcto.option : d.rightAnswer;
                                    AndroidTrivias.mostrarLog("✅ ID: " + d.rightAnswer);
                                    AndroidTrivias.mostrarRespuesta(nombre);
                                } else {
                                    AndroidTrivias.mostrarLog("❌ Sin ID, no es trivia");
                                }
                            } catch(e) { AndroidTrivias.mostrarLog("⚠️ Error: " + e); }
                        };

                        const originalFetch = window.fetch;
                        window.fetch = async function(...args){
                            let res = await originalFetch.apply(this, args);
                            let url = (args[0] ? args[0].toString() : '').toString();
                            if(url.includes('question') || url.includes('trivia')){
                                try{ let j = await res.clone().json(); enviar(j); }catch(e){}
                            }
                            return res;
                        };
                    })();
                """.trimIndent()
                webView.evaluateJavascript(js, null)
            }
        }
        findViewById<Button>(R.id.btnWebView).setOnClickListener {
            val container = findViewById<FrameLayout>(R.id.webContainer)
            container.removeAllViews()
            container.addView(webView)
            webView.loadUrl("https://www.wwechampions.com")
        }
        findViewById<Button>(R.id.btnCustomTab).setOnClickListener {
            CustomTabsIntent.Builder().build().launchUrl(this, Uri.parse("https://www.wwechampions.com"))
        }
        findViewById<Button>(R.id.btnFloat).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                startService(Intent(this, FloatingService::class.java))
            }
        }
    }
    class WebAppInterface {
        @JavascriptInterface
        fun mostrarRespuesta(nombre: String) {
            instancia?.runOnUiThread {
                ultimaRespuesta = "✅ CORRECTA: $nombre"
                FloatingService.actualizarTexto(ultimaRespuesta)
            }
        }
        @JavascriptInterface
        fun mostrarLog(mensaje: String) {
            instancia?.runOnUiThread {
                ultimaRespuesta = mensaje
                FloatingService.actualizarTexto(mensaje)
            }
        }
    }
}