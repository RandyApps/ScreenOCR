package com.trivias.app
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.*
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.browser.customtabs.CustomTabsIntent
import com.trivias.app.R

class MainActivity : AppCompatActivity() {
    companion object {
        var instancia: MainActivity? = null
        var ultimaRespuesta: String = "Esperando trivia..."
    }
    private lateinit var webView: WebView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instancia = this
        setContentView(R.layout.activity_main)
        webView = WebView(this)
        webView.addJavascriptInterface(WebAppInterface(), "AndroidTrivias")
        findViewById<Button>(R.id.btnWebView).setOnClickListener {
            setContentView(webView)
            webView.settings.javaScriptEnabled = true
            webView.settings.domStorageEnabled = true
            webView.webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    val js = """
                        (function(){
                            if(window.triviaInterceptado) return;
                            window.triviaInterceptado = true;
                            const originalFetch = window.fetch;
                            window.fetch = async function(...args){
                                let res = await originalFetch.apply(this, args);
                                let url = (args[0]?.url || args[0] || '').toString();
                                if(url.includes('question')){
                                    try{
                                        let clone = res.clone();
                                        let j = await clone.json();
                                        let data = j.data || j;
                                        if(data.options && data.rightAnswer){
                                            let correcto = data.options.find(o => o.id === data.rightAnswer);
                                            let nombre = correcto ? correcto.option : data.rightAnswer;
                                            AndroidTrivias.mostrarRespuesta(nombre);
                                        }
                                    }catch(e){}
                                }
                                return res;
                            };
                        })();
                    """.trimIndent()
                    webView.evaluateJavascript(js, null)
                }
            }
            webView.loadUrl("https://www.wwechampions.com")
        }
        findViewById<Button>(R.id.btnCustomTab).setOnClickListener {
            CustomTabsIntent.Builder().build().launchUrl(this, Uri.parse("https://www.wwechampions.com"))
        }
        findViewById<Button>(R.id.btnFloat).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                startService(Intent(this, FloatingService::class.java))
            }
        }
    }
    class WebAppInterface {
        @JavascriptInterface
        fun mostrarRespuesta(nombre: String) {
            instancia?.runOnUiThread {
                ultimaRespuesta = nombre
                FloatingService.actualizarTexto("✅ CORRECTA: $nombre")
            }
        }
    }
}