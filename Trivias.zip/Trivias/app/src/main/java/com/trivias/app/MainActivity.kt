package com.trivias.app
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.*
import android.widget.Button
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.browser.customtabs.CustomTabsIntent

class MainActivity : AppCompatActivity() {
    companion object {
        var instancia: MainActivity? = null
        var ultimaRespuesta: String = "Esperando trivia..."
    }
    private lateinit var webView: WebView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instancia = this
        setContentView(R.layout.activity_main)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.addJavascriptInterface(WebAppInterface(), "AndroidTrivias")

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                val js = """
                (function(){
                    if(window.hackUniversal) return;
                    window.hackUniversal = true;
                    AndroidTrivias.mostrarLog("✅ Hack Universal Activo");
                    let cacheOpciones = [];
                    const _fetch = window.fetch;
                    window.fetch = async function(...args){
                        let res = await _fetch.apply(this, args);
                        try{
                            let url = (args[0] || "").toString();
                            if(!url.includes("question")) return res;
                            let clon = res.clone();
                            let j = await clon.json();
                            let d = j.data || j;

                            // ANTES - question?gameId=15242478 - ESTA ES TU FOTO 2
                            if(url.includes("gameId=") && d.options){
                                cacheOpciones = d.options;
                                let q = d.question || "Trivia";
                                let txt = "❓ " + q + "\n";
                                for(let i=0; i<d.options.length; i++){
                                    txt += i + ": " + d.options[i].option + "\n";
                                }
                                AndroidTrivias.mostrarRespuesta(txt);
                            }
                            
                            // DESPUÉS - question POST - ESTA ES TU FOTO 1
                            if(!url.includes("gameId=") && d.rightAnswer){
                                let idCorrecto = d.rightAnswer;
                                let obj = cacheOpciones.find(o => o.id === idCorrecto);
                                let nombre = obj ? obj.option : "ID: " + idCorrecto;
                                AndroidTrivias.mostrarRespuesta("✅ CORRECTA: " + nombre);
                            }
                        }catch(e){}
                        return res;
                    };
                })();
                """.trimIndent()
                webView.evaluateJavascript(js, null)
            }
        }
        findViewById<Button>(R.id.btnWebView).setOnClickListener {
            val container = findViewById<FrameLayout>(R.id.webContainer)
            container.removeAllViews()
            container.addView(webView)
            if(webView.url == null) webView.loadUrl("https://www.wwechampions.com")
        }
        findViewById<Button>(R.id.btnCustomTab).setOnClickListener {
            CustomTabsIntent.Builder().build().launchUrl(this, Uri.parse("https://www.wwechampions.com"))
        }
        findViewById<Button>(R.id.btnFloat).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                startService(Intent(this, FloatingService::class.java))
            }
        }
    }
    class WebAppInterface {
        @JavascriptInterface
        fun mostrarRespuesta(nombre: String) {
            instancia?.runOnUiThread {
                ultimaRespuesta = nombre
                FloatingService.actualizarTexto(ultimaRespuesta)
            }
        }
        @JavascriptInterface
        fun mostrarLog(mensaje: String) {
            instancia?.runOnUiThread {
                ultimaRespuesta = mensaje
                FloatingService.actualizarTexto(mensaje)
            }
        }
    }
}