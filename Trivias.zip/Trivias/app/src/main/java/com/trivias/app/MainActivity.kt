package com.trivias.app

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import android.graphics.Typeface
import android.widget.TextView
import android.widget.LinearLayout
import android.widget.Button
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.trivias.app.databinding.ActivityMainBinding
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: PrefsHelper
    private var edgeSwipeStartX = 0f
    private var edgeSwipeStartY = 0f
    private var edgeSwipeTracking = false
    @Volatile private var openingAdminPanel = false
    private var forceUpdateDialog: AlertDialog? = null
    private var pendingEnableNotif = false
    private var answerBlink: Animation? = null
    private var activeWeb = 1
    private var web1Open = false
    private var web2Open = false
    /** Con WebView abierto: false = candado cerrado (sin gesto admin). Persiste al cambiar WV1/WV2. */
    private var adminGestureUnlocked = false
    private var adminPanelOpen = false
    private var adminController: AdminController? = null
    private var adminBound = false
    private var adminSwipeActive = false
    private var adminVelocityTracker: android.view.VelocityTracker? = null
    private val ADMIN_SWIPE_THRESHOLD = 0.40f
    private val ADMIN_EDGE_FRACTION = 0.25f
    private val ADMIN_ANIM_MS = 240L
    private fun elevDp(dp: Float): Float = dp * resources.displayMetrics.density
    private fun adminEase() = android.view.animation.DecelerateInterpolator(1.6f)
    private var panelDragCommitted = false

    private fun beginPanelDrag(moving: android.view.View) {
        try {
            moving.setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null)
        } catch (_: Exception) {}
        panelDragCommitted = false
    }

    private fun endPanelDrag(moving: android.view.View) {
        try {
            moving.setLayerType(android.view.View.LAYER_TYPE_NONE, null)
        } catch (_: Exception) {}
        panelDragCommitted = false
    }
    private var preguntaPendiente: String? = null
    private var chatGptWaiting = false
    private val chatGptDiagHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val chatGptTimeoutRunnable = Runnable {
        if (!chatGptWaiting) return@Runnable
        chatGptWaiting = false
        notifyChatGptDiag(
            "TIMEOUT_25S",
            "25s sin respuesta usable. Red y DOM no entregaron texto. Revisa si viste DOM_ASIST/DOM_SIN_RESP/HOOK_OK."
        )
    }
    private var chatListo = false
    /** Opciones de la pregunta actual: id + texto (para auto-clic). */
    private var currentOptions: List<Pair<String, String>> = emptyList()
    private var currentQuestionText: String = ""
    private var currentImageUrl: String = ""
    private var currentImageFile: String = ""
    private var currentGameQuestionId: String = ""
    private var testPanelCenteredThisSession = false

    private val desktopChromeUa =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        try {
            binding.adminDrawer.translationX = resources.displayMetrics.widthPixels.toFloat()
        } catch (_: Exception) {}
        prefs = PrefsHelper(this)
        applyScreenCapturePolicy()

        if (prefs.isBanned()) {
            startActivity(Intent(this, BannedActivity::class.java))
            finish()
            return
        }
        if (!prefs.isApproved()) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        Thread {
            val ban = try {
                SupabaseBanClient.checkIfBanned(DeviceIdHelper.get(this@MainActivity), prefs.getUserUid())
            } catch (_: Exception) { SupabaseBanClient.BanResult(false) }
            if (ban.banned) {
                runOnUiThread {
                    val status = if (ban.kind == "DEVICE") "DEVICE_BANNED" else "BANNED"
                    prefs.saveUserSession(prefs.getUserUid(), prefs.getUserEmail(), prefs.getUserNombre(), status, prefs.getUserRole())
                    startActivity(Intent(this@MainActivity, BannedActivity::class.java))
                    finish()
                }
            }
        }.start()

        SessionRealtimeWatcher.start(this)
        setupWebView()
        setupClicks()
        setupTestChatPanel()
        applyStrings()
        updateAdminOnlyUi()
        showVersionBadge()
        startAnswerBlink()
        showWebIdle()
        setAnswerState(LocaleHelper.t(this, "answer_placeholder"), "#FF1744", true)

        if (prefs.isPendingShowAbout()) {
            prefs.setPendingShowAbout(false)
            prefs.setSeenAboutOnFirstLogin(true)
            binding.root.post {
                showHelp(LocaleHelper.t(this, "about_title"), LocaleHelper.t(this, "about_body"))
            }
        }
    }


    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 9101) {
            val granted = grantResults.isNotEmpty() && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED
            if (granted && pendingEnableNotif) {
                pendingEnableNotif = false
                prefs.setNotifDecorEnabled(true)
                updateNotifDecorButton()
                EnergyNotifier.ensureChannel(this)
                val at = prefs.getEnergyRefreshAtMs()
                if (at > System.currentTimeMillis()) EnergyScheduler.schedule(this, at)
            } else if (!granted) {
                pendingEnableNotif = false
                prefs.setNotifDecorEnabled(false)
                updateNotifDecorButton()
                openAppNotificationSettings()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (!adminPanelOpen) {
            openingAdminPanel = false
            edgeSwipeTracking = false
            adminSwipeActive = false
            panelDragCommitted = false
            try {
                binding.adminDrawer.animate().cancel()
                binding.adminDrawer.translationX = screenW()
                binding.adminDrawer.visibility = View.GONE
                binding.adminDrawer.isClickable = false
                binding.mainLayer.translationX = 0f
                binding.mainLayer.elevation = 0f
                binding.mainLayer.bringToFront()
                endPanelDrag(binding.mainLayer)
                endPanelDrag(binding.adminDrawer)
            } catch (_: Exception) {}
        } else {
            try { adminController?.onHostResume() } catch (_: Exception) {}
        }
        if (::prefs.isInitialized && prefs.isApproved()) checkForceUpdate()
        applyStrings()
        updateAdminOnlyUi()
        updateTestChatPanelVisibility()
        SessionRealtimeWatcher.attach(this)
        startEnergyTicker()
        // Restaurar estado de botones desde prefs (no resetear)
        try {
            syncNotifPermissionState()
            updateAutoClickButton()
            updateNotifDecorButton()
            updateRetryButton()
            refreshEnergyUi()
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        try { binding.webView1.stopLoading(); binding.webView1.destroy() } catch (_: Exception) {}
        try { binding.webView2.stopLoading(); binding.webView2.destroy() } catch (_: Exception) {}
        super.onDestroy()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        configureWebView2(binding.webView2)
        configureWebView1WithHook(binding.webView1)
    }

    @SuppressLint("SetJavaScriptEnabled")
	private fun configureWebView2(wv: WebView) {
		wv.settings.builtInZoomControls = true
		wv.settings.displayZoomControls = false
		wv.settings.setSupportZoom(true)
		wv.settings.textZoom = 100
	    wv.settings.javaScriptEnabled = true
	    wv.settings.domStorageEnabled = true
		wv.settings.loadWithOverviewMode = true
		wv.settings.useWideViewPort = true
		wv.setInitialScale(90)
		
	    wv.settings.userAgentString = desktopChromeUa
	    wv.addJavascriptInterface(JsBridge(), "AndroidChatGPT")
	    wv.webViewClient = object : WebViewClient() {
	        override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
	            super.onPageStarted(view, url, favicon)
	            // Inyección temprana (antes de que termine de cargar la respuesta)
	            view?.evaluateJavascript("window._triviaHook=false;", null)
	        }
	        override fun onPageFinished(view: WebView?, url: String?) {
	            super.onPageFinished(view, url)
	            chatListo = true
	            view?.evaluateJavascript("""
				(function(){
					// --- ESTO ES LO QUE QUITA EL ZOOM ---
					let m = document.querySelector('meta[name=viewport]');
					if(!m){ m = document.createElement('meta'); m.name='viewport'; document.head.appendChild(m); }
					m.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no';
					let s = document.createElement('style');
					s.innerHTML = '#prompt-textarea, textarea, input { font-size: 16px !important; }';
					document.head.appendChild(s);
					// --- FIN ZOOM ---
  
					// --- ZOOM-OUT PARA QUE ENCAJE ---
					document.documentElement.style.zoom = '0.95'; // 95% - cambia a 0.90 si lo quieres más pequeño
					document.body.style.zoom = '0.95';
					let m2 = document.querySelector('meta[name=viewport]');
					m2.content = 'width=1024, initial-scale=0.8, maximum-scale=0.8, minimum-scale=0.8, user-scalable=no';
					// --- FIN ZOOM-OUT ---

	                if(window._triviaHook) return;
	                window._triviaHook = true;
	                window._best = "";
	                window._lastSent = "";
	                window._cgptUpdatesSeen = 0;
	                window._cgptHadMarkdown = false;

	                function diag(code, detail){
	                    try{
	                        if(typeof AndroidChatGPT !== "undefined" && AndroidChatGPT.onChatGptDiag){
	                            AndroidChatGPT.onChatGptDiag(String(code||""), String(detail||""));
	                        }
	                    }catch(e){}
	                }
	                diag("HOOK_OK", "Interceptor instalado (red + DOM)");

	                function clean(s){
	                    try{
	                        return s.replace(/\\n/g," ").replace(/\\"/g,'"').replace(/\\\\/g,"\\").trim();
	                    }catch(e){ return s; }
	                }

	                function isNoise(t){
	                    if(!t || t.length < 1 || t.length > 400) return true;
	                    var low = t.toLowerCase();
	                    if(low.indexOf("reply with only") !== -1) return true;
	                    if(low.indexOf("quickly answer") !== -1) return true;
	                    if(low.indexOf("wwe / wwe") !== -1) return true;
	                    if(low.indexOf("wwe trivia") !== -1) return true;
	                    if(low.indexOf("please answer") !== -1) return true;
	                    if(low.indexOf("no explanations") !== -1) return true;
	                    if(low.indexOf("just the answer") !== -1) return true;
	                    if(low.indexOf("searching") !== -1) return true;
	                    if(low.indexOf("thinking") !== -1) return true;
	                    if(low.indexOf("pensando") !== -1) return true;
	                    if(low.indexOf("como estas") !== -1) return true;
	                    if(low.indexOf("puedo ayudar") !== -1) return true;
	                    if(low.indexOf("choose the one") !== -1) return true;
	                    return false;
	                }

	                function trySend(candidate, source){
	                    if(!candidate) return;
	                    candidate = (""+candidate).trim();
	                    if(candidate.length < 2){
	                        diag("DESCARTADO_CORTO", "Texto < 2 chars desde "+(source||"?"));
	                        return;
	                    }
	                    if(isNoise(candidate)){
	                        diag("DESCARTADO_RUIDO", "Filtrado desde "+(source||"?")+": "+candidate.substring(0,60));
	                        return;
	                    }
	                    if(candidate.length >= window._best.length){
	                        window._best = candidate;
	                        clearTimeout(window._timer);
	                        window._timer = setTimeout(function(){
	                            if(window._best !== window._lastSent){
	                                window._lastSent = window._best;
	                                diag("ENVIADO_APP", "Respuesta ("+(source||"net")+"): "+window._best.substring(0,80));
	                                try{ AndroidChatGPT.onRespuestaChatGPT(window._best); }catch(e){}
	                            }
	                        }, 600);
	                    }
	                }

	                function extractAll(txt, via){
	                    window._cgptUpdatesSeen++;
	                    if(!txt || !String(txt).trim()){
	                        diag("UPDATES_VACIO", "Llego /updates por "+(via||"?")+" pero cuerpo VACIO");
	                        return;
	                    }
	                    var before = window._best;
	                    var m, found = false;
	                    var re1 = /"(?:fallbackMarkdown|markdown)"\s*:\s*"((?:\\.|[^"\\])*)"/g;
	                    while((m = re1.exec(txt)) !== null){
	                        found = true;
	                        window._cgptHadMarkdown = true;
	                        trySend(clean(m[1]), "markdown/"+via);
	                    }
	                    var re2 = /"constants"\s*:\s*\{\s*"0"\s*:\s*"((?:\\.|[^"\\])*)"/g;
	                    while((m = re2.exec(txt)) !== null){
	                        found = true;
	                        window._cgptHadMarkdown = true;
	                        trySend(clean(m[1]), "constants/"+via);
	                    }
	                    // otros formatos frecuentes
	                    var re3 = /"content"\s*:\s*"((?:\\.|[^"\\])*)"/g;
	                    while((m = re3.exec(txt)) !== null){
	                        var c = clean(m[1]);
	                        if(c.length >= 2 && c.length < 120 && !isNoise(c)){
	                            found = true;
	                            trySend(c, "content/"+via);
	                        }
	                    }
	                    if(!found){
	                        var preview = String(txt).replace(/\s+/g," ").substring(0,100);
	                        diag("UPDATES_SIN_CAMPOS", "updates "+(via||"?")+" len="+String(txt).length+" sin markdown/constants. Inicio: "+preview);
	                    } else if(window._best && window._best !== before){
	                        diag("CANDIDATO", "Desde "+(via||"?")+": "+window._best.substring(0,80));
	                    }
	                }

	                var oFetch = window.fetch;
	                window.fetch = async function(){
	                    var a = arguments;
	                    var url = (a[0]||"").toString();
	                    var res = await oFetch.apply(this, a);
	                    if(url.indexOf("updates") !== -1 || url.indexOf("conversation") !== -1){
	                        try{
	                            res.clone().text().then(function(t){ extractAll(t, "fetch"); }).catch(function(e){
	                                diag("FETCH_READ_FAIL", String(e));
	                            });
	                        }catch(e){ diag("FETCH_HOOK_ERR", String(e)); }
	                    }
	                    return res;
	                };
	                var oOpen = XMLHttpRequest.prototype.open;
	                XMLHttpRequest.prototype.open = function(m,u){ this._u = u||""; return oOpen.apply(this, arguments); };
	                var oSend = XMLHttpRequest.prototype.send;
	                XMLHttpRequest.prototype.send = function(b){
	                    this.addEventListener("load", function(){
	                        var u = this._u||"";
	                        if(u.indexOf("updates") !== -1 || u.indexOf("conversation") !== -1){
	                            extractAll(this.responseText||"", "xhr");
	                        }
	                    });
	                    return oSend.apply(this, arguments);
	                };

	                // Fallback DOM: lee el texto del asistente si la red no entrega
	                if(window._triviaDomTimer) clearInterval(window._triviaDomTimer);
	                window._triviaDomCount = document.querySelectorAll('[data-message-author-role="assistant"]').length;
	                window._triviaDomTimer = setInterval(function(){
	                    try{
	                        if(window._lastSent) return;
	                        var list = document.querySelectorAll('[data-message-author-role="assistant"]');
	                        if(!list || list.length === 0){
	                            // selectores alternativos ChatGPT
	                            list = document.querySelectorAll('[data-testid*="assistant"], .agent-turn, div.markdown');
	                        }
	                        if(!list || list.length === 0) return;
	                        var el = list[list.length - 1];
	                        var raw = (el.innerText || el.textContent || "").trim();
	                        var first = raw.split(/[\r\n]+/).map(function(l){ return l.trim(); }).filter(function(l){ return l.length > 0; })[0] || "";
	                        if(!first || isNoise(first)) return;
	                        if(first === window._triviaLastAnswer) return;
	                        window._triviaLastAnswer = first;
	                        diag("DOM_FALLBACK", "Respuesta leida del DOM: "+first.substring(0,80));
	                        trySend(first, "dom");
	                    }catch(e){}
	                }, 800);

	            })();
	            """.trimIndent(), null)
	        }
	    }
	}

    /** WWE Champions – SIN CAMBIOS (el que ya te funciona). */
    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView1WithHook(wv: WebView) {
        val s = wv.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.userAgentString = desktopChromeUa
        if (Build.VERSION.SDK_INT >= 21) s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        wv.addJavascriptInterface(JsBridge(), "AndroidChatGPT")
        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                view?.evaluateJavascript("""
                (function(){
                    if(window.hackTrivia) return;
                    window.hackTrivia = true;
                    let origOpen = XMLHttpRequest.prototype.open;
                    let origSend = XMLHttpRequest.prototype.send;
                    XMLHttpRequest.prototype.open = function(m,u){
                        this._url = u ? u.toString() : "";
                        return origOpen.apply(this, arguments);
                    };
                    XMLHttpRequest.prototype.send = function(body){
                        let xhr = this;
                        xhr.addEventListener('load', function(){
                            try{
                                if(!xhr._url) return;
                                // Energías / user info
                                if(xhr._url.indexOf("user/v2/info") !== -1 || xhr._url.indexOf("/user/v2/info") !== -1){
                                    try{
                                        let j = JSON.parse(xhr.responseText);
                                        let d = (j && j.data) ? j.data : j;
                                        if(d && (typeof d.energy !== "undefined")){
                                            var e = parseInt(d.energy,10); if(isNaN(e)) e = -1;
                                            var mx = parseInt(d.maxEnergy,10); if(isNaN(mx)) mx = 3;
                                            var rd = (d.energyRefreshDate || "").toString();
                                            var et = parseInt(d.energyTime,10); if(isNaN(et)) et = 0;
                                            if(typeof AndroidChatGPT.onEnergyInfo === "function"){
                                                AndroidChatGPT.onEnergyInfo(e, mx, rd, et);
                                            }
                                        }
                                    }catch(e){}
                                }
                                if(!xhr._url.includes("question")) return;
                                let json = JSON.parse(xhr.responseText);
                                let d = json.data || json;
                                if(!d) return;
                                // Fin de trivia: rightAnswer = UUID de la opción correcta
                                if(d.rightAnswer){
                                    try{
                                        AndroidChatGPT.onRespuestaCorrecta(String(d.rightAnswer));
                                    }catch(e){}
                                    return;
                                }
                                // Inicio: pregunta + opciones
                                if(!d.options) return;
                                if(xhr._url.includes("gameId=")){
                                    let opts = [];
                                    for(let i=0;i<d.options.length;i++){
                                        opts.push({
                                            id: (d.options[i].id||"").toString(),
                                            option: (d.options[i].option||d.options[i].text||"").toString()
                                        });
                                    }
                                    let img = (d.image||"").toString().trim();
                                    let imgFile = "";
                                    if(img){
                                        let idx = img.lastIndexOf("/");
                                        imgFile = (idx >= 0 ? img.substring(idx+1) : img).split("?")[0];
                                    }
                                    let payload = JSON.stringify({
                                        question: (d.question||"").trim(),
                                        options: opts,
                                        image: img,
                                        imageFile: imgFile,
                                        gameQuestionId: (d.id != null ? String(d.id) : "")
                                    });
                                    AndroidChatGPT.onPreguntaCapturada(payload);
                                }
                            }catch(e){}
                        });
                        return origSend.apply(this, arguments);
                    };
                })();
                """.trimIndent(), null)
            }
        }
    }

    private val triviaPrompt =
        "You are a WWE / WWE Champions trivia expert. Choose the ONE correct option from the list. Reply with ONLY the exact option text. No explanations, no emojis, no extra words.\n\n"

    /**
     * Si la trivia trae image URL, la añade al texto enviado a la IA
     * (pista por nombre de archivo y, si el modelo puede, abrir la imagen).
     * Sin imagen: solo prompt + pregunta + opciones (igual que antes).
     */
    private fun buildTriviaPayload(preguntaYOpciones: String): String {
        val base = triviaPrompt + preguntaYOpciones.trim()
        val img = currentImageUrl.trim()
        if (img.isEmpty()) return base
        val fileName = currentImageFile.trim().ifBlank {
            img.substringAfterLast('/').substringBefore('?')
        }
        return base +
            "\n\nThis trivia includes an image.\n" +
            "Image URL: " + img + "\n" +
            "Image file name: " + fileName + "\n" +
            "Open the image URL and look at the picture if needed. " +
            "The file name may also contain the correct superstar name. " +
            "Still reply with ONLY the exact option text from the list."
    }

    /** Groq first (rotate 4 keys on 429); ChatGPT WebView only if all keys fail. */
    fun enviarPregunta(preguntaYOpciones: String) {
        val textoCompleto = buildTriviaPayload(preguntaYOpciones)
        runOnUiThread {
            setAnswerState(LocaleHelper.t(this, "searching_groq"), "#FFC107", true)
        }
        // Siempre: DB → Groq → ChatGPT (sin selector de modo)
        Thread {
            val groqAnswer = try {
                GroqClient.ask(textoCompleto)
            } catch (_: Exception) {
                null
            }
            if (!groqAnswer.isNullOrBlank()) {
                val limpio = groqAnswer.lineSequence().map { it.trim() }.firstOrNull { it.isNotEmpty() } ?: groqAnswer.trim()
                // Si no coincide con ninguna opción → ChatGPT de inmediato
                val matchesOption = resolveOptionId(limpio) != null
                if (matchesOption) {
                    runOnUiThread { aplicarRespuestaTrivia(limpio) }
                } else {
                    enviarPreguntaAChatGPT(preguntaYOpciones)
                }
            } else {
                enviarPreguntaAChatGPT(preguntaYOpciones)
            }
        }.start()
    }



    /** Reinyecta el hook por si onPageFinished llega tarde respecto a /updates. */
    private fun scheduleChatGptHookReinjection() {
        val delays = longArrayOf(800L, 2000L, 4000L)
        for (d in delays) {
            chatGptDiagHandler.postDelayed({
                try {
                    binding.webView2.evaluateJavascript(
                        "(function(){ try { if(!window._triviaHook && document.body){ window._triviaHook=false; } } catch(e){} })();",
                        null
                    )
                    // Forzar onPageFinished-like: re-ejecutar no es trivial; al menos DOM timer se recrea si el usuario ya tiene la pagina
                    binding.webView2.evaluateJavascript(
                        """
                        (function(){
                          if(window._triviaHook) return;
                          // marca para que el siguiente onPageFinished no duplique mal - forzar false y pedir reinstall
                          window._triviaHook = false;
                        })();
                        """.trimIndent(),
                        null
                    )
                } catch (_: Exception) {}
            }, d)
        }
    }


    /**
     * DOM ChatGPT (HTML real 2026):
     * - contenedor: [data-message-role="assistant"] o [data-message-author-role="assistant"]
     * - texto en spans: span[data-d-streaming-word] (palabra a palabra) o p[data-d-component="text"]
     */
    private fun injectChatGptDomAssist() {
        if (!chatGptWaiting) return
        val optionsJson = try {
            org.json.JSONArray(currentOptions.map { it.second }).toString()
        } catch (_: Exception) {
            "[]"
        }
        val js = """
            (function(){
                try{
                    if(window._lastSent) return;
                    var opts = $optionsJson;

                    function isBad(t){
                        if(!t) return true;
                        var l = (''+t).trim().toLowerCase();
                        if(l.length < 1 || l.length > 120) return true;
                        var banned = ['pensando','thinking','buscando','searching',
                            'obtén respuestas','obten respuestas','adaptadas a ti','tailored',
                            'iniciar sesión','iniciar sesion','registrarse','sign in','log in',
                            'chatgpt','nuevo chat','new chat','ver planes','get responses',
                            'reply with only','no explanations','choose the one','trivia expert',
                            'wwe / wwe','wwe champions','dame solamente','solo la respuesta',
                            'please answer','free research','upgrade','regenerate'];
                        for(var i=0;i<banned.length;i++){
                            if(l.indexOf(banned[i]) !== -1) return true;
                        }
                        return false;
                    }

                    function send(first, src){
                        first = (''+first).replace(/\s+/g,' ').trim();
                        if(isBad(first)) return false;
                        if(typeof AndroidChatGPT!=='undefined'&&AndroidChatGPT.onChatGptDiag)
                            AndroidChatGPT.onChatGptDiag('DOM_ASIST', src+': '+first.substring(0,80));
                        if(typeof AndroidChatGPT!=='undefined'&&AndroidChatGPT.onRespuestaChatGPT)
                            AndroidChatGPT.onRespuestaChatGPT(first);
                        window._lastSent = first;
                        return true;
                    }

                    function textFromAssistant(node){
                        if(!node) return '';
                        // 1) unir palabras del stream
                        var words = node.querySelectorAll('span[data-d-streaming-word]');
                        if(words && words.length){
                            var parts = [];
                            for(var i=0;i<words.length;i++){
                                var w = (words[i].innerText||words[i].textContent||'').trim();
                                if(w) parts.push(w);
                            }
                            if(parts.length) return parts.join(' ').replace(/\s+/g,' ').trim();
                        }
                        // 2) párrafos de texto del componente
                        var ps = node.querySelectorAll('p[data-d-component="text"]');
                        if(ps && ps.length){
                            var t = (ps[ps.length-1].innerText||ps[ps.length-1].textContent||'').trim();
                            if(t) return t.replace(/\s+/g,' ').trim();
                        }
                        // 3) texto completo del nodo assistant
                        return (node.innerText||node.textContent||'').replace(/\s+/g,' ').trim();
                    }

                    // Contenedores assistant (ambos atributos por si cambia el nombre)
                    var nodes = document.querySelectorAll(
                        '[data-message-role="assistant"], [data-message-author-role="assistant"]'
                    );
                    if(nodes && nodes.length){
                        var last = nodes[nodes.length-1];
                        var full = textFromAssistant(last);
                        if(full){
                            // Si hay opciones de trivia, preferir match exacto/parcial dentro del texto del assistant
                            if(opts && opts.length){
                                for(var oi=0;oi<opts.length;oi++){
                                    var o = (opts[oi]||'').trim();
                                    if(!o || isBad(o)) continue;
                                    if(full === o || full.toLowerCase() === o.toLowerCase()){
                                        if(send(o, 'assistant-exact')) return;
                                    }
                                }
                                for(var oi2=0;oi2<opts.length;oi2++){
                                    var o2 = (opts[oi2]||'').trim();
                                    if(!o2 || isBad(o2)) continue;
                                    if(full.indexOf(o2) !== -1 || full.toLowerCase().indexOf(o2.toLowerCase()) !== -1){
                                        if(send(o2, 'assistant-option')) return;
                                    }
                                }
                            }
                            // Primera línea / texto completo corto
                            var line = full.split(/[\r\n]+/).map(function(x){return x.trim();}).filter(Boolean)[0] || full;
                            if(send(line, 'assistant-text')) return;
                        }
                    }

                    // Fallback: solo spans de streaming en el documento (último grupo)
                    var allWords = document.querySelectorAll('span[data-d-streaming-word]');
                    if(allWords && allWords.length){
                        var parts2 = [];
                        for(var j=0;j<allWords.length;j++){
                            var w2 = (allWords[j].innerText||allWords[j].textContent||'').trim();
                            if(w2) parts2.push(w2);
                        }
                        var joined = parts2.join(' ').replace(/\s+/g,' ').trim();
                        // Evitar unir TODO el historial: quedarnos con las últimas ~12 palabras si es muy largo
                        if(parts2.length > 12){
                            joined = parts2.slice(-12).join(' ').replace(/\s+/g,' ').trim();
                        }
                        if(opts && opts.length){
                            for(var k=0;k<opts.length;k++){
                                var ok = (opts[k]||'').trim();
                                if(!ok||isBad(ok)) continue;
                                if(joined.indexOf(ok)!==-1 || joined.toLowerCase().indexOf(ok.toLowerCase())!==-1){
                                    if(send(ok, 'stream-option')) return;
                                }
                            }
                        }
                        if(send(joined, 'stream-join')) return;
                    }

                    if(typeof AndroidChatGPT!=='undefined'&&AndroidChatGPT.onChatGptDiag)
                        AndroidChatGPT.onChatGptDiag('DOM_SIN_RESP','Sin assistant/streaming-word aun');
                }catch(e){
                    if(typeof AndroidChatGPT!=='undefined'&&AndroidChatGPT.onChatGptDiag)
                        AndroidChatGPT.onChatGptDiag('DOM_ERR', String(e));
                }
            })();
        """.trimIndent()
        try {
            binding.webView2.evaluateJavascript(js, null)
        } catch (e: Exception) {
            notifyChatGptDiag("DOM_INJECT_ERR", e.message ?: "error")
        }
    }

    private fun isChatGptUiChrome(text: String): Boolean {
        val l = text.lowercase()
        if (l.length < 2 || l.length > 120) return true
        val banned = listOf(
            "pensando", "thinking", "buscando", "searching",
            "obtén respuestas", "obten respuestas", "adaptadas a ti", "tailored to you",
            "iniciar sesión", "iniciar sesion", "registrarse", "sign in", "log in",
            "nuevo chat", "new chat", "ver planes", "get responses", "free research",
            "reply with only", "no explanations", "choose the one", "trivia expert"
        )
        return banned.any { l.contains(it) }
    }

    /** Diagnostico ChatGPT: solo ADMIN. Mensaje legible en Toast largo. */
    private fun notifyChatGptDiag(code: String, detail: String) {
        // Diagnósticos desactivados (sin toasts al usuario)
    }

    /** Fallback: ChatGPT WebView (unchanged behaviour). */
    fun enviarPreguntaAChatGPT(preguntaYOpciones: String) {
        val textoCompleto = buildTriviaPayload(preguntaYOpciones)
        runOnUiThread {
            try {
                setAnswerState(LocaleHelper.t(this, "searching_chatgpt"), "#FFC107", true)
                chatGptWaiting = true
                chatGptDiagHandler.removeCallbacks(chatGptTimeoutRunnable)
                chatGptDiagHandler.postDelayed(chatGptTimeoutRunnable, 25_000L)
                notifyChatGptDiag("ENVIO", "Cargando ChatGPT con ?q= (pagina nueva). Esperando /updates…")
                binding.webView2.evaluateJavascript(
                    """
                    try{
                        window._best = "";
                        window._lastSent = "";
                        window._triviaLastAnswer = "";
                        window._triviaBestMarkdown = "";
                    }catch(e){}
                    """.trimIndent(),
                    null
                )

                val encoded = java.net.URLEncoder.encode(textoCompleto, "UTF-8")
                binding.webView2.loadUrl("https://chatgpt.com/?q=$encoded")
                // Reintentos de lectura DOM por si el hook de red llega tarde
                chatGptDiagHandler.postDelayed({ injectChatGptDomAssist() }, 1200L)
                chatGptDiagHandler.postDelayed({ injectChatGptDomAssist() }, 2500L)
                chatGptDiagHandler.postDelayed({ injectChatGptDomAssist() }, 4000L)
                chatGptDiagHandler.postDelayed({ injectChatGptDomAssist() }, 6000L)
                chatGptDiagHandler.postDelayed({ injectChatGptDomAssist() }, 9000L)
                chatGptDiagHandler.postDelayed({ injectChatGptDomAssist() }, 12000L)
                chatGptDiagHandler.postDelayed({ injectChatGptDomAssist() }, 16000L)
            } catch (e: Exception) {
                Toast.makeText(this, "Error ChatGPT: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /** Show answer in the text box + optional auto-click (same path as ChatGPT response). */
    private fun aplicarRespuestaTrivia(limpio: String) {
        setAnswerState(limpio, "#1B5E20", false)
        if (prefs.isAutoClickEnabled() && currentOptions.isNotEmpty()) {
            tryAutoClickById(limpio)
        }
    }

    inner class JsBridge {
        @JavascriptInterface
        fun onPreguntaCapturada(texto: String) {
            runOnUiThread {
                cancelAutoClickRetries()
                // Intentar JSON con ids; si falla, texto plano (compatibilidad)
                try {
                    val obj = JSONObject(texto)
                    val q = obj.optString("question", "").trim()
                    val arr = obj.optJSONArray("options") ?: JSONArray()
                    val list = mutableListOf<Pair<String, String>>()
                    val sb = StringBuilder()
                    sb.append(q).append("\n\n")
                    for (i in 0 until arr.length()) {
                        val o = arr.optJSONObject(i) ?: continue
                        val id = o.optString("id", "").trim()
                        val opt = o.optString("option", "").trim()
                        if (opt.isNotEmpty()) {
                            list.add(id to opt)
                            sb.append(opt).append("\n")
                        }
                    }
                    val imgUrl = obj.optString("image", "").trim()
                    var imgFile = obj.optString("imageFile", "").trim()
                    if (imgFile.isEmpty() && imgUrl.isNotEmpty()) {
                        imgFile = imgUrl.substringAfterLast('/').substringBefore('?')
                    }
                    val gameQid = obj.optString("gameQuestionId", "").trim()
                    currentOptions = list
                    currentQuestionText = q
                    currentImageUrl = imgUrl
                    currentImageFile = imgFile
                    currentGameQuestionId = gameQid
                    setAnswerState(LocaleHelper.t(this@MainActivity, "searching_db"), "#FFC107", true)
                    val preguntaYOpciones = sb.toString().trim()
                    Thread {
                        val cached = try {
                            SupabaseBanClient.lookupTriviaAnswer(q, imgUrl, imgFile)
                        } catch (_: Exception) {
                            null
                        }
                        if (!cached.isNullOrBlank()) {
                            val optionTexts = list.map { it.second }
                            val chosen = SupabaseBanClient.pickAnswerForOptions(cached, optionTexts)
                            if (!chosen.isNullOrBlank()) {
                                runOnUiThread { aplicarRespuestaTrivia(chosen) }
                            } else {
                                // Ninguna de las respuestas en DB coincide con las opciones → IA
                                runOnUiThread { enviarPregunta(preguntaYOpciones) }
                            }
                        } else {
                            val fromFile = matchAnswerFromImageFile(imgFile, list)
                            if (!fromFile.isNullOrBlank()) {
                                runOnUiThread { aplicarRespuestaTrivia(fromFile) }
                            } else {
                                runOnUiThread { enviarPregunta(preguntaYOpciones) }
                            }
                        }
                    }.start()
                } catch (_: Exception) {
                    currentOptions = emptyList()
                    currentQuestionText = texto.lineSequence().firstOrNull()?.trim().orEmpty()
                    setAnswerState(LocaleHelper.t(this@MainActivity, "searching_db"), "#FFC107", true)
                    enviarPregunta(texto)
                }
            }
        }


        @JavascriptInterface
        fun onEnergyInfo(energy: Int, maxEnergy: Int, refreshDateIso: String, energyTimeSec: Int) {
            runOnUiThread {
                applyEnergyFromServer(energy, maxEnergy, refreshDateIso ?: "", energyTimeSec)
            }
        }

        @JavascriptInterface
        fun onRetryCostSeen(cost: Int) {
            val lim = prefs.getRetryLimit()
            if (!prefs.isAutoClickEnabled() || lim <= 0) return
            if (cost > lim) return
            val now = System.currentTimeMillis()
            if (now - lastRetryClickAt < 4000L) return
            lastRetryClickAt = now
            runOnUiThread {
                val js = """
                    (function(){
                        var body = (document.body && document.body.innerText) ? document.body.innerText : '';
                        if(body.indexOf('Too Bad') === -1 && body.indexOf('Want To Continue') === -1) return;
                        var btns = document.querySelectorAll('button');
                        for(var i=0;i<btns.length;i++){
                            var b = btns[i];
                            var t = (b.innerText || b.textContent || '').replace(/\s+/g,' ').trim();
                            var m = t.match(/\b(25|50)\b/);
                            if(!m) continue;
                            if(parseInt(m[1],10) === $cost){
                                if(b.getAttribute('data-trivias-retry-pending')==='1') break;
                                b.setAttribute('data-trivias-retry-pending','1');
                                setTimeout(function(){ try{ var now=Date.now(); if(window._triviasLastClick && (now-window._triviasLastClick)<500) return; window._triviasLastClick=Date.now(); b.click(); }catch(e){} }, 500);
                                break;
                            }
                        }
                    })();
                """.trimIndent()
                try { binding.webView1.evaluateJavascript(js, null) } catch (_: Exception) {}
            }
        }

        @JavascriptInterface
        fun onRespuestaCorrecta(rightAnswerId: String) {
            val id = rightAnswerId.trim()
            if (id.isEmpty()) return
            val q = currentQuestionText
            if (q.isBlank()) return
            val text = currentOptions.firstOrNull { it.first.equals(id, ignoreCase = true) }?.second?.trim()
            if (text.isNullOrBlank()) return
            val imgUrl = currentImageUrl
            val imgFile = currentImageFile
            val gameQid = currentGameQuestionId
            Thread {
                try {
                    SupabaseBanClient.saveTriviaAnswer(q, text, imgUrl, imgFile, gameQid)
                } catch (_: Exception) {
                }
            }.start()
            // Fin de trivia: no seguir intentando auto-click
            runOnUiThread { cancelAutoClickRetries() }
        }

        @JavascriptInterface
        fun onRespuestaChatGPT(texto: String) {
            runOnUiThread {
                val limpio = texto.lineSequence()
                    .map { it.trim() }
                    .firstOrNull { it.isNotEmpty() }
                    ?: texto.trim()
                if (isChatGptUiChrome(limpio)) {
                    notifyChatGptDiag("RECHAZADO_UI", "Texto de la interfaz ChatGPT ignorado: " + limpio.take(60))
                    return@runOnUiThread
                }
                chatGptWaiting = false
                chatGptDiagHandler.removeCallbacks(chatGptTimeoutRunnable)
                if (limpio.isNotEmpty() && limpio.length < 400) {
                    notifyChatGptDiag("OK_APP", "La app recibio y mostro: " + limpio.take(80))
                    setAnswerState(limpio, "#1B5E20", false)
                    if (prefs.isAutoClickEnabled()) {
                        tryAutoClickById(limpio)
                    }
                } else {
                    notifyChatGptDiag("OK_VACIO", "texto inutil len=" + limpio.length)
                }
            }
        }

    }

    private var autoClickAttempt = 0
    private val autoClickHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var autoClickCancelled = false

    private fun cancelAutoClickRetries() {
        autoClickCancelled = true
        autoClickHandler.removeCallbacksAndMessages(null)
        autoClickAttempt = 0
    }

    /** Exacta (ignore case) → parcial; clic en button[data-id]. Reintenta si el botón aún no existe. */
    private fun tryAutoClickById(answer: String) {
        val id = resolveOptionId(answer) ?: return
        autoClickCancelled = false
        autoClickAttempt = 0
        attemptAutoClick(id)
    }

    private fun attemptAutoClick(id: String) {
        if (autoClickCancelled) return
        val safeId = id.replace("\\", "\\\\").replace("'", "\'")
        val js = """
            (function(){
                var id = '$safeId';
                var btn = document.querySelector('button[data-id="' + id + '"]');
                if (!btn) {
                    var all = document.querySelectorAll('button[data-id]');
                    for (var i = 0; i < all.length; i++) {
                        var d = all[i].getAttribute('data-id') || '';
                        if (d === id || d.indexOf(id) === 0) { btn = all[i]; break; }
                    }
                }
                if (!btn) return '0';
                try { btn.scrollIntoView({block:'center', inline:'nearest'}); } catch(e) {}
                try {
                    if(btn.getAttribute('data-trivias-pending')==='1') return '1';
                    btn.setAttribute('data-trivias-pending','1');
                    setTimeout(function(){
                        try {
                            var now = Date.now();
                            if(window._triviasLastClick && (now - window._triviasLastClick) < 500) return;
                            window._triviasLastClick = Date.now();
                            btn.click();
                        } catch(e) {}
                    }, 500);
                    return '1';
                } catch(e) { return '0'; }
            })();
        """.trimIndent()
        binding.webView1.evaluateJavascript(js) { result ->
            val ok = result != null && result.contains("1")
            if (ok || autoClickCancelled) return@evaluateJavascript
            if (autoClickAttempt < 8) {
                autoClickAttempt++
                autoClickHandler.postDelayed({
                    if (!autoClickCancelled) attemptAutoClick(id)
                }, 1000L)
            }
        }
    }


    /** Si el nombre del archivo de image contiene el nombre de una opción (ej. AJStyles). */
    private fun matchAnswerFromImageFile(imageFile: String, options: List<Pair<String, String>>): String? {
        if (imageFile.isBlank() || options.isEmpty()) return null
        val fileNorm = imageFile.lowercase()
            .substringBeforeLast('.')
            .replace(Regex("[^a-z0-9]"), "")
        if (fileNorm.length < 4) return null
        var best: String? = null
        var bestScore = 0
        for ((_, opt) in options) {
            val o = opt.trim()
            if (o.isEmpty()) continue
            val oNorm = o.lowercase().replace(Regex("[^a-z0-9]"), "")
            if (oNorm.length < 3) continue
            val score = when {
                fileNorm.contains(oNorm) -> oNorm.length + 10
                oNorm.contains(fileNorm) && fileNorm.length >= 5 -> fileNorm.length
                else -> 0
            }
            if (score > bestScore) {
                bestScore = score
                best = o
            }
        }
        return if (bestScore >= 5) best else null
    }

    private fun resolveOptionId(answer: String): String? {
        if (currentOptions.isEmpty()) return null
        val a = answer.trim().lowercase()
        if (a.isEmpty()) return null
        // 1) Exacta
        currentOptions.firstOrNull { it.second.trim().lowercase() == a }?.let { return it.first }
        // 2) Parcial: opción contiene respuesta o respuesta contiene opción
        val partial = currentOptions.filter {
            val o = it.second.trim().lowercase()
            o.contains(a) || a.contains(o)
        }
        if (partial.isEmpty()) return null
        if (partial.size == 1) return partial[0].first
        // Desempate: mayor solapamiento (longitud de la intersección aproximada)
        return partial.maxByOrNull { opt ->
            val o = opt.second.trim().lowercase()
            when {
                o.startsWith(a) || a.startsWith(o) -> 1000 + minOf(o.length, a.length)
                else -> minOf(o.length, a.length)
            }
        }?.first
    }

    private fun setAnswerState(text: String, colorHex: String, blinking: Boolean) {
        runOnUiThread {
            val color = Color.parseColor(colorHex)
            // Banner del WebView (respuesta / Buscando… / placeholder)
            try {
                binding.tvWebAnswerValue.clearAnimation()
                binding.tvWebAnswerValue.text = text
                binding.tvWebAnswerValue.setTextColor(color)
                if (blinking) {
                    if (answerBlink == null) {
                        answerBlink = AlphaAnimation(1f, 0.25f).apply {
                            duration = 700
                            repeatMode = Animation.REVERSE
                            repeatCount = Animation.INFINITE
                        }
                    }
                    binding.tvWebAnswerValue.startAnimation(answerBlink)
                } else {
                    binding.tvWebAnswerValue.clearAnimation()
                }
            } catch (_: Exception) {}
            try {
                binding.tvAnswerValue.text = text
            } catch (_: Exception) {}
        }
    }

    fun setAnswerText(text: String?) {
        val value = text?.trim().orEmpty()
        if (value.isEmpty()) setAnswerState(LocaleHelper.t(this, "answer_placeholder"), "#FF1744", true)
        else setAnswerState(value, "#1B5E20", false)
    }


    private fun haptic() {
        try {
            window.decorView.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)
        } catch (_: Exception) {}
    }

    private fun applyScreenCapturePolicy() {
        // Solo el super-admin (randy.vargas51@gmail.com) puede capturar/grabar
        val allow = isSuperAdminEmail()
        if (allow) {
            window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        } else {
            window.setFlags(
                android.view.WindowManager.LayoutParams.FLAG_SECURE,
                android.view.WindowManager.LayoutParams.FLAG_SECURE
            )
        }
    }

    private fun updateAdminOnlyUi() {
        // Cerrar y Volver: visibles para todos cuando hay controles
        binding.btnCloseWeb.visibility = View.VISIBLE
        binding.btnBackWeb.visibility = View.VISIBLE
        // Cambiar y candado: solo ADMIN
        val isAdm = prefs.isAdmin()
        binding.btnSwitchWeb.visibility = if (isAdm) View.VISIBLE else View.INVISIBLE
        updateAdminLockUi()
    }

    private fun styleWebControlButtons() {
        fun style(btn: android.widget.ImageButton, iconRes: Int) {
            btn.setBackgroundResource(R.drawable.bg_web_control_btn)
            btn.setImageResource(iconRes)
            btn.scaleType = android.widget.ImageView.ScaleType.CENTER_INSIDE
            btn.adjustViewBounds = false
            btn.setPadding(0, 0, 0, 0)
            btn.imageTintList = android.content.res.ColorStateList.valueOf(android.graphics.Color.WHITE)
        }
        style(binding.btnCloseWeb, R.drawable.ic_web_close)
        style(binding.btnSwitchWeb, R.drawable.ic_web_switch)
        style(binding.btnBackWeb, R.drawable.ic_web_back)
    }

    private fun updateAdminLockUi() {
        try {
            val webOpen = web1Open || web2Open
            val show = webOpen && prefs.isAdmin()
            binding.btnAdminLock.visibility = if (show) View.VISIBLE else View.GONE
            if (show) {
                binding.btnAdminLock.setImageResource(
                    if (adminGestureUnlocked) R.drawable.ic_lock_open else R.drawable.ic_lock_closed
                )
            }
        } catch (_: Exception) {}
    }

    private fun setupTestChatPanel() {
        binding.btnTestChatClose.setOnClickListener {
            haptic()
            prefs.setTestChatPanelVisible(false)
            updateTestChatPanelVisibility()
        }
        binding.btnTestChatClear.setOnClickListener {
            haptic()
            binding.etTestChatInput.setText("")
            binding.etTestChatInput.isVerticalScrollBarEnabled = true
            binding.etTestChatInput.movementMethod = android.text.method.ScrollingMovementMethod.getInstance()
        }
        binding.btnTestChatPaste.setOnClickListener {
            haptic()
            try {
                val clipboard = getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                val clip = clipboard.primaryClip
                if (clip != null && clip.itemCount > 0) {
                    val paste = clip.getItemAt(0).coerceToText(this)?.toString() ?: ""
                    if (paste.isNotEmpty()) {
                        val cur = binding.etTestChatInput.text?.toString() ?: ""
                        val startSel = binding.etTestChatInput.selectionStart.coerceAtLeast(0)
                        val endSel = binding.etTestChatInput.selectionEnd.coerceAtLeast(0)
                        val a = minOf(startSel, endSel)
                        val b = maxOf(startSel, endSel)
                        val updated = cur.substring(0, a) + paste + cur.substring(b)
                        binding.etTestChatInput.setText(updated)
                        binding.etTestChatInput.setSelection((a + paste.length).coerceAtMost(updated.length))
                    }
                }
            } catch (_: Exception) {}
        }
        binding.btnTestChatSend.setOnClickListener {
            haptic()
            if (!web2Open) {
                Toast.makeText(this, LocaleHelper.t(this, "test_need_chatgpt"), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val text = binding.etTestChatInput.text?.toString()?.trim().orEmpty()
            if (text.isEmpty()) return@setOnClickListener
            setAnswerState(LocaleHelper.t(this, "searching_groq"), "#FFC107", true)
            enviarPregunta(text)
        }
        var dX = 0f
        var dY = 0f
        binding.testChatPanelHeader.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    dX = binding.testChatPanel.x - event.rawX
                    dY = binding.testChatPanel.y - event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val parent = binding.root
                    val maxX = (parent.width - binding.testChatPanel.width).toFloat().coerceAtLeast(0f)
                    val maxY = (parent.height - binding.testChatPanel.height).toFloat().coerceAtLeast(0f)
                    val nx = (event.rawX + dX).coerceIn(0f, maxX)
                    val ny = (event.rawY + dY).coerceIn(0f, maxY)
                    binding.testChatPanel.x = nx
                    binding.testChatPanel.y = ny
                    true
                }
                else -> false
            }
        }
        updateTestChatPanelVisibility()
    }

    private fun updateTestChatPanelVisibility() {
        val show = prefs.isTestChatPanelVisible()
        binding.testChatPanel.visibility = if (show) View.VISIBLE else View.GONE
        val canUse = web2Open
        binding.etTestChatInput.isEnabled = show && canUse
        binding.btnTestChatSend.isEnabled = show && canUse
        binding.btnTestChatPaste.isEnabled = show && canUse
        binding.btnTestChatClear.isEnabled = show
        if (show && !canUse) {
            binding.etTestChatInput.hint = LocaleHelper.t(this, "test_need_chatgpt")
        }
        if (show && !testPanelCenteredThisSession) {
            binding.testChatPanel.post {
                val parent = binding.root
                val pw = parent.width
                val ph = parent.height
                val cw = binding.testChatPanel.width
                val ch = binding.testChatPanel.height
                if (pw > 0 && ph > 0 && cw > 0 && ch > 0) {
                    binding.testChatPanel.x = ((pw - cw) / 2f).coerceAtLeast(0f)
                    binding.testChatPanel.y = ((ph - ch) / 2f).coerceAtLeast(0f)
                    testPanelCenteredThisSession = true
                }
            }
        }
    }

    private fun setupClicks() {
                binding.cardLanguage.setOnClickListener {
            haptic()
            // Ciclo: EN -> ES -> PT -> ID -> EN
            val order = listOf(LocaleHelper.EN, LocaleHelper.ES, LocaleHelper.PT, LocaleHelper.ID)
            val cur = LocaleHelper.getLang(this)
            val idx = order.indexOf(cur).let { if (it < 0) 0 else it }
            val next = order[(idx + 1) % order.size]
            LocaleHelper.setLang(this, next)
            applyStrings()
        }

        binding.btnAbout.setOnClickListener {
            haptic()
            showHelp(LocaleHelper.t(this, "about_title"), LocaleHelper.t(this, "about_body"))
        }
        binding.btnHelpClose.setOnClickListener {
            haptic()
            binding.helpOverlay.visibility = View.GONE
        }
        
        updateAiProviderButton()

        binding.cardTutorial.setOnClickListener {
            haptic()
            showHelp(LocaleHelper.t(this, "tutorial_title"), LocaleHelper.t(this, "tutorial_body"))
        }
        binding.cardDonate.setOnClickListener {
            haptic()
            openPaypal()
        }
        binding.cardDonate.setOnLongClickListener { Toast.makeText(this, LocaleHelper.t(this, "donation_tooltip"), Toast.LENGTH_LONG).show(); true }
        binding.btnOpenWeb.setOnClickListener {
            haptic()
            openWebView()
        }
        try {
            binding.btnAutoClick.setOnClickListener {
                haptic()
                val turningOn = !prefs.isAutoClickEnabled()
                prefs.setAutoClickEnabled(turningOn)
                updateAutoClickButton()
                if (turningOn) {
                    val saved = prefs.getRetryLimitSaved()
                    if (prefs.getRetryLimit() <= 0 && saved > 0) {
                        prefs.setRetryLimit(saved)
                    }
                    updateRetryButton()
                    if (prefs.getRetryLimit() > 0) ensureRetryWatcher()
                } else {
                    val cur = prefs.getRetryLimit()
                    if (cur > 0) {
                        prefs.setRetryLimitSaved(cur)
                        prefs.setRetryLimit(0)
                    }
                    updateRetryButton()
                    try {
                        binding.webView1.evaluateJavascript(
                            "(function(){ try{ clearInterval(window._triviasRetryWatch); window._triviasRetryWatch=null; clearInterval(window._triviasRetryClick); window._triviasRetryClick=null; }catch(e){} })();",
                            null
                        )
                    } catch (_: Exception) {}
                    retryWatchInstalled = false
                }
            }
            binding.btnNotificaciones.setOnClickListener {
                haptic()
                val wantOn = !prefs.isNotifDecorEnabled()
                if (wantOn) {
                    if (!hasNotificationPermission()) {
                        pendingEnableNotif = true
                        requestNotifPermissionIfNeeded()
                        // En Android < 13 o si el sistema no muestra diálogo, abrir ajustes
                        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                            if (pendingEnableNotif && !hasNotificationPermission()) {
                                openAppNotificationSettings()
                            }
                        }, 600)
                        return@setOnClickListener
                    }
                    prefs.setNotifDecorEnabled(true)
                    updateNotifDecorButton()
                    EnergyNotifier.ensureChannel(this)
                    val at = prefs.getEnergyRefreshAtMs()
                    if (at > System.currentTimeMillis()) EnergyScheduler.schedule(this, at)
                } else {
                    prefs.setNotifDecorEnabled(false)
                    updateNotifDecorButton()
                }
            }
            binding.btnReintentar.setOnClickListener {
                haptic()
                if (!prefs.isAutoClickEnabled()) {
                    Toast.makeText(this, LocaleHelper.t(this, "retry_need_autoclick"), Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                showRetryLimitDialog()
            }
            binding.btnTutorialGrid.setOnClickListener {
                haptic()
                showHelp(LocaleHelper.t(this, "tutorial_title"), LocaleHelper.t(this, "tutorial_body"))
            }
            binding.btnDonateGrid.setOnClickListener {
                haptic()
                openPaypal()
            }
        } catch (_: Exception) {}
        binding.btnCloseWeb.setOnClickListener {
            haptic()
            closeWebView()
        }
        binding.btnSwitchWeb.setOnClickListener {
            haptic()
            switchWebView()
        }
        binding.btnBackWeb.setOnClickListener {
            haptic()
            val wv = currentWebView()
            if (wv.canGoBack()) wv.goBack()
            else Toast.makeText(this, LocaleHelper.t(this, "webview_no_back"), Toast.LENGTH_SHORT).show()
        }

        binding.btnAdminLock.setOnClickListener {
            if (!prefs.isAdmin()) return@setOnClickListener
            if (!(web1Open || web2Open)) return@setOnClickListener
            try { window.decorView.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP) } catch (_: Exception) {}
            adminGestureUnlocked = !adminGestureUnlocked
            updateAdminLockUi()
        }

    }

    private fun currentWebView(): WebView = if (activeWeb == 2) binding.webView2 else binding.webView1

    private fun openWebView() {
        binding.headerRow.visibility = View.GONE
        binding.cardAnswer.visibility = View.GONE
        binding.webIdle.visibility = View.GONE
        binding.webActive.visibility = View.VISIBLE
        binding.webControls.visibility = View.VISIBLE
        try { binding.bottomRow.visibility = View.GONE } catch (_: Exception) {}
        setAnswerState(LocaleHelper.t(this, "answer_placeholder"), "#FF1744", true)
        adminGestureUnlocked = false
        web1Open = true; web2Open = true; activeWeb = 1
        binding.webView1.visibility = View.VISIBLE
        binding.webView2.visibility = View.GONE
        binding.webView1.loadUrl("https://www.wwechampions.com")
        binding.webView2.loadUrl("https://chatgpt.com")
        updateAdminOnlyUi()
        updateAdminLockUi()
        chatListo = false
        updateSwitchEnabled()
        updateTestChatPanelVisibility()
        binding.webView1.postDelayed({
            if (prefs.isAutoClickEnabled() && prefs.getRetryLimit() > 0) ensureRetryWatcher()
        }, 4000L)
    }

    private fun switchWebView() {
        if (!web1Open || !web2Open) { Toast.makeText(this, LocaleHelper.t(this, "switch_need_both"), Toast.LENGTH_SHORT).show(); return }
        if (activeWeb == 1) { activeWeb = 2; binding.webView1.visibility = View.GONE; binding.webView2.visibility = View.VISIBLE }
        else { activeWeb = 1; binding.webView2.visibility = View.GONE; binding.webView1.visibility = View.VISIBLE }
        updateAdminLockUi()
    }

    private fun closeWebView() {
        // Cierre real de sesión web: blank + historial (sin clearCache para no enfriar demasiado)
        try {
            binding.webView1.stopLoading()
            binding.webView1.loadUrl("about:blank")
            binding.webView1.clearHistory()
        } catch (_: Exception) {}
        try {
            binding.webView2.stopLoading()
            binding.webView2.loadUrl("about:blank")
            binding.webView2.clearHistory()
        } catch (_: Exception) {}
        chatListo = false
        try { chatGptWaiting = false } catch (_: Exception) {}
        try { chatGptDiagHandler.removeCallbacksAndMessages(null) } catch (_: Exception) {}
        web1Open = false
        web2Open = false
        activeWeb = 1
        // Cerrado: gesto admin vuelve a funcionar; candado se reinicia al reabrir
        adminGestureUnlocked = false
        updateAdminLockUi()
        binding.webView1.visibility = View.GONE
        binding.webView2.visibility = View.GONE
        showWebIdle()
        updateTestChatPanelVisibility()
    }

    private fun updateSwitchEnabled() {
        val both = web1Open && web2Open
        binding.btnSwitchWeb.isEnabled = both
        binding.btnSwitchWeb.alpha = if (both) 1f else 0.4f
    }

    private fun showWebIdle() {
        web1Open = false; web2Open = false; activeWeb = 1
        binding.headerRow.visibility = View.VISIBLE
        binding.cardAnswer.visibility = View.VISIBLE
        binding.webActive.visibility = View.GONE
        binding.webControls.visibility = View.GONE
        binding.webIdle.visibility = View.VISIBLE
        try { binding.bottomRow.visibility = View.VISIBLE } catch (_: Exception) {}
        binding.webView1.visibility = View.GONE
        binding.webView2.visibility = View.GONE
        setAnswerState(LocaleHelper.t(this, "answer_placeholder"), "#FF1744", true)
        startChromeBorderAnimations()
    }


    private val energyUiHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val energyTickRunnable = object : Runnable {
        override fun run() {
            try { refreshEnergyUi() } catch (_: Exception) {}
            energyUiHandler.postDelayed(this, 15_000L)
        }
    }

    private fun startEnergyTicker() {
        energyUiHandler.removeCallbacks(energyTickRunnable)
        energyUiHandler.post(energyTickRunnable)
    }
    private var retryWatchInstalled = false
    private var lastRetryClickAt = 0L

    private fun applyEnergyFromServer(energy: Int, maxEnergy: Int, refreshDateIso: String, energyTimeSec: Int) {
        val max = if (maxEnergy > 0) maxEnergy else 3
        var refreshAt = 0L
        if (refreshDateIso.isNotBlank()) {
            try {
                val cleaned = refreshDateIso.trim().replace("Z", "+0000")
                val fmt = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", java.util.Locale.US)
                fmt.timeZone = java.util.TimeZone.getTimeZone("UTC")
                refreshAt = fmt.parse(cleaned)?.time ?: 0L
            } catch (_: Exception) {
                try {
                    val cleaned = refreshDateIso.trim().replace("Z", "+0000")
                    val fmt = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", java.util.Locale.US)
                    fmt.timeZone = java.util.TimeZone.getTimeZone("UTC")
                    refreshAt = fmt.parse(cleaned)?.time ?: 0L
                } catch (_: Exception) {
                    refreshAt = 0L
                }
            }
        }
        if (refreshAt <= 0L && energyTimeSec > 0 && energy < max) {
            refreshAt = System.currentTimeMillis() + energyTimeSec * 1000L
        }
        if (energy >= max) refreshAt = 0L
        prefs.setEnergyState(energy, max, refreshAt)
        if (refreshAt > System.currentTimeMillis()) {
            EnergyScheduler.schedule(this, refreshAt)
        } else {
            EnergyScheduler.cancel(this)
        }
        refreshEnergyUi()
    }

    private fun refreshEnergyUi() {
        val cur = prefs.getEnergyCurrent()
        val max = prefs.getEnergyMax().coerceAtLeast(3)
        val refreshAt = prefs.getEnergyRefreshAtMs()
        try {
            if (cur < 0) {
                binding.tvEnergyCount.text = "? / ?"
                binding.tvEnergyCount.setTextColor(android.graphics.Color.WHITE)
                binding.tvEnergyCount.setTypeface(binding.tvEnergyCount.typeface, android.graphics.Typeface.BOLD)
                binding.tvEnergyNext.visibility = android.view.View.GONE
                tintBattery(binding.imgBatteryLeft, -1)
                tintBattery(binding.imgBatteryRight, -1)
                return
            }
            val colorCur = when (cur) {
                0 -> android.graphics.Color.parseColor("#F44336")
                1 -> android.graphics.Color.parseColor("#FF9800")
                2 -> android.graphics.Color.parseColor("#FFEB3B")
                else -> android.graphics.Color.parseColor("#00E676")
            }
            val green = android.graphics.Color.parseColor("#00E676")
            val white = android.graphics.Color.WHITE
            val ss = android.text.SpannableString("$cur / $max")
            val curStr = cur.toString()
            ss.setSpan(android.text.style.ForegroundColorSpan(colorCur), 0, curStr.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            ss.setSpan(android.text.style.StyleSpan(android.graphics.Typeface.BOLD), 0, curStr.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            val slashStart = curStr.length
            val slashEnd = slashStart + 3
            ss.setSpan(android.text.style.ForegroundColorSpan(white), slashStart, Math.min(slashEnd, ss.length), android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            ss.setSpan(android.text.style.StyleSpan(android.graphics.Typeface.BOLD), slashStart, Math.min(slashEnd, ss.length), android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            if (slashEnd < ss.length) {
                ss.setSpan(android.text.style.ForegroundColorSpan(green), slashEnd, ss.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                ss.setSpan(android.text.style.StyleSpan(android.graphics.Typeface.BOLD), slashEnd, ss.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            binding.tvEnergyCount.text = ss
            tintBattery(binding.imgBatteryLeft, cur)
            tintBattery(binding.imgBatteryRight, cur)
            if (cur >= max || refreshAt <= 0L) {
                binding.tvEnergyNext.visibility = android.view.View.GONE
                binding.tvEnergyNext.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, 0, 0)
            } else {
                val left = refreshAt - System.currentTimeMillis()
                if (left <= 0L) {
                    binding.tvEnergyNext.visibility = android.view.View.GONE
                    binding.tvEnergyNext.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, 0, 0)
                } else {
                    binding.tvEnergyNext.visibility = android.view.View.VISIBLE
                    binding.tvEnergyNext.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, 0, 0)
                    try {
                        val fmt = LocaleHelper.t(this, "energy_next_fmt")
                        val time = formatDuration(left)
                        val idx = fmt.indexOf("%t")
                        val before = if (idx >= 0) fmt.substring(0, idx) else fmt
                        val after = if (idx >= 0) fmt.substring(idx + 2) else ""
                        val full = before + " " + time + after
                        val ss = android.text.SpannableString(full)
                        val clock = getDrawable(R.drawable.ic_clock)?.mutate()
                        if (clock != null) {
                            val size = (binding.tvEnergyNext.textSize).toInt().coerceAtLeast(28)
                            clock.setBounds(0, 0, size, size)
                            val span = android.text.style.ImageSpan(clock, android.text.style.ImageSpan.ALIGN_BASELINE)
                            // insert clock right before the time string
                            val timePos = before.length
                            // full = before + " " + time + after; clock replaces the space before time
                            if (timePos < full.length && full[timePos] == ' ') {
                                ss.setSpan(span, timePos, timePos + 1, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                            }
                        }
                        binding.tvEnergyNext.text = ss
                    } catch (_: Exception) {
                        binding.tvEnergyNext.text = LocaleHelper.t(this, "energy_next_fmt").replace("%t", formatDuration(left))
                    }
                }
            }
        } catch (_: Exception) {}
    }

    private fun formatDuration(ms: Long): String {
        var s = (ms / 1000).coerceAtLeast(0)
        val h = s / 3600
        s %= 3600
        val m = s / 60
        return "${h}h ${m}m"
    }

    private fun tintBattery(iv: android.widget.ImageView, level: Int) {
        try {
            when (level) {
                -1 -> { iv.setColorFilter(android.graphics.Color.WHITE); iv.alpha = 0.45f }
                0 -> { iv.setColorFilter(android.graphics.Color.parseColor("#F44336")); iv.alpha = 0.35f }
                1 -> { iv.setColorFilter(android.graphics.Color.parseColor("#FF9800")); iv.alpha = 0.55f }
                2 -> { iv.setColorFilter(android.graphics.Color.parseColor("#FFEB3B")); iv.alpha = 0.8f }
                else -> { iv.setColorFilter(android.graphics.Color.parseColor("#00E676")); iv.alpha = 1f }
            }
        } catch (_: Exception) {}
    }

    private fun showRetryLimitDialog() {
        val title = LocaleHelper.t(this, "retry_limit_title")
        val options = arrayOf("25 Web Coins", "50 Web Coins", LocaleHelper.t(this, "retry_limit_off"))
        val current = prefs.getRetryLimit()
        val checked = when (current) {
            25 -> 0
            50 -> 1
            else -> 2
        }
        android.app.AlertDialog.Builder(this)
            .setTitle(title)
            .setSingleChoiceItems(options, checked) { dialog, which ->
                val lim = when (which) {
                    0 -> 25
                    1 -> 50
                    else -> 0
                }
                prefs.setRetryLimit(lim)
                if (lim > 0) {
                    prefs.setRetryLimitSaved(lim)
                } else {
                    prefs.setRetryLimitSaved(0) // eligió No Reintentar a propósito
                }
                updateRetryButton()
                if (lim > 0 && prefs.isAutoClickEnabled()) ensureRetryWatcher()
                dialog.dismiss()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }


    private fun hasNotificationPermission(): Boolean {
        return try {
            val enabled = androidx.core.app.NotificationManagerCompat.from(this).areNotificationsEnabled()
            if (!enabled) return false
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) ==
                    android.content.pm.PackageManager.PERMISSION_GRANTED
            } else {
                true
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun syncNotifPermissionState() {
        try {
            if (!::prefs.isInitialized || !::binding.isInitialized) return
            if (prefs.isNotifDecorEnabled() && !hasNotificationPermission()) {
                prefs.setNotifDecorEnabled(false)
                updateNotifDecorButton()
            }
        } catch (_: Exception) {}
    }

    private fun openAppNotificationSettings() {
        try {
            val intent = android.content.Intent()
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                intent.action = android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS
                intent.putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, packageName)
            } else {
                intent.action = android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                intent.data = android.net.Uri.parse("package:$packageName")
            }
            startActivity(intent)
        } catch (_: Exception) {
            try {
                val intent = android.content.Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                intent.data = android.net.Uri.parse("package:$packageName")
                startActivity(intent)
            } catch (_: Exception) {}
        }
    }

    private fun requestNotifPermissionIfNeeded() {
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            try {
                if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                    != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 9101)
                }
            } catch (_: Exception) {}
        }
        EnergyNotifier.ensureChannel(this)
    }

    private fun ensureRetryWatcher() {
        if (!prefs.isAutoClickEnabled() || prefs.getRetryLimit() <= 0) return
        val lim = prefs.getRetryLimit()
        try {
            binding.webView1.evaluateJavascript(
                "(function(){ try{ clearInterval(window._triviasRetryWatch); window._triviasRetryWatch=null; clearInterval(window._triviasRetryClick); window._triviasRetryClick=null; }catch(e){} })();",
                null
            )
        } catch (_: Exception) {}
        val js = """
            (function(){
                if(window._triviasRetryWatch) return;
                window._triviasRetryWatch = setInterval(function(){
                    try{
                        var body = (document.body && document.body.innerText) ? document.body.innerText : '';
                        if(body.indexOf('Too Bad') === -1 && body.indexOf('Want To Continue') === -1) return;
                        var btns = document.querySelectorAll('button');
                        for(var i=0;i<btns.length;i++){
                            var t = (btns[i].innerText || btns[i].textContent || '').replace(/\s+/g,' ').trim();
                            var m = t.match(/\b(25|50)\b/);
                            if(!m) continue;
                            var cost = parseInt(m[1],10);
                            if(typeof AndroidChatGPT !== 'undefined' && AndroidChatGPT.onRetryCostSeen){
                                AndroidChatGPT.onRetryCostSeen(cost);
                            }
                            break;
                        }
                    }catch(e){}
                }, 800);
            })();
        """.trimIndent()
        try { binding.webView1.evaluateJavascript(js, null) } catch (_: Exception) {}
        // Also install click helper with limit baked in for reliability
        val jsClick = """
            (function(){
                if(window._triviasRetryClick) return;
                var lim = $lim;
                window._triviasRetryClick = setInterval(function(){
                    try{
                        var body = (document.body && document.body.innerText) ? document.body.innerText : '';
                        if(body.indexOf('Too Bad') === -1 && body.indexOf('Want To Continue') === -1) return;
                        var btns = document.querySelectorAll('button');
                        for(var i=0;i<btns.length;i++){
                            var b = btns[i];
                            var t = (b.innerText || b.textContent || '').replace(/\s+/g,' ').trim();
                            var m = t.match(/\b(25|50)\b/);
                            if(!m) continue;
                            var cost = parseInt(m[1],10);
                            if(cost <= lim){
                                if(b.getAttribute('data-trivias-retry-pending')==='1') break;
                                b.setAttribute('data-trivias-retry-pending','1');
                                setTimeout(function(){ try{ var now=Date.now(); if(window._triviasLastClick && (now-window._triviasLastClick)<500) return; window._triviasLastClick=Date.now(); b.click(); }catch(e){} }, 500);
                                break;
                            }
                        }
                    }catch(e){}
                }, 900);
            })();
        """.trimIndent()
        try { binding.webView1.evaluateJavascript(jsClick, null) } catch (_: Exception) {}
    }


    private fun startChromeBorderAnimations() {
        // Borde con dos colores que circulan (SweepGradient rotatorio)
        try {
            val density = resources.displayMetrics.density
            fun attachRotatingBorder(view: android.view.View, c1: Int, c2: Int, durationMs: Long) {
                val stroke = (2.5f * density).toInt().coerceAtLeast(2)
                val radius = 16f * density
                val anim = android.animation.ValueAnimator.ofFloat(0f, 360f).apply {
                    duration = durationMs
                    repeatCount = android.animation.ValueAnimator.INFINITE
                    interpolator = android.view.animation.LinearInterpolator()
                    addUpdateListener { a ->
                        val angle = a.animatedValue as Float
                        try {
                            val w = view.width.coerceAtLeast(1)
                            val h = view.height.coerceAtLeast(1)
                            val shader = android.graphics.SweepGradient(
                                w / 2f, h / 2f,
                                intArrayOf(c1, c2, c1),
                                floatArrayOf(0f, 0.5f, 1f)
                            )
                            val m = android.graphics.Matrix()
                            m.postRotate(angle, w / 2f, h / 2f)
                            shader.setLocalMatrix(m)
                            val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
                            paint.shader = shader
                            paint.style = android.graphics.Paint.Style.STROKE
                            paint.strokeWidth = stroke.toFloat()
                            val bmp = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888)
                            val canvas = android.graphics.Canvas(bmp)
                            val fill = android.graphics.Paint()
                            fill.color = 0xFF14101F.toInt()
                            canvas.drawRoundRect(0f, 0f, w.toFloat(), h.toFloat(), radius, radius, fill)
                            val rr = android.graphics.RectF(
                                stroke / 2f, stroke / 2f,
                                w - stroke / 2f, h - stroke / 2f
                            )
                            canvas.drawRoundRect(rr, radius, radius, paint)
                            view.background = android.graphics.drawable.BitmapDrawable(resources, bmp)
                        } catch (_: Exception) {}
                    }
                    start()
                }
                
            }
            val purple = 0xFFE040FB.toInt()
            val cyan = 0xFF00E5FF.toInt()
            binding.cardAnswer.post {
                attachRotatingBorder(binding.cardAnswer, purple, cyan, 4000L)
            }
            binding.cardWeb.post {
                attachRotatingBorder(binding.cardWeb, purple, cyan, 4500L)
            }
        } catch (_: Exception) {}
    }

    private fun startAnswerBlink() {
        answerBlink = AlphaAnimation(1f, 0.25f).apply {
            duration = 700
            repeatMode = Animation.REVERSE
            repeatCount = Animation.INFINITE
        }
    }

    private var aiProviderToast: Toast? = null
    private val aiToastHandler = android.os.Handler(android.os.Looper.getMainLooper())

    private fun showAiProviderToast(message: String, durationMs: Long = 4000L) {
        aiProviderToast?.cancel()
        aiToastHandler.removeCallbacksAndMessages(null)
        val toast = Toast.makeText(this, message, Toast.LENGTH_LONG)
        aiProviderToast = toast
        toast.show()
        aiToastHandler.postDelayed({
            try { toast.cancel() } catch (_: Exception) {}
            if (aiProviderToast === toast) aiProviderToast = null
        }, durationMs)
    }

    private fun updateAiProviderButton() {
        // Modo AI fijo (GROQ prioritario); botón eliminado de la UI
    }

    private fun updateAutoClickButton() {
        val on = prefs.isAutoClickEnabled()
        try {
            binding.btnAutoClick.setBackgroundResource(
                if (on) R.drawable.bg_btn_auto_on else R.drawable.bg_btn_auto_off
            )
            binding.tvAutoClickBadge.text = if (on) "ON" else "OFF"
            binding.tvAutoClickBadge.setTypeface(binding.tvAutoClickBadge.typeface, android.graphics.Typeface.BOLD)
            binding.tvAutoClickLabel.text = "AUTO-CLICK"
        } catch (_: Exception) {}
    }

    private fun updateNotifDecorButton() {
        val on = prefs.isNotifDecorEnabled()
        try {
            binding.btnNotificaciones.setBackgroundResource(
                if (on) R.drawable.bg_btn_notif_on else R.drawable.bg_btn_notif_off
            )
            binding.tvNotifBadge.text = if (on) "ON" else "OFF"
            binding.tvNotifBadge.setTypeface(binding.tvNotifBadge.typeface, android.graphics.Typeface.BOLD)
        } catch (_: Exception) {}
    }

    private fun updateRetryButton() {
        val lim = prefs.getRetryLimit()
        try {
            if (lim <= 0) {
                binding.btnReintentar.setBackgroundResource(R.drawable.bg_btn_auto_off)
                // reuse auto-off red with white border
                if (binding.tvReintentarLabel != null) { /* label via applyStrings */ }
            } else {
                binding.btnReintentar.setBackgroundResource(R.drawable.bg_btn_auto_on)
            }
            // Badge LMT / OFF on top-left: use tag view if exists — create via text on label prefix
            val badge = binding.root.findViewWithTag<android.widget.TextView>("retry_lmt_badge")
            // Fallback: put limit in a small overlay — layout has no badge; use content description and overlay TextView id if we add
        } catch (_: Exception) {}
        try {
            val lim = prefs.getRetryLimit()
            val tvBadge = binding.root.findViewById<android.widget.TextView>(R.id.tvRetryLimitBadge)
            if (tvBadge != null) {
                if (lim <= 0) {
                    tvBadge.text = "OFF"
                    binding.btnReintentar.setBackgroundResource(R.drawable.bg_btn_auto_off)
                } else {
                    tvBadge.text = "LMT. $lim"
                    binding.btnReintentar.setBackgroundResource(R.drawable.bg_btn_auto_on)
                }
                tvBadge.setTypeface(tvBadge.typeface, android.graphics.Typeface.BOLD)
            }
        } catch (_: Exception) {}
    }

    private fun applyStrings() {
        binding.tvAppTitle.text = LocaleHelper.t(this, "app_name")
        binding.tvLanguage.text = currentLanguageLabel().uppercase(java.util.Locale.getDefault())
        try {
            val flagRes = when (LocaleHelper.getLang(this)) {
                LocaleHelper.EN -> R.drawable.ic_flag_en
                LocaleHelper.PT -> R.drawable.ic_flag_pt
                LocaleHelper.ID -> R.drawable.ic_flag_id
                else -> R.drawable.ic_flag_es
            }
            binding.imgLanguageFlag.setImageResource(flagRes)
        } catch (_: Exception) {}
        binding.tvAnswerLabel.text = LocaleHelper.t(this, "energy_title")
        try {
            refreshEnergyUi()
        } catch (_: Exception) {}
        try {
            binding.tvOpenWebLabel.text = LocaleHelper.t(this, "start_webview")
            binding.tvOpenWebLabel.setTypeface(binding.tvOpenWebLabel.typeface, android.graphics.Typeface.BOLD)
            binding.tvTutorialGrid.text = LocaleHelper.t(this, "btn_tutorial")
            binding.tvTutorialGrid.setTypeface(binding.tvTutorialGrid.typeface, android.graphics.Typeface.BOLD)
            binding.tvDonateGrid.text = LocaleHelper.t(this, "btn_donations")
            binding.tvDonateGrid.setTypeface(binding.tvDonateGrid.typeface, android.graphics.Typeface.BOLD)
            binding.tvReintentarLabel.text = LocaleHelper.t(this, "btn_retry")
            binding.tvReintentarLabel.setTypeface(binding.tvReintentarLabel.typeface, android.graphics.Typeface.BOLD)
            binding.tvNotificacionesLabel.text = LocaleHelper.t(this, "btn_notifications")
            binding.tvNotificacionesLabel.setTypeface(binding.tvNotificacionesLabel.typeface, android.graphics.Typeface.BOLD)
            binding.tvAutoClickLabel.setTypeface(binding.tvAutoClickLabel.typeface, android.graphics.Typeface.BOLD)
        } catch (_: Exception) {}
        try {
            binding.tvTutorial.text = LocaleHelper.t(this, "tutorial")
            binding.tvDonate.text = LocaleHelper.t(this, "donations")
        } catch (_: Exception) {}
        /* icon-only */ binding.btnCloseWeb.text = ""
        /* icon-only */ binding.btnSwitchWeb.text = ""
        /* icon-only */ binding.btnBackWeb.text = ""
        styleWebControlButtons()
        binding.btnTestChatSend.setTypeface(binding.btnTestChatSend.typeface, android.graphics.Typeface.BOLD)
        try {
            binding.tvTestChatLabel.text = LocaleHelper.t(this, "send_to_chatgpt")
            binding.tvTestChatLabel.setTypeface(binding.tvTestChatLabel.typeface, android.graphics.Typeface.BOLD)
            binding.btnTestChatSend.text = LocaleHelper.t(this, "send")
        } catch (_: Exception) {}
        updateAutoClickButton()
        // Placeholder del banner WebView si está en idle de respuesta
        try {
            val cur = binding.tvWebAnswerValue.text?.toString().orEmpty()
            if (cur.isEmpty() || cur.contains("---") || cur == "- - - - - -") {
                binding.tvWebAnswerValue.text = LocaleHelper.t(this, "answer_placeholder")
            }
        } catch (_: Exception) {}
    }

    private fun showLanguagePicker() {
        val langs = arrayOf("Español", "English", "Português", "Bahasa Indonesia")
        val codes = arrayOf("es", "en", "pt", "id")
        AlertDialog.Builder(this).setTitle(LocaleHelper.t(this, "language")).setItems(langs) { _, which -> LocaleHelper.setLang(this, codes[which]); applyStrings() }.show()
    }

    private fun showHelp(title: String, body: String) {
        binding.helpTitle.text = title
        binding.helpTitle.setTypeface(binding.helpTitle.typeface, android.graphics.Typeface.BOLD)
        binding.helpTitle.setTextColor(android.graphics.Color.parseColor("#E040FB"))
        val ss = android.text.SpannableString(body)
        ss.setSpan(android.text.style.StyleSpan(android.graphics.Typeface.BOLD), 0, ss.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        val links = listOf(
            "www.wwechampions.com",
            "WWEChampions.com",
            "wwechampions.com"
        )
        for (link in links) {
            var start = body.indexOf(link)
            while (start >= 0) {
                val end = start + link.length
                ss.setSpan(android.text.style.ForegroundColorSpan(android.graphics.Color.parseColor("#42A5F5")), start, end, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                ss.setSpan(android.text.style.StyleSpan(android.graphics.Typeface.BOLD), start, end, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                start = body.indexOf(link, end)
            }
        }
        binding.helpBody.text = ss
        binding.helpBody.movementMethod = null // no clickable links
        binding.helpOverlay.visibility = View.VISIBLE
    }

    private fun openPaypal() {
        val url = "https://www.paypal.me/randyrubi"
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) { Toast.makeText(this, url, Toast.LENGTH_SHORT).show() }
    }


    private fun screenW(): Float = resources.displayMetrics.widthPixels.coerceAtLeast(1).toFloat()

    private fun ensureAdminDrawer() {
        if (adminBound) return
        try {
            binding.adminDrawer.removeAllViews()
            layoutInflater.inflate(R.layout.activity_admin, binding.adminDrawer, true)
            // ocultar mainPeek interno si existe
            try { binding.adminDrawer.findViewById<View>(R.id.mainPeek)?.visibility = View.GONE } catch (_: Exception) {}
            val c = AdminController(this, binding.adminDrawer)
            c.onClose = { closeAdminPanel(animated = true) }
            c.bind()
            adminController = c
            adminBound = true
        } catch (e: Exception) {
            try { Toast.makeText(this, e.message, Toast.LENGTH_SHORT).show() } catch (_: Exception) {}
        }
        // fuera de pantalla a la derecha y sin comer toques
        binding.adminDrawer.translationX = screenW()
        binding.adminDrawer.visibility = View.GONE
        binding.adminDrawer.isClickable = false
        binding.mainLayer.translationX = 0f
        binding.mainLayer.bringToFront()
    }

    /** Evita que el gesto de cerrar el drawer se apropie de los toques de los controles WebView. */
    private fun isWebControlTouch(ev: MotionEvent): Boolean {
        val controls = listOf(binding.btnCloseWeb, binding.btnSwitchWeb, binding.btnBackWeb, binding.btnAdminLock)
        for (view in controls) {
            if (view.visibility != View.VISIBLE || !view.isShown) continue
            val location = IntArray(2)
            view.getLocationOnScreen(location)
            val x = ev.rawX
            val y = ev.rawY
            if (x >= location[0] && x < location[0] + view.width &&
                y >= location[1] && y < location[1] + view.height) return true
        }
        return false
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        val webOpen = web1Open || web2Open
        val allowOpen = (!webOpen || adminGestureUnlocked) &&
            prefs.getUserRole().equals("ADMIN", ignoreCase = true) && !openingAdminPanel
        val w = screenW()
        val edge = w * ADMIN_EDGE_FRACTION
        val threshold = w * ADMIN_SWIPE_THRESHOLD

        // --- Cerrar: arrastrar el panel ADMIN hacia fuera (derecha). El principal no se mueve. ---
        if (adminPanelOpen) {
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    if (ev.x <= edge && !isWebControlTouch(ev)) {
                        adminSwipeActive = true
                        panelDragCommitted = false
                        edgeSwipeStartX = ev.x
                        edgeSwipeStartY = ev.y
                        adminVelocityTracker?.recycle()
                        adminVelocityTracker = android.view.VelocityTracker.obtain()
                        adminVelocityTracker?.addMovement(ev)
                        binding.adminDrawer.animate().cancel()
                        binding.adminDrawer.bringToFront()
                        binding.adminDrawer.elevation = elevDp(28f)
                        binding.mainLayer.elevation = 0f
                        binding.mainLayer.translationX = 0f
                        binding.adminDrawer.translationX = 0f
                        beginPanelDrag(binding.adminDrawer)
                        return true
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    if (adminSwipeActive) {
                        adminVelocityTracker?.addMovement(ev)
                        val dx = (ev.x - edgeSwipeStartX).coerceAtLeast(0f)
                        val dy = kotlin.math.abs(ev.y - edgeSwipeStartY)
                        if (!panelDragCommitted) {
                            if (dx > 12f) panelDragCommitted = true
                            else if (dy > dx * 1.8f && dx < 16f) {
                                adminSwipeActive = false
                                endPanelDrag(binding.adminDrawer)
                                binding.adminDrawer.animate()
                                    .translationX(0f)
                                    .setDuration(ADMIN_ANIM_MS)
                                    .setInterpolator(adminEase())
                                    .start()
                                return true
                            }
                        }
                        // El dedo desplaza el propio drawer; el panel principal permanece fijo.
                        binding.adminDrawer.translationX = dx.coerceIn(0f, w)
                        return true
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (adminSwipeActive) {
                        adminVelocityTracker?.addMovement(ev)
                        adminVelocityTracker?.computeCurrentVelocity(1000)
                        val vx = adminVelocityTracker?.xVelocity ?: 0f
                        adminVelocityTracker?.recycle()
                        adminVelocityTracker = null
                        val dx = (ev.x - edgeSwipeStartX).coerceAtLeast(0f)
                        adminSwipeActive = false
                        val fling = vx > 900f && dx > w * 0.12f
                        val done = { endPanelDrag(binding.adminDrawer) }
                        if (dx >= threshold || fling) {
                            binding.adminDrawer.animate()
                                .translationX(w)
                                .setDuration(ADMIN_ANIM_MS)
                                .setInterpolator(adminEase())
                                .withEndAction {
                                    done()
                                    closeAdminPanel(animated = false)
                                }.start()
                        } else {
                            binding.adminDrawer.animate()
                                .translationX(0f)
                                .setDuration(ADMIN_ANIM_MS)
                                .setInterpolator(adminEase())
                                .withEndAction {
                                    done()
                                    binding.adminDrawer.bringToFront()
                                    binding.adminDrawer.elevation = elevDp(28f)
                                }.start()
                        }
                        return true
                    }
                }
            }
            return super.dispatchTouchEvent(ev)
        }

        // --- Abrir: admin REAL desde la derecha ---
        if (allowOpen) {
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    if (ev.x >= (w - edge)) {
                        edgeSwipeTracking = true
                        panelDragCommitted = false
                        edgeSwipeStartX = ev.x
                        edgeSwipeStartY = ev.y
                        adminVelocityTracker?.recycle()
                        adminVelocityTracker = android.view.VelocityTracker.obtain()
                        adminVelocityTracker?.addMovement(ev)
                        ensureAdminDrawer()
                        binding.adminDrawer.visibility = View.VISIBLE
                        binding.adminDrawer.isClickable = true
                        binding.adminDrawer.animate().cancel()
                        binding.adminDrawer.bringToFront()
                        binding.adminDrawer.elevation = elevDp(28f)
                        binding.mainLayer.elevation = 0f
                        binding.mainLayer.translationX = 0f
                        beginPanelDrag(binding.adminDrawer)
                        return true
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    if (edgeSwipeTracking) {
                        adminVelocityTracker?.addMovement(ev)
                        val dx = (ev.x - edgeSwipeStartX).coerceAtMost(0f)
                        val dy = kotlin.math.abs(ev.y - edgeSwipeStartY)
                        if (!panelDragCommitted) {
                            if (kotlin.math.abs(dx) > 12f) panelDragCommitted = true
                            else if (dy > kotlin.math.abs(dx) * 1.8f && kotlin.math.abs(dx) < 16f) {
                                edgeSwipeTracking = false
                                endPanelDrag(binding.adminDrawer)
                                binding.adminDrawer.animate()
                                    .translationX(w)
                                    .setDuration(ADMIN_ANIM_MS)
                                    .setInterpolator(adminEase())
                                    .start()
                                return true
                            }
                        }
                        binding.mainLayer.translationX = 0f
                        binding.adminDrawer.translationX = (w + dx).coerceIn(0f, w)
                        return true
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (edgeSwipeTracking) {
                        adminVelocityTracker?.addMovement(ev)
                        adminVelocityTracker?.computeCurrentVelocity(1000)
                        val vx = adminVelocityTracker?.xVelocity ?: 0f
                        adminVelocityTracker?.recycle()
                        adminVelocityTracker = null
                        val dx = ev.x - edgeSwipeStartX
                        edgeSwipeTracking = false
                        val dragged = -dx
                        val fling = vx < -900f && dragged > w * 0.12f
                        val done = { endPanelDrag(binding.adminDrawer) }
                        if (dragged >= threshold || fling) {
                            binding.adminDrawer.animate()
                                .translationX(0f)
                                .setDuration(ADMIN_ANIM_MS)
                                .setInterpolator(adminEase())
                                .withEndAction {
                                    done()
                                    openAdminPanelSettled()
                                }.start()
                        } else {
                            binding.adminDrawer.animate()
                                .translationX(w)
                                .setDuration(ADMIN_ANIM_MS)
                                .setInterpolator(adminEase())
                                .withEndAction { done() }
                                .start()
                        }
                        return true
                    }
                }
            }
        }
        return super.dispatchTouchEvent(ev)
    }


    private fun openAdminPanelSettled() {
        adminPanelOpen = true
        openingAdminPanel = false
        edgeSwipeTracking = false
        adminSwipeActive = false
        panelDragCommitted = false
        binding.adminDrawer.visibility = View.VISIBLE
        binding.adminDrawer.isClickable = true
        binding.adminDrawer.bringToFront()
        binding.adminDrawer.elevation = elevDp(28f)
        binding.adminDrawer.translationX = 0f
        binding.mainLayer.translationX = 0f
        binding.mainLayer.elevation = 0f
        try { endPanelDrag(binding.adminDrawer) } catch (_: Exception) {}
        try { adminController?.onHostResume() } catch (_: Exception) {}
    }

    private fun closeAdminPanel(animated: Boolean) {
        val w = screenW()
        adminPanelOpen = false
        openingAdminPanel = false
        adminSwipeActive = false
        edgeSwipeTracking = false
        panelDragCommitted = false
        try { adminVelocityTracker?.recycle() } catch (_: Exception) {}
        adminVelocityTracker = null
        // Restaurar capas y que el principal reciba clics
        try {
            endPanelDrag(binding.mainLayer)
            endPanelDrag(binding.adminDrawer)
        } catch (_: Exception) {}
        binding.mainLayer.animate().cancel()
        binding.adminDrawer.animate().cancel()
        binding.mainLayer.elevation = 0f
        binding.mainLayer.translationX = 0f
        binding.mainLayer.bringToFront()
        binding.adminDrawer.elevation = elevDp(28f)
        val finishHide = {
            binding.adminDrawer.translationX = w
            // GONE: evita que un drawer fuera de pantalla siga comiendo toques
            binding.adminDrawer.visibility = View.GONE
            binding.adminDrawer.isClickable = false
        }
        if (animated) {
            binding.adminDrawer.visibility = View.VISIBLE
            binding.adminDrawer.animate()
                .translationX(w)
                .setDuration(ADMIN_ANIM_MS)
                .setInterpolator(adminEase())
                .withEndAction { finishHide() }
                .start()
        } else {
            finishHide()
        }
    }


    private fun isSuperAdminEmail(): Boolean {
        val target = "randy.vargas51@gmail.com"
        var email = prefs.getUserEmail().trim()
        if (email.isEmpty()) {
            email = try {
                com.google.android.gms.auth.api.signin.GoogleSignIn
                    .getLastSignedInAccount(this)?.email?.trim().orEmpty()
            } catch (_: Exception) { "" }
            if (email.isNotEmpty()) {
                try { prefs.setUserEmail(email) } catch (_: Exception) {}
            }
        }
        return email.equals(target, ignoreCase = true)
    }

    private fun compareVersions(current: String, required: String): Int {
        fun parts(s: String) = s.trim().split(".").map { it.toIntOrNull() ?: 0 }
        val a = parts(current)
        val b = parts(required)
        val n = maxOf(a.size, b.size)
        for (i in 0 until n) {
            val x = a.getOrElse(i) { 0 }
            val y = b.getOrElse(i) { 0 }
            if (x != y) return x.compareTo(y)
        }
        return 0
    }

    private fun checkForceUpdate() {
        Thread {
            try {
                val info = SupabaseBanClient.getForceUpdate()
                val cur = try {
                    packageManager.getPackageInfo(packageName, 0).versionName ?: "0"
                } catch (_: Exception) {
                    "0"
                }
                // News icon: after update to required version, show once
                // ! novedades: SOLO la versión exacta del force update (no superiores)
                if (info.news.isNotBlank() &&
                    info.minVersion.isNotBlank() &&
                    compareVersions(cur, info.minVersion) == 0 &&
                    prefs.getSeenNewsVersion() != info.minVersion
                ) {
                    runOnUiThread { showWhatsNewIcon(info.news, info.minVersion) }
                } else {
                    runOnUiThread { hideWhatsNewIcon() }
                }
                // Force update dialog (super admin exempt)
                if (isSuperAdminEmail()) return@Thread
                if (!info.enabled || info.minVersion.isBlank()) return@Thread
                if (compareVersions(cur, info.minVersion) >= 0) return@Thread
                runOnUiThread { showForceUpdateDialog(info.apkUrl) }
            } catch (_: Exception) {
            }
        }.start()
    }

    private var whatsNewBounce: Animation? = null
    private var pendingNewsText: String = ""
    private var pendingNewsVersion: String = ""

    private fun showWhatsNewIcon(news: String, version: String) {
        pendingNewsText = news
        pendingNewsVersion = version
        val btn = binding.btnWhatsNew
        btn.visibility = View.VISIBLE
        whatsNewBounce?.cancel()
        whatsNewBounce = android.view.animation.TranslateAnimation(0f, 0f, 0f, -10f).apply {
            duration = 450
            repeatMode = Animation.REVERSE
            repeatCount = Animation.INFINITE
        }
        btn.startAnimation(whatsNewBounce)
        btn.setOnClickListener {
            haptic()
            showWhatsNewDialog(pendingNewsText, pendingNewsVersion)
        }
    }

    private fun hideWhatsNewIcon() {
        whatsNewBounce?.cancel()
        whatsNewBounce = null
        binding.btnWhatsNew.clearAnimation()
        binding.btnWhatsNew.visibility = View.GONE
    }

    private fun showWhatsNewDialog(news: String, version: String) {
        val density = resources.displayMetrics.density
        val side = (280 * density).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 20, 24, 16)
            setBackgroundResource(R.drawable.bg_card)
            layoutParams = LinearLayout.LayoutParams(side, side)
        }
        val title = TextView(this).apply {
            text = LocaleHelper.t(this@MainActivity, "whats_new_title")
            setTextColor(Color.parseColor("#FFD700"))
            textSize = 17f
            setTypeface(typeface, Typeface.BOLD)
            gravity = android.view.Gravity.CENTER
            setPadding(0, 0, 0, 12)
        }
        val scroll = android.widget.ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
            isFillViewport = true
        }
        val body = TextView(this).apply {
            text = news
            setTextColor(Color.WHITE)
            textSize = 14f
            gravity = android.view.Gravity.CENTER_HORIZONTAL
            setPadding(8, 4, 8, 8)
        }
        scroll.addView(body)
        box.addView(title)
        box.addView(scroll)
        val dlg = AlertDialog.Builder(this).setView(box).setCancelable(true).create()
        dlg.setOnDismissListener {
            prefs.setSeenNewsVersion(version)
            hideWhatsNewIcon()
        }
        dlg.show()
        dlg.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dlg.window?.setLayout(side, side)
    }

    private fun showForceUpdateDialog(apkUrl: String) {
        if (forceUpdateDialog?.isShowing == true) return
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 24)
            setBackgroundResource(R.drawable.bg_card)
            gravity = android.view.Gravity.CENTER_HORIZONTAL
        }
        val title = TextView(this).apply {
            text = LocaleHelper.t(this@MainActivity, "force_update_title")
            setTextColor(Color.WHITE)
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            gravity = android.view.Gravity.CENTER
            setPadding(0, 0, 0, 16)
        }
        val msg = TextView(this).apply {
            text = LocaleHelper.t(this@MainActivity, "force_update_msg")
            setTextColor(Color.WHITE)
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            gravity = android.view.Gravity.CENTER
            setPadding(0, 0, 0, 22)
        }
        val btn = Button(this).apply {
            text = LocaleHelper.t(this@MainActivity, "force_update_btn")
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            backgroundTintList = null
            setBackgroundColor(Color.parseColor("#25D366"))
            textSize = 14f
            // WhatsApp-style compact button
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.gravity = android.view.Gravity.CENTER_HORIZONTAL
            layoutParams = lp
            setPadding(48, 18, 48, 18)
            minWidth = 0
            minimumWidth = 0
            setOnClickListener {
                haptic()
                val url = apkUrl.trim()
                if (url.isEmpty()) {
                    Toast.makeText(this@MainActivity, "URL vacía", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                try {
                    val uri = Uri.parse(url)
                    val intent = Intent(Intent.ACTION_VIEW, uri)
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(intent)
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, e.message ?: "Error", Toast.LENGTH_LONG).show()
                }
            }
        }
        box.addView(title)
        box.addView(msg)
        box.addView(btn)
        val dlg = AlertDialog.Builder(this)
            .setView(box)
            .setCancelable(false)
            .create()
        dlg.setCanceledOnTouchOutside(false)
        dlg.setOnKeyListener { _, keyCode, _ ->
            keyCode == android.view.KeyEvent.KEYCODE_BACK
        }
        forceUpdateDialog = dlg
        dlg.show()
        dlg.window?.setBackgroundDrawableResource(android.R.color.transparent)
    }

    private fun tryOpenAdminPanel() {
        if (openingAdminPanel || adminPanelOpen) return
        if (!prefs.getUserRole().equals("ADMIN", ignoreCase = true)) return
        openingAdminPanel = true
        ensureAdminDrawer()
        val w = screenW()
        binding.adminDrawer.animate().translationX(0f).setDuration(220).withEndAction {
            openAdminPanelSettled()
        }.start()
    }


    private fun currentLanguageLabel(): String = when (LocaleHelper.getLang(this)) {
        LocaleHelper.ES -> "Idioma"; LocaleHelper.PT -> "Idioma"; LocaleHelper.ID -> "Bahasa Indonesia"; else -> "Language"
    }

    private fun showVersionBadge() {
        val ver = try { val pi = packageManager.getPackageInfo(packageName, 0); pi.versionName ?: "1.0.82" } catch (_: Exception) { "1.0.82" }
        binding.tvVersion.text = if (ver.startsWith("v")) ver else "v$ver"
    }

    companion object {

        /**
         * Interceptor de red apuntado al endpoint real descubierto:
         *   https://chatgpt.com/unauth-mweb/conversation/updates?lightweight_authenticated=0&operationId=...
         *
         * El texto de la respuesta viene en el campo JSON "markdown".
         * Se enganchan fetch + XHR. operationId cambia cada vez; el path /updates es estable.
         */
        private val CHAT_GPT_NETWORK_INJECTOR = """
            (function(){
                // Reset por cada carga de página (cada pregunta nueva)
                window._triviaLastAnswer = "";
                window._triviaBestMarkdown = "";

                function isNoise(t) {
                    if (!t || t.length < 1 || t.length > 400) return true;
                    var low = t.toLowerCase();
                    if (low.indexOf("reply with only") !== -1) return true;
                    if (low.indexOf("quickly answer") !== -1) return true;
                    if (low.indexOf("wwe trivia") !== -1) return true;
                    if (low.indexOf("please answer") !== -1) return true;
                    if (low.indexOf("no explanations") !== -1) return true;
                    if (low.indexOf("just the answer") !== -1) return true;
                    if (low.indexOf("searching") !== -1) return true;
                    if (low.indexOf("thinking") !== -1) return true;
                    return false;
                }

                function sendAnswer(txt) {
                    if (!txt) return;
                    var first = ("" + txt).trim().split(/[\r\n]+/).map(function(l){ return l.trim(); }).filter(function(l){ return l.length > 0; })[0] || "";
                    // Quitar emojis comunes al inicio/final si el modelo los pone
                    first = first.replace(/^[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}\s]+/u, "").replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}\s]+$/u, "").trim();
                    if (isNoise(first)) return;
                    if (first === window._triviaLastAnswer) return;
                    window._triviaLastAnswer = first;
                    if (typeof AndroidChatGPT !== "undefined" && AndroidChatGPT.onRespuestaChatGPT) {
                        AndroidChatGPT.onRespuestaChatGPT(first);
                    }
                }

                function extractMarkdown(raw) {
                    if (!raw || typeof raw !== "string") return "";
                    var best = "";

                    // 1) Buscar "markdown":"..." con regex (funciona aunque haya varios eventos)
                    try {
                        var re = /"markdown"\s*:\s*"((?:\\.|[^"\\])*)"/g;
                        var m;
                        while ((m = re.exec(raw)) !== null) {
                            var decoded = m[1]
                                .replace(/\\n/g, "\n")
                                .replace(/\\r/g, "")
                                .replace(/\\"/g, '"')
                                .replace(/\\\\/g, "\\")
                                .replace(/\\u[\dA-Fa-f]{4}/g, function(x) {
                                    try { return String.fromCharCode(parseInt(x.slice(2), 16)); } catch(e) { return x; }
                                });
                            decoded = decoded.trim();
                            if (decoded.length > best.length) best = decoded;
                        }
                    } catch (e) {}

                    // 2) Intentar parsear como JSON / líneas JSON
                    if (!best) {
                        var chunks = raw.split(/\n/);
                        for (var i = 0; i < chunks.length; i++) {
                            var line = chunks[i].trim();
                            if (line.indexOf("data: ") === 0) line = line.substring(6).trim();
                            if (!line || line === "[DONE]") continue;
                            try {
                                var obj = JSON.parse(line);
                                var md = findMarkdownInObject(obj);
                                if (md && md.length > best.length) best = md;
                            } catch (e) {}
                        }
                    }

                    // 3) Parsear el body completo
                    if (!best) {
                        try {
                            var whole = JSON.parse(raw);
                            var md2 = findMarkdownInObject(whole);
                            if (md2) best = md2;
                        } catch (e) {}
                    }

                    return best;
                }

                function findMarkdownInObject(obj) {
                    if (!obj || typeof obj !== "object") return "";
                    if (typeof obj.markdown === "string" && obj.markdown.trim()) return obj.markdown.trim();
                    // Estructura vista en DevTools: type/content con markdown
                    if (obj.type === "content" && typeof obj.markdown === "string") return obj.markdown.trim();
                    // dil.constants["0"] a veces duplica el texto
                    if (obj.dil && obj.dil.constants && typeof obj.dil.constants["0"] === "string") {
                        return obj.dil.constants["0"].trim();
                    }
                    // Recorrer propiedades de primer nivel
                    for (var k in obj) {
                        if (!obj.hasOwnProperty(k)) continue;
                        var v = obj[k];
                        if (typeof v === "string" && k.toLowerCase().indexOf("markdown") !== -1 && v.trim()) return v.trim();
                        if (v && typeof v === "object") {
                            var inner = findMarkdownInObject(v);
                            if (inner) return inner;
                        }
                    }
                    return "";
                }

                function handleBody(raw) {
                    var md = extractMarkdown(raw);
                    if (!md) return;
                    // Quedarse con el markdown más largo visto (el stream puede ir creciendo)
                    if (md.length >= (window._triviaBestMarkdown || "").length) {
                        window._triviaBestMarkdown = md;
                        sendAnswer(md);
                    }
                }

                function isUpdatesUrl(url) {
                    if (!url) return false;
                    var u = url.toString().toLowerCase();
                    // Endpoint real sin login:
                    // https://chatgpt.com/unauth-mweb/conversation/updates?lightweight_authenticated=0&operationId=...
                    return (u.indexOf("conversation/updates") !== -1)
                        || (u.indexOf("unauth-mweb") !== -1 && u.indexOf("updates") !== -1)
                        || (u.indexOf("/updates?") !== -1 && u.indexOf("lightweight_authenticated") !== -1);
                }

                // ----- fetch -----
                if (!window._triviaFetchHooked) {
                    window._triviaFetchHooked = true;
                    var origFetch = window.fetch;
                    window.fetch = function(input, init) {
                        var url = "";
                        try {
                            url = (typeof input === "string") ? input : (input && input.url) ? input.url : "";
                        } catch (e) {}
                        return origFetch.apply(this, arguments).then(function(response) {
                            if (isUpdatesUrl(url)) {
                                try {
                                    var clone = response.clone();
                                    clone.text().then(function(raw) {
                                        handleBody(raw);
                                    }).catch(function(){});
                                } catch (e) {}
                            }
                            return response;
                        });
                    };
                }

                // ----- XMLHttpRequest -----
                if (!window._triviaXHRHooked) {
                    window._triviaXHRHooked = true;
                    var origOpen = XMLHttpRequest.prototype.open;
                    var origSend = XMLHttpRequest.prototype.send;

                    XMLHttpRequest.prototype.open = function(method, url) {
                        this._triviaUrl = url ? url.toString() : "";
                        return origOpen.apply(this, arguments);
                    };

                    XMLHttpRequest.prototype.send = function(body) {
                        var xhr = this;
                        if (isUpdatesUrl(xhr._triviaUrl)) {
                            xhr.addEventListener("load", function() {
                                try { handleBody(xhr.responseText || ""); } catch (e) {}
                            });
                            xhr.addEventListener("readystatechange", function() {
                                try {
                                    if (xhr.readyState >= 3 && xhr.responseText) {
                                        handleBody(xhr.responseText);
                                    }
                                } catch (e) {}
                            });
                        }
                        return origSend.apply(this, arguments);
                    };
                }

                // ----- Fallback DOM (por si falla la red) -----
                if (window._triviaDomTimer) clearInterval(window._triviaDomTimer);
                window._triviaDomCount = document.querySelectorAll('div[data-message-author-role="assistant"]').length;
                window._triviaDomTimer = setInterval(function(){
                    try {
                        var list = document.querySelectorAll('div[data-message-author-role="assistant"]');
                        if (!list || list.length === 0) return;
                        var raw = (list[list.length - 1].innerText || "").trim();
                        var first = raw.split(/[\r\n]+/).map(function(l){ return l.trim(); }).filter(function(l){ return l.length > 0; })[0] || "";
                        if (!first || isNoise(first)) return;
                        if (first === window._triviaLastAnswer) return;
                        if (list.length > window._triviaDomCount || first.length > 0) {
                            window._triviaDomCount = list.length;
                            sendAnswer(first);
                        }
                    } catch (e) {}
                }, 1000);

            })();
        """.trimIndent()
    }
}
