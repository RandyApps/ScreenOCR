package com.trivias.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    companion object { var webView: WebView? = null }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val wv = findViewById<WebView>(R.id.webView)
        webView = wv
        wv.webViewClient = WebViewClient()
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.cacheMode = WebSettings.LOAD_DEFAULT
        wv.loadUrl("https://www.wwechampions.com")

        findViewById<Button>(R.id.btnPermiso).setOnClickListener {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(intent)
        }
        findViewById<Button>(R.id.btnAbrir).setOnClickListener {
            startService(Intent(this, FloatingService::class.java))
        }
    }
}