package com.trivias.app
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.*
import android.widget.Button
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.browser.customtabs.CustomTabsIntent

class MainActivity : AppCompatActivity() {
    companion object {
        var instancia: MainActivity? = null
        var ultimaRespuesta: String = "Esperando trivia..."
    }
    private lateinit var webView: WebView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instancia = this
        setContentView(R.layout.activity_main)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.addJavascriptInterface(WebAppInterface(), "AndroidTrivias")

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                val js = """
                (function(){
                    if(window.hackUniversal) return;
                    window.hackUniversal = true;

                    let cacheOpciones = [];
                    let cachePreguntaId = null;

                    let origOpen = XMLHttpRequest.prototype.open;
                    let origSend = XMLHttpRequest.prototype.send;

                    XMLHttpRequest.prototype.open = function(method, url){
                        this._url = url ? url.toString() : "";
                        this._method = method;
                        return origOpen.apply(this, arguments);
                    };

                    XMLHttpRequest.prototype.send = function(body){
                        let xhr = this;
                        xhr.addEventListener('load', function(){
                            try{
                                if(!xhr._url.includes("question")) return;
                                let json = JSON.parse(xhr.responseText);
                                let d = json.data || json;
                                if(!d) return;

                                // CASO 1: question?gameId= -> AL INICIAR - PREGUNTA + OPCIONES
                                if(xhr._url.includes("gameId=") && d.options){
                                    cacheOpciones = d.options;
                                    cachePreguntaId = d.id;
                                    let q = d.question || "Trivia";
                                    let txt = "❓ " + q + "\n\n";
                                    for(let i=0; i<d.options.length; i++){
                                        txt += (i+1) + ". " + d.options[i].option + "\n";
                                    }
                                    txt += "\nID: " + d.id;
                                    AndroidTrivias.mostrarRespuesta(txt);
                                }

                                // CASO 2: question POST -> AL TERMINAR - RESPUESTA CORRECTA
                                if(d.rightAnswer){
                                    let idCorrecto = d.rightAnswer;
                                    let obj = cacheOpciones.find(o => o.id === idCorrecto);
                                    let nombre = obj ? obj.option : idCorrecto;
                                    AndroidTrivias.mostrarRespuesta("✅ CORRECTA: " + nombre + "\n\nPregunta ID: " + cachePreguntaId);
                                }
                            }catch(e){}
                        });
                        return origSend.apply(this, arguments);
                    };
                })();
                """.trimIndent()
                webView.evaluateJavascript(js, null)
            }
        }
        findViewById<Button>(R.id.btnWebView).setOnClickListener {
            val container = findViewById<FrameLayout>(R.id.webContainer)
            container.removeAllViews()
            container.addView(webView)
            if(webView.url == null) webView.loadUrl("https://www.wwechampions.com")
        }
        findViewById<Button>(R.id.btnCustomTab).setOnClickListener {
            CustomTabsIntent.Builder().build().launchUrl(this, Uri.parse("https://www.wwechampions.com"))
        }
        findViewById<Button>(R.id.btnFloat).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                startService(Intent(this, FloatingService::class.java))
            }
        }
    }
    class WebAppInterface {
        @JavascriptInterface
        fun mostrarRespuesta(nombre: String) {
            instancia?.runOnUiThread {
                ultimaRespuesta = nombre
                FloatingService.actualizarTexto(ultimaRespuesta)
            }
        }
        @JavascriptInterface
        fun mostrarLog(mensaje: String) {
            instancia?.runOnUiThread {
                // Log no sobrescribe la respuesta ahora
                android.util.Log.d("TRIVIA", mensaje)
            }
        }
    }
}