package com.trivias.app

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    companion object { var webView: android.webkit.WebView? = null }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        Toast.makeText(this, "Activity cargada", Toast.LENGTH_SHORT).show()
        
        val btnPermiso = findViewById<Button>(R.id.btnPermiso)
        val btnFlotante = findViewById<Button>(R.id.btnFlotante)
        val webViewLocal = findViewById<android.webkit.WebView>(R.id.webView)
        webView = webViewLocal
        
        webViewLocal.settings.javaScriptEnabled = true
        webViewLocal.loadUrl("https://www.google.com")

        btnPermiso.setOnClickListener {
            Toast.makeText(this, "Click PERMISO funciona!", Toast.LENGTH_SHORT).show()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                startActivity(intent)
            }
        }

        btnFlotante.setOnClickListener {
            Toast.makeText(this, "Click FLOTANTE funciona!", Toast.LENGTH_SHORT).show()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Primero dale a PERMISO", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            startService(Intent(this, FloatingService::class.java))
        }
    }
}