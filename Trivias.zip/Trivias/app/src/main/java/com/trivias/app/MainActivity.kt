package com.trivias.app

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.trivias.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: PrefsHelper
    private var edgeSwipeStartX = 0f
    private var edgeSwipeStartY = 0f
    private var edgeSwipeTracking = false
    private var answerBlink: Animation? = null
    /** 1 = WWE Champions, 2 = ChatGot */
    private var activeWeb = 1
    private var web1Open = false
    private var web2Open = false

    private val desktopChromeUa =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefs = PrefsHelper(this)

        if (prefs.isBanned()) {
            startActivity(Intent(this, BannedActivity::class.java))
            finish()
            return
        }
        if (!prefs.isApproved()) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        Thread {
            val ban = try {
                SupabaseBanClient.checkIfBanned(
                    DeviceIdHelper.get(this@MainActivity),
                    prefs.getUserUid()
                )
            } catch (_: Exception) {
                SupabaseBanClient.BanResult(false)
            }
            if (ban.banned) {
                runOnUiThread {
                    val status = if (ban.kind == "DEVICE") "DEVICE_BANNED" else "BANNED"
                    prefs.saveUserSession(
                        prefs.getUserUid(),
                        prefs.getUserEmail(),
                        prefs.getUserNombre(),
                        status,
                        prefs.getUserRole()
                    )
                    startActivity(Intent(this@MainActivity, BannedActivity::class.java))
                    finish()
                }
            }
        }.start()

        SessionRealtimeWatcher.start(this)
        setupWebView()
        setupClicks()
        applyStrings()
        showVersionBadge()
        startAnswerBlink()
        showWebIdle()
    }

    override fun onResume() {
        super.onResume()
        applyStrings()
        SessionRealtimeWatcher.attach(this)
    }

    override fun onDestroy() {
        try {
            binding.webView1.stopLoading()
            binding.webView1.destroy()
        } catch (_: Exception) { }
        try {
            binding.webView2.stopLoading()
            binding.webView2.destroy()
        } catch (_: Exception) { }
        super.onDestroy()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        configureWebView(binding.webView1)
        configureWebView(binding.webView2)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView(wv: WebView) {
        wv.webViewClient = WebViewClient()
        val s = wv.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.userAgentString = desktopChromeUa
        if (Build.VERSION.SDK_INT >= 21) {
            s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        }
    }

    private fun setupClicks() {
        binding.cardLanguage.setOnClickListener { showLanguagePicker() }
        binding.btnAbout.setOnClickListener {
            showHelp(
                LocaleHelper.t(this, "about_title"),
                LocaleHelper.t(this, "about_body")
            )
        }
        binding.btnHelpClose.setOnClickListener {
            binding.helpOverlay.visibility = View.GONE
        }
        binding.cardTutorial.setOnClickListener {
            showHelp(
                LocaleHelper.t(this, "tutorial"),
                LocaleHelper.t(this, "tutorial_body")
            )
        }
        binding.cardDonate.setOnClickListener { openPaypal() }
        binding.cardDonate.setOnLongClickListener {
            Toast.makeText(this, LocaleHelper.t(this, "donation_tooltip"), Toast.LENGTH_LONG).show()
            true
        }
        binding.btnOpenWeb.setOnClickListener { openWebView() }
        binding.btnCloseWeb.setOnClickListener { closeWebView() }
        binding.btnSwitchWeb.setOnClickListener { switchWebView() }
        binding.btnBackWeb.setOnClickListener {
            val wv = currentWebView()
            if (wv.canGoBack()) wv.goBack()
            else Toast.makeText(this, LocaleHelper.t(this, "webview_no_back"), Toast.LENGTH_SHORT).show()
        }
    }

    private fun currentWebView(): WebView =
        if (activeWeb == 2) binding.webView2 else binding.webView1

    private fun openWebView() {
        binding.webIdle.visibility = View.GONE
        binding.webActive.visibility = View.VISIBLE
        binding.webControls.visibility = View.VISIBLE

        // Both open; WebView 1 visible, WebView 2 hidden behind
        web1Open = true
        web2Open = true
        activeWeb = 1
        binding.webView1.visibility = View.VISIBLE
        binding.webView2.visibility = View.GONE
        binding.webView1.loadUrl("https://www.wwechampions.com")
        binding.webView2.loadUrl("https://www.chatgot.com")
        updateSwitchEnabled()
    }

    private fun switchWebView() {
        if (!web1Open || !web2Open) {
            Toast.makeText(this, LocaleHelper.t(this, "switch_need_both"), Toast.LENGTH_SHORT).show()
            return
        }
        if (activeWeb == 1) {
            activeWeb = 2
            binding.webView1.visibility = View.GONE
            binding.webView2.visibility = View.VISIBLE
        } else {
            activeWeb = 1
            binding.webView2.visibility = View.GONE
            binding.webView1.visibility = View.VISIBLE
        }
    }

    private fun closeWebView() {
        // Same as before: fully close the *visible* WebView only
        val closing = activeWeb
        try {
            val wv = currentWebView()
            wv.stopLoading()
            wv.loadUrl("about:blank")
        } catch (_: Exception) { }

        if (closing == 1) {
            web1Open = false
            binding.webView1.visibility = View.GONE
        } else {
            web2Open = false
            binding.webView2.visibility = View.GONE
        }

        when {
            web1Open -> {
                activeWeb = 1
                binding.webView1.visibility = View.VISIBLE
                binding.webView2.visibility = View.GONE
                updateSwitchEnabled()
            }
            web2Open -> {
                activeWeb = 2
                binding.webView2.visibility = View.VISIBLE
                binding.webView1.visibility = View.GONE
                updateSwitchEnabled()
            }
            else -> showWebIdle()
        }
    }

    private fun updateSwitchEnabled() {
        val both = web1Open && web2Open
        binding.btnSwitchWeb.isEnabled = both
        binding.btnSwitchWeb.alpha = if (both) 1f else 0.4f
    }

    private fun showWebIdle() {
        web1Open = false
        web2Open = false
        activeWeb = 1
        binding.webActive.visibility = View.GONE
        binding.webControls.visibility = View.GONE
        binding.webIdle.visibility = View.VISIBLE
        try {
            binding.webView1.visibility = View.VISIBLE
            binding.webView2.visibility = View.GONE
        } catch (_: Exception) { }
    }

    private fun startAnswerBlink() {
        val anim = AlphaAnimation(1f, 0.25f).apply {
            duration = 700
            repeatMode = Animation.REVERSE
            repeatCount = Animation.INFINITE
        }
        answerBlink = anim
        binding.tvAnswerValue.startAnimation(anim)
    }

    /** Public helper if later code sets a real answer */
    fun setAnswerText(text: String?) {
        val value = text?.trim().orEmpty()
        runOnUiThread {
            if (value.isEmpty()) {
                binding.tvAnswerValue.text = "- - - -"
                binding.tvAnswerValue.setTextColor(Color.parseColor("#FF1744"))
                if (answerBlink != null) binding.tvAnswerValue.startAnimation(answerBlink)
            } else {
                binding.tvAnswerValue.clearAnimation()
                binding.tvAnswerValue.text = value
                binding.tvAnswerValue.setTextColor(Color.parseColor("#1B5E20"))
            }
        }
    }

    private fun applyStrings() {
        binding.tvAppTitle.text = LocaleHelper.t(this, "app_name")
        binding.tvLanguage.text = currentLanguageLabel()
        binding.tvAnswerLabel.text = LocaleHelper.t(this, "answer_label")
        if (binding.tvAnswerValue.text.toString() == "- - - -" ||
            binding.tvAnswerValue.text.isNullOrBlank()
        ) {
            // keep dashes
        }
        binding.btnOpenWeb.text = LocaleHelper.t(this, "open_webview")
        binding.btnCloseWeb.text = LocaleHelper.t(this, "close")
        binding.btnSwitchWeb.text = LocaleHelper.t(this, "switch_web")
        binding.btnBackWeb.text = LocaleHelper.t(this, "back")
        binding.tvTutorial.text = LocaleHelper.t(this, "tutorial")
        binding.tvDonate.text = LocaleHelper.t(this, "donations")
    }

    private fun showLanguagePicker() {
        val langs = arrayOf("Español", "English", "Português", "Bahasa")
        val codes = arrayOf("es", "en", "pt", "id")
        AlertDialog.Builder(this)
            .setTitle(LocaleHelper.t(this, "language"))
            .setItems(langs) { _, which ->
                LocaleHelper.setLang(this, codes[which])
                applyStrings()
            }
            .show()
    }

    private fun showHelp(title: String, body: String) {
        binding.helpTitle.text = title
        binding.helpBody.text = body
        binding.helpOverlay.visibility = View.VISIBLE
    }

    private fun openPaypal() {
        val url = "https://www.paypal.me/randyrubi"
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            Toast.makeText(this, url, Toast.LENGTH_SHORT).show()
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (::prefs.isInitialized && prefs.isApproved()) {
            val w = resources.displayMetrics.widthPixels.coerceAtLeast(1)
            val edge = w * 0.18f
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    edgeSwipeTracking = ev.x >= (w - edge)
                    edgeSwipeStartX = ev.x
                    edgeSwipeStartY = ev.y
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (edgeSwipeTracking) {
                        val dx = ev.x - edgeSwipeStartX
                        val dy = ev.y - edgeSwipeStartY
                        if (dx < -80 && kotlin.math.abs(dx) > kotlin.math.abs(dy) * 1.1f) {
                            tryOpenAdminPanel()
                        }
                    }
                    edgeSwipeTracking = false
                }
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun tryOpenAdminPanel() {
        Thread {
            val role = try {
                SupabaseBanClient.getUserRole(prefs.getUserUid())
            } catch (_: Exception) {
                prefs.getUserRole()
            }
            if (role.isNotBlank()) {
                prefs.saveUserSession(
                    prefs.getUserUid(),
                    prefs.getUserEmail(),
                    prefs.getUserNombre(),
                    "APPROVED",
                    role
                )
            }
            val isAdmin = role.equals("ADMIN", ignoreCase = true) ||
                prefs.getUserRole().equals("ADMIN", ignoreCase = true)
            runOnUiThread {
                if (isAdmin) {
                    startActivity(Intent(this, AdminActivity::class.java))
                }
            }
        }.start()
    }

    private fun currentLanguageLabel(): String {
        // Label of the Language button according to active language
        return when (LocaleHelper.getLang(this)) {
            LocaleHelper.ES -> "Idioma"
            LocaleHelper.PT -> "Idioma"
            LocaleHelper.ID -> "Bahasa"
            else -> "Language"
        }
    }

    private fun showVersionBadge() {
        val ver = try {
            val pi = packageManager.getPackageInfo(packageName, 0)
            pi.versionName ?: "1.0.3"
        } catch (_: Exception) {
            "1.0.3"
        }
        binding.tvVersion.text = if (ver.startsWith("v")) ver else "v$ver"
    }


}
