package com.trivias.app

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.trivias.app.databinding.ActivityMainBinding
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: PrefsHelper
    private var edgeSwipeStartX = 0f
    private var edgeSwipeStartY = 0f
    private var edgeSwipeTracking = false
    private var answerBlink: Animation? = null
    private var activeWeb = 1
    private var web1Open = false
    private var web2Open = false
    private var preguntaPendiente: String? = null
    private var chatListo = false
    /** Opciones de la pregunta actual: id + texto (para auto-clic). */
    private var currentOptions: List<Pair<String, String>> = emptyList()
    private var testPanelCenteredThisSession = false

    private val desktopChromeUa =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefs = PrefsHelper(this)
        applyScreenCapturePolicy()

        if (prefs.isBanned()) {
            startActivity(Intent(this, BannedActivity::class.java))
            finish()
            return
        }
        if (!prefs.isApproved()) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        Thread {
            val ban = try {
                SupabaseBanClient.checkIfBanned(DeviceIdHelper.get(this@MainActivity), prefs.getUserUid())
            } catch (_: Exception) { SupabaseBanClient.BanResult(false) }
            if (ban.banned) {
                runOnUiThread {
                    val status = if (ban.kind == "DEVICE") "DEVICE_BANNED" else "BANNED"
                    prefs.saveUserSession(prefs.getUserUid(), prefs.getUserEmail(), prefs.getUserNombre(), status, prefs.getUserRole())
                    startActivity(Intent(this@MainActivity, BannedActivity::class.java))
                    finish()
                }
            }
        }.start()

        SessionRealtimeWatcher.start(this)
        setupWebView()
        setupClicks()
        setupTestChatPanel()
        applyStrings()
        updateAdminOnlyUi()
        showVersionBadge()
        startAnswerBlink()
        showWebIdle()
        setAnswerState("- - - -", "#FF1744", true)

        if (prefs.isPendingShowAbout()) {
            prefs.setPendingShowAbout(false)
            prefs.setSeenAboutOnFirstLogin(true)
            binding.root.post {
                showHelp(LocaleHelper.t(this, "about_title"), LocaleHelper.t(this, "about_body"))
            }
        }
    }

    override fun onResume() {
        super.onResume()
        applyStrings()
        updateAdminOnlyUi()
        updateTestChatPanelVisibility()
        SessionRealtimeWatcher.attach(this)
    }

    override fun onDestroy() {
        try { binding.webView1.stopLoading(); binding.webView1.destroy() } catch (_: Exception) {}
        try { binding.webView2.stopLoading(); binding.webView2.destroy() } catch (_: Exception) {}
        super.onDestroy()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        configureWebView2(binding.webView2)
        configureWebView1WithHook(binding.webView1)
    }

    @SuppressLint("SetJavaScriptEnabled")
	private fun configureWebView2(wv: WebView) {
		wv.settings.builtInZoomControls = true
		wv.settings.displayZoomControls = false
		wv.settings.setSupportZoom(true)
		wv.settings.textZoom = 100
	    wv.settings.javaScriptEnabled = true
	    wv.settings.domStorageEnabled = true
		wv.settings.loadWithOverviewMode = true
		wv.settings.useWideViewPort = true
		wv.setInitialScale(90)
		
	    wv.settings.userAgentString = desktopChromeUa
	    wv.addJavascriptInterface(JsBridge(), "AndroidChatGPT")
	    wv.webViewClient = object : WebViewClient() {
	        override fun onPageFinished(view: WebView?, url: String?) {
	            super.onPageFinished(view, url)
	            chatListo = true
	            view?.evaluateJavascript("""
				(function(){
					// --- ESTO ES LO QUE QUITA EL ZOOM ---
					let m = document.querySelector('meta[name=viewport]');
					if(!m){ m = document.createElement('meta'); m.name='viewport'; document.head.appendChild(m); }
					m.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no';
					let s = document.createElement('style');
					s.innerHTML = '#prompt-textarea, textarea, input { font-size: 16px !important; }';
					document.head.appendChild(s);
					// --- FIN ZOOM ---
  
					// --- ZOOM-OUT PARA QUE ENCAJE ---
					document.documentElement.style.zoom = '0.95'; // 95% - cambia a 0.90 si lo quieres más pequeño
					document.body.style.zoom = '0.95';
					let m2 = document.querySelector('meta[name=viewport]');
					m2.content = 'width=1024, initial-scale=0.8, maximum-scale=0.8, minimum-scale=0.8, user-scalable=no';
					// --- FIN ZOOM-OUT ---

	                if(window._triviaHook) return;
	                window._triviaHook = true;
	                window._best = "";
	                window._lastSent = "";
	
	                function clean(s){
	                    try{
	                        return s.replace(/\\n/g," ").replace(/\\"/g,'"').replace(/\\\\/g,"\\").trim();
	                    }catch(e){ return s; }
	                }
	
	                function trySend(candidate){
	                    if(!candidate) return;
	                    candidate = candidate.trim();
	                    if(candidate.length < 2) return; // ignora "" y "S"
	                    if(candidate.toLowerCase().includes("como estas")) return;
	                    if(candidate.toLowerCase().includes("puedo ayudar")) return;
	                    
	                    // NOS QUEDAMOS CON EL MAS LARGO
	                    if(candidate.length >= window._best.length){
	                        window._best = candidate;
	                        clearTimeout(window._timer);
	                        // espera a que termine de escribir
	                        window._timer = setTimeout(()=>{
	                            if(window._best !== window._lastSent){
	                                window._lastSent = window._best;
	                                AndroidChatGPT.onRespuestaChatGPT(window._best);
	                            }
	                        }, 1000);
	                    }
	                }
	
	                function extractAll(txt){
	                    let m;
	                    // 1. markdown y fallbackMarkdown
	                    let re1 = /"(?:fallbackMarkdown|markdown)"\s*:\s*"((?:\\.|[^"\\])*)"/g;
	                    while((m = re1.exec(txt)) !== null){
	                        trySend(clean(m[1]));
	                    }
	                    // 2. constants -> "0": "respuesta" (como en tus fotos de Matt Riddle y Shinsuke)
	                    let re2 = /"constants"\s*:\s*\{\s*"0"\s*:\s*"((?:\\.|[^"\\])*)"/g;
	                    while((m = re2.exec(txt)) !== null){
	                        trySend(clean(m[1]));
	                    }
	                }
	
	                let oFetch = window.fetch;
	                window.fetch = async function(...a){
	                    let url = (a[0]||"").toString();
	                    let res = await oFetch.apply(this, a);
	                    if(url.includes("updates")){
	                        try{ res.clone().text().then(t=>extractAll(t)); }catch(e){}
	                    }
	                    return res;
	                };
	                let oOpen = XMLHttpRequest.prototype.open;
	                XMLHttpRequest.prototype.open = function(m,u){ this._u = u||""; return oOpen.apply(this, arguments); };
	                let oSend = XMLHttpRequest.prototype.send;
	                XMLHttpRequest.prototype.send = function(b){
	                    this.addEventListener('load', function(){
	                        if((this._u||"").includes("updates")) extractAll(this.responseText||"");
	                    });
	                    return oSend.apply(this, arguments);
	                };
	            })();
	            """.trimIndent(), null)
	        }
	    }
	}

    /** WWE Champions – SIN CAMBIOS (el que ya te funciona). */
    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView1WithHook(wv: WebView) {
        val s = wv.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.userAgentString = desktopChromeUa
        if (Build.VERSION.SDK_INT >= 21) s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        wv.addJavascriptInterface(JsBridge(), "AndroidChatGPT")
        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                view?.evaluateJavascript("""
                (function(){
                    if(window.hackTrivia) return;
                    window.hackTrivia = true;
                    let origOpen = XMLHttpRequest.prototype.open;
                    let origSend = XMLHttpRequest.prototype.send;
                    XMLHttpRequest.prototype.open = function(m,u){
                        this._url = u ? u.toString() : "";
                        return origOpen.apply(this, arguments);
                    };
                    XMLHttpRequest.prototype.send = function(body){
                        let xhr = this;
                        xhr.addEventListener('load', function(){
                            try{
                                if(!xhr._url || !xhr._url.includes("question")) return;
                                let json = JSON.parse(xhr.responseText);
                                let d = json.data || json;
                                if(!d || !d.options) return;
                                if(xhr._url.includes("gameId=")){
                                    let opts = [];
                                    for(let i=0;i<d.options.length;i++){
                                        opts.push({
                                            id: (d.options[i].id||"").toString(),
                                            option: (d.options[i].option||d.options[i].text||"").toString()
                                        });
                                    }
                                    let payload = JSON.stringify({
                                        question: (d.question||"").trim(),
                                        options: opts
                                    });
                                    AndroidChatGPT.onPreguntaCapturada(payload);
                                }
                            }catch(e){}
                        });
                        return origSend.apply(this, arguments);
                    };
                })();
                """.trimIndent(), null)
            }
        }
    }

    fun enviarPreguntaAChatGPT(preguntaYOpciones: String) {
	    val prompt = "Please reply with ONLY the correct answer to this WWE trivia. No explanations, no emojis, no extra text. Just the answer. Check the facts before answering.\n\n"
	    val textoCompleto = prompt + preguntaYOpciones.trim()
	    runOnUiThread {
	        try {
	            setAnswerState(LocaleHelper.t(this, "searching"), "#FFC107", true)
	            // RESET del comparador del más largo
	            binding.webView2.evaluateJavascript(
	                """
	                try{
	                    window._best = "";
	                    window._lastSent = "";
	                    window._triviaLastAnswer = "";
	                    window._triviaBestMarkdown = "";
	                }catch(e){}
	                """.trimIndent(),
	                null
	            )
	            val encoded = java.net.URLEncoder.encode(textoCompleto, "UTF-8")
	            binding.webView2.loadUrl("https://chatgpt.com/?q=$encoded")
	        } catch (e: Exception) {
	            Toast.makeText(this, "Error ChatGPT: ${e.message}", Toast.LENGTH_SHORT).show()
	        }
	    }
	}

    inner class JsBridge {
        @JavascriptInterface
        fun onPreguntaCapturada(texto: String) {
            runOnUiThread {
                // Intentar JSON con ids; si falla, texto plano (compatibilidad)
                try {
                    val obj = JSONObject(texto)
                    val q = obj.optString("question", "").trim()
                    val arr = obj.optJSONArray("options") ?: JSONArray()
                    val list = mutableListOf<Pair<String, String>>()
                    val sb = StringBuilder()
                    sb.append(q).append("\n\n")
                    for (i in 0 until arr.length()) {
                        val o = arr.optJSONObject(i) ?: continue
                        val id = o.optString("id", "").trim()
                        val opt = o.optString("option", "").trim()
                        if (opt.isNotEmpty()) {
                            list.add(id to opt)
                            sb.append(opt).append("\n")
                        }
                    }
                    currentOptions = list
                    setAnswerState(LocaleHelper.t(this@MainActivity, "searching"), "#FFC107", true)
                    enviarPreguntaAChatGPT(sb.toString().trim())
                } catch (_: Exception) {
                    currentOptions = emptyList()
                    setAnswerState(LocaleHelper.t(this@MainActivity, "searching"), "#FFC107", true)
                    enviarPreguntaAChatGPT(texto)
                }
            }
        }

        @JavascriptInterface
        fun onRespuestaChatGPT(texto: String) {
            runOnUiThread {
                val limpio = texto.trim()
                    .split("\n")
                    .firstOrNull { it.trim().isNotEmpty() }
                    ?.trim()
                    ?: texto.trim()
                if (limpio.isNotEmpty() && limpio.length < 400) {
                    setAnswerState(limpio, "#1B5E20", false)
                    if (prefs.isAutoClickEnabled()) {
                        tryAutoClickById(limpio)
                    }
                }
            }
        }
    }

    /** Exacta (ignore case) → parcial; clic en button[data-id]. */
    private fun tryAutoClickById(answer: String) {
        val id = resolveOptionId(answer) ?: return
        val safeId = id.replace("\\", "\\\\").replace("'", "\\'")
        val js = """
            (function(){
                var id = '$safeId';
                var btn = document.querySelector('button[data-id="' + id + '"]');
                if (!btn) {
                    var all = document.querySelectorAll('button[data-id]');
                    for (var i = 0; i < all.length; i++) {
                        var d = all[i].getAttribute('data-id') || '';
                        if (d === id || d.indexOf(id) === 0) { btn = all[i]; break; }
                    }
                }
                if (!btn) return false;
                try { btn.scrollIntoView({block:'center', inline:'nearest'}); } catch(e) {}
                try { btn.click(); return true; } catch(e) { return false; }
            })();
        """.trimIndent()
        binding.webView1.evaluateJavascript(js, null)
    }

    private fun resolveOptionId(answer: String): String? {
        if (currentOptions.isEmpty()) return null
        val a = answer.trim().lowercase()
        if (a.isEmpty()) return null
        // 1) Exacta
        currentOptions.firstOrNull { it.second.trim().lowercase() == a }?.let { return it.first }
        // 2) Parcial: opción contiene respuesta o respuesta contiene opción
        val partial = currentOptions.filter {
            val o = it.second.trim().lowercase()
            o.contains(a) || a.contains(o)
        }
        if (partial.isEmpty()) return null
        if (partial.size == 1) return partial[0].first
        // Desempate: mayor solapamiento (longitud de la intersección aproximada)
        return partial.maxByOrNull { opt ->
            val o = opt.second.trim().lowercase()
            when {
                o.startsWith(a) || a.startsWith(o) -> 1000 + minOf(o.length, a.length)
                else -> minOf(o.length, a.length)
            }
        }?.first
    }

    private fun setAnswerState(text: String, colorHex: String, blinking: Boolean) {
        runOnUiThread {
            binding.tvAnswerValue.clearAnimation()
            binding.tvAnswerValue.text = text
            binding.tvAnswerValue.setTextColor(Color.parseColor(colorHex))
            if (blinking) {
                if (answerBlink == null) {
                    answerBlink = AlphaAnimation(1f, 0.25f).apply {
                        duration = 700
                        repeatMode = Animation.REVERSE
                        repeatCount = Animation.INFINITE
                    }
                }
                binding.tvAnswerValue.startAnimation(answerBlink)
            } else {
                binding.tvAnswerValue.clearAnimation()
            }
        }
    }

    fun setAnswerText(text: String?) {
        val value = text?.trim().orEmpty()
        if (value.isEmpty()) setAnswerState("- - - -", "#FF1744", true)
        else setAnswerState(value, "#1B5E20", false)
    }


    private fun applyScreenCapturePolicy() {
        // Solo el super-admin puede capturar/grabar pantalla
        val allow = prefs.isAdmin() &&
                prefs.getUserEmail().trim().equals("randy.vargas51@gmail.com", ignoreCase = true)
        if (allow) {
            window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        } else {
            window.setFlags(
                android.view.WindowManager.LayoutParams.FLAG_SECURE,
                android.view.WindowManager.LayoutParams.FLAG_SECURE
            )
        }
    }

    private fun updateAdminOnlyUi() {
        // Cerrar y Volver: visibles para todos
        binding.btnCloseWeb.visibility = View.VISIBLE
        binding.btnBackWeb.visibility = View.VISIBLE
        // Cambiar (Switch): solo ADMIN
        binding.btnSwitchWeb.visibility = if (prefs.isAdmin()) View.VISIBLE else View.GONE
    }

    private fun setupTestChatPanel() {
        binding.btnTestChatClose.setOnClickListener {
            prefs.setTestChatPanelVisible(false)
            updateTestChatPanelVisibility()
        }
        binding.btnTestChatClear.setOnClickListener {
            binding.etTestChatInput.setText("")
        }
        binding.btnTestChatPaste.setOnClickListener {
            try {
                val clipboard = getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                val clip = clipboard.primaryClip
                if (clip != null && clip.itemCount > 0) {
                    val paste = clip.getItemAt(0).coerceToText(this)?.toString() ?: ""
                    if (paste.isNotEmpty()) {
                        val cur = binding.etTestChatInput.text?.toString() ?: ""
                        val startSel = binding.etTestChatInput.selectionStart.coerceAtLeast(0)
                        val endSel = binding.etTestChatInput.selectionEnd.coerceAtLeast(0)
                        val a = minOf(startSel, endSel)
                        val b = maxOf(startSel, endSel)
                        val updated = cur.substring(0, a) + paste + cur.substring(b)
                        binding.etTestChatInput.setText(updated)
                        binding.etTestChatInput.setSelection((a + paste.length).coerceAtMost(updated.length))
                    }
                }
            } catch (_: Exception) {}
        }
        binding.btnTestChatSend.setOnClickListener {
            if (!web2Open) {
                Toast.makeText(this, LocaleHelper.t(this, "test_need_chatgpt"), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val text = binding.etTestChatInput.text?.toString()?.trim().orEmpty()
            if (text.isEmpty()) return@setOnClickListener
            setAnswerState(LocaleHelper.t(this, "searching"), "#FFC107", true)
            enviarPreguntaAChatGPT(text)
        }
        var dX = 0f
        var dY = 0f
        binding.testChatPanelHeader.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    dX = binding.testChatPanel.x - event.rawX
                    dY = binding.testChatPanel.y - event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val parent = binding.root
                    val maxX = (parent.width - binding.testChatPanel.width).toFloat().coerceAtLeast(0f)
                    val maxY = (parent.height - binding.testChatPanel.height).toFloat().coerceAtLeast(0f)
                    val nx = (event.rawX + dX).coerceIn(0f, maxX)
                    val ny = (event.rawY + dY).coerceIn(0f, maxY)
                    binding.testChatPanel.x = nx
                    binding.testChatPanel.y = ny
                    true
                }
                else -> false
            }
        }
        updateTestChatPanelVisibility()
    }

    private fun updateTestChatPanelVisibility() {
        val show = prefs.isTestChatPanelVisible()
        binding.testChatPanel.visibility = if (show) View.VISIBLE else View.GONE
        val canUse = web2Open
        binding.etTestChatInput.isEnabled = show && canUse
        binding.btnTestChatSend.isEnabled = show && canUse
        binding.btnTestChatPaste.isEnabled = show && canUse
        binding.btnTestChatClear.isEnabled = show
        if (show && !canUse) {
            binding.etTestChatInput.hint = LocaleHelper.t(this, "test_need_chatgpt")
        }
        if (show && !testPanelCenteredThisSession) {
            binding.testChatPanel.post {
                val parent = binding.root
                val pw = parent.width
                val ph = parent.height
                val cw = binding.testChatPanel.width
                val ch = binding.testChatPanel.height
                if (pw > 0 && ph > 0 && cw > 0 && ch > 0) {
                    binding.testChatPanel.x = ((pw - cw) / 2f).coerceAtLeast(0f)
                    binding.testChatPanel.y = ((ph - ch) / 2f).coerceAtLeast(0f)
                    testPanelCenteredThisSession = true
                }
            }
        }
    }

    private fun setupClicks() {
        binding.cardLanguage.setOnClickListener { showLanguagePicker() }
        binding.btnAbout.setOnClickListener { showHelp(LocaleHelper.t(this, "about_title"), LocaleHelper.t(this, "about_body")) }
        binding.btnHelpClose.setOnClickListener { binding.helpOverlay.visibility = View.GONE }
        binding.cardTutorial.setOnClickListener { showHelp(LocaleHelper.t(this, "tutorial"), LocaleHelper.t(this, "tutorial_body")) }
        binding.cardDonate.setOnClickListener { openPaypal() }
        binding.cardDonate.setOnLongClickListener { Toast.makeText(this, LocaleHelper.t(this, "donation_tooltip"), Toast.LENGTH_LONG).show(); true }
        binding.btnOpenWeb.setOnClickListener { openWebView() }
        binding.btnCloseWeb.setOnClickListener { closeWebView() }
        binding.btnSwitchWeb.setOnClickListener { switchWebView() }
        binding.btnBackWeb.setOnClickListener {
            val wv = currentWebView()
            if (wv.canGoBack()) wv.goBack()
            else Toast.makeText(this, LocaleHelper.t(this, "webview_no_back"), Toast.LENGTH_SHORT).show()
        }
    }

    private fun currentWebView(): WebView = if (activeWeb == 2) binding.webView2 else binding.webView1

    private fun openWebView() {
        binding.webIdle.visibility = View.GONE
        binding.webActive.visibility = View.VISIBLE
        binding.webControls.visibility = View.VISIBLE
        web1Open = true; web2Open = true; activeWeb = 1
        binding.webView1.visibility = View.VISIBLE
        binding.webView2.visibility = View.GONE
        binding.webView1.loadUrl("https://www.wwechampions.com")
        binding.webView2.loadUrl("https://chatgpt.com")
        chatListo = false
        updateSwitchEnabled()
        updateTestChatPanelVisibility()
    }

    private fun switchWebView() {
        if (!web1Open || !web2Open) { Toast.makeText(this, LocaleHelper.t(this, "switch_need_both"), Toast.LENGTH_SHORT).show(); return }
        if (activeWeb == 1) { activeWeb = 2; binding.webView1.visibility = View.GONE; binding.webView2.visibility = View.VISIBLE }
        else { activeWeb = 1; binding.webView2.visibility = View.GONE; binding.webView1.visibility = View.VISIBLE }
    }

    private fun closeWebView() {
        // Cierra ambos WebViews a la vez
        try { binding.webView1.stopLoading(); binding.webView1.loadUrl("about:blank") } catch (_: Exception) {}
        try { binding.webView2.stopLoading(); binding.webView2.loadUrl("about:blank") } catch (_: Exception) {}
        web1Open = false
        web2Open = false
        binding.webView1.visibility = View.GONE
        binding.webView2.visibility = View.GONE
        showWebIdle()
        updateTestChatPanelVisibility()
    }

    private fun updateSwitchEnabled() {
        val both = web1Open && web2Open
        binding.btnSwitchWeb.isEnabled = both
        binding.btnSwitchWeb.alpha = if (both) 1f else 0.4f
    }

    private fun showWebIdle() {
        web1Open = false; web2Open = false; activeWeb = 1
        binding.webActive.visibility = View.GONE
        binding.webControls.visibility = View.GONE
        binding.webIdle.visibility = View.VISIBLE
        setAnswerState("- - - -", "#FF1744", true)
        try { binding.webView1.visibility = View.VISIBLE; binding.webView2.visibility = View.GONE } catch (_: Exception) {}
    }

    private fun startAnswerBlink() {
        answerBlink = AlphaAnimation(1f, 0.25f).apply {
            duration = 700
            repeatMode = Animation.REVERSE
            repeatCount = Animation.INFINITE
        }
    }

    private fun applyStrings() {
        binding.tvAppTitle.text = LocaleHelper.t(this, "app_name")
        binding.tvLanguage.text = currentLanguageLabel()
        binding.tvAnswerLabel.text = LocaleHelper.t(this, "answer_label")
        binding.btnOpenWeb.text = LocaleHelper.t(this, "open_webview")
        binding.btnOpenWeb.setTypeface(binding.btnOpenWeb.typeface, android.graphics.Typeface.BOLD)
        binding.btnCloseWeb.text = LocaleHelper.t(this, "close")
        binding.btnCloseWeb.setTypeface(binding.btnCloseWeb.typeface, android.graphics.Typeface.BOLD)
        binding.btnSwitchWeb.text = LocaleHelper.t(this, "switch_web")
        binding.btnSwitchWeb.setTypeface(binding.btnSwitchWeb.typeface, android.graphics.Typeface.BOLD)
        binding.btnBackWeb.text = LocaleHelper.t(this, "back")
        binding.btnBackWeb.setTypeface(binding.btnBackWeb.typeface, android.graphics.Typeface.BOLD)
        binding.btnTestChatSend.setTypeface(binding.btnTestChatSend.typeface, android.graphics.Typeface.BOLD)
        binding.tvTutorial.text = LocaleHelper.t(this, "tutorial")
        binding.tvDonate.text = LocaleHelper.t(this, "donations")
        try {
            binding.tvTestChatLabel.text = LocaleHelper.t(this, "send_to_chatgpt")
            binding.btnTestChatSend.text = LocaleHelper.t(this, "send")
        } catch (_: Exception) {}
    }

    private fun showLanguagePicker() {
        val langs = arrayOf("Español", "English", "Português", "Bahasa")
        val codes = arrayOf("es", "en", "pt", "id")
        AlertDialog.Builder(this).setTitle(LocaleHelper.t(this, "language")).setItems(langs) { _, which -> LocaleHelper.setLang(this, codes[which]); applyStrings() }.show()
    }

    private fun showHelp(title: String, body: String) {
        binding.helpTitle.text = title; binding.helpBody.text = body; binding.helpOverlay.visibility = View.VISIBLE
    }

    private fun openPaypal() {
        val url = "https://www.paypal.me/randyrubi"
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) { Toast.makeText(this, url, Toast.LENGTH_SHORT).show() }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        // Desactivar acceso admin por gesto mientras WebView 2 (ChatGPT) esté visible
        val web2Visible = web2Open && activeWeb == 2 && binding.webView2.visibility == View.VISIBLE
        if (::prefs.isInitialized && prefs.isApproved() && !web2Visible) {
            val w = resources.displayMetrics.widthPixels.coerceAtLeast(1)
            val edge = w * 0.18f
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> { edgeSwipeTracking = ev.x >= (w - edge); edgeSwipeStartX = ev.x; edgeSwipeStartY = ev.y }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (edgeSwipeTracking) {
                        val dx = ev.x - edgeSwipeStartX; val dy = ev.y - edgeSwipeStartY
                        if (dx < -80 && kotlin.math.abs(dx) > kotlin.math.abs(dy) * 1.1f) { tryOpenAdminPanel() }
                    }
                    edgeSwipeTracking = false
                }
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun tryOpenAdminPanel() {
        Thread {
            val role = try { SupabaseBanClient.getUserRole(prefs.getUserUid()) } catch (_: Exception) { prefs.getUserRole() }
            if (role.isNotBlank()) {
                prefs.saveUserSession(prefs.getUserUid(), prefs.getUserEmail(), prefs.getUserNombre(), "APPROVED", role)
            }
            val canPanel = role.equals("ADMIN", ignoreCase = true) ||
                    role.equals("TESTER", ignoreCase = true) ||
                    prefs.canAccessAdminPanel()
            runOnUiThread {
                if (canPanel) startActivity(Intent(this, AdminActivity::class.java))
            }
        }.start()
    }

    private fun currentLanguageLabel(): String = when (LocaleHelper.getLang(this)) {
        LocaleHelper.ES -> "Idioma"; LocaleHelper.PT -> "Idioma"; LocaleHelper.ID -> "Bahasa"; else -> "Language"
    }

    private fun showVersionBadge() {
        val ver = try { val pi = packageManager.getPackageInfo(packageName, 0); pi.versionName ?: "1.0.17" } catch (_: Exception) { "1.0.17" }
        binding.tvVersion.text = if (ver.startsWith("v")) ver else "v$ver"
    }

    companion object {

        /**
         * Interceptor de red apuntado al endpoint real descubierto:
         *   https://chatgpt.com/unauth-mweb/conversation/updates?lightweight_authenticated=0&operationId=...
         *
         * El texto de la respuesta viene en el campo JSON "markdown".
         * Se enganchan fetch + XHR. operationId cambia cada vez; el path /updates es estable.
         */
        private val CHAT_GPT_NETWORK_INJECTOR = """
            (function(){
                // Reset por cada carga de página (cada pregunta nueva)
                window._triviaLastAnswer = "";
                window._triviaBestMarkdown = "";

                function isNoise(t) {
                    if (!t || t.length < 1 || t.length > 400) return true;
                    var low = t.toLowerCase();
                    if (low.indexOf("reply with only") !== -1) return true;
                    if (low.indexOf("quickly answer") !== -1) return true;
                    if (low.indexOf("wwe trivia") !== -1) return true;
                    if (low.indexOf("please answer") !== -1) return true;
                    if (low.indexOf("no explanations") !== -1) return true;
                    if (low.indexOf("just the answer") !== -1) return true;
                    if (low.indexOf("searching") !== -1) return true;
                    if (low.indexOf("thinking") !== -1) return true;
                    return false;
                }

                function sendAnswer(txt) {
                    if (!txt) return;
                    var first = ("" + txt).trim().split(/[\r\n]+/).map(function(l){ return l.trim(); }).filter(function(l){ return l.length > 0; })[0] || "";
                    // Quitar emojis comunes al inicio/final si el modelo los pone
                    first = first.replace(/^[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}\s]+/u, "").replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}\s]+$/u, "").trim();
                    if (isNoise(first)) return;
                    if (first === window._triviaLastAnswer) return;
                    window._triviaLastAnswer = first;
                    if (typeof AndroidChatGPT !== "undefined" && AndroidChatGPT.onRespuestaChatGPT) {
                        AndroidChatGPT.onRespuestaChatGPT(first);
                    }
                }

                function extractMarkdown(raw) {
                    if (!raw || typeof raw !== "string") return "";
                    var best = "";

                    // 1) Buscar "markdown":"..." con regex (funciona aunque haya varios eventos)
                    try {
                        var re = /"markdown"\s*:\s*"((?:\\.|[^"\\])*)"/g;
                        var m;
                        while ((m = re.exec(raw)) !== null) {
                            var decoded = m[1]
                                .replace(/\\n/g, "\n")
                                .replace(/\\r/g, "")
                                .replace(/\\"/g, '"')
                                .replace(/\\\\/g, "\\")
                                .replace(/\\u[\dA-Fa-f]{4}/g, function(x) {
                                    try { return String.fromCharCode(parseInt(x.slice(2), 16)); } catch(e) { return x; }
                                });
                            decoded = decoded.trim();
                            if (decoded.length > best.length) best = decoded;
                        }
                    } catch (e) {}

                    // 2) Intentar parsear como JSON / líneas JSON
                    if (!best) {
                        var chunks = raw.split(/\n/);
                        for (var i = 0; i < chunks.length; i++) {
                            var line = chunks[i].trim();
                            if (line.indexOf("data: ") === 0) line = line.substring(6).trim();
                            if (!line || line === "[DONE]") continue;
                            try {
                                var obj = JSON.parse(line);
                                var md = findMarkdownInObject(obj);
                                if (md && md.length > best.length) best = md;
                            } catch (e) {}
                        }
                    }

                    // 3) Parsear el body completo
                    if (!best) {
                        try {
                            var whole = JSON.parse(raw);
                            var md2 = findMarkdownInObject(whole);
                            if (md2) best = md2;
                        } catch (e) {}
                    }

                    return best;
                }

                function findMarkdownInObject(obj) {
                    if (!obj || typeof obj !== "object") return "";
                    if (typeof obj.markdown === "string" && obj.markdown.trim()) return obj.markdown.trim();
                    // Estructura vista en DevTools: type/content con markdown
                    if (obj.type === "content" && typeof obj.markdown === "string") return obj.markdown.trim();
                    // dil.constants["0"] a veces duplica el texto
                    if (obj.dil && obj.dil.constants && typeof obj.dil.constants["0"] === "string") {
                        return obj.dil.constants["0"].trim();
                    }
                    // Recorrer propiedades de primer nivel
                    for (var k in obj) {
                        if (!obj.hasOwnProperty(k)) continue;
                        var v = obj[k];
                        if (typeof v === "string" && k.toLowerCase().indexOf("markdown") !== -1 && v.trim()) return v.trim();
                        if (v && typeof v === "object") {
                            var inner = findMarkdownInObject(v);
                            if (inner) return inner;
                        }
                    }
                    return "";
                }

                function handleBody(raw) {
                    var md = extractMarkdown(raw);
                    if (!md) return;
                    // Quedarse con el markdown más largo visto (el stream puede ir creciendo)
                    if (md.length >= (window._triviaBestMarkdown || "").length) {
                        window._triviaBestMarkdown = md;
                        sendAnswer(md);
                    }
                }

                function isUpdatesUrl(url) {
                    if (!url) return false;
                    var u = url.toString().toLowerCase();
                    // Endpoint real sin login:
                    // https://chatgpt.com/unauth-mweb/conversation/updates?lightweight_authenticated=0&operationId=...
                    return (u.indexOf("conversation/updates") !== -1)
                        || (u.indexOf("unauth-mweb") !== -1 && u.indexOf("updates") !== -1)
                        || (u.indexOf("/updates?") !== -1 && u.indexOf("lightweight_authenticated") !== -1);
                }

                // ----- fetch -----
                if (!window._triviaFetchHooked) {
                    window._triviaFetchHooked = true;
                    var origFetch = window.fetch;
                    window.fetch = function(input, init) {
                        var url = "";
                        try {
                            url = (typeof input === "string") ? input : (input && input.url) ? input.url : "";
                        } catch (e) {}
                        return origFetch.apply(this, arguments).then(function(response) {
                            if (isUpdatesUrl(url)) {
                                try {
                                    var clone = response.clone();
                                    clone.text().then(function(raw) {
                                        handleBody(raw);
                                    }).catch(function(){});
                                } catch (e) {}
                            }
                            return response;
                        });
                    };
                }

                // ----- XMLHttpRequest -----
                if (!window._triviaXHRHooked) {
                    window._triviaXHRHooked = true;
                    var origOpen = XMLHttpRequest.prototype.open;
                    var origSend = XMLHttpRequest.prototype.send;

                    XMLHttpRequest.prototype.open = function(method, url) {
                        this._triviaUrl = url ? url.toString() : "";
                        return origOpen.apply(this, arguments);
                    };

                    XMLHttpRequest.prototype.send = function(body) {
                        var xhr = this;
                        if (isUpdatesUrl(xhr._triviaUrl)) {
                            xhr.addEventListener("load", function() {
                                try { handleBody(xhr.responseText || ""); } catch (e) {}
                            });
                            xhr.addEventListener("readystatechange", function() {
                                try {
                                    if (xhr.readyState >= 3 && xhr.responseText) {
                                        handleBody(xhr.responseText);
                                    }
                                } catch (e) {}
                            });
                        }
                        return origSend.apply(this, arguments);
                    };
                }

                // ----- Fallback DOM (por si falla la red) -----
                if (window._triviaDomTimer) clearInterval(window._triviaDomTimer);
                window._triviaDomCount = document.querySelectorAll('div[data-message-author-role="assistant"]').length;
                window._triviaDomTimer = setInterval(function(){
                    try {
                        var list = document.querySelectorAll('div[data-message-author-role="assistant"]');
                        if (!list || list.length === 0) return;
                        var raw = (list[list.length - 1].innerText || "").trim();
                        var first = raw.split(/[\r\n]+/).map(function(l){ return l.trim(); }).filter(function(l){ return l.length > 0; })[0] || "";
                        if (!first || isNoise(first)) return;
                        if (first === window._triviaLastAnswer) return;
                        if (list.length > window._triviaDomCount || first.length > 0) {
                            window._triviaDomCount = list.length;
                            sendAnswer(first);
                        }
                    } catch (e) {}
                }, 1000);

            })();
        """.trimIndent()
    }
}
