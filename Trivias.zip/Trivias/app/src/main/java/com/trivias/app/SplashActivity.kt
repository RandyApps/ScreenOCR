package com.trivias.app

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyScreenCapturePolicy()
        setContentView(R.layout.activity_splash)
        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            try {
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            } catch (_: Exception) {}
        }, 500L)
    }

    private fun applyScreenCapturePolicy() {
        val target = "randy.vargas51@gmail.com"
        var email = try {
            PrefsHelper(this).getUserEmail().trim()
        } catch (_: Exception) {
            ""
        }
        if (email.isEmpty()) {
            email = try {
                com.google.android.gms.auth.api.signin.GoogleSignIn
                    .getLastSignedInAccount(this)?.email?.trim().orEmpty()
            } catch (_: Exception) {
                ""
            }
        }
        val allow = email.equals(target, ignoreCase = true)
        if (allow) {
            window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        } else {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE
            )
        }
    }
}
