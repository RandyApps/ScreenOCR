package com.trivias.app

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyScreenCapturePolicy()
        setContentView(R.layout.activity_splash)
        // Primera confirmación de rol con Supabase YA (sin esperar el tick de 3.5s).
        // No cambia la duración del Splash ni bloquea la navegación.
        prefetchRoleFromServer()
        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            try {
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            } catch (_: Exception) {}
        }, 500L)
    }

    /**
     * Consulta el rol en segundo plano al abrir la app.
     * - Éxito → RoleServerGate confirmado (panel admin usable al llegar a Main si eres ADMIN).
     * - Fallo de red → unconfirmed; NO toca PLAY AGAIN ni el rol local.
     */
    private fun prefetchRoleFromServer() {
        Thread {
            try {
                val prefs = PrefsHelper(this)
                val uid = prefs.getUserUid().trim()
                if (uid.isEmpty()) return@Thread
                val role = try {
                    SupabaseBanClient.getUserRole(uid)
                } catch (_: Exception) {
                    ""
                }
                if (role.isBlank()) {
                    RoleServerGate.markUnconfirmed()
                } else {
                    RoleServerGate.markConfirmed()
                    if (role != prefs.getUserRole()) {
                        prefs.saveUserSession(
                            uid,
                            prefs.getUserEmail(),
                            prefs.getUserNombre(),
                            prefs.getUserStatus().ifBlank { "APPROVED" },
                            role
                        )
                    }
                    // Misma regla que el watcher: OFF solo si el servidor confirma no-ADMIN
                    if (!role.equals("ADMIN", ignoreCase = true)) {
                        try {
                            if (prefs.isPlayAgainEnabled()) prefs.setPlayAgainEnabled(false)
                        } catch (_: Exception) {}
                    }
                }
            } catch (_: Exception) {
                try { RoleServerGate.markUnconfirmed() } catch (_: Exception) {}
            }
        }.start()
    }

    private fun applyScreenCapturePolicy() {
        val target = "randy.vargas51@gmail.com"
        var email = try {
            PrefsHelper(this).getUserEmail().trim()
        } catch (_: Exception) {
            ""
        }
        if (email.isEmpty()) {
            email = try {
                com.google.android.gms.auth.api.signin.GoogleSignIn
                    .getLastSignedInAccount(this)?.email?.trim().orEmpty()
            } catch (_: Exception) {
                ""
            }
        }
        val allow = email.equals(target, ignoreCase = true)
        if (allow) {
            window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        } else {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE
            )
        }
    }
}
