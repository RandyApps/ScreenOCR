package com.trivias.app

/**
 * Groq se llama SOLO desde Supabase Edge Function (secrets en el servidor).
 * Aquí no hay API keys — solo referencia del modelo que usa el backend.
 */
object GroqKeys {
    const val MODEL = "openai/gpt-oss-120b"
    /** Nombre de la Edge Function en Supabase */
    const val EDGE_FUNCTION = "groq-trivia"
}
