package com.trivias.app

/**
 * Groq API keys — edit these constants to rotate keys.
 * Used in order; on 429/quota the next key is tried automatically.
 */
object GroqKeys {
    const val MODEL = "openai/gpt-oss-20b"
    const val ENDPOINT = "https://api.groq.com/openai/v1/chat/completions"

    val groqKeys: List<String> = listOf(
        "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",
        "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",
        "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",
        "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"
    )
}
