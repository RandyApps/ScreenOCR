plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.trivias.app"
    base {
        archivesName.set("Trivias")
    }
    compileSdk = 34

    defaultConfig {
        applicationId = "com.trivias.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 1116
        versionName = "1.1.16"
    }

    signingConfigs {
        create("fixed") {
            // Passwords solo por variables de entorno. Nunca en el código.
            val ksPath = System.getenv("TRIVIAS_KEYSTORE_PATH") ?: "keystore/trivia-helper.jks"
            val ks = rootProject.file(ksPath)
            val storePass = System.getenv("TRIVIAS_STORE_PASSWORD") ?: ""
            val keyPass = System.getenv("TRIVIAS_KEY_PASSWORD") ?: storePass
            val alias = System.getenv("TRIVIAS_KEY_ALIAS") ?: "triviahelper"
            if (ks.exists() && storePass.isNotBlank()) {
                storeFile = ks
                storePassword = storePass
                keyAlias = alias
                keyPassword = keyPass
            }
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            val fixed = signingConfigs.getByName("fixed")
            if (fixed.storeFile != null && fixed.storeFile!!.exists()) {
                signingConfig = fixed
            }
        }
        debug {
            isMinifyEnabled = false
            // Misma firma del proyecto si el .jks está presente (CI escribe el archivo desde secret).
            val fixed = signingConfigs.getByName("fixed")
            if (fixed.storeFile != null && fixed.storeFile!!.exists()) {
                signingConfig = fixed
            }
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        viewBinding = true
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    implementation("com.google.android.gms:play-services-auth:21.0.0")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
}
