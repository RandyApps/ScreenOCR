plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.trivias.app"
    base {
        archivesName.set("Trivias")
    }
    compileSdk = 34

    defaultConfig {
        applicationId = "com.trivias.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 87
        versionName = "1.0.87"
    }

    signingConfigs {
        create("fixed") {
            val ks = rootProject.file("keystore/trivia-helper.jks")
            if (ks.exists()) {
                storeFile = ks
                storePassword = "triviahelper2024"
                keyAlias = "triviahelper"
                keyPassword = "triviahelper2024"
            }
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("fixed")
        }
        debug {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("fixed")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        viewBinding = true
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    implementation("com.google.android.gms:play-services-auth:21.0.0")
}
