package com.trivias.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

/**
 * Cliente Supabase vía RPC (tablas cerradas al anon).
 * Llamar desde hilo de fondo.
 */
object SupabaseBanClient {

    data class BanResult(
        val banned: Boolean,
        val kind: String? = null,
        val reason: String? = null
    )

    data class UserRow(
        val userId: String,
        val email: String,
        val nombre: String,
        val deviceId: String,
        val role: String,
        val lastSeenMs: Long?
    ) {
        fun isOnline(nowMs: Long = System.currentTimeMillis()): Boolean {
            val ls = lastSeenMs ?: return false
            return nowMs - ls < 90_000L // 90 s
        }
    }

    fun checkIfBanned(deviceId: String, userId: String?): BanResult {
        return try {
            val body = JSONObject()
                .put("p_user_id", userId ?: "")
                .put("p_device_id", deviceId)
            val json = rpc("is_banned", body)
            BanResult(
                banned = json.optBoolean("banned", false),
                kind = if (json.isNull("kind")) null else json.optString("kind", null),
                reason = if (json.isNull("reason")) null else json.optString("reason", null)
            )
        } catch (_: Exception) {
            BanResult(false)
        }
    }

    fun upsertUser(userId: String, email: String, nombre: String, deviceId: String): String {
        val body = JSONObject()
            .put("p_user_id", userId)
            .put("p_email", email)
            .put("p_nombre", nombre)
            .put("p_device_id", deviceId)
        val json = rpc("upsert_my_user", body)
        try { heartbeat(userId) } catch (_: Exception) {}
        return json.optString("role", "USER").ifBlank { "USER" }
    }

    fun getUserRole(userId: String): String {
        if (userId.isBlank()) return "USER"
        return try {
            var raw = rpcRaw("get_my_role", JSONObject().put("p_user_id", userId)).trim()
            if (raw.length >= 2) {
                val a = raw.first()
                val b = raw.last()
                if ((a == '"' && b == '"') || (a == '\'' && b == '\'')) {
                    raw = raw.substring(1, raw.length - 1).trim()
                }
            }
            raw = raw.uppercase()
            if (raw.isBlank()) "USER" else raw
        } catch (_: Exception) {
            "USER"
        }
    }

    fun heartbeat(userId: String) {
        if (userId.isBlank()) return
        rpc("heartbeat", JSONObject().put("p_user_id", userId))
    }

    fun adminListUsers(adminId: String): List<UserRow> {
        val text = rpcRaw("admin_list_users", JSONObject().put("p_admin_id", adminId))
        val arr = try {
            JSONArray(text)
        } catch (_: Exception) {
            return emptyList()
        }
        val out = ArrayList<UserRow>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(
                UserRow(
                    userId = o.optString("user_id", ""),
                    email = o.optString("email", ""),
                    nombre = o.optString("nombre", ""),
                    deviceId = o.optString("device_id", ""),
                    role = o.optString("role", "USER").ifBlank { "USER" },
                    lastSeenMs = parseTs(o.optString("last_seen", null))
                )
            )
        }
        return out
    }

    fun adminListBans(adminId: String): Pair<Set<String>, Set<String>> {
        val json = rpc("admin_list_bans", JSONObject().put("p_admin_id", adminId))
        val users = mutableSetOf<String>()
        val devices = mutableSetOf<String>()
        val uArr = json.optJSONArray("users")
        if (uArr != null) {
            for (i in 0 until uArr.length()) {
                users.add(uArr.getJSONObject(i).optString("user_id", ""))
            }
        }
        val dArr = json.optJSONArray("devices")
        if (dArr != null) {
            for (i in 0 until dArr.length()) {
                devices.add(dArr.getJSONObject(i).optString("device_id", ""))
            }
        }
        return users to devices
    }

    fun adminBan(adminId: String, userId: String, deviceId: String?, reason: String?) {
        val body = JSONObject()
            .put("p_admin_id", adminId)
            .put("p_user_id", userId)
            .put("p_device_id", deviceId ?: "")
            .put("p_reason", reason ?: "banned from app panel")
        rpc("admin_ban", body)
    }

    fun adminUnban(adminId: String, userId: String, deviceId: String?) {
        val body = JSONObject()
            .put("p_admin_id", adminId)
            .put("p_user_id", userId)
            .put("p_device_id", deviceId ?: "")
        rpc("admin_unban", body)
    }

    fun adminSetRole(adminId: String, targetUserId: String, role: String) {
        val body = JSONObject()
            .put("p_admin_id", adminId)
            .put("p_target_user_id", targetUserId)
            .put("p_role", role)
        rpc("admin_set_role", body)
    }

    private fun parseTs(s: String?): Long? {
        if (s.isNullOrBlank() || s == "null") return null
        return try {
            val cleaned = s.replace(" ", "T")
            // Accept ISO-8601 with or without millis / offset
            val patterns = arrayOf(
                "yyyy-MM-dd'T'HH:mm:ss.SSSSSSXXX",
                "yyyy-MM-dd'T'HH:mm:ss.SSSXXX",
                "yyyy-MM-dd'T'HH:mm:ssXXX",
                "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
                "yyyy-MM-dd'T'HH:mm:ss'Z'"
            )
            for (pat in patterns) {
                try {
                    val sdf = java.text.SimpleDateFormat(pat, java.util.Locale.US)
                    sdf.timeZone = java.util.TimeZone.getTimeZone("UTC")
                    return sdf.parse(cleaned)?.time
                } catch (_: Exception) { }
            }
            // Fallback: strip to epoch-ish via Instant if available
            try {
                java.time.Instant.parse(cleaned).toEpochMilli()
            } catch (_: Exception) {
                null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun rpc(fn: String, body: JSONObject): JSONObject {
        val text = rpcRaw(fn, body)
        if (text.isBlank()) return JSONObject()
        return try {
            JSONObject(text)
        } catch (_: Exception) {
            JSONObject()
        }
    }

    private fun rpcRaw(fn: String, body: JSONObject): String {
        val url = URL("${SupabaseConfig.URL.trimEnd('/')}/rest/v1/rpc/$fn")
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 20000
        conn.readTimeout = 20000
        conn.requestMethod = "POST"
        conn.doOutput = true
        conn.instanceFollowRedirects = true
        conn.setRequestProperty("apikey", SupabaseConfig.ANON_KEY)
        conn.setRequestProperty("Authorization", "Bearer ${SupabaseConfig.ANON_KEY}")
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("Accept", "application/json")
        OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.let { BufferedReader(InputStreamReader(it, Charsets.UTF_8)).use { r -> r.readText() } } ?: ""
        conn.disconnect()
        if (code !in 200..299) {
            throw IllegalStateException("Supabase RPC $fn HTTP $code: $text")
        }
        return text
    }
}
