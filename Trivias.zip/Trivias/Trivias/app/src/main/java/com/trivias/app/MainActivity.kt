package com.trivias.app

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.trivias.app.databinding.ActivityMainBinding
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: PrefsHelper
    private var edgeSwipeStartX = 0f
    private var edgeSwipeStartY = 0f
    private var edgeSwipeTracking = false
    private var answerBlink: Animation? = null
    private var activeWeb = 1
    private var web1Open = false
    private var web2Open = false
    private var preguntaPendiente: String? = null
    private var chatListo = false

    private val desktopChromeUa =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefs = PrefsHelper(this)

        if (prefs.isBanned()) {
            startActivity(Intent(this, BannedActivity::class.java))
            finish()
            return
        }
        if (!prefs.isApproved()) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        Thread {
            val ban = try {
                SupabaseBanClient.checkIfBanned(DeviceIdHelper.get(this@MainActivity), prefs.getUserUid())
            } catch (_: Exception) { SupabaseBanClient.BanResult(false) }
            if (ban.banned) {
                runOnUiThread {
                    val status = if (ban.kind == "DEVICE") "DEVICE_BANNED" else "BANNED"
                    prefs.saveUserSession(prefs.getUserUid(), prefs.getUserEmail(), prefs.getUserNombre(), status, prefs.getUserRole())
                    startActivity(Intent(this@MainActivity, BannedActivity::class.java))
                    finish()
                }
            }
        }.start()

        SessionRealtimeWatcher.start(this)
        setupWebView()
        setupClicks()
        applyStrings()
        showVersionBadge()
        startAnswerBlink()
        showWebIdle()
        setAnswerState("- - - -", "#FF1744", true)
    }

    override fun onResume() {
        super.onResume()
        applyStrings()
        SessionRealtimeWatcher.attach(this)
    }

    override fun onDestroy() {
        try { binding.webView1.stopLoading(); binding.webView1.destroy() } catch (_: Exception) {}
        try { binding.webView2.stopLoading(); binding.webView2.destroy() } catch (_: Exception) {}
        super.onDestroy()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        configureWebView2(binding.webView2)
        configureWebView1WithHook(binding.webView1)
    }

    /**
     * WebView 2 = ChatGPT
     * Intercepta la red (fetch + XHR) para capturar la respuesta del asistente.
     * También mantiene un fallback DOM por si el endpoint cambia.
     */
    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView2(wv: WebView) {
        val s = wv.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.userAgentString = desktopChromeUa
        if (Build.VERSION.SDK_INT >= 21) s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        wv.addJavascriptInterface(JsBridge(), "AndroidChatGPT")
        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                chatListo = true
                view?.evaluateJavascript(CHAT_GPT_NETWORK_INJECTOR, null)
            }
        }
    }

    /**
     * WebView 1 = WWE Champions
     * SIN CAMBIOS: el hook que ya te funciona bien.
     */
    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView1WithHook(wv: WebView) {
        val s = wv.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.userAgentString = desktopChromeUa
        if (Build.VERSION.SDK_INT >= 21) s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        wv.addJavascriptInterface(JsBridge(), "AndroidChatGPT")
        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                view?.evaluateJavascript("""
                (function(){
                    if(window.hackTrivia) return;
                    window.hackTrivia = true;
                    let origOpen = XMLHttpRequest.prototype.open;
                    let origSend = XMLHttpRequest.prototype.send;
                    XMLHttpRequest.prototype.open = function(m,u){
                        this._url = u ? u.toString() : "";
                        return origOpen.apply(this, arguments);
                    };
                    XMLHttpRequest.prototype.send = function(body){
                        let xhr = this;
                        xhr.addEventListener('load', function(){
                            try{
                                if(!xhr._url || !xhr._url.includes("question")) return;
                                let json = JSON.parse(xhr.responseText);
                                let d = json.data || json;
                                if(!d || !d.options) return;
                                // SOLO PREGUNTA + OPCIONES
                                if(xhr._url.includes("gameId=")){
                                    let txt = (d.question||"") + "\n\n";
                                    for(let i=0;i<d.options.length;i++){
                                        txt += (d.options[i].option||"") + "\n";
                                    }
                                    AndroidChatGPT.onPreguntaCapturada(txt);
                                }
                            }catch(e){}
                        });
                        return origSend.apply(this, arguments);
                    };
                })();
                """.trimIndent(), null)
            }
        }
    }

    fun enviarPreguntaAChatGPT(preguntaYOpciones: String) {
        val prompt = "Reply with ONLY the correct answer to this WWE trivia. No explanations, no emojis, no extra text. Just the answer.\n\n"
        val textoCompleto = prompt + preguntaYOpciones.trim()
        runOnUiThread {
            try {
                setAnswerState(LocaleHelper.t(this, "searching"), "#FFC107", true)
                val encoded = java.net.URLEncoder.encode(textoCompleto, "UTF-8")
                binding.webView2.loadUrl("https://chatgpt.com/?q=$encoded&hints=search")
            } catch (e: Exception) {
                Toast.makeText(this, "Error ChatGPT: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    inner class JsBridge {
        @JavascriptInterface
        fun onPreguntaCapturada(texto: String) {
            runOnUiThread {
                setAnswerState(LocaleHelper.t(this@MainActivity, "searching"), "#FFC107", true)
                enviarPreguntaAChatGPT(texto)
            }
        }

        @JavascriptInterface
        fun onRespuestaChatGPT(texto: String) {
            runOnUiThread {
                val limpio = texto.trim().split("\n").firstOrNull()?.trim() ?: texto.trim()
                if (limpio.isNotEmpty() && limpio.length < 300) {
                    setAnswerState(limpio, "#1B5E20", false)
                }
            }
        }
    }

    private fun setAnswerState(text: String, colorHex: String, blinking: Boolean) {
        runOnUiThread {
            binding.tvAnswerValue.clearAnimation()
            binding.tvAnswerValue.text = text
            binding.tvAnswerValue.setTextColor(Color.parseColor(colorHex))
            if (blinking) {
                if (answerBlink == null) {
                    answerBlink = AlphaAnimation(1f, 0.25f).apply {
                        duration = 700
                        repeatMode = Animation.REVERSE
                        repeatCount = Animation.INFINITE
                    }
                }
                binding.tvAnswerValue.startAnimation(answerBlink)
            } else {
                binding.tvAnswerValue.clearAnimation()
            }
        }
    }

    fun setAnswerText(text: String?) {
        val value = text?.trim().orEmpty()
        if (value.isEmpty()) setAnswerState("- - - -", "#FF1744", true)
        else setAnswerState(value, "#1B5E20", false)
    }

    private fun setupClicks() {
        binding.cardLanguage.setOnClickListener { showLanguagePicker() }
        binding.btnAbout.setOnClickListener { showHelp(LocaleHelper.t(this, "about_title"), LocaleHelper.t(this, "about_body")) }
        binding.btnHelpClose.setOnClickListener { binding.helpOverlay.visibility = View.GONE }
        binding.cardTutorial.setOnClickListener { showHelp(LocaleHelper.t(this, "tutorial"), LocaleHelper.t(this, "tutorial_body")) }
        binding.cardDonate.setOnClickListener { openPaypal() }
        binding.cardDonate.setOnLongClickListener { Toast.makeText(this, LocaleHelper.t(this, "donation_tooltip"), Toast.LENGTH_LONG).show(); true }
        binding.btnOpenWeb.setOnClickListener { openWebView() }
        binding.btnCloseWeb.setOnClickListener { closeWebView() }
        binding.btnSwitchWeb.setOnClickListener { switchWebView() }
        binding.btnBackWeb.setOnClickListener {
            val wv = currentWebView()
            if (wv.canGoBack()) wv.goBack()
            else Toast.makeText(this, LocaleHelper.t(this, "webview_no_back"), Toast.LENGTH_SHORT).show()
        }
    }

    private fun currentWebView(): WebView = if (activeWeb == 2) binding.webView2 else binding.webView1

    private fun openWebView() {
        binding.webIdle.visibility = View.GONE
        binding.webActive.visibility = View.VISIBLE
        binding.webControls.visibility = View.VISIBLE
        web1Open = true; web2Open = true; activeWeb = 1
        binding.webView1.visibility = View.VISIBLE
        binding.webView2.visibility = View.GONE
        binding.webView1.loadUrl("https://www.wwechampions.com")
        binding.webView2.loadUrl("https://chatgpt.com")
        chatListo = false
        updateSwitchEnabled()
    }

    private fun switchWebView() {
        if (!web1Open || !web2Open) { Toast.makeText(this, LocaleHelper.t(this, "switch_need_both"), Toast.LENGTH_SHORT).show(); return }
        if (activeWeb == 1) { activeWeb = 2; binding.webView1.visibility = View.GONE; binding.webView2.visibility = View.VISIBLE }
        else { activeWeb = 1; binding.webView2.visibility = View.GONE; binding.webView1.visibility = View.VISIBLE }
    }

    private fun closeWebView() {
        val closing = activeWeb
        try { currentWebView().stopLoading(); currentWebView().loadUrl("about:blank") } catch (_: Exception) {}
        if (closing == 1) { web1Open = false; binding.webView1.visibility = View.GONE }
        else { web2Open = false; binding.webView2.visibility = View.GONE }
        when {
            web1Open -> { activeWeb = 1; binding.webView1.visibility = View.VISIBLE; binding.webView2.visibility = View.GONE; updateSwitchEnabled() }
            web2Open -> { activeWeb = 2; binding.webView2.visibility = View.VISIBLE; binding.webView1.visibility = View.GONE; updateSwitchEnabled() }
            else -> showWebIdle()
        }
    }

    private fun updateSwitchEnabled() {
        val both = web1Open && web2Open
        binding.btnSwitchWeb.isEnabled = both
        binding.btnSwitchWeb.alpha = if (both) 1f else 0.4f
    }

    private fun showWebIdle() {
        web1Open = false; web2Open = false; activeWeb = 1
        binding.webActive.visibility = View.GONE
        binding.webControls.visibility = View.GONE
        binding.webIdle.visibility = View.VISIBLE
        setAnswerState("- - - -", "#FF1744", true)
        try { binding.webView1.visibility = View.VISIBLE; binding.webView2.visibility = View.GONE } catch (_: Exception) {}
    }

    private fun startAnswerBlink() {
        answerBlink = AlphaAnimation(1f, 0.25f).apply {
            duration = 700
            repeatMode = Animation.REVERSE
            repeatCount = Animation.INFINITE
        }
    }

    private fun applyStrings() {
        binding.tvAppTitle.text = LocaleHelper.t(this, "app_name")
        binding.tvLanguage.text = currentLanguageLabel()
        binding.tvAnswerLabel.text = LocaleHelper.t(this, "answer_label")
        binding.btnOpenWeb.text = LocaleHelper.t(this, "open_webview")
        binding.btnCloseWeb.text = LocaleHelper.t(this, "close")
        binding.btnSwitchWeb.text = LocaleHelper.t(this, "switch_web")
        binding.btnBackWeb.text = LocaleHelper.t(this, "back")
        binding.tvTutorial.text = LocaleHelper.t(this, "tutorial")
        binding.tvDonate.text = LocaleHelper.t(this, "donations")
    }

    private fun showLanguagePicker() {
        val langs = arrayOf("Español", "English", "Português", "Bahasa")
        val codes = arrayOf("es", "en", "pt", "id")
        AlertDialog.Builder(this).setTitle(LocaleHelper.t(this, "language")).setItems(langs) { _, which -> LocaleHelper.setLang(this, codes[which]); applyStrings() }.show()
    }

    private fun showHelp(title: String, body: String) {
        binding.helpTitle.text = title; binding.helpBody.text = body; binding.helpOverlay.visibility = View.VISIBLE
    }

    private fun openPaypal() {
        val url = "https://www.paypal.me/randyrubi"
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) { Toast.makeText(this, url, Toast.LENGTH_SHORT).show() }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (::prefs.isInitialized && prefs.isApproved()) {
            val w = resources.displayMetrics.widthPixels.coerceAtLeast(1)
            val edge = w * 0.18f
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> { edgeSwipeTracking = ev.x >= (w - edge); edgeSwipeStartX = ev.x; edgeSwipeStartY = ev.y }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (edgeSwipeTracking) {
                        val dx = ev.x - edgeSwipeStartX; val dy = ev.y - edgeSwipeStartY
                        if (dx < -80 && kotlin.math.abs(dx) > kotlin.math.abs(dy) * 1.1f) { tryOpenAdminPanel() }
                    }
                    edgeSwipeTracking = false
                }
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun tryOpenAdminPanel() {
        Thread {
            val role = try { SupabaseBanClient.getUserRole(prefs.getUserUid()) } catch (_: Exception) { prefs.getUserRole() }
            if (role.isNotBlank()) { prefs.saveUserSession(prefs.getUserUid(), prefs.getUserEmail(), prefs.getUserNombre(), "APPROVED", role) }
            val isAdmin = role.equals("ADMIN", ignoreCase = true) || prefs.getUserRole().equals("ADMIN", ignoreCase = true)
            runOnUiThread { if (isAdmin) { startActivity(Intent(this, AdminActivity::class.java)) } }
        }.start()
    }

    private fun currentLanguageLabel(): String = when (LocaleHelper.getLang(this)) {
        LocaleHelper.ES -> "Idioma"; LocaleHelper.PT -> "Idioma"; LocaleHelper.ID -> "Bahasa"; else -> "Language"
    }

    private fun showVersionBadge() {
        val ver = try { val pi = packageManager.getPackageInfo(packageName, 0); pi.versionName ?: "1.0.8" } catch (_: Exception) { "1.0.8" }
        binding.tvVersion.text = if (ver.startsWith("v")) ver else "v$ver"
    }

    companion object {

        /**
         * Inyector de red para ChatGPT.
         * Intercepta fetch + XMLHttpRequest a endpoints de conversation,
         * parsea el stream SSE/JSON y extrae el texto del asistente.
         * Incluye fallback DOM por si el endpoint cambia.
         */
        private val CHAT_GPT_NETWORK_INJECTOR = """
            (function(){
                if (window._triviaNetReady) {
                    // Reiniciar estado por cada carga de página (cada pregunta)
                    window._triviaLastAnswer = "";
                    window._triviaAccum = "";
                    return;
                }
                window._triviaNetReady = true;
                window._triviaLastAnswer = "";
                window._triviaAccum = "";

                function isNoise(t) {
                    if (!t || t.length < 2 || t.length > 300) return true;
                    var low = t.toLowerCase();
                    if (low.indexOf("reply with only") !== -1) return true;
                    if (low.indexOf("quickly answer") !== -1) return true;
                    if (low.indexOf("wwe trivia") !== -1) return true;
                    if (low.indexOf("please answer") !== -1) return true;
                    if (low.indexOf("searching") !== -1) return true;
                    if (low.indexOf("thinking") !== -1) return true;
                    return false;
                }

                function sendAnswer(txt) {
                    if (!txt) return;
                    var first = txt.trim().split(/[\r\n]+/).map(function(l){ return l.trim(); }).filter(function(l){ return l.length > 0; })[0] || "";
                    if (isNoise(first)) return;
                    if (first === window._triviaLastAnswer) return;
                    window._triviaLastAnswer = first;
                    if (typeof AndroidChatGPT !== "undefined" && AndroidChatGPT.onRespuestaChatGPT) {
                        AndroidChatGPT.onRespuestaChatGPT(first);
                    }
                }

                function extractFromSSE(raw) {
                    if (!raw || typeof raw !== "string") return "";
                    var best = "";
                    var lines = raw.split(/\n/);
                    for (var i = 0; i < lines.length; i++) {
                        var line = lines[i].trim();
                        if (line.indexOf("data: ") === 0) {
                            var payload = line.substring(6).trim();
                            if (!payload || payload === "[DONE]") continue;
                            try {
                                var obj = JSON.parse(payload);
                                var text = pickAssistantText(obj);
                                if (text && text.length >= best.length) best = text;
                            } catch (e) {}
                        } else if (line.length > 2 && line.charAt(0) === "{") {
                            try {
                                var obj2 = JSON.parse(line);
                                var text2 = pickAssistantText(obj2);
                                if (text2 && text2.length >= best.length) best = text2;
                            } catch (e) {}
                        }
                    }
                    // También intentar parsear el raw completo como JSON
                    if (!best) {
                        try {
                            var whole = JSON.parse(raw);
                            best = pickAssistantText(whole) || best;
                        } catch (e) {}
                    }
                    return best;
                }

                function pickAssistantText(obj) {
                    if (!obj || typeof obj !== "object") return "";
                    // Formato clásico: message.author.role + content.parts
                    var msg = obj.message || obj;
                    if (msg && msg.author && msg.author.role === "assistant") {
                        if (msg.content && msg.content.parts && msg.content.parts.length) {
                            return msg.content.parts.join("");
                        }
                        if (typeof msg.content === "string") return msg.content;
                    }
                    // Deltas de streaming
                    if (obj.v && typeof obj.v === "string") return obj.v;
                    if (obj.delta && obj.delta.content) {
                        if (typeof obj.delta.content === "string") return obj.delta.content;
                        if (obj.delta.content.parts) return obj.delta.content.parts.join("");
                    }
                    if (obj.choices && obj.choices[0]) {
                        var c = obj.choices[0];
                        if (c.delta && c.delta.content) return c.delta.content;
                        if (c.message && c.message.content) return c.message.content;
                    }
                    // Buscar recursivo en campos comunes
                    if (obj.content && obj.content.parts) return obj.content.parts.join("");
                    return "";
                }

                function handleResponseBody(raw) {
                    var text = extractFromSSE(raw);
                    if (text) {
                        window._triviaAccum = text;
                        sendAnswer(text);
                    }
                }

                function isConversationUrl(url) {
                    if (!url) return false;
                    var u = url.toString().toLowerCase();
                    return u.indexOf("conversation") !== -1
                        || u.indexOf("/backend-api/") !== -1
                        || u.indexOf("chatgpt.com/backend") !== -1;
                }

                // ---------- fetch ----------
                if (!window._triviaFetchHooked) {
                    window._triviaFetchHooked = true;
                    var origFetch = window.fetch;
                    window.fetch = function(input, init) {
                        var url = "";
                        try {
                            url = (typeof input === "string") ? input : (input && input.url) ? input.url : "";
                        } catch (e) {}
                        return origFetch.apply(this, arguments).then(function(response) {
                            if (isConversationUrl(url)) {
                                try {
                                    var clone = response.clone();
                                    clone.text().then(function(raw) {
                                        handleResponseBody(raw);
                                    }).catch(function(){});
                                } catch (e) {}
                            }
                            return response;
                        });
                    };
                }

                // ---------- XMLHttpRequest ----------
                if (!window._triviaXHRHooked) {
                    window._triviaXHRHooked = true;
                    var origOpen = XMLHttpRequest.prototype.open;
                    var origSend = XMLHttpRequest.prototype.send;

                    XMLHttpRequest.prototype.open = function(method, url) {
                        this._triviaUrl = url ? url.toString() : "";
                        return origOpen.apply(this, arguments);
                    };

                    XMLHttpRequest.prototype.send = function(body) {
                        var xhr = this;
                        if (isConversationUrl(xhr._triviaUrl)) {
                            // Capturar respuesta completa
                            xhr.addEventListener("load", function() {
                                try {
                                    var raw = xhr.responseText || "";
                                    handleResponseBody(raw);
                                } catch (e) {}
                            });
                            // Capturar progreso del stream (si responseType permite)
                            xhr.addEventListener("readystatechange", function() {
                                try {
                                    if (xhr.readyState >= 3 && xhr.responseText) {
                                        var partial = extractFromSSE(xhr.responseText);
                                        if (partial && partial.length > (window._triviaAccum || "").length) {
                                            window._triviaAccum = partial;
                                            // No enviar aún en cada chunk; se envía en load
                                        }
                                    }
                                } catch (e) {}
                            });
                        }
                        return origSend.apply(this, arguments);
                    };
                }

                // ---------- Fallback DOM (por si la red no se captura) ----------
                if (window._triviaDomTimer) clearInterval(window._triviaDomTimer);
                window._triviaDomCount = document.querySelectorAll('div[data-message-author-role="assistant"]').length;
                window._triviaDomLast = "";
                window._triviaDomTimer = setInterval(function(){
                    try {
                        var list = document.querySelectorAll('div[data-message-author-role="assistant"]');
                        if (!list || list.length === 0) return;
                        var raw = (list[list.length - 1].innerText || "").trim();
                        var first = raw.split(/[\r\n]+/).map(function(l){ return l.trim(); }).filter(function(l){ return l.length > 0; })[0] || "";
                        if (!first || isNoise(first)) return;
                        if (first === window._triviaLastAnswer) return;
                        if (first === window._triviaDomLast) return;
                        // Solo si hay mensaje nuevo o el texto cambió de forma significativa
                        if (list.length > window._triviaDomCount || first.length > 0) {
                            window._triviaDomLast = first;
                            window._triviaDomCount = list.length;
                            sendAnswer(first);
                        }
                    } catch (e) {}
                }, 900);

            })();
        """.trimIndent()
    }
}
