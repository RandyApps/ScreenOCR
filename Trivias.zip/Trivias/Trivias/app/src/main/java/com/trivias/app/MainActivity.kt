package com.trivias.app

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.trivias.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: PrefsHelper
    private var edgeSwipeStartX = 0f
    private var edgeSwipeStartY = 0f
    private var edgeSwipeTracking = false
    private var answerBlink: Animation? = null
    private var activeWeb = 1
    private var web1Open = false
    private var web2Open = false

    private val desktopChromeUa =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefs = PrefsHelper(this)

        if (prefs.isBanned()) {
            startActivity(Intent(this, BannedActivity::class.java))
            finish()
            return
        }
        if (!prefs.isApproved()) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        Thread {
            val ban = try {
                SupabaseBanClient.checkIfBanned(DeviceIdHelper.get(this@MainActivity), prefs.getUserUid())
            } catch (_: Exception) { SupabaseBanClient.BanResult(false) }
            if (ban.banned) {
                runOnUiThread {
                    val status = if (ban.kind == "DEVICE") "DEVICE_BANNED" else "BANNED"
                    prefs.saveUserSession(prefs.getUserUid(), prefs.getUserEmail(), prefs.getUserNombre(), status, prefs.getUserRole())
                    startActivity(Intent(this@MainActivity, BannedActivity::class.java))
                    finish()
                }
            }
        }.start()

        SessionRealtimeWatcher.start(this)
        setupWebView()
        setupClicks()
        applyStrings()
        showVersionBadge()
        startAnswerBlink()
        showWebIdle()
        setAnswerState("- - - -", "#FF1744", true) // Default rojo destellando
    }

    override fun onResume() {
        super.onResume()
        applyStrings()
        SessionRealtimeWatcher.attach(this)
    }

    override fun onDestroy() {
        try { binding.webView1.stopLoading(); binding.webView1.destroy() } catch (_: Exception) {}
        try { binding.webView2.stopLoading(); binding.webView2.destroy() } catch (_: Exception) {}
        super.onDestroy()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        configureWebView2(binding.webView2)
        configureWebView1WithHook(binding.webView1)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView2(wv: WebView) {
        val s = wv.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.userAgentString = desktopChromeUa
        if (Build.VERSION.SDK_INT >= 21) s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        wv.addJavascriptInterface(JsBridge(), "AndroidChatGPT")

        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                // Activa el observador que detecta cuando ChatGPT responde
                view?.evaluateJavascript("""
                    (function(){
                        if(window.chatObserverActivo) return;
                        window.chatObserverActivo = true;
                        let lastAnswer = "";
                        setInterval(function(){
                            // ChatGPT nuevo usa data-message-author-role="assistant"
                            let all = document.querySelectorAll('div[data-message-author-role="assistant"]');
                            if(all.length === 0) return;
                            let last = all[all.length - 1];
                            let txt = last.innerText || last.textContent || "";
                            txt = txt.trim();
                            if(txt && txt !== lastAnswer && txt.length > 1 && txt.length < 200){
                                // Evita respuestas vacías o muy largas con razonamiento
                                lastAnswer = txt;
                                // Solo mandamos si parece una respuesta final (no "Typing...")
                                if(!txt.toLowerCase().includes("typing") && !txt.toLowerCase().includes("searching")){
                                    try{ AndroidChatGPT.onRespuestaChatGPT(txt); }catch(e){}
                                }
                            }
                        }, 1500);
                    })();
                """.trimIndent(), null)
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView1WithHook(wv: WebView) {
        val s = wv.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.userAgentString = desktopChromeUa
        if (Build.VERSION.SDK_INT >= 21) s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        wv.addJavascriptInterface(JsBridge(), "AndroidTrivias")

        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (view?.id != R.id.webView1) return
                val js = """
                (function(){
                    if(window.hackUniversal) return;
                    window.hackUniversal = true;
                    let origOpen = XMLHttpRequest.prototype.open;
                    let origSend = XMLHttpRequest.prototype.send;
                    XMLHttpRequest.prototype.open = function(m,u){ this._url = u?u.toString():""; return origOpen.apply(this, arguments); };
                    XMLHttpRequest.prototype.send = function(b){
                        let xhr = this;
                        xhr.addEventListener('load', function(){
                            try{
                                if(!xhr._url.includes("question")) return;
                                let json = JSON.parse(xhr.responseText);
                                let d = json.data || json;
                                if(!d) return;
                                if(xhr._url.includes("gameId=") && d.options){
                                    let q = d.question || "";
                                    let txt = q + "\n";
                                    for(let i=0;i<d.options.length;i++){ txt += (i+1)+". "+d.options[i].option+"\n"; }
                                    AndroidTrivias.onPreguntaCapturada(txt);
                                }
                            }catch(e){}
                        });
                        return origSend.apply(this, arguments);
                    };
                })();
                """.trimIndent()
                view.evaluateJavascript(js, null)
            }
        }
    }

    fun enviarPreguntaAChatGPT(preguntaYOpciones: String) {
        val prompt = "Please answer this WWE Trivia without giving explanations.\n\n"
        val textoCompleto = prompt + preguntaYOpciones.trim()
        val escaped = textoCompleto.replace("\\", "\\\\").replace("`", "'").replace("\n", "\\n").replace