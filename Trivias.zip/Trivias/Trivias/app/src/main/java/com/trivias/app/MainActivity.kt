package com.trivias.app

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.trivias.app.databinding.ActivityMainBinding
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: PrefsHelper
    private var edgeSwipeStartX = 0f
    private var edgeSwipeStartY = 0f
    private var edgeSwipeTracking = false
    private var answerBlink: Animation? = null
    private var activeWeb = 1
    private var web1Open = false
    private var web2Open = false
    private var chatListo = false

    private val desktopChromeUa =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefs = PrefsHelper(this)

        if (prefs.isBanned()) {
            startActivity(Intent(this, BannedActivity::class.java))
            finish()
            return
        }
        if (!prefs.isApproved()) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        Thread {
            val ban = try {
                SupabaseBanClient.checkIfBanned(DeviceIdHelper.get(this@MainActivity), prefs.getUserUid())
            } catch (_: Exception) {
                SupabaseBanClient.BanResult(false)
            }
            if (ban.banned) {
                runOnUiThread {
                    val status = if (ban.kind == "DEVICE") "DEVICE_BANNED" else "BANNED"
                    prefs.saveUserSession(
                        prefs.getUserUid(), prefs.getUserEmail(), prefs.getUserNombre(),
                        status, prefs.getUserRole()
                    )
                    startActivity(Intent(this@MainActivity, BannedActivity::class.java))
                    finish()
                }
            }
        }.start()

        SessionRealtimeWatcher.start(this)
        setupWebView()
        setupClicks()
        applyStrings()
        showVersionBadge()
        startAnswerBlink()
        showWebIdle()
        setAnswerState("- - - -", "#FF1744", true)
    }

    override fun onResume() {
        super.onResume()
        applyStrings()
        SessionRealtimeWatcher.attach(this)
    }

    override fun onDestroy() {
        try {
            binding.webView1.stopLoading()
            binding.webView1.destroy()
        } catch (_: Exception) {
        }
        try {
            binding.webView2.stopLoading()
            binding.webView2.destroy()
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        configureWebView2(binding.webView2)
        configureWebView1WithHook(binding.webView1)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView2(wv: WebView) {
        val s = wv.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.userAgentString = desktopChromeUa
        if (Build.VERSION.SDK_INT >= 21) {
            s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        }
        wv.addJavascriptInterface(JsBridge(), "AndroidChatGPT")

        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                chatListo = true
                // Siempre reinyectar en cada carga (cada pregunta nueva)
                view?.evaluateJavascript(CHAT_GPT_INJECTOR, null)
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView1WithHook(wv: WebView) {
        val s = wv.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.userAgentString = desktopChromeUa
        if (Build.VERSION.SDK_INT >= 21) {
            s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        }
        wv.addJavascriptInterface(JsBridge(), "AndroidChatGPT")

        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                view?.evaluateJavascript(WWE_HOOK_INJECTOR, null)
            }
        }
    }

    fun enviarPreguntaAChatGPT(preguntaYOpciones: String) {
        val prompt = "Reply with ONLY the correct answer to this WWE trivia. No explanations, no emojis, no extra text. Just the answer.\n\n"
        val textoCompleto = prompt + preguntaYOpciones.trim()
        runOnUiThread {
            try {
                setAnswerState(LocaleHelper.t(this, "searching"), "#FFC107", true)
                val encoded = java.net.URLEncoder.encode(textoCompleto, "UTF-8")
                binding.webView2.loadUrl("https://chatgpt.com/?q=$encoded")
            } catch (e: Exception) {
                Toast.makeText(this, "Error ChatGPT: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    inner class JsBridge {
        @JavascriptInterface
        fun onPreguntaCapturada(jsonStr: String) {
            try {
                val obj = JSONObject(jsonStr)
                val question = obj.optString("question", "").trim()
                val optionsArr = obj.optJSONArray("options") ?: JSONArray()

                val sb = StringBuilder()
                sb.append(question).append("\n\n")
                for (i in 0 until optionsArr.length()) {
                    val opt = optionsArr.optString(i, "").trim()
                    if (opt.isNotEmpty()) {
                        sb.append(opt).append("\n")
                    }
                }
                val textoFormateado = sb.toString().trim()

                runOnUiThread {
                    setAnswerState(LocaleHelper.t(this@MainActivity, "searching"), "#FFC107", true)
                    enviarPreguntaAChatGPT(textoFormateado)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    setAnswerState(LocaleHelper.t(this@MainActivity, "searching"), "#FFC107", true)
                    enviarPreguntaAChatGPT(jsonStr)
                }
            }
        }

        @JavascriptInterface
        fun onRespuestaChatGPT(texto: String) {
            runOnUiThread {
                val limpio = texto.trim()
                    .split("\n")
                    .firstOrNull { it.trim().isNotEmpty() }
                    ?.trim()
                    ?: texto.trim()

                if (limpio.isNotEmpty() && limpio.length < 300) {
                    setAnswerState(limpio, "#1B5E20", false)
                }
            }
        }
    }

    private fun setAnswerState(text: String, colorHex: String, blinking: Boolean) {
        runOnUiThread {
            binding.tvAnswerValue.clearAnimation()
            binding.tvAnswerValue.text = text
            binding.tvAnswerValue.setTextColor(Color.parseColor(colorHex))
            if (blinking) {
                if (answerBlink == null) {
                    answerBlink = AlphaAnimation(1f, 0.25f).apply {
                        duration = 700
                        repeatMode = Animation.REVERSE
                        repeatCount = Animation.INFINITE
                    }
                }
                binding.tvAnswerValue.startAnimation(answerBlink)
            } else {
                binding.tvAnswerValue.clearAnimation()
            }
        }
    }

    fun setAnswerText(text: String?) {
        val value = text?.trim().orEmpty()
        if (value.isEmpty()) setAnswerState("- - - -", "#FF1744", true)
        else setAnswerState(value, "#1B5E20", false)
    }

    private fun setupClicks() {
        binding.cardLanguage.setOnClickListener { showLanguagePicker() }
        binding.btnAbout.setOnClickListener {
            showHelp(LocaleHelper.t(this, "about_title"), LocaleHelper.t(this, "about_body"))
        }
        binding.btnHelpClose.setOnClickListener { binding.helpOverlay.visibility = View.GONE }
        binding.cardTutorial.setOnClickListener {
            showHelp(LocaleHelper.t(this, "tutorial"), LocaleHelper.t(this, "tutorial_body"))
        }
        binding.cardDonate.setOnClickListener { openPaypal() }
        binding.cardDonate.setOnLongClickListener {
            Toast.makeText(this, LocaleHelper.t(this, "donation_tooltip"), Toast.LENGTH_LONG).show()
            true
        }
        binding.btnOpenWeb.setOnClickListener { openWebView() }
        binding.btnCloseWeb.setOnClickListener { closeWebView() }
        binding.btnSwitchWeb.setOnClickListener { switchWebView() }
        binding.btnBackWeb.setOnClickListener {
            val wv = currentWebView()
            if (wv.canGoBack()) wv.goBack()
            else Toast.makeText(this, LocaleHelper.t(this, "webview_no_back"), Toast.LENGTH_SHORT).show()
        }
    }

    private fun currentWebView(): WebView =
        if (activeWeb == 2) binding.webView2 else binding.webView1

    private fun openWebView() {
        binding.webIdle.visibility = View.GONE
        binding.webActive.visibility = View.VISIBLE
        binding.webControls.visibility = View.VISIBLE
        web1Open = true
        web2Open = true
        activeWeb = 1
        binding.webView1.visibility = View.VISIBLE
        binding.webView2.visibility = View.GONE
        binding.webView1.loadUrl("https://www.wwechampions.com")
        binding.webView2.loadUrl("https://chatgpt.com")
        chatListo = false
        updateSwitchEnabled()
    }

    private fun switchWebView() {
        if (!web1Open || !web2Open) {
            Toast.makeText(this, LocaleHelper.t(this, "switch_need_both"), Toast.LENGTH_SHORT).show()
            return
        }
        if (activeWeb == 1) {
            activeWeb = 2
            binding.webView1.visibility = View.GONE
            binding.webView2.visibility = View.VISIBLE
        } else {
            activeWeb = 1
            binding.webView2.visibility = View.GONE
            binding.webView1.visibility = View.VISIBLE
        }
    }

    private fun closeWebView() {
        val closing = activeWeb
        try {
            currentWebView().stopLoading()
            currentWebView().loadUrl("about:blank")
        } catch (_: Exception) {
        }
        if (closing == 1) {
            web1Open = false
            binding.webView1.visibility = View.GONE
        } else {
            web2Open = false
            binding.webView2.visibility = View.GONE
        }
        when {
            web1Open -> {
                activeWeb = 1
                binding.webView1.visibility = View.VISIBLE
                binding.webView2.visibility = View.GONE
                updateSwitchEnabled()
            }
            web2Open -> {
                activeWeb = 2
                binding.webView2.visibility = View.VISIBLE
                binding.webView1.visibility = View.GONE
                updateSwitchEnabled()
            }
            else -> showWebIdle()
        }
    }

    private fun updateSwitchEnabled() {
        val both = web1Open && web2Open
        binding.btnSwitchWeb.isEnabled = both
        binding.btnSwitchWeb.alpha = if (both) 1f else 0.4f
    }

    private fun showWebIdle() {
        web1Open = false
        web2Open = false
        activeWeb = 1
        binding.webActive.visibility = View.GONE
        binding.webControls.visibility = View.GONE
        binding.webIdle.visibility = View.VISIBLE
        setAnswerState("- - - -", "#FF1744", true)
        try {
            binding.webView1.visibility = View.VISIBLE
            binding.webView2.visibility = View.GONE
        } catch (_: Exception) {
        }
    }

    private fun startAnswerBlink() {
        answerBlink = AlphaAnimation(1f, 0.25f).apply {
            duration = 700
            repeatMode = Animation.REVERSE
            repeatCount = Animation.INFINITE
        }
    }

    private fun applyStrings() {
        binding.tvAppTitle.text = LocaleHelper.t(this, "app_name")
        binding.tvLanguage.text = currentLanguageLabel()
        binding.tvAnswerLabel.text = LocaleHelper.t(this, "answer_label")
        binding.btnOpenWeb.text = LocaleHelper.t(this, "open_webview")
        binding.btnCloseWeb.text = LocaleHelper.t(this, "close")
        binding.btnSwitchWeb.text = LocaleHelper.t(this, "switch_web")
        binding.btnBackWeb.text = LocaleHelper.t(this, "back")
        binding.tvTutorial.text = LocaleHelper.t(this, "tutorial")
        binding.tvDonate.text = LocaleHelper.t(this, "donations")
    }

    private fun showLanguagePicker() {
        val langs = arrayOf("Español", "English", "Português", "Bahasa")
        val codes = arrayOf("es", "en", "pt", "id")
        AlertDialog.Builder(this)
            .setTitle(LocaleHelper.t(this, "language"))
            .setItems(langs) { _, which ->
                LocaleHelper.setLang(this, codes[which])
                applyStrings()
                val current = binding.tvAnswerValue.text?.toString() ?: ""
                if (current.contains("Buscando") || current.contains("Searching") ||
                    current.contains("Mencari")
                ) {
                    setAnswerState(LocaleHelper.t(this, "searching"), "#FFC107", true)
                }
            }
            .show()
    }

    private fun showHelp(title: String, body: String) {
        binding.helpTitle.text = title
        binding.helpBody.text = body
        binding.helpOverlay.visibility = View.VISIBLE
    }

    private fun openPaypal() {
        val url = "https://www.paypal.me/randyrubi"
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            Toast.makeText(this, url, Toast.LENGTH_SHORT).show()
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (::prefs.isInitialized && prefs.isApproved()) {
            val w = resources.displayMetrics.widthPixels.coerceAtLeast(1)
            val edge = w * 0.18f
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    edgeSwipeTracking = ev.x >= (w - edge)
                    edgeSwipeStartX = ev.x
                    edgeSwipeStartY = ev.y
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (edgeSwipeTracking) {
                        val dx = ev.x - edgeSwipeStartX
                        val dy = ev.y - edgeSwipeStartY
                        if (dx < -80 && kotlin.math.abs(dx) > kotlin.math.abs(dy) * 1.1f) {
                            tryOpenAdminPanel()
                        }
                    }
                    edgeSwipeTracking = false
                }
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun tryOpenAdminPanel() {
        Thread {
            val role = try {
                SupabaseBanClient.getUserRole(prefs.getUserUid())
            } catch (_: Exception) {
                prefs.getUserRole()
            }
            if (role.isNotBlank()) {
                prefs.saveUserSession(
                    prefs.getUserUid(), prefs.getUserEmail(), prefs.getUserNombre(),
                    "APPROVED", role
                )
            }
            val isAdmin = role.equals("ADMIN", ignoreCase = true) ||
                    prefs.getUserRole().equals("ADMIN", ignoreCase = true)
            runOnUiThread {
                if (isAdmin) {
                    startActivity(Intent(this, AdminActivity::class.java))
                }
            }
        }.start()
    }

    private fun currentLanguageLabel(): String = when (LocaleHelper.getLang(this)) {
        LocaleHelper.ES -> "Idioma"
        LocaleHelper.PT -> "Idioma"
        LocaleHelper.ID -> "Bahasa"
        else -> "Language"
    }

    private fun showVersionBadge() {
        val ver = try {
            val pi = packageManager.getPackageInfo(packageName, 0)
            pi.versionName ?: "1.0.8"
        } catch (_: Exception) {
            "1.0.8"
        }
        binding.tvVersion.text = if (ver.startsWith("v")) ver else "v$ver"
    }

    companion object {

        /**
         * Inyector basado en la versión antigua que SÍ funcionaba,
         * corregido para funcionar en TODAS las preguntas (1, 2, 3... 100).
         *
         * - Se reinyecta en cada onPageFinished (cada pregunta nueva).
         * - Guarda cuántos mensajes del asistente hay al cargar la página.
         * - Solo envía cuando aparece un mensaje NUEVO del asistente.
         */
        private val CHAT_GPT_INJECTOR = """
            (function(){
                if (window._triviaTimer) clearInterval(window._triviaTimer);

                window.assistantCountPrevio = document.querySelectorAll('div[data-message-author-role="assistant"]').length;
                window.lastAnswerSent = "";

                window._triviaTimer = setInterval(function(){
                    try {
                        var list = document.querySelectorAll('div[data-message-author-role="assistant"]');
                        if (!list || list.length <= window.assistantCountPrevio) return;

                        var last = list[list.length - 1];
                        var raw = (last.innerText || last.textContent || "").trim();
                        if (!raw) return;

                        var firstLine = raw.split(/[\r\n]+/).map(function(l){ return l.trim(); }).filter(function(l){ return l.length > 0; })[0] || "";
                        if (!firstLine || firstLine.length < 2 || firstLine.length > 280) return;

                        if (firstLine === window.lastAnswerSent) return;

                        var low = firstLine.toLowerCase();
                        if (low.indexOf("please answer") !== -1) return;
                        if (low.indexOf("quickly answer") !== -1) return;
                        if (low.indexOf("wwe trivia") !== -1) return;
                        if (low.indexOf("searching") !== -1) return;
                        if (low.indexOf("thinking") !== -1) return;

                        window.lastAnswerSent = firstLine;
                        if (typeof AndroidChatGPT !== "undefined" && AndroidChatGPT.onRespuestaChatGPT) {
                            AndroidChatGPT.onRespuestaChatGPT(firstLine);
                        }
                    } catch (e) {}
                }, 800);
            })();
        """.trimIndent()

        private val WWE_HOOK_INJECTOR = """
            (function(){
                if (window.hackTrivia) return;
                window.hackTrivia = true;

                var origOpen = XMLHttpRequest.prototype.open;
                var origSend = XMLHttpRequest.prototype.send;

                XMLHttpRequest.prototype.open = function(m, u) {
                    this._url = u ? u.toString() : "";
                    return origOpen.apply(this, arguments);
                };

                XMLHttpRequest.prototype.send = function(body) {
                    var xhr = this;
                    xhr.addEventListener("load", function() {
                        try {
                            if (!xhr._url || xhr._url.indexOf("question") === -1) return;
                            if (xhr._url.indexOf("gameId=") === -1) return;

                            var json = JSON.parse(xhr.responseText);
                            var d = json.data || json;
                            if (!d || !d.options) return;

                            var opts = [];
                            for (var i = 0; i < d.options.length; i++) {
                                var o = d.options[i].option || d.options[i].text || d.options[i] || "";
                                if (typeof o === "string" && o.trim().length > 0) {
                                    opts.push(o.trim());
                                }
                            }

                            var payload = JSON.stringify({
                                question: (d.question || "").trim(),
                                options: opts
                            });

                            if (typeof AndroidChatGPT !== "undefined" && AndroidChatGPT.onPreguntaCapturada) {
                                AndroidChatGPT.onPreguntaCapturada(payload);
                            }
                        } catch (e) {}
                    });
                    return origSend.apply(this, arguments);
                };
            })();
        """.trimIndent()
    }
}
